@echo off
cd /d "%~dp0"
title CyberBuddy Classic Proxy 6.1 - EXACT 2013 FORECAST

echo ============================================================
echo CyberBuddy Classic Proxy 6.1 - EXACT 2013 FORECAST
echo ============================================================
echo.
echo IMPORTANT: Close any older CyberBuddy proxy window first.
echo This version must own port 8081 to show the corrected page.
echo.
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 proxy.py
) else (
  python proxy.py
)
echo.
echo The proxy stopped or encountered an error.
pause
