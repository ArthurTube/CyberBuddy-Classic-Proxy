@echo off
setlocal
set /p "LOCAL=Enter a city, ZIP code, or airport: "
if not defined LOCAL exit /b 1
powershell -NoProfile -ExecutionPolicy Bypass -Command "$v=[uri]::EscapeDataString($env:LOCAL); Start-Process ('http://weather.unisys.com/forecast.cgi/' + $v)"
endlocal
