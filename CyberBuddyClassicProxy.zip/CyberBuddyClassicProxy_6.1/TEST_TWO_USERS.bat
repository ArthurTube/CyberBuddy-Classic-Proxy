@echo off
echo CyberBuddy Classic Proxy 6.1 - two-user test
echo.
echo 1. Start START_PROXY.bat on the server computer.
echo 2. On two separate CyberBuddy clients, configure the SAME server host.
echo 3. Publish a different real UIN from each client.
echo 4. Open the UIN Directory from both clients.
echo 5. Confirm each client sees the other UIN.
echo 6. Add the other UIN to the Contact List.
echo 7. Confirm both users show ONLINE.
echo 8. Send a message in each direction.
echo 9. Restart the proxy and verify the live directory persists.
echo.
echo This test does not create fake/historical users.
pause
