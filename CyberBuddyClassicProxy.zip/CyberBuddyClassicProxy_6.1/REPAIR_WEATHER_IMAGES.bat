@echo off
cd /d "%~dp0"
title Unisys Weather - Restore missing archived images
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 repair_mirror_images.py
) else (
  python repair_mirror_images.py
)
echo.
echo Report: weather_site\MIRROR_STATUS.txt
pause
