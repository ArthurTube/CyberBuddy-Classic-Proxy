#!/usr/bin/env python3
"""Try alternate Wayback image captures for missing local mirror images."""
from html.parser import HTMLParser
from pathlib import Path
import argparse
import time
import urllib.error
import urllib.parse
import urllib.request

ROOT = Path(__file__).resolve().parent / 'weather_site'
STAMP = '20130124124126'
EXTENSIONS = {'.gif', '.jpg', '.jpeg', '.png', '.webp'}
MAGIC = {
    '.gif': lambda b: b.startswith((b'GIF87a', b'GIF89a')),
    '.jpg': lambda b: b.startswith(b'\xff\xd8\xff'),
    '.jpeg': lambda b: b.startswith(b'\xff\xd8\xff'),
    '.png': lambda b: b.startswith(b'\x89PNG\r\n\x1a\n'),
    '.webp': lambda b: b.startswith(b'RIFF') and b[8:12] == b'WEBP',
}

class ImageRefs(HTMLParser):
    def __init__(self):
        super().__init__()
        self.urls = set()

    def handle_starttag(self, tag, attributes):
        if tag.lower() != 'img':
            return
        src = dict(attributes).get('src', '')
        if src.startswith('/') and not src.startswith('//'):
            self.urls.add(urllib.parse.urlsplit(src).path)


def missing_images():
    missing = set()
    for page in ROOT.rglob('*'):
        if page.suffix.lower() not in {'.php', '.htm', '.html'} or not page.is_file():
            continue
        parser = ImageRefs()
        parser.feed(page.read_text(encoding='utf-8', errors='replace'))
        for url in parser.urls:
            dest = (ROOT / urllib.parse.unquote(url).lstrip('/')).resolve()
            if dest.suffix.lower() in EXTENSIONS and dest.is_relative_to(ROOT.resolve()) and not dest.is_file():
                missing.add((url, dest))
    return sorted(missing, key=lambda pair: pair[0])


def fetch(url, extension):
    req = urllib.request.Request(url, headers={'User-Agent': 'CyberBuddyClassicProxy-ImageRepair/5.5.55'})
    with urllib.request.urlopen(req, timeout=12) as response:
        if urllib.parse.urlsplit(response.geturl()).hostname != 'web.archive.org':
            raise ValueError('unexpected redirect')
        image = response.read(4 * 1024 * 1024 + 1)
    if len(image) > 4 * 1024 * 1024 or not MAGIC[extension](image):
        raise ValueError('archive response was not the requested image format')
    return image


def main():
    arguments = argparse.ArgumentParser(description=__doc__)
    arguments.add_argument('--limit', type=int, default=0, help='maximum number of missing images to attempt')
    args = arguments.parse_args()
    missing = missing_images()
    recovered = []
    failed = []
    for index, (url, dest) in enumerate(missing[:args.limit or None], 1):
        origin = 'http://weather.unisys.com' + urllib.parse.quote(url, safe='/')
        errors = []
        for modifier in ('id_', 'im_'):
            try:
                data = fetch(f'https://web.archive.org/web/{STAMP}{modifier}/{origin}', dest.suffix.lower())
                dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_bytes(data)
                recovered.append(url)
                print(f'[{index}/{len(missing)}] recovered {url} ({len(data)} bytes)', flush=True)
                break
            except (OSError, ValueError, urllib.error.HTTPError) as error:
                errors.append(str(error))
        else:
            failed.append(url)
            print(f'[{index}/{len(missing)}] unavailable {url}: {errors[-1]}', flush=True)
        time.sleep(0.3)
    remaining = missing_images()
    report = (f'Missing before: {len(missing)}\nRecovered this run: {len(recovered)}\n'
              f'Still missing: {len(remaining)}\n'
              'The mirror is historical. Missing archive images are never marked as current.\n'
              '\nMissing image paths:\n' + '\n'.join(url for url, _ in remaining) + '\n')
    (ROOT / 'MIRROR_STATUS.txt').write_text(report, encoding='utf-8')
    print(f'\nReport: {ROOT / "MIRROR_STATUS.txt"}', flush=True)

if __name__ == '__main__':
    main()
