@echo off
title Restore Internet - CyberBuddy Classic Proxy 2.7
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Internet Settings" /v ProxyEnable /t REG_DWORD /d 0 /f >nul
echo.
echo Windows proxy disabled. Your Internet connection is direct again.
echo Restart your web browsers.
echo.
pause
