@echo off
title Enable CyberBuddy Classic Proxy 2.9
echo.
echo This sets the HTTP and HTTPS proxy for your Windows account to 127.0.0.1:8081.
echo Keep START_PROXY.bat open while the proxy is enabled.
echo.
pause
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Internet Settings" /v ProxyEnable /t REG_DWORD /d 1 /f >nul
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Internet Settings" /v ProxyServer /t REG_SZ /d "http=127.0.0.1:8081;https=127.0.0.1:8081" /f >nul
reg add "HKCU\Software\Microsoft\Windows\CurrentVersion\Internet Settings" /v ProxyOverride /t REG_SZ /d "localhost;127.*;<local>" /f >nul
echo.
echo Proxy enabled. Restart CyberBuddy.
echo To restore the original Internet connection, run RESTORE_INTERNET.bat.
echo.
pause
