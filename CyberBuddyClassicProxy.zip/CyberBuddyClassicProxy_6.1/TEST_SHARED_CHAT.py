import http.client

def req(path, body=None):
    c=http.client.HTTPConnection("127.0.0.1", 8081, timeout=5)
    headers={"Content-Type":"application/x-www-form-urlencoded"} if body else {}
    c.request("POST" if body else "GET", path, body, headers)
    r=c.getresponse(); data=r.read(); c.close()
    return r.status, data.decode("cp1252", "replace")

req("/cgi-bin/uinlister.exe?Y422643&ArthurTube&Hello")
req("/cgi-bin/uinlister.exe?Y123456&Friend&Hi")
status, directory = req("/cgi-bin/uinlister.exe?A")
assert "ArthurTube" in directory and "Friend" in directory
status, _ = req("/cgi-bin/cbonline2.exe", "uin=422643&sendto=123456&message=Hello+Friend")
assert status == 200
status, received = req("/cgi-bin/cbonline2.exe", "uin=123456&action=poll")
assert "Hello Friend" in received
status, _ = req("/cgi-bin/cbonline2.exe", "uin=123456&sendto=422643&message=Hi+Arthur")
assert status == 200
status, received = req("/cgi-bin/cbonline2.exe", "uin=422643&action=poll")
assert "Hi Arthur" in received
print("TWO-USER SHARED CHAT TEST: PASS")
