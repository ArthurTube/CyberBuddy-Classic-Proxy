@echo off
title Web Watching Test - CyberBuddy Classic Proxy 5.5.2
echo.
echo Testing the compatible news page...
echo.
powershell -NoProfile -Command "try { $r = Invoke-WebRequest -UseBasicParsing -Proxy 'http://127.0.0.1:8081' -Uri 'http://proxy.local/news' -TimeoutSec 60; Write-Host ('OK - HTTP ' + [int]$r.StatusCode); Write-Host ('Size: ' + $r.RawContentLength + ' bytes'); if ($r.Content -match 'FOX News headlines') { Write-Host 'News page ready for Web Watching.' } else { Write-Host 'WARNING: unexpected response.' } } catch { Write-Host ('ERROR: ' + $_.Exception.Message); exit 1 }"
echo.
echo In the Web Watching Wizard, add:
echo http://proxy.local/news
echo.
pause
