@echo off
cd /d "%~dp0"
echo Keep the proxy running in another window.
echo.
powershell -NoProfile -Command "$p=Test-NetConnection 127.0.0.1 -Port 110 -WarningAction SilentlyContinue; if($p.TcpTestSucceeded){Write-Host 'POP3 local port 110: OK' -ForegroundColor Green}else{Write-Host 'POP3 local port 110: FAILED' -ForegroundColor Red}"
powershell -NoProfile -Command "$p=Test-NetConnection 127.0.0.1 -Port 25 -WarningAction SilentlyContinue; if($p.TcpTestSucceeded){Write-Host 'SMTP local port 25: OK' -ForegroundColor Green}else{Write-Host 'SMTP local port 25: FAILED' -ForegroundColor Red}"
echo.
echo This checks the local bridges. Gmail login still requires a Google app password.
pause
