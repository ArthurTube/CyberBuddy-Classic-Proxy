#!/usr/bin/env python3
"""Create a polite local mirror of the Jan-24-2013 Unisys Weather site.
Downloads HTML plus recursively referenced CSS/JS/images/fonts/media from Wayback.
"""
from pathlib import Path
from html.parser import HTMLParser
import hashlib, mimetypes, re, time, urllib.parse, urllib.request

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'weather_site'
STAMP = '20130124124126id_'
HOSTS = {'weather.unisys.com', 'www.weather.unisys.com'}
SEEDS = [
'http://weather.unisys.com/index.php','http://weather.unisys.com/solutions/index.php',
'http://weather.unisys.com/mobile/index.php','http://weather.unisys.com/info/index.php',
'http://weather.unisys.com/content.php','http://weather.unisys.com/analyses.php',
'http://weather.unisys.com/satellite/index.php','http://weather.unisys.com/surface/index.php',
'http://weather.unisys.com/upper_air/index.php','http://weather.unisys.com/radar/index.php',
'http://weather.unisys.com/forehome.php','http://weather.unisys.com/foresetup.php',
'http://weather.unisys.com/mos/index.php','http://weather.unisys.com/nam/index.php',
'http://weather.unisys.com/gfs/index.php?r=us','http://weather.unisys.com/gfsx/index.php?r=us',
'http://weather.unisys.com/rap/index.php','http://weather.unisys.com/ecmwf/index.php',
'http://weather.unisys.com/archives.php','http://weather.unisys.com/hurricane/index.php',
'http://weather.unisys.com/archive/index.php','http://weather.unisys.com/usgs/index.php',
'http://weather.unisys.com/links.php','http://weather.unisys.com/overview.php',
'http://weather.unisys.com/contactus.php']
MAX_FILES = 2500
ASSET_EXTS = {'.css','.js','.gif','.jpg','.jpeg','.png','.webp','.svg','.ico','.bmp','.tif','.tiff',
              '.woff','.woff2','.ttf','.eot','.mp4','.webm','.xml','.txt'}

WAYBACK_RE = re.compile(r'^https?://web\.archive\.org/web/(?:\d{1,14}(?:id_|im_|js_|cs_)?/)?(https?://.+)$', re.I)

class Links(HTMLParser):
    def __init__(self):
        super().__init__(); self.urls=[]
    def handle_starttag(self, tag, attrs):
        for k,v in attrs:
            if not v: continue
            k=k.lower()
            if k in ('href','src','background','action','poster','data-src','data-original'):
                self.urls.append(v)
            elif k == 'srcset':
                for item in v.split(','):
                    candidate=item.strip().split()[0] if item.strip() else ''
                    if candidate: self.urls.append(candidate)
            elif k == 'style':
                self.urls.extend(css_urls(v))


def css_urls(text):
    out=[]
    for m in re.finditer(r'(?is)url\(\s*(["\']?)(.*?)\1\s*\)', text):
        if m.group(2): out.append(m.group(2).strip())
    for m in re.finditer(r'(?is)@import\s+(?:url\()?\s*["\']([^"\']+)', text):
        out.append(m.group(1).strip())
    return out


def unwrap_wayback(raw):
    raw=raw.replace('&amp;','&')
    m=WAYBACK_RE.match(raw)
    return m.group(1) if m else raw


def normalize(base, raw):
    if not raw: return None
    raw=unwrap_wayback(raw.strip())
    if raw.startswith(('#','javascript:','mailto:','data:','about:','tel:')): return None
    a=urllib.parse.urljoin(base, raw)
    u=urllib.parse.urlsplit(a)
    if u.scheme not in ('http','https') or (u.hostname or '').lower() not in HOSTS: return None
    return urllib.parse.urlunsplit(('http', 'weather.unisys.com', u.path or '/', u.query, ''))


def local_path(url):
    u=urllib.parse.urlsplit(url)
    path=urllib.parse.unquote(u.path or '/index.php')
    if path.endswith('/'): path += 'index.php'
    rel=path.lstrip('/') or 'index.php'
    dest=OUT/rel
    # Static resources with meaningful query variants get unique files; PHP/HTML pages retain classic names.
    if u.query and dest.suffix.lower() in ASSET_EXTS:
        h=hashlib.sha1(u.query.encode('utf-8')).hexdigest()[:10]
        dest=dest.with_name(dest.stem+'__q_'+h+dest.suffix)
    return dest


def local_url(url):
    dest=local_path(url)
    rel='/' + dest.relative_to(OUT).as_posix()
    u=urllib.parse.urlsplit(url)
    if u.query and dest.suffix.lower() not in ASSET_EXTS:
        rel += '?' + u.query
    return rel


def rewrite_refs(text, base, is_css=False):
    if is_css:
        def css_repl(m):
            q=m.group(1) or ''
            raw=m.group(2).strip()
            a=normalize(base, raw)
            return 'url('+q+(local_url(a) if a else raw)+q+')'
        text=re.sub(r'(?is)url\(\s*(["\']?)(.*?)\1\s*\)', css_repl, text)
        return text

    attr_re=re.compile(r'(?is)(\b(?:href|src|background|action|poster|data-src|data-original)\s*=\s*)(["\'])(.*?)\2')
    def attr_repl(m):
        a=normalize(base,m.group(3))
        return m.group(1)+m.group(2)+(local_url(a) if a else m.group(3))+m.group(2)
    text=attr_re.sub(attr_repl,text)

    def srcset_repl(m):
        q=m.group(2); parts=[]
        for item in m.group(3).split(','):
            bits=item.strip().split()
            if not bits: continue
            a=normalize(base,bits[0]); bits[0]=local_url(a) if a else bits[0]
            parts.append(' '.join(bits))
        return m.group(1)+q+', '.join(parts)+q
    text=re.sub(r'(?is)(\bsrcset\s*=\s*)(["\'])(.*?)\2',srcset_repl,text)
    return text


def get(url):
    archived='https://web.archive.org/web/'+STAMP+'/'+url
    req=urllib.request.Request(archived,headers={'User-Agent':'CyberBuddyClassicProxy-Mirror/5.5.54 (personal archival use)'})
    last=None
    for attempt in range(5):
        try:
            with urllib.request.urlopen(req,timeout=40) as r:
                return r.read(20*1024*1024), r.headers.get('Content-Type','application/octet-stream')
        except Exception as e:
            last=e; time.sleep(min(12,2*(attempt+1)))
    raise last


def decode(data):
    for enc in ('utf-8','cp1252','latin-1'):
        try: return data.decode(enc)
        except UnicodeDecodeError: pass
    return data.decode('utf-8','replace')


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    queue=list(SEEDS); queued=set(queue); seen=set(); ok=fail=assets=0
    while queue and len(seen)<MAX_FILES:
        url=queue.pop(0); queued.discard(url)
        if url in seen: continue
        seen.add(url); dest=local_path(url)
        print(f'[{len(seen):04d}] {url}')
        try: data,ctype=get(url)
        except Exception as e:
            print('       unavailable:',e); fail+=1; continue
        ctype=(ctype or '').lower(); suffix=dest.suffix.lower()
        textual=('html' in ctype or 'css' in ctype or 'javascript' in ctype or 'text/' in ctype or suffix in {'.php','.html','.htm','.css','.js','.xml','.txt',''})
        if textual:
            text=decode(data)
            discovered=[]
            is_css=('css' in ctype or suffix=='.css')
            if is_css:
                discovered=css_urls(text)
            elif 'html' in ctype or suffix in {'.php','.html','.htm',''}:
                parser=Links()
                try: parser.feed(text)
                except Exception: pass
                discovered.extend(parser.urls)
                # CSS URLs inside <style> blocks.
                for block in re.findall(r'(?is)<style\b[^>]*>(.*?)</style>',text): discovered.extend(css_urls(block))
            for raw in discovered:
                a=normalize(url,raw)
                if a and a not in seen and a not in queued and len(seen)+len(queue)<MAX_FILES:
                    queue.append(a); queued.add(a)
            text=rewrite_refs(text,url,is_css=is_css)
            data=text.encode('utf-8')
        else:
            assets+=1
        dest.parent.mkdir(parents=True,exist_ok=True); dest.write_bytes(data); ok+=1
        print(f'       saved -> {dest.relative_to(ROOT)} ({len(data):,} bytes)')
        time.sleep(0.75)
    status=(f'Downloaded: {ok}\nStatic/binary assets: {assets}\nUnavailable: {fail}\nAttempted: {len(seen)}\n'
            f'Queue remaining: {len(queue)}\nLimit: {MAX_FILES}\n')
    (OUT/'MIRROR_STATUS.txt').write_text(status,encoding='utf-8')
    print('\nFinished.\n'+status+'Files: '+str(OUT))

if __name__=='__main__': main()
