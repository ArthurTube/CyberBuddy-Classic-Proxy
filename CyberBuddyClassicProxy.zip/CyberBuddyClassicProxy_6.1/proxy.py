#!/usr/bin/env python3
"""CyberBuddy Classic Proxy - HTTP bridge for legacy Windows software."""

from __future__ import annotations
SHARED_SERVER_HOST = "127.0.0.1"
SHARED_SERVER_PORT = 8081

import os

import configparser
import csv
import math
import datetime
import base64
import email.header
import email.parser
import email.policy
import gzip
import hashlib
import http.client
import html
from html.parser import HTMLParser
import io
import json
import logging
import re
import random
import select
import socket
import socketserver
import smtplib
import ssl
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import unicodedata
import xml.etree.ElementTree as ET
import zlib
from pathlib import Path


APP_NAME = "CyberBuddy Classic Proxy"
APP_VERSION = "6.1"
ROOT = Path(__file__).resolve().parent
CONFIG_PATH = ROOT / "proxy.ini"
LOG_PATH = ROOT / "proxy.log"
WEATHER_ASSETS = ROOT / "weather_assets"
WEATHER_SITE = ROOT / "weather_site"
MODEL_IMAGES = {}
MODEL_IMAGES_LOCK = threading.Lock()
WEATHER_CACHE = {}
GEOCODE_CACHE = {}
INMET_ALERT_CACHE = {}
WEATHER_LOCK = threading.RLock()
WEATHER_COOLDOWN_UNTIL = 0.0

# Experimental local replacement for CyberBuddy's retired UIN/chat service.
# Nothing is forwarded to the historical public endpoints.
CHAT_LOCK = threading.RLock()
CHAT_USERS = {}       # uin -> {name, comments, last_seen}
CHAT_QUEUES = {}      # uin -> [{from_uin, from_name, text, when}]
CHAT_LAST_TARGET = {}
UIN_DIRECTORY_MAX = 200
  # last successful G recipient lookup

def _chat_fields(pairs):
    return {str(k).strip().lower(): str(v) for k, v in pairs}

def _chat_pick(fields, *names):
    for name in names:
        v = fields.get(name.lower(), '').strip()
        if v:
            return v
    return ''

def _chat_safe_uin(value):
    value = re.sub(r'[^0-9A-Za-z_.-]', '', value or '')[:64]
    return value



CHAT_DIRECTORY_STATE_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'chat_directory_2026.json')

def _chat_directory_load_state():
    try:
        with open(CHAT_DIRECTORY_STATE_FILE, 'r', encoding='utf-8') as f:
            saved = json.load(f)
        if not isinstance(saved, dict):
            return
        with CHAT_LOCK:
            for uin, info in saved.items():
                if not isinstance(info, dict):
                    continue
                cur = CHAT_USERS.get(str(uin), {})
                cur.update({
                    'name': str(info.get('name','')),
                    'comments': str(info.get('comments','')),
                    'last_seen': int(info.get('last_seen',0) or 0),
                    'published': bool(info.get('published',False)),
                    'archived': bool(info.get('archived',False)),
                })
                CHAT_USERS[str(uin)] = cur
    except Exception:
        pass

def _chat_directory_save_state():
    try:
        with CHAT_LOCK:
            saved = {}
            for uin, info in CHAT_USERS.items():
                if info.get('published'):
                    saved[str(uin)] = {
                        'name': info.get('name',''),
                        'comments': info.get('comments',''),
                        'last_seen': int(info.get('last_seen',0) or 0),
                        'published': True,
                        'archived': bool(info.get('archived',False)),
                    }
        tmp = CHAT_DIRECTORY_STATE_FILE + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(saved, f, ensure_ascii=False, indent=2)
        os.replace(tmp, CHAT_DIRECTORY_STATE_FILE)
    except Exception:
        pass


# Live/published UIN state is intentionally persistent across proxy restarts.
# The archived historical directory remains separate from this state.

def _invitebuddy_html(message=""):
    try:
        raw=open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "page18_original.html"), "rb").read()
        raw=raw.replace(b"http://thecyberbuddy.com/cgi-bin/invitebuddy.exe", b"/cgi-bin/invitebuddy.exe")
        if not message: return raw
    except Exception: raw=b""
    import html as _html
    msg=_html.escape(message).encode("windows-1252","replace")
    if raw and b"</form>" in raw: return raw.replace(b"</form>", b"<p><b>"+msg+b"</b></p></form>", 1)
    return b"<html><body><h2>Invite a Buddy</h2><p><b>"+msg+b"</b></p></body></html>"

def _invitebuddy_result_page(filename, fallback_message):
    """Serve the preserved original invitebuddy result page when available."""
    try:
        path = os.path.join(os.path.dirname(os.path.abspath(__file__)), filename)
        with open(path, 'rb') as f:
            raw = f.read()
        # Keep the historical page appearance, but make its Back link stay on
        # the restored local Page 18 instead of leaving for the dead website.
        raw = raw.replace(b'http://thecyberbuddy.com/', b'/page18.html')
        return raw
    except Exception as error:
        log.warning('INVITE BUDDY: could not load %s: %s', filename, error)
        return _invitebuddy_html(fallback_message)

def _invitebuddy_response(fields):
    fromname = str(fields.get('fromname') or fields.get('yourname') or '').strip()
    fromemail = str(fields.get('fromemail') or fields.get('youremail') or '').strip()
    toname = str(fields.get('toname') or fields.get('buddyname') or '').strip()
    sendto = str(fields.get('sendto') or fields.get('buddyemail') or '').strip()
    uin = _chat_safe_uin(str(fields.get('uin','')))
    comments = str(fields.get('comments','')).strip()
    log.warning('INVITE BUDDY: form received required_fields=%s uin=%s message_bytes=%d',
                'yes' if bool(fromname and fromemail and toname and sendto) else 'no',
                'yes' if bool(uin) else 'no', len(comments.encode('utf-8','replace')))

    if not fromname or not fromemail or not toname or not sendto:
        log.warning('INVITE BUDDY: validation failed missing_required_fields=yes')
        return _invitebuddy_result_page("error.html", "Required Information is missing.")
    log.warning('INVITE BUDDY: validation passed')

    # Basic header-injection protection for this old web form.
    if any(('\r' in v or '\n' in v) for v in (fromname, fromemail, toname, sendto)):
        return _invitebuddy_result_page("error.html", "Required Information is missing.")

    # Reuse the temporary Gmail/App-Password credentials already captured by
    # CyberBuddy's restored POP3/SMTP bridge. They remain process-memory only.
    try:
        with MAIL_CREDENTIALS_LOCK:
            username = MAIL_CREDENTIALS.get('username')
            password = MAIL_CREDENTIALS.get('password')
    except Exception as error:
        log.exception('INVITE BUDDY: credential bridge error: %s', error)
        return _invitebuddy_html('Your invitation form is complete, but the e-mail credential bridge failed. Check proxy.log.')
    if not username or not password:
        username, password = _load_mail_credentials()
        if username and password:
            with MAIL_CREDENTIALS_LOCK:
                MAIL_CREDENTIALS["username"] = username
                MAIL_CREDENTIALS["password"] = password
            log.warning("INVITE BUDDY: restored cached mail credentials")

    log.warning('INVITE BUDDY: mail credentials available=%s', 'yes' if bool(username and password) else 'no')

    if not username or not password:
        log.error('INVITE BUDDY: SMTP credentials unavailable; form itself was valid')
        return _invitebuddy_html(
            'Your invitation form is complete, but no outgoing e-mail account has been configured yet. '
            'Configure CyberBuddy e-mail once; Invite Your Buddy will remember it afterward.'
        )

    subject = 'CyberBuddy invitation from %s' % fromname
    body = (
        'Hello %s,\r\n\r\n'
        '%s\r\n\r\n'
        'From: %s <%s>\r\n'
        '%s'
    ) % (
        toname,
        comments or 'I found this great program called CyberBuddy.',
        fromname,
        fromemail,
        ('CyberBuddy UIN: %s\r\n' % uin) if uin else ''
    )

    # Send through the same authenticated SMTP service configured for the
    # restored CyberBuddy mail bridge. The authenticated account is the SMTP
    # envelope sender; the historical form address is kept as Reply-To.
    msg = (
        'From: "%s" <%s>\r\n'
        'Reply-To: %s\r\n'
        'To: "%s" <%s>\r\n'
        'Subject: %s\r\n'
        'MIME-Version: 1.0\r\n'
        'Content-Type: text/plain; charset=utf-8\r\n'
        'Content-Transfer-Encoding: 8bit\r\n'
        '\r\n%s'
    ) % (fromname.replace('"',''), username, fromemail, toname.replace('"',''),
         sendto, subject, body)

    try:
        log.warning('INVITE BUDDY: SMTP connecting host=%s port=%s', SMTP_REMOTE_HOST, SMTP_REMOTE_PORT)
        with smtplib.SMTP_SSL(
            SMTP_REMOTE_HOST, SMTP_REMOTE_PORT, timeout=TIMEOUT, context=tls_context()
        ) as smtp:
            log.warning('INVITE BUDDY: SMTP connected; authenticating')
            smtp.login(username, password)
            log.warning('INVITE BUDDY: SMTP authenticated; sending invitation')
            refused = smtp.sendmail(username, [sendto], msg.encode('utf-8'))
            if refused:
                raise RuntimeError('SMTP recipient refused')
            log.warning('INVITE BUDDY: SMTP accepted invitation for delivery')

        try:
            path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'invitebuddy_2026.log')
            with open(path, 'a', encoding='utf-8') as f:
                f.write('%s | DELIVERED | from=%s <%s> | to=%s <%s> | uin=%s\n' %
                        (time.strftime('%Y-%m-%d %H:%M:%S'), fromname, fromemail,
                         toname, sendto, uin))
        except Exception:
            pass

        log.info('INVITE BUDDY: email delivered through configured SMTP bridge to %s', sendto)
        return _invitebuddy_result_page("complete.html", "Your Invitation Has Been Sent!")

    except smtplib.SMTPAuthenticationError:
        log.error('INVITE BUDDY: SMTP authentication failed')
        return _invitebuddy_html(
            'Your invitation form is complete, but SMTP authentication failed. '
            'Check the e-mail/app password and try again.'
        )
    except Exception as error:
        log.error('INVITE BUDDY: SMTP delivery failed: %s', error)
        return _invitebuddy_html(
            'Your invitation form is complete, but e-mail delivery failed. '
            'Check proxy.log for the SMTP error and try again.'
        )



def _invitebuddy_safe_response(fields):
    try:
        return _invitebuddy_response(fields)
    except Exception as error:
        log.exception('INVITE BUDDY: unhandled server error: %s', error)
        return _invitebuddy_html(
            'Your invitation form was received, but the restored Invite a Buddy server encountered an error. Check proxy.log.'
        )

def _chat_directory_html():
    import html as _html
    now = int(time.time())
    live = []
    with CHAT_LOCK:
        for uin, info in CHAT_USERS.items():
            if not info.get('published'):
                continue
            last = int(info.get('last_seen',0) or 0)
            live.append((info.get('name','') or ('UIN '+uin), str(uin),
                         info.get('comments',''), max(0, now-last) if last else 0))
    live.sort(key=lambda r:r[3])

    def age(sec):
        if sec < 60: return '%d Secs' % sec
        if sec < 3600: return '%d Mins' % (sec//60)
        if sec < 86400:
            return '%d Hrs %d Mins' % (sec//3600, (sec%3600)//60)
        return '%d Days %d Hrs %d Mins' % (sec//86400, (sec%86400)//3600, (sec%3600)//60)

    rows=[]
    for n,u,c,a in live[:200]:
        rows.append('<tr><td>%s</td><td><a href="/cgi-bin/uinlister.exe?u%s">%s</a></td><td>%s</td><td>%s</td></tr>' %
                    (_html.escape(n),_html.escape(u),_html.escape(u),_html.escape(c),_html.escape(age(a))))
    if not rows:
        rows.append('<tr><td colspan="4"><i>No CyberBuddies have published their UIN on this server yet.</i></td></tr>')

    page = ('<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 3.2 Final//EN"><html><head>'
            '<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">'
            '<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate">'
            '<meta http-equiv="Pragma" content="no-cache"><meta http-equiv="Expires" content="0">'
            '<meta http-equiv="refresh" content="15">'
            '<title>CyberBuddy UIN Directory</title></head>'
            '<body bgcolor="#FFE8C4" link="#0000FF" vlink="#FF00FF" text="#4040FF">'
            '<center><font size="+3"><b>CyberBuddy UIN Directory</b></font></center><p>'
            'This is a list of the last 200 CyberBuddies that have gone online and have selected to publish their UIN.<br><small>Maximum: 200 entries. This directory contains CyberBuddies that have published their UIN to this server.</small> '
            'It is computer generated and updated constantly. To contact someone, put their UIN in the designated box on the "Send" section of CyberBuddy. '
            'If you have CyberBuddy version 2.09.06 or greater, just click on the UIN of the person in the list. '
            'To put an icon in your listing see the "Advanced" Section.<p>'
            '<table border="1" cellpadding="3" cellspacing="0"><tr><td><b>Name</b></td><td><b>UIN</b></td>'
            '<td><b>Comments</b></td><td><b>Since Last On</b></td></tr>' + ''.join(rows) + '</table><p>'
            'CyberBuddy UIN List Generator by John DeFino</body></html>')
    return page.encode('windows-1252','replace')

def _chat_uin_contact_html(selected_uin):
    """Render the original-style UIN-to-contact-list page for ?u<UIN>."""
    import html as _html
    selected_uin = _chat_safe_uin(str(selected_uin or ''))
    if not selected_uin:
        return b''
    now = int(time.time())
    name = ''
    comments = ''
    last_on = 'Unknown'
    with CHAT_LOCK:
        info = CHAT_USERS.get(selected_uin, {})
        if info:
            name = info.get('name','') or ('UIN ' + selected_uin)
            comments = info.get('comments','') or ''
            last = int(info.get('last_seen',0) or 0)
            if last:
                sec = max(0, now-last)
                if sec < 60: last_on = '%d Secs' % sec
                elif sec < 3600: last_on = '%d Mins' % (sec//60)
                elif sec < 86400: last_on = '%d Hrs %d Mins' % (sec//3600, (sec%3600)//60)
                else: last_on = '%d Days %d Hrs %d Mins' % (sec//86400, (sec%86400)//3600, (sec%3600)//60)
    if not name:
        name = 'UIN ' + selected_uin

    page = ('<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 3.2 Final//EN"><html><head>'
            '<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">'
            '<meta name="Generator" content="CyberBuddy UIN Lister by John DeFino"></head>'
            '<body bgcolor="#FFE8C4" link="0000FF" vlink="#FF00FF" text="#4040FF">'
            '<center><table border="1" bgcolor="0000FF"><tr><td><font size="+2" face="Comic Sans MS" color="#FFFF00"> CyberBuddy UIN to Contact List </font></td></tr></table></center><p><br>'
            '<font size="3">If you have CyberBuddy Rev 2.09.06 or above, and Internet Explorer, click the button below to put this person on your contact list. '
            'The contact list is on the "Send" tab of CyberBuddy.<br><br><br></font>'
            '<center><font size="3"><table border="1" cellpadding="3">'
            '<tr><td><b>UIN:</b> %s</td></tr><tr><td><b> Name:</b> %s</td></tr>'
            '<tr><td><b>Comments:</b> %s</td></tr><tr><td><b>Last On:</b> %s </td></tr></table>'
            '<br><br><br><form action="/cgi-bin/UIN/%s.cbb" method="get">'
            '<input value="Send to Contact List" type="submit"></form><br><br><br><br>'
            '<form action="/cgi-bin/uinlister.exe" method="get"><input name="a" type="hidden">'
            '<input value="Back to List" type="submit"></form><br><br><br><br></font></center>'
            '<font size="3"><br><br><br><p></p><center><font size="-2">CyberBuddy UIN List Generator by John DeFino</font></center></font></body></html>') % (
                _html.escape(selected_uin), _html.escape(name), _html.escape(comments),
                _html.escape(last_on), _html.escape(selected_uin))
    return page.encode('windows-1252','replace')


def _chat_uin_cbb(selected_uin):
    """Original .cbb contact payload, verified from archived UIN 1111.cbb."""
    selected_uin = _chat_safe_uin(str(selected_uin or ''))
    return (('$$UIN%s\r\n' % selected_uin).encode('ascii')) if selected_uin else b''


def _chat_directory_refresh_login(fields):
    """Refresh presence for the same UIN already published in UINlister."""
    if str(fields.get('action','')).upper() != 'L':
        return
    uin = _chat_safe_uin(str(fields.get('uin','')))
    if not uin:
        return
    changed = False
    with CHAT_LOCK:
        info = CHAT_USERS.get(uin)
        if info and info.get('published'):
            info['last_seen'] = int(time.time())
            if fields.get('name'):
                info['name'] = str(fields.get('name'))
            CHAT_USERS[uin] = info
            changed = True
    if changed:
        _chat_directory_save_state()

def _chat_legacy_response(fields, endpoint):
    _chat_directory_refresh_login(fields)
    """Best-effort local implementation of the retired CyberBuddy UIN service."""
    now = int(time.time())
    uin = _chat_safe_uin(_chat_pick(fields, 'uin','myuin','fromuin','senderuin','userid','user'))
    dest = _chat_safe_uin(_chat_pick(fields, 'sndto','sendto','touin','destuin','targetuin','recipientuin','to'))
    name = _chat_pick(fields, 'name','nickname','nick','myname','fromname','sender')[:80]
    comments = _chat_pick(fields, 'comments','comment')[:240]
    message = _chat_pick(fields, 'message','msg','text','chat','body')[:4000]
    action = _chat_pick(fields, 'action','cmd','command','mode','request').lower()

    with CHAT_LOCK:
        if uin:
            old = CHAT_USERS.get(uin, {})
            CHAT_USERS[uin] = {
                'name': name or old.get('name',''),
                'comments': comments or old.get('comments',''),
                'last_seen': now,
                'published': bool(old.get('published', False) or
                                  (endpoint.lower() == 'uinlister.exe' and action == 'y')),
            }
            CHAT_QUEUES.setdefault(uin, [])

        # Persist the newly published live UIN AFTER registering it.
        if uin and endpoint.lower() == 'uinlister.exe' and action == 'y':
            _chat_directory_save_state()

        sent = False
        if uin and dest and message:
            sender_name = CHAT_USERS.get(uin, {}).get('name','') or name
            CHAT_QUEUES.setdefault(dest, []).append({
                'from_uin': uin, 'from_name': sender_name,
                'text': message, 'when': now,
            })
            sent = True

        incoming = None
        # Poll/receive requests consume one queued message. Avoid consuming on a
        # request that is itself sending a message.
        wants_receive = (not message) and (uin and (endpoint.lower() == 'cbonline2.exe' or
                         action in {'get','poll','receive','recv','check','online'}))
        if wants_receive and CHAT_QUEUES.get(uin):
            incoming = CHAT_QUEUES[uin].pop(0)

        lookup = dest or _chat_safe_uin(_chat_pick(fields, 'lookupuin','ping','finduin'))
        target = CHAT_USERS.get(lookup, {}) if lookup else {}
        online = bool(target and now - int(target.get('last_seen', 0)) <= 300)
        if action == 'g':
            # G is not only a visual ping: CyberBuddy uses it as the recipient
            # availability handshake before enabling a send target.
            if online and lookup:
                CHAT_LAST_TARGET['default'] = lookup
            log.warning('LEGACY CHAT PING target=<hidden> online=%s selected=%s',
                        'yes' if online else 'no',
                        'yes' if (online and lookup) else 'no')

        # Directory list is intentionally compact. Unknown clients can ignore it;
        # known marker lines remain available to the original CyberBuddy parser.
        directory = []
        if endpoint.lower() == 'uinlister.exe':
            for key, info in sorted(CHAT_USERS.items()):
                directory.append('%s|%s' % (key, info.get('name','')))

    lines = [
        '$$UIN' + uin,
        '$$SNDTO' + (dest or lookup),
        '$$ONLINE=' + ('1' if online else '0'),
        '$$SENT=' + ('1' if sent else '0'),
    ]
    # Ping/Get-UIN compatibility records.  Keep these in addition to the
    # key=value form while reconstructing the original CyberBuddy parser.
    if action == 'g':
        lines += [
            '$$PING=' + (lookup or ''),
            '$$PINGONLINE=' + ('1' if online else '0'),
        ]
    if target:
        lines += [
            '$$NAME=' + target.get('name',''),
            '$$COMMENTS=' + target.get('comments',''),
            '$$UINFOUND=' + (lookup or ''),
            '$$STATUS=ONLINE' if online else '$$STATUS=OFFLINE',
        ]
    if incoming:
        lines += [
            '$$FROMUIN=' + incoming['from_uin'],
            '$$FROMNAME=' + incoming['from_name'],
            '$$MESSAGE=' + incoming['text'].replace('\r',' ').replace('\n',' '),
        ]
    for row in directory:
        lines.append('$$USER=' + row)
    lines.append('&&EOT')

    # CBonline2 G is a special lookup/ping transaction.  The old client appears
    # to decide "UIN not found" from the first response record, before looking
    # at our newer diagnostic markers. Put the requested UIN/status first and
    # include both compact positional and marker forms for compatibility.
    if endpoint.lower() == 'cbonline2.exe' and action == 'g':
        target_name = target.get('name','') if target else ''
        if online:
            # CyberBud.exe 4.13.9 parses these markers with NO '=' delimiter.
            # Keep the UIN as first record because G lookup also checks it early.
            g_lines = [
                (lookup or ''),
                '$$UIN' + (lookup or ''),
                '$$SNDTO' + (lookup or ''),
                        '&&EOT',
            ]
        else:
            g_lines = [
                '0',
                '$$UIN' + (lookup or ''),
                '$$SNDTO' + (lookup or ''),
                '&&EOT',
            ]
        payload = ('\r\n'.join(g_lines) + '\r\n').encode('windows-1252', 'replace')
        log.warning('LEGACY CHAT G RESPONSE online=%s bytes=%d native_markers=yes first_record=%s',
                    'yes' if online else 'no', len(payload),
                    '<uin>' if online else '0')
        return payload

    return ('\r\n'.join(lines) + '\r\n').encode('windows-1252', 'replace')


def cached_forecast(url):
    """Share recent forecasts and stop retrying while Open-Meteo throttles us."""
    global WEATHER_COOLDOWN_UNTIL
    with WEATHER_LOCK:
        now = time.monotonic()
        saved = WEATHER_CACHE.get(url)
        if saved and now - saved[0] < 20 * 60:
            return saved[1], False
        if now < WEATHER_COOLDOWN_UNTIL:
            if saved:
                return saved[1], True
            raise RuntimeError("Open-Meteo rate limit: please try again later")
        try:
            with direct_urlopen(url, timeout=TIMEOUT) as response:
                data = json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as error:
            if error.code != 429:
                if saved:
                    return saved[1], True
                raise
            retry = error.headers.get("Retry-After", "") if error.headers else ""
            try:
                delay = max(60, min(3600, int(retry)))
            except (TypeError, ValueError):
                delay = 300
            WEATHER_COOLDOWN_UNTIL = time.monotonic() + delay
            log.warning("Open-Meteo rate limited requests; pausing for %s seconds", delay)
            if saved:
                return saved[1], True
            raise RuntimeError("Open-Meteo rate limit: please try again later") from error
        except (OSError, ValueError):
            if saved:
                return saved[1], True
            raise
        WEATHER_CACHE[url] = (time.monotonic(), data)
        return data, False


def cached_geocode(url, user_agent):
    """Avoid asking Nominatim again for every repeat visit to a location."""
    with WEATHER_LOCK:
        saved = GEOCODE_CACHE.get(url)
        if saved and time.monotonic() - saved[0] < 24 * 3600:
            return saved[1]
        request = urllib.request.Request(url, headers={"User-Agent": user_agent})
        with direct_urlopen(request, timeout=TIMEOUT) as response:
            places = json.loads(response.read().decode("utf-8"))
        GEOCODE_CACHE[url] = (time.monotonic(), places)
        return places


def cached_inmet_alerts(place):
    """Reuse an INMET result or outage briefly instead of retrying on refresh."""
    key = (str(place.get("lat")), str(place.get("lon")))
    with WEATHER_LOCK:
        saved = INMET_ALERT_CACHE.get(key)
        if saved and time.monotonic() - saved[0] < 5 * 60:
            if saved[2]:
                raise ValueError(saved[2])
            return saved[1]
        try:
            notices = fetch_inmet_alerts(place)
        except (OSError, ValueError, ET.ParseError, KeyError) as error:
            INMET_ALERT_CACHE[key] = (time.monotonic(), None, str(error))
            raise
        INMET_ALERT_CACHE[key] = (time.monotonic(), notices, None)
        return notices


def observation_is_night(current, daily):
    """Use local observation time and that date's sunrise/sunset for the icon."""
    try:
        observed = datetime.datetime.fromisoformat(str(current['time']))
        dates = daily.get('time') or []
        index = dates.index(observed.date().isoformat())
        sunrise = datetime.datetime.fromisoformat(str(daily['sunrise'][index]))
        sunset = datetime.datetime.fromisoformat(str(daily['sunset'][index]))
        return observed < sunrise or observed >= sunset
    except (KeyError, ValueError, IndexError, TypeError):
        # Open-Meteo supplies this when daily sunrise/sunset are unavailable.
        return current.get('is_day') == 0


def forecast_place_name(place, requested):
    """Use a named locality for the old forecast heading, never a postal code."""
    address = place.get("address") or {}
    for key in ("city", "town", "village", "municipality", "hamlet", "county"):
        name = str(address.get(key) or "").strip()
        if name and not re.fullmatch(r"[0-9][0-9\s-]*", name):
            return clean_news_text(name)
    for part in str(place.get("display_name") or "").split(","):
        name = part.strip()
        if name and not re.fullmatch(r"[0-9][0-9\s-]*", name):
            return clean_news_text(name)
    return clean_news_text(requested)


def cap_value(element, name):
    """Read a CAP XML child independent of its namespace."""
    return next((child.text.strip() for child in element if child.tag.rsplit('}', 1)[-1] == name
                 and child.text), "")


def cap_inside_polygon(latitude, longitude, polygon):
    try:
        points = [tuple(float(v) for v in pair.split(',')) for pair in polygon.split()]
        if len(points) < 3:
            return False
        inside = False
        for index, (y1, x1) in enumerate(points):
            y2, x2 = points[(index + 1) % len(points)]
            if (y1 > latitude) != (y2 > latitude) and longitude < (x2 - x1) * (
                    latitude - y1) / (y2 - y1) + x1:
                inside = not inside
        return inside
    except (ValueError, ZeroDivisionError):
        return False


def inmet_alert_for_place(area, place):
    """Reject national/state alerts unless the specific city or point matches."""
    address = place.get('address') or {}
    city = str(address.get('city') or address.get('town') or
               address.get('municipality') or '').strip()
    state = str(address.get('state_code') or '').strip()
    for child in area:
        tag = child.tag.rsplit('}', 1)[-1]
        if tag == 'polygon' and child.text and cap_inside_polygon(
                float(place['lat']), float(place['lon']), child.text):
            return True
        if tag == 'geocode' and city and state:
            name = cap_value(child, 'valueName')
            value = cap_value(child, 'value')
            if name.casefold() in {'municipios', 'municípios'}:
                normalized = lambda s: ''.join(c for c in unicodedata.normalize('NFKD', s.casefold())
                                               if not unicodedata.combining(c))
                pattern = rf'(?:^|,)\s*{re.escape(normalized(city))}\s*-\s*{re.escape(normalized(state))}\s*\('
                if re.search(pattern, normalized(value)):
                    return True
    return False


def fetch_inmet_alerts(place, now=None):
    """INMET official RSS of CAP notices, filtered by their affected area."""
    now = now or datetime.datetime.now(datetime.timezone.utc)
    feed = 'https://apiprevmet3.inmet.gov.br/avisos/rss'
    with direct_urlopen(urllib.request.Request(feed, headers={'User-Agent':
                        'CyberBuddyClassicProxy/6.0 (weather alerts)'}),
                        timeout=min(TIMEOUT, 6)) as response:
        root = ET.fromstring(response.read(2 * 1024 * 1024))
    links = []
    for item in root.iter():
        if item.tag.rsplit('}', 1)[-1] not in {'item', 'entry'}:
            continue
        for child in item:
            if child.tag.rsplit('}', 1)[-1] == 'link':
                links.append((child.get('href') or child.text or '').strip())
    if root.tag.rsplit('}', 1)[-1] == 'alert':
        alerts_xml = [root]
    else:
        alerts_xml = []
    valid_links = []
    for link in dict.fromkeys(links):
        parsed = urllib.parse.urlparse(link)
        if parsed.scheme != 'https' or parsed.hostname != 'apiprevmet3.inmet.gov.br' or not re.fullmatch(
                r'/avisos/rss/\d+', parsed.path):
            continue
        valid_links.append(link)
    # The INMET host can reset concurrent requests. Stop after the first
    # unavailable CAP document: silently skipping it could produce a false
    # "no alerts" result for the requested municipality.
    if links and len(valid_links) != len(set(links)):
        raise ValueError('INMET feed contained unsupported or incomplete alert links')
    for link in valid_links:
        try:
            with direct_urlopen(link, timeout=min(TIMEOUT, 4)) as response:
                alerts_xml.append(ET.fromstring(response.read(512 * 1024)))
        except (OSError, ValueError, ET.ParseError) as error:
            raise ValueError('INMET alert details unavailable; coverage cannot be confirmed') from error
    results = []
    for alert in alerts_xml:
        for info in alert:
            if info.tag.rsplit('}', 1)[-1] != 'info':
                continue
            expiry = cap_value(info, 'expires')
            try:
                until = datetime.datetime.fromisoformat(expiry.replace('Z', '+00:00'))
                if until.tzinfo is None or until <= now:
                    continue
            except ValueError:
                continue
            if not any(area.tag.rsplit('}', 1)[-1] == 'area' and
                       inmet_alert_for_place(area, place) for area in info):
                continue
            event = cap_value(info, 'event') or 'Weather alert'
            message = cap_value(info, 'headline') or cap_value(info, 'description')
            message = re.sub(r'\s+', ' ', message).strip()[:220]
            record = (event, until, message)
            if record not in results:
                results.append(record)
    return results[:5]


def fetch_global_alerts(place, now=None):
    """Find location-matched meteorological CAP warnings in IFRC Alert Hub."""
    now = now or datetime.datetime.now(datetime.timezone.utc)
    endpoint = 'https://alerthub-api.ifrc.org/graphql/'
    def query(graphql, variables=None):
        payload = json.dumps({'query': graphql, 'variables': variables or {}}).encode('utf-8')
        request = urllib.request.Request(endpoint, data=payload, headers={
            'Content-Type': 'application/json',
            'User-Agent': 'CyberBuddyClassicProxy/6.0 (weather alerts)'})
        with direct_urlopen(request, timeout=min(TIMEOUT, 7)) as response:
            result = json.loads(response.read(3 * 1024 * 1024))
        if result.get('errors'):
            raise ValueError('IFRC Alert Hub rejected the alert query')
        return result['data']['public']

    countries = query('{ public { countries { items { id name iso3 alertCount } } } }')[
        'countries']['items']
    country_name = str((place.get('address') or {}).get('country') or '')
    normalized = lambda s: ''.join(c for c in unicodedata.normalize('NFKD', s.casefold())
                                   if not unicodedata.combining(c))
    country = next((item for item in countries if normalized(item['name']) ==
                    normalized(country_name)), None)
    if country is None:
        return None  # No confirmed national feed coverage for this location.
    if not country.get('alertCount'):
        feeds = query('{ public { feeds { items { countryId enablePolling official status } } } }')[
            'feeds']['items']
        covered = any(feed['countryId'] == country['id'] and feed['enablePolling'] and
                      feed['official'] and feed['status'] == 'ACTIVE' for feed in feeds)
        return [] if covered else None
    listing = query('''query($id: ID!) { public {
      alerts(filters: {country: {pk: $id}}, pagination: {limit: 100, offset: 0}) {
        count items { id status msgType infos { language category event headline description
          expires areas { areaDesc polygons { value } circles { value } } } }
      }
    } }''', {'id': country['id']})['alerts']
    if listing['count'] > 100:
        raise ValueError('Too many alerts to check every affected area')
    lat, lon = float(place['lat']), float(place['lon'])
    results = []
    for alert in listing['items']:
        if alert['status'] != 'ACTUAL' or alert['msgType'] not in ('ALERT', 'UPDATE'):
            continue
        for info in alert.get('infos') or []:
            if info['category'] != 'MET':
                continue
            try:
                expiry = datetime.datetime.fromisoformat(info['expires'].replace('Z', '+00:00'))
                if expiry.tzinfo is None or expiry <= now:
                    continue
            except (AttributeError, ValueError):
                continue
            matched = False
            for area in info.get('areas') or []:
                if any(cap_inside_polygon(lat, lon, p['value']) for p in area.get('polygons') or []):
                    matched = True
                for circle in area.get('circles') or []:
                    try:
                        center_lat, center_lon, radius_km = map(float, re.split(r'[ ,]+', circle['value']))
                        import math
                        dlat, dlon = math.radians(lat - center_lat), math.radians(lon - center_lon)
                        a = (math.sin(dlat / 2) ** 2 + math.cos(math.radians(lat)) *
                             math.cos(math.radians(center_lat)) * math.sin(dlon / 2) ** 2)
                        matched |= 12742 * math.asin(min(1, math.sqrt(a))) <= radius_km
                    except (ValueError, TypeError, KeyError):
                        continue
            if matched:
                message = re.sub(r'\s+', ' ', info.get('headline') or
                                 info.get('description') or '').strip()[:220]
                record = (info.get('event') or 'Weather alert', expiry, message)
                if record not in results:
                    results.append(record)
                break
    return results[:5]


def load_config() -> configparser.ConfigParser:
    cfg = configparser.ConfigParser()
    cfg.read(CONFIG_PATH, encoding="utf-8")
    return cfg


CFG = load_config()
BIND = CFG.get("server", "bind", fallback="127.0.0.1")
PORT = CFG.getint("server", "port", fallback=8081)
TIMEOUT = CFG.getint("server", "timeout", fallback=45)
MAX_BODY_MB = CFG.getint("server", "max_body_mb", fallback=20)
CONVERT_XML = CFG.getboolean("compatibility", "convert_xml_to_windows_1252", fallback=True)
REMOVE_SCRIPTS = CFG.getboolean("compatibility", "remove_scripts_from_html", fallback=False)
VERIFY_TLS = CFG.getboolean("security", "verify_tls_certificates", fallback=True)
POP3_ENABLED = CFG.getboolean("pop3_bridge", "enabled", fallback=True)
POP3_BIND = CFG.get("pop3_bridge", "bind", fallback="127.0.0.1")
POP3_LOCAL_PORT = CFG.getint("pop3_bridge", "local_port", fallback=110)
POP3_REMOTE_HOST = CFG.get("pop3_bridge", "remote_host", fallback="pop.gmail.com")
POP3_REMOTE_PORT = CFG.getint("pop3_bridge", "remote_port", fallback=995)
SMTP_ENABLED = CFG.getboolean("smtp_bridge", "enabled", fallback=True)
SMTP_BIND = CFG.get("smtp_bridge", "bind", fallback="127.0.0.1")
SMTP_LOCAL_PORT = CFG.getint("smtp_bridge", "local_port", fallback=25)
SMTP_REMOTE_HOST = CFG.get("smtp_bridge", "remote_host", fallback="smtp.gmail.com")
SMTP_REMOTE_PORT = CFG.getint("smtp_bridge", "remote_port", fallback=465)


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    handlers=[logging.FileHandler(LOG_PATH, encoding="utf-8"), logging.StreamHandler(sys.stdout)],
)
log = logging.getLogger("cyberbuddy-proxy")

_chat_directory_load_state()
log.info("CHAT DATABASE: loaded persistent live-user state; startup reset disabled")

# A browser using the system proxy may cancel thousands of background requests.
# Keep one useful diagnostic per upstream host instead of flooding the console.
UPSTREAM_FAILURES = {}
UPSTREAM_FAILURES_LOCK = threading.Lock()


def log_upstream_failure(target, error):
    address = urllib.parse.urlsplit(target)
    host = address.hostname or "unknown host"
    host_port = host + (":" + str(address.port) if address.port else "")
    now = time.monotonic()
    with UPSTREAM_FAILURES_LOCK:
        if len(UPSTREAM_FAILURES) > 512:
            UPSTREAM_FAILURES.clear()
        previous, suppressed = UPSTREAM_FAILURES.get(host_port, (0, 0))
        if now - previous < 30:
            UPSTREAM_FAILURES[host_port] = (previous, suppressed + 1)
            return
        UPSTREAM_FAILURES[host_port] = (now, 0)
    log.warning("Upstream %s failed: %s%s", host_port, error,
                " (%d repeated failures suppressed)" % suppressed if suppressed else "")

# The app password is retained only in process memory after a successful POP3
# login. It is never written to proxy.ini or proxy.log.
MAIL_CREDENTIALS = {"username": None, "password": None}
MAIL_CREDENTIALS_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "mail_credentials.ini")

def _save_mail_credentials(username, password):
    if not username or not password:
        return
    try:
        cfg = configparser.ConfigParser()
        cfg["mail"] = {"username": str(username), "password": str(password)}
        with open(MAIL_CREDENTIALS_FILE, "w", encoding="utf-8") as f:
            cfg.write(f)
        try:
            os.chmod(MAIL_CREDENTIALS_FILE, 0o600)
        except Exception:
            pass
        log.warning("MAIL CREDENTIAL BRIDGE: credentials cached locally")
    except Exception as error:
        log.warning("MAIL CREDENTIAL BRIDGE: cache failed: %s", error)

def _load_mail_credentials():
    try:
        if not os.path.isfile(MAIL_CREDENTIALS_FILE):
            return None, None
        cfg = configparser.ConfigParser()
        cfg.read(MAIL_CREDENTIALS_FILE, encoding="utf-8")
        return cfg.get("mail","username",fallback=None), cfg.get("mail","password",fallback=None)
    except Exception as error:
        log.warning("MAIL CREDENTIAL BRIDGE: load failed: %s", error)
        return None, None

MAIL_CREDENTIALS_LOCK = threading.Lock()

FUN_ITEMS = {'joke': ('&&Explain\nWhy was the computer smiling?\n&&Pleased\nIt needed a little cache flow.\n&&RestPose', '&&Explain\nWhat did the computer say when things got difficult?\n&&Pleased\nIt needed a little cache flow. That was its whole explanation.\n&&RestPose', '&&Explain\nWhy did the computer stop arguing?\n&&Pleased\nIt needed a little cache flow. There was no point continuing.\n&&RestPose', '&&Explain\nWhat was the computer thinking about?\n&&Pleased\nMostly cache. It needed a little cache flow.\n&&RestPose', '&&Explain\nWhy did everyone laugh with the computer?\n&&Pleased\nIt needed a little cache flow. Apparently that was funny enough.\n&&RestPose', '&&Explain\nWhat is the computer best known for?\n&&Pleased\nProbably cache. It needed a little cache flow.\n&&RestPose', '&&Explain\nWhy did the computer need a break?\n&&Pleased\nIt needed a little cache flow. Even a cache needs a rest sometimes.\n&&RestPose', '&&Explain\nWhat excuse did the computer give?\n&&Pleased\nIt blamed the cache. It needed a little cache flow.\n&&RestPose', '&&Explain\nWhy was the computer so confident?\n&&Pleased\nIt knew all about cache. It needed a little cache flow.\n&&RestPose', '&&Explain\nWhat made the computer laugh?\n&&Pleased\nThe thought of cache. It needed a little cache flow.\n&&RestPose', '&&Explain\nWhy did the computer change its mind?\n&&Pleased\nIt reconsidered the cache. It needed a little cache flow.\n&&RestPose', '&&Explain\nWhat did the computer learn today?\n&&Pleased\nA surprising amount about cache. It needed a little cache flow.\n&&RestPose', '&&Explain\nWhy did the computer get everyone’s attention?\n&&Pleased\nIt mentioned cache, then said, “It needed a little cache flow.”\n&&RestPose', '&&Explain\nWhat secret was the computer keeping?\n&&Pleased\nIt would not say, but it involved cache. It needed a little cache flow.\n&&RestPose', '&&Explain\nWhy was the computer having a strange day?\n&&Pleased\nToo much cache for one day. It needed a little cache flow.\n&&RestPose', '&&Explain\nWhat advice did the computer give?\n&&Pleased\n“Never underestimate cache.” It needed a little cache flow.\n&&RestPose', '&&Explain\nWhy did the computer refuse to panic?\n&&Pleased\nIt had cache under control. It needed a little cache flow.\n&&RestPose', '&&Explain\nWhat made the computer feel clever?\n&&Pleased\nFinally understanding cache. It needed a little cache flow.\n&&RestPose', '&&Explain\nWhy was the computer telling jokes?\n&&Pleased\nIt had material about cache. It needed a little cache flow.\n&&RestPose', '&&Explain\nWhat did the computer say after a long day?\n&&Pleased\n“Enough cache for today.” It needed a little cache flow.\n&&RestPose', '&&Explain\nWhy was the keyboard smiling?\n&&Pleased\nIt needed more space.\n&&RestPose', '&&Explain\nWhat did the keyboard say when things got difficult?\n&&Pleased\nIt needed more space. That was its whole explanation.\n&&RestPose', '&&Explain\nWhy did the keyboard stop arguing?\n&&Pleased\nIt needed more space. There was no point continuing.\n&&RestPose', '&&Explain\nWhat was the keyboard thinking about?\n&&Pleased\nMostly space bar. It needed more space.\n&&RestPose', '&&Explain\nWhy did everyone laugh with the keyboard?\n&&Pleased\nIt needed more space. Apparently that was funny enough.\n&&RestPose', '&&Explain\nWhat is the keyboard best known for?\n&&Pleased\nProbably space bar. It needed more space.\n&&RestPose', '&&Explain\nWhy did the keyboard need a break?\n&&Pleased\nIt needed more space. Even a space bar needs a rest sometimes.\n&&RestPose', '&&Explain\nWhat excuse did the keyboard give?\n&&Pleased\nIt blamed the space bar. It needed more space.\n&&RestPose', '&&Explain\nWhy was the keyboard so confident?\n&&Pleased\nIt knew all about space bar. It needed more space.\n&&RestPose', '&&Explain\nWhat made the keyboard laugh?\n&&Pleased\nThe thought of space bar. It needed more space.\n&&RestPose', '&&Explain\nWhy did the keyboard change its mind?\n&&Pleased\nIt reconsidered the space bar. It needed more space.\n&&RestPose', '&&Explain\nWhat did the keyboard learn today?\n&&Pleased\nA surprising amount about space bar. It needed more space.\n&&RestPose', '&&Explain\nWhy did the keyboard get everyone’s attention?\n&&Pleased\nIt mentioned space bar, then said, “It needed more space.”\n&&RestPose', '&&Explain\nWhat secret was the keyboard keeping?\n&&Pleased\nIt would not say, but it involved space bar. It needed more space.\n&&RestPose', '&&Explain\nWhy was the keyboard having a strange day?\n&&Pleased\nToo much space bar for one day. It needed more space.\n&&RestPose', '&&Explain\nWhat advice did the keyboard give?\n&&Pleased\n“Never underestimate space bar.” It needed more space.\n&&RestPose', '&&Explain\nWhy did the keyboard refuse to panic?\n&&Pleased\nIt had space bar under control. It needed more space.\n&&RestPose', '&&Explain\nWhat made the keyboard feel clever?\n&&Pleased\nFinally understanding space bar. It needed more space.\n&&RestPose', '&&Explain\nWhy was the keyboard telling jokes?\n&&Pleased\nIt had material about space bar. It needed more space.\n&&RestPose', '&&Explain\nWhat did the keyboard say after a long day?\n&&Pleased\n“Enough space bar for today.” It needed more space.\n&&RestPose', '&&Explain\nWhy was the mouse smiling?\n&&Pleased\nIt just clicked with everyone.\n&&RestPose', '&&Explain\nWhat did the mouse say when things got difficult?\n&&Pleased\nIt just clicked with everyone. That was its whole explanation.\n&&RestPose', '&&Explain\nWhy did the mouse stop arguing?\n&&Pleased\nIt just clicked with everyone. There was no point continuing.\n&&RestPose', '&&Explain\nWhat was the mouse thinking about?\n&&Pleased\nMostly click. It just clicked with everyone.\n&&RestPose', '&&Explain\nWhy did everyone laugh with the mouse?\n&&Pleased\nIt just clicked with everyone. Apparently that was funny enough.\n&&RestPose', '&&Explain\nWhat is the mouse best known for?\n&&Pleased\nProbably click. It just clicked with everyone.\n&&RestPose', '&&Explain\nWhy did the mouse need a break?\n&&Pleased\nIt just clicked with everyone. Even a click needs a rest sometimes.\n&&RestPose', '&&Explain\nWhat excuse did the mouse give?\n&&Pleased\nIt blamed the click. It just clicked with everyone.\n&&RestPose', '&&Explain\nWhy was the mouse so confident?\n&&Pleased\nIt knew all about click. It just clicked with everyone.\n&&RestPose', '&&Explain\nWhat made the mouse laugh?\n&&Pleased\nThe thought of click. It just clicked with everyone.\n&&RestPose', '&&Explain\nWhy did the mouse change its mind?\n&&Pleased\nIt reconsidered the click. It just clicked with everyone.\n&&RestPose', '&&Explain\nWhat did the mouse learn today?\n&&Pleased\nA surprising amount about click. It just clicked with everyone.\n&&RestPose', '&&Explain\nWhy did the mouse get everyone’s attention?\n&&Pleased\nIt mentioned click, then said, “It just clicked with everyone.”\n&&RestPose', '&&Explain\nWhat secret was the mouse keeping?\n&&Pleased\nIt would not say, but it involved click. It just clicked with everyone.\n&&RestPose', '&&Explain\nWhy was the mouse having a strange day?\n&&Pleased\nToo much click for one day. It just clicked with everyone.\n&&RestPose', '&&Explain\nWhat advice did the mouse give?\n&&Pleased\n“Never underestimate click.” It just clicked with everyone.\n&&RestPose', '&&Explain\nWhy did the mouse refuse to panic?\n&&Pleased\nIt had click under control. It just clicked with everyone.\n&&RestPose', '&&Explain\nWhat made the mouse feel clever?\n&&Pleased\nFinally understanding click. It just clicked with everyone.\n&&RestPose', '&&Explain\nWhy was the mouse telling jokes?\n&&Pleased\nIt had material about click. It just clicked with everyone.\n&&RestPose', '&&Explain\nWhat did the mouse say after a long day?\n&&Pleased\n“Enough click for today.” It just clicked with everyone.\n&&RestPose', '&&Explain\nWhy was the printer smiling?\n&&Pleased\nIt was tired of being pressed.\n&&RestPose', '&&Explain\nWhat did the printer say when things got difficult?\n&&Pleased\nIt was tired of being pressed. That was its whole explanation.\n&&RestPose', '&&Explain\nWhy did the printer stop arguing?\n&&Pleased\nIt was tired of being pressed. There was no point continuing.\n&&RestPose', '&&Explain\nWhat was the printer thinking about?\n&&Pleased\nMostly paper. It was tired of being pressed.\n&&RestPose', '&&Explain\nWhy did everyone laugh with the printer?\n&&Pleased\nIt was tired of being pressed. Apparently that was funny enough.\n&&RestPose', '&&Explain\nWhat is the printer best known for?\n&&Pleased\nProbably paper. It was tired of being pressed.\n&&RestPose', '&&Explain\nWhy did the printer need a break?\n&&Pleased\nIt was tired of being pressed. Even a paper needs a rest sometimes.\n&&RestPose', '&&Explain\nWhat excuse did the printer give?\n&&Pleased\nIt blamed the paper. It was tired of being pressed.\n&&RestPose', '&&Explain\nWhy was the printer so confident?\n&&Pleased\nIt knew all about paper. It was tired of being pressed.\n&&RestPose', '&&Explain\nWhat made the printer laugh?\n&&Pleased\nThe thought of paper. It was tired of being pressed.\n&&RestPose', '&&Explain\nWhy did the printer change its mind?\n&&Pleased\nIt reconsidered the paper. It was tired of being pressed.\n&&RestPose', '&&Explain\nWhat did the printer learn today?\n&&Pleased\nA surprising amount about paper. It was tired of being pressed.\n&&RestPose', '&&Explain\nWhy did the printer get everyone’s attention?\n&&Pleased\nIt mentioned paper, then said, “It was tired of being pressed.”\n&&RestPose', '&&Explain\nWhat secret was the printer keeping?\n&&Pleased\nIt would not say, but it involved paper. It was tired of being pressed.\n&&RestPose', '&&Explain\nWhy was the printer having a strange day?\n&&Pleased\nToo much paper for one day. It was tired of being pressed.\n&&RestPose', '&&Explain\nWhat advice did the printer give?\n&&Pleased\n“Never underestimate paper.” It was tired of being pressed.\n&&RestPose', '&&Explain\nWhy did the printer refuse to panic?\n&&Pleased\nIt had paper under control. It was tired of being pressed.\n&&RestPose', '&&Explain\nWhat made the printer feel clever?\n&&Pleased\nFinally understanding paper. It was tired of being pressed.\n&&RestPose', '&&Explain\nWhy was the printer telling jokes?\n&&Pleased\nIt had material about paper. It was tired of being pressed.\n&&RestPose', '&&Explain\nWhat did the printer say after a long day?\n&&Pleased\n“Enough paper for today.” It was tired of being pressed.\n&&RestPose', '&&Explain\nWhy was the monitor smiling?\n&&Pleased\nIt wanted to broaden its screen of view.\n&&RestPose', '&&Explain\nWhat did the monitor say when things got difficult?\n&&Pleased\nIt wanted to broaden its screen of view. That was its whole explanation.\n&&RestPose', '&&Explain\nWhy did the monitor stop arguing?\n&&Pleased\nIt wanted to broaden its screen of view. There was no point continuing.\n&&RestPose', '&&Explain\nWhat was the monitor thinking about?\n&&Pleased\nMostly screen. It wanted to broaden its screen of view.\n&&RestPose', '&&Explain\nWhy did everyone laugh with the monitor?\n&&Pleased\nIt wanted to broaden its screen of view. Apparently that was funny enough.\n&&RestPose', '&&Explain\nWhat is the monitor best known for?\n&&Pleased\nProbably screen. It wanted to broaden its screen of view.\n&&RestPose', '&&Explain\nWhy did the monitor need a break?\n&&Pleased\nIt wanted to broaden its screen of view. Even a screen needs a rest sometimes.\n&&RestPose', '&&Explain\nWhat excuse did the monitor give?\n&&Pleased\nIt blamed the screen. It wanted to broaden its screen of view.\n&&RestPose', '&&Explain\nWhy was the monitor so confident?\n&&Pleased\nIt knew all about screen. It wanted to broaden its screen of view.\n&&RestPose', '&&Explain\nWhat made the monitor laugh?\n&&Pleased\nThe thought of screen. It wanted to broaden its screen of view.\n&&RestPose', '&&Explain\nWhy did the monitor change its mind?\n&&Pleased\nIt reconsidered the screen. It wanted to broaden its screen of view.\n&&RestPose', '&&Explain\nWhat did the monitor learn today?\n&&Pleased\nA surprising amount about screen. It wanted to broaden its screen of view.\n&&RestPose', '&&Explain\nWhy did the monitor get everyone’s attention?\n&&Pleased\nIt mentioned screen, then said, “It wanted to broaden its screen of view.”\n&&RestPose', '&&Explain\nWhat secret was the monitor keeping?\n&&Pleased\nIt would not say, but it involved screen. It wanted to broaden its screen of view.\n&&RestPose', '&&Explain\nWhy was the monitor having a strange day?\n&&Pleased\nToo much screen for one day. It wanted to broaden its screen of view.\n&&RestPose', '&&Explain\nWhat advice did the monitor give?\n&&Pleased\n“Never underestimate screen.” It wanted to broaden its screen of view.\n&&RestPose', '&&Explain\nWhy did the monitor refuse to panic?\n&&Pleased\nIt had screen under control. It wanted to broaden its screen of view.\n&&RestPose', '&&Explain\nWhat made the monitor feel clever?\n&&Pleased\nFinally understanding screen. It wanted to broaden its screen of view.\n&&RestPose', '&&Explain\nWhy was the monitor telling jokes?\n&&Pleased\nIt had material about screen. It wanted to broaden its screen of view.\n&&RestPose', '&&Explain\nWhat did the monitor say after a long day?\n&&Pleased\n“Enough screen for today.” It wanted to broaden its screen of view.\n&&RestPose', '&&Explain\nWhy was the modem smiling?\n&&Pleased\nIt was trying to make a connection.\n&&RestPose', '&&Explain\nWhat did the modem say when things got difficult?\n&&Pleased\nIt was trying to make a connection. That was its whole explanation.\n&&RestPose', '&&Explain\nWhy did the modem stop arguing?\n&&Pleased\nIt was trying to make a connection. There was no point continuing.\n&&RestPose', '&&Explain\nWhat was the modem thinking about?\n&&Pleased\nMostly connection. It was trying to make a connection.\n&&RestPose', '&&Explain\nWhy did everyone laugh with the modem?\n&&Pleased\nIt was trying to make a connection. Apparently that was funny enough.\n&&RestPose', '&&Explain\nWhat is the modem best known for?\n&&Pleased\nProbably connection. It was trying to make a connection.\n&&RestPose', '&&Explain\nWhy did the modem need a break?\n&&Pleased\nIt was trying to make a connection. Even a connection needs a rest sometimes.\n&&RestPose', '&&Explain\nWhat excuse did the modem give?\n&&Pleased\nIt blamed the connection. It was trying to make a connection.\n&&RestPose', '&&Explain\nWhy was the modem so confident?\n&&Pleased\nIt knew all about connection. It was trying to make a connection.\n&&RestPose', '&&Explain\nWhat made the modem laugh?\n&&Pleased\nThe thought of connection. It was trying to make a connection.\n&&RestPose', '&&Explain\nWhy did the modem change its mind?\n&&Pleased\nIt reconsidered the connection. It was trying to make a connection.\n&&RestPose', '&&Explain\nWhat did the modem learn today?\n&&Pleased\nA surprising amount about connection. It was trying to make a connection.\n&&RestPose', '&&Explain\nWhy did the modem get everyone’s attention?\n&&Pleased\nIt mentioned connection, then said, “It was trying to make a connection.”\n&&RestPose', '&&Explain\nWhat secret was the modem keeping?\n&&Pleased\nIt would not say, but it involved connection. It was trying to make a connection.\n&&RestPose', '&&Explain\nWhy was the modem having a strange day?\n&&Pleased\nToo much connection for one day. It was trying to make a connection.\n&&RestPose', '&&Explain\nWhat advice did the modem give?\n&&Pleased\n“Never underestimate connection.” It was trying to make a connection.\n&&RestPose', '&&Explain\nWhy did the modem refuse to panic?\n&&Pleased\nIt had connection under control. It was trying to make a connection.\n&&RestPose', '&&Explain\nWhat made the modem feel clever?\n&&Pleased\nFinally understanding connection. It was trying to make a connection.\n&&RestPose', '&&Explain\nWhy was the modem telling jokes?\n&&Pleased\nIt had material about connection. It was trying to make a connection.\n&&RestPose', '&&Explain\nWhat did the modem say after a long day?\n&&Pleased\n“Enough connection for today.” It was trying to make a connection.\n&&RestPose', '&&Explain\nWhy was the browser smiling?\n&&Pleased\nIt had too many tabs on its mind.\n&&RestPose', '&&Explain\nWhat did the browser say when things got difficult?\n&&Pleased\nIt had too many tabs on its mind. That was its whole explanation.\n&&RestPose', '&&Explain\nWhy did the browser stop arguing?\n&&Pleased\nIt had too many tabs on its mind. There was no point continuing.\n&&RestPose', '&&Explain\nWhat was the browser thinking about?\n&&Pleased\nMostly tabs. It had too many tabs on its mind.\n&&RestPose', '&&Explain\nWhy did everyone laugh with the browser?\n&&Pleased\nIt had too many tabs on its mind. Apparently that was funny enough.\n&&RestPose', '&&Explain\nWhat is the browser best known for?\n&&Pleased\nProbably tabs. It had too many tabs on its mind.\n&&RestPose', '&&Explain\nWhy did the browser need a break?\n&&Pleased\nIt had too many tabs on its mind. Even a tabs needs a rest sometimes.\n&&RestPose', '&&Explain\nWhat excuse did the browser give?\n&&Pleased\nIt blamed the tabs. It had too many tabs on its mind.\n&&RestPose', '&&Explain\nWhy was the browser so confident?\n&&Pleased\nIt knew all about tabs. It had too many tabs on its mind.\n&&RestPose', '&&Explain\nWhat made the browser laugh?\n&&Pleased\nThe thought of tabs. It had too many tabs on its mind.\n&&RestPose', '&&Explain\nWhy did the browser change its mind?\n&&Pleased\nIt reconsidered the tabs. It had too many tabs on its mind.\n&&RestPose', '&&Explain\nWhat did the browser learn today?\n&&Pleased\nA surprising amount about tabs. It had too many tabs on its mind.\n&&RestPose', '&&Explain\nWhy did the browser get everyone’s attention?\n&&Pleased\nIt mentioned tabs, then said, “It had too many tabs on its mind.”\n&&RestPose', '&&Explain\nWhat secret was the browser keeping?\n&&Pleased\nIt would not say, but it involved tabs. It had too many tabs on its mind.\n&&RestPose', '&&Explain\nWhy was the browser having a strange day?\n&&Pleased\nToo much tabs for one day. It had too many tabs on its mind.\n&&RestPose', '&&Explain\nWhat advice did the browser give?\n&&Pleased\n“Never underestimate tabs.” It had too many tabs on its mind.\n&&RestPose', '&&Explain\nWhy did the browser refuse to panic?\n&&Pleased\nIt had tabs under control. It had too many tabs on its mind.\n&&RestPose', '&&Explain\nWhat made the browser feel clever?\n&&Pleased\nFinally understanding tabs. It had too many tabs on its mind.\n&&RestPose', '&&Explain\nWhy was the browser telling jokes?\n&&Pleased\nIt had material about tabs. It had too many tabs on its mind.\n&&RestPose', '&&Explain\nWhat did the browser say after a long day?\n&&Pleased\n“Enough tabs for today.” It had too many tabs on its mind.\n&&RestPose', '&&Explain\nWhy was the server smiling?\n&&Pleased\nIt could not handle all the requests.\n&&RestPose', '&&Explain\nWhat did the server say when things got difficult?\n&&Pleased\nIt could not handle all the requests. That was its whole explanation.\n&&RestPose', '&&Explain\nWhy did the server stop arguing?\n&&Pleased\nIt could not handle all the requests. There was no point continuing.\n&&RestPose', '&&Explain\nWhat was the server thinking about?\n&&Pleased\nMostly requests. It could not handle all the requests.\n&&RestPose', '&&Explain\nWhy did everyone laugh with the server?\n&&Pleased\nIt could not handle all the requests. Apparently that was funny enough.\n&&RestPose', '&&Explain\nWhat is the server best known for?\n&&Pleased\nProbably requests. It could not handle all the requests.\n&&RestPose', '&&Explain\nWhy did the server need a break?\n&&Pleased\nIt could not handle all the requests. Even a requests needs a rest sometimes.\n&&RestPose', '&&Explain\nWhat excuse did the server give?\n&&Pleased\nIt blamed the requests. It could not handle all the requests.\n&&RestPose', '&&Explain\nWhy was the server so confident?\n&&Pleased\nIt knew all about requests. It could not handle all the requests.\n&&RestPose', '&&Explain\nWhat made the server laugh?\n&&Pleased\nThe thought of requests. It could not handle all the requests.\n&&RestPose', '&&Explain\nWhy did the server change its mind?\n&&Pleased\nIt reconsidered the requests. It could not handle all the requests.\n&&RestPose', '&&Explain\nWhat did the server learn today?\n&&Pleased\nA surprising amount about requests. It could not handle all the requests.\n&&RestPose', '&&Explain\nWhy did the server get everyone’s attention?\n&&Pleased\nIt mentioned requests, then said, “It could not handle all the requests.”\n&&RestPose', '&&Explain\nWhat secret was the server keeping?\n&&Pleased\nIt would not say, but it involved requests. It could not handle all the requests.\n&&RestPose', '&&Explain\nWhy was the server having a strange day?\n&&Pleased\nToo much requests for one day. It could not handle all the requests.\n&&RestPose', '&&Explain\nWhat advice did the server give?\n&&Pleased\n“Never underestimate requests.” It could not handle all the requests.\n&&RestPose', '&&Explain\nWhy did the server refuse to panic?\n&&Pleased\nIt had requests under control. It could not handle all the requests.\n&&RestPose', '&&Explain\nWhat made the server feel clever?\n&&Pleased\nFinally understanding requests. It could not handle all the requests.\n&&RestPose', '&&Explain\nWhy was the server telling jokes?\n&&Pleased\nIt had material about requests. It could not handle all the requests.\n&&RestPose', '&&Explain\nWhat did the server say after a long day?\n&&Pleased\n“Enough requests for today.” It could not handle all the requests.\n&&RestPose', '&&Explain\nWhy was the router smiling?\n&&Pleased\nIt was looking for a better route.\n&&RestPose', '&&Explain\nWhat did the router say when things got difficult?\n&&Pleased\nIt was looking for a better route. That was its whole explanation.\n&&RestPose', '&&Explain\nWhy did the router stop arguing?\n&&Pleased\nIt was looking for a better route. There was no point continuing.\n&&RestPose', '&&Explain\nWhat was the router thinking about?\n&&Pleased\nMostly route. It was looking for a better route.\n&&RestPose', '&&Explain\nWhy did everyone laugh with the router?\n&&Pleased\nIt was looking for a better route. Apparently that was funny enough.\n&&RestPose', '&&Explain\nWhat is the router best known for?\n&&Pleased\nProbably route. It was looking for a better route.\n&&RestPose', '&&Explain\nWhy did the router need a break?\n&&Pleased\nIt was looking for a better route. Even a route needs a rest sometimes.\n&&RestPose', '&&Explain\nWhat excuse did the router give?\n&&Pleased\nIt blamed the route. It was looking for a better route.\n&&RestPose', '&&Explain\nWhy was the router so confident?\n&&Pleased\nIt knew all about route. It was looking for a better route.\n&&RestPose', '&&Explain\nWhat made the router laugh?\n&&Pleased\nThe thought of route. It was looking for a better route.\n&&RestPose', '&&Explain\nWhy did the router change its mind?\n&&Pleased\nIt reconsidered the route. It was looking for a better route.\n&&RestPose', '&&Explain\nWhat did the router learn today?\n&&Pleased\nA surprising amount about route. It was looking for a better route.\n&&RestPose', '&&Explain\nWhy did the router get everyone’s attention?\n&&Pleased\nIt mentioned route, then said, “It was looking for a better route.”\n&&RestPose', '&&Explain\nWhat secret was the router keeping?\n&&Pleased\nIt would not say, but it involved route. It was looking for a better route.\n&&RestPose', '&&Explain\nWhy was the router having a strange day?\n&&Pleased\nToo much route for one day. It was looking for a better route.\n&&RestPose', '&&Explain\nWhat advice did the router give?\n&&Pleased\n“Never underestimate route.” It was looking for a better route.\n&&RestPose', '&&Explain\nWhy did the router refuse to panic?\n&&Pleased\nIt had route under control. It was looking for a better route.\n&&RestPose', '&&Explain\nWhat made the router feel clever?\n&&Pleased\nFinally understanding route. It was looking for a better route.\n&&RestPose', '&&Explain\nWhy was the router telling jokes?\n&&Pleased\nIt had material about route. It was looking for a better route.\n&&RestPose', '&&Explain\nWhat did the router say after a long day?\n&&Pleased\n“Enough route for today.” It was looking for a better route.\n&&RestPose', '&&Explain\nWhy was the programmer smiling?\n&&Pleased\nThe bugs kept giving it new features.\n&&RestPose', '&&Explain\nWhat did the programmer say when things got difficult?\n&&Pleased\nThe bugs kept giving it new features. That was its whole explanation.\n&&RestPose', '&&Explain\nWhy did the programmer stop arguing?\n&&Pleased\nThe bugs kept giving it new features. There was no point continuing.\n&&RestPose', '&&Explain\nWhat was the programmer thinking about?\n&&Pleased\nMostly bugs. The bugs kept giving it new features.\n&&RestPose', '&&Explain\nWhy did everyone laugh with the programmer?\n&&Pleased\nThe bugs kept giving it new features. Apparently that was funny enough.\n&&RestPose', '&&Explain\nWhat is the programmer best known for?\n&&Pleased\nProbably bugs. The bugs kept giving it new features.\n&&RestPose', '&&Explain\nWhy did the programmer need a break?\n&&Pleased\nThe bugs kept giving it new features. Even a bugs needs a rest sometimes.\n&&RestPose', '&&Explain\nWhat excuse did the programmer give?\n&&Pleased\nIt blamed the bugs. The bugs kept giving it new features.\n&&RestPose', '&&Explain\nWhy was the programmer so confident?\n&&Pleased\nIt knew all about bugs. The bugs kept giving it new features.\n&&RestPose', '&&Explain\nWhat made the programmer laugh?\n&&Pleased\nThe thought of bugs. The bugs kept giving it new features.\n&&RestPose', '&&Explain\nWhy did the programmer change its mind?\n&&Pleased\nIt reconsidered the bugs. The bugs kept giving it new features.\n&&RestPose', '&&Explain\nWhat did the programmer learn today?\n&&Pleased\nA surprising amount about bugs. The bugs kept giving it new features.\n&&RestPose', '&&Explain\nWhy did the programmer get everyone’s attention?\n&&Pleased\nIt mentioned bugs, then said, “The bugs kept giving it new features.”\n&&RestPose', '&&Explain\nWhat secret was the programmer keeping?\n&&Pleased\nIt would not say, but it involved bugs. The bugs kept giving it new features.\n&&RestPose', '&&Explain\nWhy was the programmer having a strange day?\n&&Pleased\nToo much bugs for one day. The bugs kept giving it new features.\n&&RestPose', '&&Explain\nWhat advice did the programmer give?\n&&Pleased\n“Never underestimate bugs.” The bugs kept giving it new features.\n&&RestPose', '&&Explain\nWhy did the programmer refuse to panic?\n&&Pleased\nIt had bugs under control. The bugs kept giving it new features.\n&&RestPose', '&&Explain\nWhat made the programmer feel clever?\n&&Pleased\nFinally understanding bugs. The bugs kept giving it new features.\n&&RestPose', '&&Explain\nWhy was the programmer telling jokes?\n&&Pleased\nIt had material about bugs. The bugs kept giving it new features.\n&&RestPose', '&&Explain\nWhat did the programmer say after a long day?\n&&Pleased\n“Enough bugs for today.” The bugs kept giving it new features.\n&&RestPose', '&&Explain\nWhy was the robot smiling?\n&&Pleased\nIt was watching its byte-sized diet.\n&&RestPose', '&&Explain\nWhat did the robot say when things got difficult?\n&&Pleased\nIt was watching its byte-sized diet. That was its whole explanation.\n&&RestPose', '&&Explain\nWhy did the robot stop arguing?\n&&Pleased\nIt was watching its byte-sized diet. There was no point continuing.\n&&RestPose', '&&Explain\nWhat was the robot thinking about?\n&&Pleased\nMostly bytes. It was watching its byte-sized diet.\n&&RestPose', '&&Explain\nWhy did everyone laugh with the robot?\n&&Pleased\nIt was watching its byte-sized diet. Apparently that was funny enough.\n&&RestPose', '&&Explain\nWhat is the robot best known for?\n&&Pleased\nProbably bytes. It was watching its byte-sized diet.\n&&RestPose', '&&Explain\nWhy did the robot need a break?\n&&Pleased\nIt was watching its byte-sized diet. Even a bytes needs a rest sometimes.\n&&RestPose', '&&Explain\nWhat excuse did the robot give?\n&&Pleased\nIt blamed the bytes. It was watching its byte-sized diet.\n&&RestPose', '&&Explain\nWhy was the robot so confident?\n&&Pleased\nIt knew all about bytes. It was watching its byte-sized diet.\n&&RestPose', '&&Explain\nWhat made the robot laugh?\n&&Pleased\nThe thought of bytes. It was watching its byte-sized diet.\n&&RestPose', '&&Explain\nWhy did the robot change its mind?\n&&Pleased\nIt reconsidered the bytes. It was watching its byte-sized diet.\n&&RestPose', '&&Explain\nWhat did the robot learn today?\n&&Pleased\nA surprising amount about bytes. It was watching its byte-sized diet.\n&&RestPose', '&&Explain\nWhy did the robot get everyone’s attention?\n&&Pleased\nIt mentioned bytes, then said, “It was watching its byte-sized diet.”\n&&RestPose', '&&Explain\nWhat secret was the robot keeping?\n&&Pleased\nIt would not say, but it involved bytes. It was watching its byte-sized diet.\n&&RestPose', '&&Explain\nWhy was the robot having a strange day?\n&&Pleased\nToo much bytes for one day. It was watching its byte-sized diet.\n&&RestPose', '&&Explain\nWhat advice did the robot give?\n&&Pleased\n“Never underestimate bytes.” It was watching its byte-sized diet.\n&&RestPose', '&&Explain\nWhy did the robot refuse to panic?\n&&Pleased\nIt had bytes under control. It was watching its byte-sized diet.\n&&RestPose', '&&Explain\nWhat made the robot feel clever?\n&&Pleased\nFinally understanding bytes. It was watching its byte-sized diet.\n&&RestPose', '&&Explain\nWhy was the robot telling jokes?\n&&Pleased\nIt had material about bytes. It was watching its byte-sized diet.\n&&RestPose', '&&Explain\nWhat did the robot say after a long day?\n&&Pleased\n“Enough bytes for today.” It was watching its byte-sized diet.\n&&RestPose', '&&Explain\nWhy was the clock smiling?\n&&Pleased\nIt needed a second to think.\n&&RestPose', '&&Explain\nWhat did the clock say when things got difficult?\n&&Pleased\nIt needed a second to think. That was its whole explanation.\n&&RestPose', '&&Explain\nWhy did the clock stop arguing?\n&&Pleased\nIt needed a second to think. There was no point continuing.\n&&RestPose', '&&Explain\nWhat was the clock thinking about?\n&&Pleased\nMostly second. It needed a second to think.\n&&RestPose', '&&Explain\nWhy did everyone laugh with the clock?\n&&Pleased\nIt needed a second to think. Apparently that was funny enough.\n&&RestPose', '&&Explain\nWhat is the clock best known for?\n&&Pleased\nProbably second. It needed a second to think.\n&&RestPose', '&&Explain\nWhy did the clock need a break?\n&&Pleased\nIt needed a second to think. Even a second needs a rest sometimes.\n&&RestPose', '&&Explain\nWhat excuse did the clock give?\n&&Pleased\nIt blamed the second. It needed a second to think.\n&&RestPose', '&&Explain\nWhy was the clock so confident?\n&&Pleased\nIt knew all about second. It needed a second to think.\n&&RestPose', '&&Explain\nWhat made the clock laugh?\n&&Pleased\nThe thought of second. It needed a second to think.\n&&RestPose', '&&Explain\nWhy did the clock change its mind?\n&&Pleased\nIt reconsidered the second. It needed a second to think.\n&&RestPose', '&&Explain\nWhat did the clock learn today?\n&&Pleased\nA surprising amount about second. It needed a second to think.\n&&RestPose', '&&Explain\nWhy did the clock get everyone’s attention?\n&&Pleased\nIt mentioned second, then said, “It needed a second to think.”\n&&RestPose', '&&Explain\nWhat secret was the clock keeping?\n&&Pleased\nIt would not say, but it involved second. It needed a second to think.\n&&RestPose', '&&Explain\nWhy was the clock having a strange day?\n&&Pleased\nToo much second for one day. It needed a second to think.\n&&RestPose', '&&Explain\nWhat advice did the clock give?\n&&Pleased\n“Never underestimate second.” It needed a second to think.\n&&RestPose', '&&Explain\nWhy did the clock refuse to panic?\n&&Pleased\nIt had second under control. It needed a second to think.\n&&RestPose', '&&Explain\nWhat made the clock feel clever?\n&&Pleased\nFinally understanding second. It needed a second to think.\n&&RestPose', '&&Explain\nWhy was the clock telling jokes?\n&&Pleased\nIt had material about second. It needed a second to think.\n&&RestPose', '&&Explain\nWhat did the clock say after a long day?\n&&Pleased\n“Enough second for today.” It needed a second to think.\n&&RestPose', '&&Explain\nWhy was the calendar smiling?\n&&Pleased\nIt had too many dates already.\n&&RestPose', '&&Explain\nWhat did the calendar say when things got difficult?\n&&Pleased\nIt had too many dates already. That was its whole explanation.\n&&RestPose', '&&Explain\nWhy did the calendar stop arguing?\n&&Pleased\nIt had too many dates already. There was no point continuing.\n&&RestPose', '&&Explain\nWhat was the calendar thinking about?\n&&Pleased\nMostly dates. It had too many dates already.\n&&RestPose', '&&Explain\nWhy did everyone laugh with the calendar?\n&&Pleased\nIt had too many dates already. Apparently that was funny enough.\n&&RestPose', '&&Explain\nWhat is the calendar best known for?\n&&Pleased\nProbably dates. It had too many dates already.\n&&RestPose', '&&Explain\nWhy did the calendar need a break?\n&&Pleased\nIt had too many dates already. Even a dates needs a rest sometimes.\n&&RestPose', '&&Explain\nWhat excuse did the calendar give?\n&&Pleased\nIt blamed the dates. It had too many dates already.\n&&RestPose', '&&Explain\nWhy was the calendar so confident?\n&&Pleased\nIt knew all about dates. It had too many dates already.\n&&RestPose', '&&Explain\nWhat made the calendar laugh?\n&&Pleased\nThe thought of dates. It had too many dates already.\n&&RestPose', '&&Explain\nWhy did the calendar change its mind?\n&&Pleased\nIt reconsidered the dates. It had too many dates already.\n&&RestPose', '&&Explain\nWhat did the calendar learn today?\n&&Pleased\nA surprising amount about dates. It had too many dates already.\n&&RestPose', '&&Explain\nWhy did the calendar get everyone’s attention?\n&&Pleased\nIt mentioned dates, then said, “It had too many dates already.”\n&&RestPose', '&&Explain\nWhat secret was the calendar keeping?\n&&Pleased\nIt would not say, but it involved dates. It had too many dates already.\n&&RestPose', '&&Explain\nWhy was the calendar having a strange day?\n&&Pleased\nToo much dates for one day. It had too many dates already.\n&&RestPose', '&&Explain\nWhat advice did the calendar give?\n&&Pleased\n“Never underestimate dates.” It had too many dates already.\n&&RestPose', '&&Explain\nWhy did the calendar refuse to panic?\n&&Pleased\nIt had dates under control. It had too many dates already.\n&&RestPose', '&&Explain\nWhat made the calendar feel clever?\n&&Pleased\nFinally understanding dates. It had too many dates already.\n&&RestPose', '&&Explain\nWhy was the calendar telling jokes?\n&&Pleased\nIt had material about dates. It had too many dates already.\n&&RestPose', '&&Explain\nWhat did the calendar say after a long day?\n&&Pleased\n“Enough dates for today.” It had too many dates already.\n&&RestPose', '&&Explain\nWhy was the book smiling?\n&&Pleased\nIt wanted to turn over a new page.\n&&RestPose', '&&Explain\nWhat did the book say when things got difficult?\n&&Pleased\nIt wanted to turn over a new page. That was its whole explanation.\n&&RestPose', '&&Explain\nWhy did the book stop arguing?\n&&Pleased\nIt wanted to turn over a new page. There was no point continuing.\n&&RestPose', '&&Explain\nWhat was the book thinking about?\n&&Pleased\nMostly chapters. It wanted to turn over a new page.\n&&RestPose', '&&Explain\nWhy did everyone laugh with the book?\n&&Pleased\nIt wanted to turn over a new page. Apparently that was funny enough.\n&&RestPose', '&&Explain\nWhat is the book best known for?\n&&Pleased\nProbably chapters. It wanted to turn over a new page.\n&&RestPose', '&&Explain\nWhy did the book need a break?\n&&Pleased\nIt wanted to turn over a new page. Even a chapters needs a rest sometimes.\n&&RestPose', '&&Explain\nWhat excuse did the book give?\n&&Pleased\nIt blamed the chapters. It wanted to turn over a new page.\n&&RestPose', '&&Explain\nWhy was the book so confident?\n&&Pleased\nIt knew all about chapters. It wanted to turn over a new page.\n&&RestPose', '&&Explain\nWhat made the book laugh?\n&&Pleased\nThe thought of chapters. It wanted to turn over a new page.\n&&RestPose', '&&Explain\nWhy did the book change its mind?\n&&Pleased\nIt reconsidered the chapters. It wanted to turn over a new page.\n&&RestPose', '&&Explain\nWhat did the book learn today?\n&&Pleased\nA surprising amount about chapters. It wanted to turn over a new page.\n&&RestPose', '&&Explain\nWhy did the book get everyone’s attention?\n&&Pleased\nIt mentioned chapters, then said, “It wanted to turn over a new page.”\n&&RestPose', '&&Explain\nWhat secret was the book keeping?\n&&Pleased\nIt would not say, but it involved chapters. It wanted to turn over a new page.\n&&RestPose', '&&Explain\nWhy was the book having a strange day?\n&&Pleased\nToo much chapters for one day. It wanted to turn over a new page.\n&&RestPose', '&&Explain\nWhat advice did the book give?\n&&Pleased\n“Never underestimate chapters.” It wanted to turn over a new page.\n&&RestPose', '&&Explain\nWhy did the book refuse to panic?\n&&Pleased\nIt had chapters under control. It wanted to turn over a new page.\n&&RestPose', '&&Explain\nWhat made the book feel clever?\n&&Pleased\nFinally understanding chapters. It wanted to turn over a new page.\n&&RestPose', '&&Explain\nWhy was the book telling jokes?\n&&Pleased\nIt had material about chapters. It wanted to turn over a new page.\n&&RestPose', '&&Explain\nWhat did the book say after a long day?\n&&Pleased\n“Enough chapters for today.” It wanted to turn over a new page.\n&&RestPose', '&&Explain\nWhy was the pencil smiling?\n&&Pleased\nIt finally got the point.\n&&RestPose', '&&Explain\nWhat did the pencil say when things got difficult?\n&&Pleased\nIt finally got the point. That was its whole explanation.\n&&RestPose', '&&Explain\nWhy did the pencil stop arguing?\n&&Pleased\nIt finally got the point. There was no point continuing.\n&&RestPose', '&&Explain\nWhat was the pencil thinking about?\n&&Pleased\nMostly point. It finally got the point.\n&&RestPose', '&&Explain\nWhy did everyone laugh with the pencil?\n&&Pleased\nIt finally got the point. Apparently that was funny enough.\n&&RestPose', '&&Explain\nWhat is the pencil best known for?\n&&Pleased\nProbably point. It finally got the point.\n&&RestPose', '&&Explain\nWhy did the pencil need a break?\n&&Pleased\nIt finally got the point. Even a point needs a rest sometimes.\n&&RestPose', '&&Explain\nWhat excuse did the pencil give?\n&&Pleased\nIt blamed the point. It finally got the point.\n&&RestPose', '&&Explain\nWhy was the pencil so confident?\n&&Pleased\nIt knew all about point. It finally got the point.\n&&RestPose', '&&Explain\nWhat made the pencil laugh?\n&&Pleased\nThe thought of point. It finally got the point.\n&&RestPose', '&&Explain\nWhy did the pencil change its mind?\n&&Pleased\nIt reconsidered the point. It finally got the point.\n&&RestPose', '&&Explain\nWhat did the pencil learn today?\n&&Pleased\nA surprising amount about point. It finally got the point.\n&&RestPose', '&&Explain\nWhy did the pencil get everyone’s attention?\n&&Pleased\nIt mentioned point, then said, “It finally got the point.”\n&&RestPose', '&&Explain\nWhat secret was the pencil keeping?\n&&Pleased\nIt would not say, but it involved point. It finally got the point.\n&&RestPose', '&&Explain\nWhy was the pencil having a strange day?\n&&Pleased\nToo much point for one day. It finally got the point.\n&&RestPose', '&&Explain\nWhat advice did the pencil give?\n&&Pleased\n“Never underestimate point.” It finally got the point.\n&&RestPose', '&&Explain\nWhy did the pencil refuse to panic?\n&&Pleased\nIt had point under control. It finally got the point.\n&&RestPose', '&&Explain\nWhat made the pencil feel clever?\n&&Pleased\nFinally understanding point. It finally got the point.\n&&RestPose', '&&Explain\nWhy was the pencil telling jokes?\n&&Pleased\nIt had material about point. It finally got the point.\n&&RestPose', '&&Explain\nWhat did the pencil say after a long day?\n&&Pleased\n“Enough point for today.” It finally got the point.\n&&RestPose', '&&Explain\nWhy was the camera smiling?\n&&Pleased\nIt needed to focus.\n&&RestPose', '&&Explain\nWhat did the camera say when things got difficult?\n&&Pleased\nIt needed to focus. That was its whole explanation.\n&&RestPose', '&&Explain\nWhy did the camera stop arguing?\n&&Pleased\nIt needed to focus. There was no point continuing.\n&&RestPose', '&&Explain\nWhat was the camera thinking about?\n&&Pleased\nMostly focus. It needed to focus.\n&&RestPose', '&&Explain\nWhy did everyone laugh with the camera?\n&&Pleased\nIt needed to focus. Apparently that was funny enough.\n&&RestPose', '&&Explain\nWhat is the camera best known for?\n&&Pleased\nProbably focus. It needed to focus.\n&&RestPose', '&&Explain\nWhy did the camera need a break?\n&&Pleased\nIt needed to focus. Even a focus needs a rest sometimes.\n&&RestPose', '&&Explain\nWhat excuse did the camera give?\n&&Pleased\nIt blamed the focus. It needed to focus.\n&&RestPose', '&&Explain\nWhy was the camera so confident?\n&&Pleased\nIt knew all about focus. It needed to focus.\n&&RestPose', '&&Explain\nWhat made the camera laugh?\n&&Pleased\nThe thought of focus. It needed to focus.\n&&RestPose', '&&Explain\nWhy did the camera change its mind?\n&&Pleased\nIt reconsidered the focus. It needed to focus.\n&&RestPose', '&&Explain\nWhat did the camera learn today?\n&&Pleased\nA surprising amount about focus. It needed to focus.\n&&RestPose', '&&Explain\nWhy did the camera get everyone’s attention?\n&&Pleased\nIt mentioned focus, then said, “It needed to focus.”\n&&RestPose', '&&Explain\nWhat secret was the camera keeping?\n&&Pleased\nIt would not say, but it involved focus. It needed to focus.\n&&RestPose', '&&Explain\nWhy was the camera having a strange day?\n&&Pleased\nToo much focus for one day. It needed to focus.\n&&RestPose', '&&Explain\nWhat advice did the camera give?\n&&Pleased\n“Never underestimate focus.” It needed to focus.\n&&RestPose', '&&Explain\nWhy did the camera refuse to panic?\n&&Pleased\nIt had focus under control. It needed to focus.\n&&RestPose', '&&Explain\nWhat made the camera feel clever?\n&&Pleased\nFinally understanding focus. It needed to focus.\n&&RestPose', '&&Explain\nWhy was the camera telling jokes?\n&&Pleased\nIt had material about focus. It needed to focus.\n&&RestPose', '&&Explain\nWhat did the camera say after a long day?\n&&Pleased\n“Enough focus for today.” It needed to focus.\n&&RestPose', '&&Explain\nWhy was the lamp smiling?\n&&Pleased\nIt finally had a bright idea.\n&&RestPose', '&&Explain\nWhat did the lamp say when things got difficult?\n&&Pleased\nIt finally had a bright idea. That was its whole explanation.\n&&RestPose', '&&Explain\nWhy did the lamp stop arguing?\n&&Pleased\nIt finally had a bright idea. There was no point continuing.\n&&RestPose', '&&Explain\nWhat was the lamp thinking about?\n&&Pleased\nMostly bright idea. It finally had a bright idea.\n&&RestPose', '&&Explain\nWhy did everyone laugh with the lamp?\n&&Pleased\nIt finally had a bright idea. Apparently that was funny enough.\n&&RestPose', '&&Explain\nWhat is the lamp best known for?\n&&Pleased\nProbably bright idea. It finally had a bright idea.\n&&RestPose', '&&Explain\nWhy did the lamp need a break?\n&&Pleased\nIt finally had a bright idea. Even a bright idea needs a rest sometimes.\n&&RestPose', '&&Explain\nWhat excuse did the lamp give?\n&&Pleased\nIt blamed the bright idea. It finally had a bright idea.\n&&RestPose', '&&Explain\nWhy was the lamp so confident?\n&&Pleased\nIt knew all about bright idea. It finally had a bright idea.\n&&RestPose', '&&Explain\nWhat made the lamp laugh?\n&&Pleased\nThe thought of bright idea. It finally had a bright idea.\n&&RestPose', '&&Explain\nWhy did the lamp change its mind?\n&&Pleased\nIt reconsidered the bright idea. It finally had a bright idea.\n&&RestPose', '&&Explain\nWhat did the lamp learn today?\n&&Pleased\nA surprising amount about bright idea. It finally had a bright idea.\n&&RestPose', '&&Explain\nWhy did the lamp get everyone’s attention?\n&&Pleased\nIt mentioned bright idea, then said, “It finally had a bright idea.”\n&&RestPose', '&&Explain\nWhat secret was the lamp keeping?\n&&Pleased\nIt would not say, but it involved bright idea. It finally had a bright idea.\n&&RestPose', '&&Explain\nWhy was the lamp having a strange day?\n&&Pleased\nToo much bright idea for one day. It finally had a bright idea.\n&&RestPose', '&&Explain\nWhat advice did the lamp give?\n&&Pleased\n“Never underestimate bright idea.” It finally had a bright idea.\n&&RestPose', '&&Explain\nWhy did the lamp refuse to panic?\n&&Pleased\nIt had bright idea under control. It finally had a bright idea.\n&&RestPose', '&&Explain\nWhat made the lamp feel clever?\n&&Pleased\nFinally understanding bright idea. It finally had a bright idea.\n&&RestPose', '&&Explain\nWhy was the lamp telling jokes?\n&&Pleased\nIt had material about bright idea. It finally had a bright idea.\n&&RestPose', '&&Explain\nWhat did the lamp say after a long day?\n&&Pleased\n“Enough bright idea for today.” It finally had a bright idea.\n&&RestPose', '&&Explain\nWhy was the magnet smiling?\n&&Pleased\nIt had a very attractive personality.\n&&RestPose', '&&Explain\nWhat did the magnet say when things got difficult?\n&&Pleased\nIt had a very attractive personality. That was its whole explanation.\n&&RestPose', '&&Explain\nWhy did the magnet stop arguing?\n&&Pleased\nIt had a very attractive personality. There was no point continuing.\n&&RestPose', '&&Explain\nWhat was the magnet thinking about?\n&&Pleased\nMostly attraction. It had a very attractive personality.\n&&RestPose', '&&Explain\nWhy did everyone laugh with the magnet?\n&&Pleased\nIt had a very attractive personality. Apparently that was funny enough.\n&&RestPose', '&&Explain\nWhat is the magnet best known for?\n&&Pleased\nProbably attraction. It had a very attractive personality.\n&&RestPose', '&&Explain\nWhy did the magnet need a break?\n&&Pleased\nIt had a very attractive personality. Even a attraction needs a rest sometimes.\n&&RestPose', '&&Explain\nWhat excuse did the magnet give?\n&&Pleased\nIt blamed the attraction. It had a very attractive personality.\n&&RestPose', '&&Explain\nWhy was the magnet so confident?\n&&Pleased\nIt knew all about attraction. It had a very attractive personality.\n&&RestPose', '&&Explain\nWhat made the magnet laugh?\n&&Pleased\nThe thought of attraction. It had a very attractive personality.\n&&RestPose', '&&Explain\nWhy did the magnet change its mind?\n&&Pleased\nIt reconsidered the attraction. It had a very attractive personality.\n&&RestPose', '&&Explain\nWhat did the magnet learn today?\n&&Pleased\nA surprising amount about attraction. It had a very attractive personality.\n&&RestPose', '&&Explain\nWhy did the magnet get everyone’s attention?\n&&Pleased\nIt mentioned attraction, then said, “It had a very attractive personality.”\n&&RestPose', '&&Explain\nWhat secret was the magnet keeping?\n&&Pleased\nIt would not say, but it involved attraction. It had a very attractive personality.\n&&RestPose', '&&Explain\nWhy was the magnet having a strange day?\n&&Pleased\nToo much attraction for one day. It had a very attractive personality.\n&&RestPose', '&&Explain\nWhat advice did the magnet give?\n&&Pleased\n“Never underestimate attraction.” It had a very attractive personality.\n&&RestPose', '&&Explain\nWhy did the magnet refuse to panic?\n&&Pleased\nIt had attraction under control. It had a very attractive personality.\n&&RestPose', '&&Explain\nWhat made the magnet feel clever?\n&&Pleased\nFinally understanding attraction. It had a very attractive personality.\n&&RestPose', '&&Explain\nWhy was the magnet telling jokes?\n&&Pleased\nIt had material about attraction. It had a very attractive personality.\n&&RestPose', '&&Explain\nWhat did the magnet say after a long day?\n&&Pleased\n“Enough attraction for today.” It had a very attractive personality.\n&&RestPose', '&&Explain\nWhy was the broom smiling?\n&&Pleased\nIt was swept up in the moment.\n&&RestPose', '&&Explain\nWhat did the broom say when things got difficult?\n&&Pleased\nIt was swept up in the moment. That was its whole explanation.\n&&RestPose', '&&Explain\nWhy did the broom stop arguing?\n&&Pleased\nIt was swept up in the moment. There was no point continuing.\n&&RestPose', '&&Explain\nWhat was the broom thinking about?\n&&Pleased\nMostly sweep. It was swept up in the moment.\n&&RestPose', '&&Explain\nWhy did everyone laugh with the broom?\n&&Pleased\nIt was swept up in the moment. Apparently that was funny enough.\n&&RestPose', '&&Explain\nWhat is the broom best known for?\n&&Pleased\nProbably sweep. It was swept up in the moment.\n&&RestPose', '&&Explain\nWhy did the broom need a break?\n&&Pleased\nIt was swept up in the moment. Even a sweep needs a rest sometimes.\n&&RestPose', '&&Explain\nWhat excuse did the broom give?\n&&Pleased\nIt blamed the sweep. It was swept up in the moment.\n&&RestPose', '&&Explain\nWhy was the broom so confident?\n&&Pleased\nIt knew all about sweep. It was swept up in the moment.\n&&RestPose', '&&Explain\nWhat made the broom laugh?\n&&Pleased\nThe thought of sweep. It was swept up in the moment.\n&&RestPose', '&&Explain\nWhy did the broom change its mind?\n&&Pleased\nIt reconsidered the sweep. It was swept up in the moment.\n&&RestPose', '&&Explain\nWhat did the broom learn today?\n&&Pleased\nA surprising amount about sweep. It was swept up in the moment.\n&&RestPose', '&&Explain\nWhy did the broom get everyone’s attention?\n&&Pleased\nIt mentioned sweep, then said, “It was swept up in the moment.”\n&&RestPose', '&&Explain\nWhat secret was the broom keeping?\n&&Pleased\nIt would not say, but it involved sweep. It was swept up in the moment.\n&&RestPose', '&&Explain\nWhy was the broom having a strange day?\n&&Pleased\nToo much sweep for one day. It was swept up in the moment.\n&&RestPose', '&&Explain\nWhat advice did the broom give?\n&&Pleased\n“Never underestimate sweep.” It was swept up in the moment.\n&&RestPose', '&&Explain\nWhy did the broom refuse to panic?\n&&Pleased\nIt had sweep under control. It was swept up in the moment.\n&&RestPose', '&&Explain\nWhat made the broom feel clever?\n&&Pleased\nFinally understanding sweep. It was swept up in the moment.\n&&RestPose', '&&Explain\nWhy was the broom telling jokes?\n&&Pleased\nIt had material about sweep. It was swept up in the moment.\n&&RestPose', '&&Explain\nWhat did the broom say after a long day?\n&&Pleased\n“Enough sweep for today.” It was swept up in the moment.\n&&RestPose', '&&Explain\nWhy was the elevator smiling?\n&&Pleased\nIt was taking things to another level.\n&&RestPose', '&&Explain\nWhat did the elevator say when things got difficult?\n&&Pleased\nIt was taking things to another level. That was its whole explanation.\n&&RestPose', '&&Explain\nWhy did the elevator stop arguing?\n&&Pleased\nIt was taking things to another level. There was no point continuing.\n&&RestPose', '&&Explain\nWhat was the elevator thinking about?\n&&Pleased\nMostly levels. It was taking things to another level.\n&&RestPose', '&&Explain\nWhy did everyone laugh with the elevator?\n&&Pleased\nIt was taking things to another level. Apparently that was funny enough.\n&&RestPose', '&&Explain\nWhat is the elevator best known for?\n&&Pleased\nProbably levels. It was taking things to another level.\n&&RestPose', '&&Explain\nWhy did the elevator need a break?\n&&Pleased\nIt was taking things to another level. Even a levels needs a rest sometimes.\n&&RestPose', '&&Explain\nWhat excuse did the elevator give?\n&&Pleased\nIt blamed the levels. It was taking things to another level.\n&&RestPose', '&&Explain\nWhy was the elevator so confident?\n&&Pleased\nIt knew all about levels. It was taking things to another level.\n&&RestPose', '&&Explain\nWhat made the elevator laugh?\n&&Pleased\nThe thought of levels. It was taking things to another level.\n&&RestPose', '&&Explain\nWhy did the elevator change its mind?\n&&Pleased\nIt reconsidered the levels. It was taking things to another level.\n&&RestPose', '&&Explain\nWhat did the elevator learn today?\n&&Pleased\nA surprising amount about levels. It was taking things to another level.\n&&RestPose', '&&Explain\nWhy did the elevator get everyone’s attention?\n&&Pleased\nIt mentioned levels, then said, “It was taking things to another level.”\n&&RestPose', '&&Explain\nWhat secret was the elevator keeping?\n&&Pleased\nIt would not say, but it involved levels. It was taking things to another level.\n&&RestPose', '&&Explain\nWhy was the elevator having a strange day?\n&&Pleased\nToo much levels for one day. It was taking things to another level.\n&&RestPose', '&&Explain\nWhat advice did the elevator give?\n&&Pleased\n“Never underestimate levels.” It was taking things to another level.\n&&RestPose', '&&Explain\nWhy did the elevator refuse to panic?\n&&Pleased\nIt had levels under control. It was taking things to another level.\n&&RestPose', '&&Explain\nWhat made the elevator feel clever?\n&&Pleased\nFinally understanding levels. It was taking things to another level.\n&&RestPose', '&&Explain\nWhy was the elevator telling jokes?\n&&Pleased\nIt had material about levels. It was taking things to another level.\n&&RestPose', '&&Explain\nWhat did the elevator say after a long day?\n&&Pleased\n“Enough levels for today.” It was taking things to another level.\n&&RestPose', '&&Explain\nWhy was the banana smiling?\n&&Pleased\nIt found the situation very a-peeling.\n&&RestPose', '&&Explain\nWhat did the banana say when things got difficult?\n&&Pleased\nIt found the situation very a-peeling. That was its whole explanation.\n&&RestPose', '&&Explain\nWhy did the banana stop arguing?\n&&Pleased\nIt found the situation very a-peeling. There was no point continuing.\n&&RestPose', '&&Explain\nWhat was the banana thinking about?\n&&Pleased\nMostly appeal. It found the situation very a-peeling.\n&&RestPose', '&&Explain\nWhy did everyone laugh with the banana?\n&&Pleased\nIt found the situation very a-peeling. Apparently that was funny enough.\n&&RestPose', '&&Explain\nWhat is the banana best known for?\n&&Pleased\nProbably appeal. It found the situation very a-peeling.\n&&RestPose', '&&Explain\nWhy did the banana need a break?\n&&Pleased\nIt found the situation very a-peeling. Even a appeal needs a rest sometimes.\n&&RestPose', '&&Explain\nWhat excuse did the banana give?\n&&Pleased\nIt blamed the appeal. It found the situation very a-peeling.\n&&RestPose', '&&Explain\nWhy was the banana so confident?\n&&Pleased\nIt knew all about appeal. It found the situation very a-peeling.\n&&RestPose', '&&Explain\nWhat made the banana laugh?\n&&Pleased\nThe thought of appeal. It found the situation very a-peeling.\n&&RestPose', '&&Explain\nWhy did the banana change its mind?\n&&Pleased\nIt reconsidered the appeal. It found the situation very a-peeling.\n&&RestPose', '&&Explain\nWhat did the banana learn today?\n&&Pleased\nA surprising amount about appeal. It found the situation very a-peeling.\n&&RestPose', '&&Explain\nWhy did the banana get everyone’s attention?\n&&Pleased\nIt mentioned appeal, then said, “It found the situation very a-peeling.”\n&&RestPose', '&&Explain\nWhat secret was the banana keeping?\n&&Pleased\nIt would not say, but it involved appeal. It found the situation very a-peeling.\n&&RestPose', '&&Explain\nWhy was the banana having a strange day?\n&&Pleased\nToo much appeal for one day. It found the situation very a-peeling.\n&&RestPose', '&&Explain\nWhat advice did the banana give?\n&&Pleased\n“Never underestimate appeal.” It found the situation very a-peeling.\n&&RestPose', '&&Explain\nWhy did the banana refuse to panic?\n&&Pleased\nIt had appeal under control. It found the situation very a-peeling.\n&&RestPose', '&&Explain\nWhat made the banana feel clever?\n&&Pleased\nFinally understanding appeal. It found the situation very a-peeling.\n&&RestPose', '&&Explain\nWhy was the banana telling jokes?\n&&Pleased\nIt had material about appeal. It found the situation very a-peeling.\n&&RestPose', '&&Explain\nWhat did the banana say after a long day?\n&&Pleased\n“Enough appeal for today.” It found the situation very a-peeling.\n&&RestPose', '&&Explain\nWhy was the orange smiling?\n&&Pleased\nIt ran out of juice.\n&&RestPose', '&&Explain\nWhat did the orange say when things got difficult?\n&&Pleased\nIt ran out of juice. That was its whole explanation.\n&&RestPose', '&&Explain\nWhy did the orange stop arguing?\n&&Pleased\nIt ran out of juice. There was no point continuing.\n&&RestPose', '&&Explain\nWhat was the orange thinking about?\n&&Pleased\nMostly juice. It ran out of juice.\n&&RestPose', '&&Explain\nWhy did everyone laugh with the orange?\n&&Pleased\nIt ran out of juice. Apparently that was funny enough.\n&&RestPose', '&&Explain\nWhat is the orange best known for?\n&&Pleased\nProbably juice. It ran out of juice.\n&&RestPose', '&&Explain\nWhy did the orange need a break?\n&&Pleased\nIt ran out of juice. Even a juice needs a rest sometimes.\n&&RestPose', '&&Explain\nWhat excuse did the orange give?\n&&Pleased\nIt blamed the juice. It ran out of juice.\n&&RestPose', '&&Explain\nWhy was the orange so confident?\n&&Pleased\nIt knew all about juice. It ran out of juice.\n&&RestPose', '&&Explain\nWhat made the orange laugh?\n&&Pleased\nThe thought of juice. It ran out of juice.\n&&RestPose', '&&Explain\nWhy did the orange change its mind?\n&&Pleased\nIt reconsidered the juice. It ran out of juice.\n&&RestPose', '&&Explain\nWhat did the orange learn today?\n&&Pleased\nA surprising amount about juice. It ran out of juice.\n&&RestPose', '&&Explain\nWhy did the orange get everyone’s attention?\n&&Pleased\nIt mentioned juice, then said, “It ran out of juice.”\n&&RestPose', '&&Explain\nWhat secret was the orange keeping?\n&&Pleased\nIt would not say, but it involved juice. It ran out of juice.\n&&RestPose', '&&Explain\nWhy was the orange having a strange day?\n&&Pleased\nToo much juice for one day. It ran out of juice.\n&&RestPose', '&&Explain\nWhat advice did the orange give?\n&&Pleased\n“Never underestimate juice.” It ran out of juice.\n&&RestPose', '&&Explain\nWhy did the orange refuse to panic?\n&&Pleased\nIt had juice under control. It ran out of juice.\n&&RestPose', '&&Explain\nWhat made the orange feel clever?\n&&Pleased\nFinally understanding juice. It ran out of juice.\n&&RestPose', '&&Explain\nWhy was the orange telling jokes?\n&&Pleased\nIt had material about juice. It ran out of juice.\n&&RestPose', '&&Explain\nWhat did the orange say after a long day?\n&&Pleased\n“Enough juice for today.” It ran out of juice.\n&&RestPose', '&&Explain\nWhy was the potato smiling?\n&&Pleased\nIt kept an eye on everything.\n&&RestPose', '&&Explain\nWhat did the potato say when things got difficult?\n&&Pleased\nIt kept an eye on everything. That was its whole explanation.\n&&RestPose', '&&Explain\nWhy did the potato stop arguing?\n&&Pleased\nIt kept an eye on everything. There was no point continuing.\n&&RestPose', '&&Explain\nWhat was the potato thinking about?\n&&Pleased\nMostly eyes. It kept an eye on everything.\n&&RestPose', '&&Explain\nWhy did everyone laugh with the potato?\n&&Pleased\nIt kept an eye on everything. Apparently that was funny enough.\n&&RestPose', '&&Explain\nWhat is the potato best known for?\n&&Pleased\nProbably eyes. It kept an eye on everything.\n&&RestPose', '&&Explain\nWhy did the potato need a break?\n&&Pleased\nIt kept an eye on everything. Even a eyes needs a rest sometimes.\n&&RestPose', '&&Explain\nWhat excuse did the potato give?\n&&Pleased\nIt blamed the eyes. It kept an eye on everything.\n&&RestPose', '&&Explain\nWhy was the potato so confident?\n&&Pleased\nIt knew all about eyes. It kept an eye on everything.\n&&RestPose', '&&Explain\nWhat made the potato laugh?\n&&Pleased\nThe thought of eyes. It kept an eye on everything.\n&&RestPose', '&&Explain\nWhy did the potato change its mind?\n&&Pleased\nIt reconsidered the eyes. It kept an eye on everything.\n&&RestPose', '&&Explain\nWhat did the potato learn today?\n&&Pleased\nA surprising amount about eyes. It kept an eye on everything.\n&&RestPose', '&&Explain\nWhy did the potato get everyone’s attention?\n&&Pleased\nIt mentioned eyes, then said, “It kept an eye on everything.”\n&&RestPose', '&&Explain\nWhat secret was the potato keeping?\n&&Pleased\nIt would not say, but it involved eyes. It kept an eye on everything.\n&&RestPose', '&&Explain\nWhy was the potato having a strange day?\n&&Pleased\nToo much eyes for one day. It kept an eye on everything.\n&&RestPose', '&&Explain\nWhat advice did the potato give?\n&&Pleased\n“Never underestimate eyes.” It kept an eye on everything.\n&&RestPose', '&&Explain\nWhy did the potato refuse to panic?\n&&Pleased\nIt had eyes under control. It kept an eye on everything.\n&&RestPose', '&&Explain\nWhat made the potato feel clever?\n&&Pleased\nFinally understanding eyes. It kept an eye on everything.\n&&RestPose', '&&Explain\nWhy was the potato telling jokes?\n&&Pleased\nIt had material about eyes. It kept an eye on everything.\n&&RestPose', '&&Explain\nWhat did the potato say after a long day?\n&&Pleased\n“Enough eyes for today.” It kept an eye on everything.\n&&RestPose', '&&Explain\nWhy was the tomato smiling?\n&&Pleased\nIt was trying to ketchup.\n&&RestPose', '&&Explain\nWhat did the tomato say when things got difficult?\n&&Pleased\nIt was trying to ketchup. That was its whole explanation.\n&&RestPose', '&&Explain\nWhy did the tomato stop arguing?\n&&Pleased\nIt was trying to ketchup. There was no point continuing.\n&&RestPose', '&&Explain\nWhat was the tomato thinking about?\n&&Pleased\nMostly ketchup. It was trying to ketchup.\n&&RestPose', '&&Explain\nWhy did everyone laugh with the tomato?\n&&Pleased\nIt was trying to ketchup. Apparently that was funny enough.\n&&RestPose', '&&Explain\nWhat is the tomato best known for?\n&&Pleased\nProbably ketchup. It was trying to ketchup.\n&&RestPose', '&&Explain\nWhy did the tomato need a break?\n&&Pleased\nIt was trying to ketchup. Even a ketchup needs a rest sometimes.\n&&RestPose', '&&Explain\nWhat excuse did the tomato give?\n&&Pleased\nIt blamed the ketchup. It was trying to ketchup.\n&&RestPose', '&&Explain\nWhy was the tomato so confident?\n&&Pleased\nIt knew all about ketchup. It was trying to ketchup.\n&&RestPose', '&&Explain\nWhat made the tomato laugh?\n&&Pleased\nThe thought of ketchup. It was trying to ketchup.\n&&RestPose', '&&Explain\nWhy did the tomato change its mind?\n&&Pleased\nIt reconsidered the ketchup. It was trying to ketchup.\n&&RestPose', '&&Explain\nWhat did the tomato learn today?\n&&Pleased\nA surprising amount about ketchup. It was trying to ketchup.\n&&RestPose', '&&Explain\nWhy did the tomato get everyone’s attention?\n&&Pleased\nIt mentioned ketchup, then said, “It was trying to ketchup.”\n&&RestPose', '&&Explain\nWhat secret was the tomato keeping?\n&&Pleased\nIt would not say, but it involved ketchup. It was trying to ketchup.\n&&RestPose', '&&Explain\nWhy was the tomato having a strange day?\n&&Pleased\nToo much ketchup for one day. It was trying to ketchup.\n&&RestPose', '&&Explain\nWhat advice did the tomato give?\n&&Pleased\n“Never underestimate ketchup.” It was trying to ketchup.\n&&RestPose', '&&Explain\nWhy did the tomato refuse to panic?\n&&Pleased\nIt had ketchup under control. It was trying to ketchup.\n&&RestPose', '&&Explain\nWhat made the tomato feel clever?\n&&Pleased\nFinally understanding ketchup. It was trying to ketchup.\n&&RestPose', '&&Explain\nWhy was the tomato telling jokes?\n&&Pleased\nIt had material about ketchup. It was trying to ketchup.\n&&RestPose', '&&Explain\nWhat did the tomato say after a long day?\n&&Pleased\n“Enough ketchup for today.” It was trying to ketchup.\n&&RestPose', '&&Explain\nWhy was the bread smiling?\n&&Pleased\nIt wanted to make a toast.\n&&RestPose', '&&Explain\nWhat did the bread say when things got difficult?\n&&Pleased\nIt wanted to make a toast. That was its whole explanation.\n&&RestPose', '&&Explain\nWhy did the bread stop arguing?\n&&Pleased\nIt wanted to make a toast. There was no point continuing.\n&&RestPose', '&&Explain\nWhat was the bread thinking about?\n&&Pleased\nMostly toast. It wanted to make a toast.\n&&RestPose', '&&Explain\nWhy did everyone laugh with the bread?\n&&Pleased\nIt wanted to make a toast. Apparently that was funny enough.\n&&RestPose', '&&Explain\nWhat is the bread best known for?\n&&Pleased\nProbably toast. It wanted to make a toast.\n&&RestPose', '&&Explain\nWhy did the bread need a break?\n&&Pleased\nIt wanted to make a toast. Even a toast needs a rest sometimes.\n&&RestPose', '&&Explain\nWhat excuse did the bread give?\n&&Pleased\nIt blamed the toast. It wanted to make a toast.\n&&RestPose', '&&Explain\nWhy was the bread so confident?\n&&Pleased\nIt knew all about toast. It wanted to make a toast.\n&&RestPose', '&&Explain\nWhat made the bread laugh?\n&&Pleased\nThe thought of toast. It wanted to make a toast.\n&&RestPose', '&&Explain\nWhy did the bread change its mind?\n&&Pleased\nIt reconsidered the toast. It wanted to make a toast.\n&&RestPose', '&&Explain\nWhat did the bread learn today?\n&&Pleased\nA surprising amount about toast. It wanted to make a toast.\n&&RestPose', '&&Explain\nWhy did the bread get everyone’s attention?\n&&Pleased\nIt mentioned toast, then said, “It wanted to make a toast.”\n&&RestPose', '&&Explain\nWhat secret was the bread keeping?\n&&Pleased\nIt would not say, but it involved toast. It wanted to make a toast.\n&&RestPose', '&&Explain\nWhy was the bread having a strange day?\n&&Pleased\nToo much toast for one day. It wanted to make a toast.\n&&RestPose', '&&Explain\nWhat advice did the bread give?\n&&Pleased\n“Never underestimate toast.” It wanted to make a toast.\n&&RestPose', '&&Explain\nWhy did the bread refuse to panic?\n&&Pleased\nIt had toast under control. It wanted to make a toast.\n&&RestPose', '&&Explain\nWhat made the bread feel clever?\n&&Pleased\nFinally understanding toast. It wanted to make a toast.\n&&RestPose', '&&Explain\nWhy was the bread telling jokes?\n&&Pleased\nIt had material about toast. It wanted to make a toast.\n&&RestPose', '&&Explain\nWhat did the bread say after a long day?\n&&Pleased\n“Enough toast for today.” It wanted to make a toast.\n&&RestPose', '&&Explain\nWhy was the cheese smiling?\n&&Pleased\nIt was feeling grate.\n&&RestPose', '&&Explain\nWhat did the cheese say when things got difficult?\n&&Pleased\nIt was feeling grate. That was its whole explanation.\n&&RestPose', '&&Explain\nWhy did the cheese stop arguing?\n&&Pleased\nIt was feeling grate. There was no point continuing.\n&&RestPose', '&&Explain\nWhat was the cheese thinking about?\n&&Pleased\nMostly grate. It was feeling grate.\n&&RestPose', '&&Explain\nWhy did everyone laugh with the cheese?\n&&Pleased\nIt was feeling grate. Apparently that was funny enough.\n&&RestPose', '&&Explain\nWhat is the cheese best known for?\n&&Pleased\nProbably grate. It was feeling grate.\n&&RestPose', '&&Explain\nWhy did the cheese need a break?\n&&Pleased\nIt was feeling grate. Even a grate needs a rest sometimes.\n&&RestPose', '&&Explain\nWhat excuse did the cheese give?\n&&Pleased\nIt blamed the grate. It was feeling grate.\n&&RestPose', '&&Explain\nWhy was the cheese so confident?\n&&Pleased\nIt knew all about grate. It was feeling grate.\n&&RestPose', '&&Explain\nWhat made the cheese laugh?\n&&Pleased\nThe thought of grate. It was feeling grate.\n&&RestPose', '&&Explain\nWhy did the cheese change its mind?\n&&Pleased\nIt reconsidered the grate. It was feeling grate.\n&&RestPose', '&&Explain\nWhat did the cheese learn today?\n&&Pleased\nA surprising amount about grate. It was feeling grate.\n&&RestPose', '&&Explain\nWhy did the cheese get everyone’s attention?\n&&Pleased\nIt mentioned grate, then said, “It was feeling grate.”\n&&RestPose', '&&Explain\nWhat secret was the cheese keeping?\n&&Pleased\nIt would not say, but it involved grate. It was feeling grate.\n&&RestPose', '&&Explain\nWhy was the cheese having a strange day?\n&&Pleased\nToo much grate for one day. It was feeling grate.\n&&RestPose', '&&Explain\nWhat advice did the cheese give?\n&&Pleased\n“Never underestimate grate.” It was feeling grate.\n&&RestPose', '&&Explain\nWhy did the cheese refuse to panic?\n&&Pleased\nIt had grate under control. It was feeling grate.\n&&RestPose', '&&Explain\nWhat made the cheese feel clever?\n&&Pleased\nFinally understanding grate. It was feeling grate.\n&&RestPose', '&&Explain\nWhy was the cheese telling jokes?\n&&Pleased\nIt had material about grate. It was feeling grate.\n&&RestPose', '&&Explain\nWhat did the cheese say after a long day?\n&&Pleased\n“Enough grate for today.” It was feeling grate.\n&&RestPose', '&&Explain\nWhy was the egg smiling?\n&&Pleased\nIt finally cracked up.\n&&RestPose', '&&Explain\nWhat did the egg say when things got difficult?\n&&Pleased\nIt finally cracked up. That was its whole explanation.\n&&RestPose', '&&Explain\nWhy did the egg stop arguing?\n&&Pleased\nIt finally cracked up. There was no point continuing.\n&&RestPose', '&&Explain\nWhat was the egg thinking about?\n&&Pleased\nMostly crack. It finally cracked up.\n&&RestPose', '&&Explain\nWhy did everyone laugh with the egg?\n&&Pleased\nIt finally cracked up. Apparently that was funny enough.\n&&RestPose', '&&Explain\nWhat is the egg best known for?\n&&Pleased\nProbably crack. It finally cracked up.\n&&RestPose', '&&Explain\nWhy did the egg need a break?\n&&Pleased\nIt finally cracked up. Even a crack needs a rest sometimes.\n&&RestPose', '&&Explain\nWhat excuse did the egg give?\n&&Pleased\nIt blamed the crack. It finally cracked up.\n&&RestPose', '&&Explain\nWhy was the egg so confident?\n&&Pleased\nIt knew all about crack. It finally cracked up.\n&&RestPose', '&&Explain\nWhat made the egg laugh?\n&&Pleased\nThe thought of crack. It finally cracked up.\n&&RestPose', '&&Explain\nWhy did the egg change its mind?\n&&Pleased\nIt reconsidered the crack. It finally cracked up.\n&&RestPose', '&&Explain\nWhat did the egg learn today?\n&&Pleased\nA surprising amount about crack. It finally cracked up.\n&&RestPose', '&&Explain\nWhy did the egg get everyone’s attention?\n&&Pleased\nIt mentioned crack, then said, “It finally cracked up.”\n&&RestPose', '&&Explain\nWhat secret was the egg keeping?\n&&Pleased\nIt would not say, but it involved crack. It finally cracked up.\n&&RestPose', '&&Explain\nWhy was the egg having a strange day?\n&&Pleased\nToo much crack for one day. It finally cracked up.\n&&RestPose', '&&Explain\nWhat advice did the egg give?\n&&Pleased\n“Never underestimate crack.” It finally cracked up.\n&&RestPose', '&&Explain\nWhy did the egg refuse to panic?\n&&Pleased\nIt had crack under control. It finally cracked up.\n&&RestPose', '&&Explain\nWhat made the egg feel clever?\n&&Pleased\nFinally understanding crack. It finally cracked up.\n&&RestPose', '&&Explain\nWhy was the egg telling jokes?\n&&Pleased\nIt had material about crack. It finally cracked up.\n&&RestPose', '&&Explain\nWhat did the egg say after a long day?\n&&Pleased\n“Enough crack for today.” It finally cracked up.\n&&RestPose', '&&Explain\nWhy was the cookie smiling?\n&&Pleased\nIt was falling apart under the crumbs.\n&&RestPose', '&&Explain\nWhat did the cookie say when things got difficult?\n&&Pleased\nIt was falling apart under the crumbs. That was its whole explanation.\n&&RestPose', '&&Explain\nWhy did the cookie stop arguing?\n&&Pleased\nIt was falling apart under the crumbs. There was no point continuing.\n&&RestPose', '&&Explain\nWhat was the cookie thinking about?\n&&Pleased\nMostly crumbs. It was falling apart under the crumbs.\n&&RestPose', '&&Explain\nWhy did everyone laugh with the cookie?\n&&Pleased\nIt was falling apart under the crumbs. Apparently that was funny enough.\n&&RestPose', '&&Explain\nWhat is the cookie best known for?\n&&Pleased\nProbably crumbs. It was falling apart under the crumbs.\n&&RestPose', '&&Explain\nWhy did the cookie need a break?\n&&Pleased\nIt was falling apart under the crumbs. Even a crumbs needs a rest sometimes.\n&&RestPose', '&&Explain\nWhat excuse did the cookie give?\n&&Pleased\nIt blamed the crumbs. It was falling apart under the crumbs.\n&&RestPose', '&&Explain\nWhy was the cookie so confident?\n&&Pleased\nIt knew all about crumbs. It was falling apart under the crumbs.\n&&RestPose', '&&Explain\nWhat made the cookie laugh?\n&&Pleased\nThe thought of crumbs. It was falling apart under the crumbs.\n&&RestPose', '&&Explain\nWhy did the cookie change its mind?\n&&Pleased\nIt reconsidered the crumbs. It was falling apart under the crumbs.\n&&RestPose', '&&Explain\nWhat did the cookie learn today?\n&&Pleased\nA surprising amount about crumbs. It was falling apart under the crumbs.\n&&RestPose', '&&Explain\nWhy did the cookie get everyone’s attention?\n&&Pleased\nIt mentioned crumbs, then said, “It was falling apart under the crumbs.”\n&&RestPose', '&&Explain\nWhat secret was the cookie keeping?\n&&Pleased\nIt would not say, but it involved crumbs. It was falling apart under the crumbs.\n&&RestPose', '&&Explain\nWhy was the cookie having a strange day?\n&&Pleased\nToo much crumbs for one day. It was falling apart under the crumbs.\n&&RestPose', '&&Explain\nWhat advice did the cookie give?\n&&Pleased\n“Never underestimate crumbs.” It was falling apart under the crumbs.\n&&RestPose', '&&Explain\nWhy did the cookie refuse to panic?\n&&Pleased\nIt had crumbs under control. It was falling apart under the crumbs.\n&&RestPose', '&&Explain\nWhat made the cookie feel clever?\n&&Pleased\nFinally understanding crumbs. It was falling apart under the crumbs.\n&&RestPose', '&&Explain\nWhy was the cookie telling jokes?\n&&Pleased\nIt had material about crumbs. It was falling apart under the crumbs.\n&&RestPose', '&&Explain\nWhat did the cookie say after a long day?\n&&Pleased\n“Enough crumbs for today.” It was falling apart under the crumbs.\n&&RestPose', '&&Explain\nWhy was the coffee smiling?\n&&Pleased\nIt had grounds for complaint.\n&&RestPose', '&&Explain\nWhat did the coffee say when things got difficult?\n&&Pleased\nIt had grounds for complaint. That was its whole explanation.\n&&RestPose', '&&Explain\nWhy did the coffee stop arguing?\n&&Pleased\nIt had grounds for complaint. There was no point continuing.\n&&RestPose', '&&Explain\nWhat was the coffee thinking about?\n&&Pleased\nMostly grounds. It had grounds for complaint.\n&&RestPose', '&&Explain\nWhy did everyone laugh with the coffee?\n&&Pleased\nIt had grounds for complaint. Apparently that was funny enough.\n&&RestPose', '&&Explain\nWhat is the coffee best known for?\n&&Pleased\nProbably grounds. It had grounds for complaint.\n&&RestPose', '&&Explain\nWhy did the coffee need a break?\n&&Pleased\nIt had grounds for complaint. Even a grounds needs a rest sometimes.\n&&RestPose', '&&Explain\nWhat excuse did the coffee give?\n&&Pleased\nIt blamed the grounds. It had grounds for complaint.\n&&RestPose', '&&Explain\nWhy was the coffee so confident?\n&&Pleased\nIt knew all about grounds. It had grounds for complaint.\n&&RestPose', '&&Explain\nWhat made the coffee laugh?\n&&Pleased\nThe thought of grounds. It had grounds for complaint.\n&&RestPose', '&&Explain\nWhy did the coffee change its mind?\n&&Pleased\nIt reconsidered the grounds. It had grounds for complaint.\n&&RestPose', '&&Explain\nWhat did the coffee learn today?\n&&Pleased\nA surprising amount about grounds. It had grounds for complaint.\n&&RestPose', '&&Explain\nWhy did the coffee get everyone’s attention?\n&&Pleased\nIt mentioned grounds, then said, “It had grounds for complaint.”\n&&RestPose', '&&Explain\nWhat secret was the coffee keeping?\n&&Pleased\nIt would not say, but it involved grounds. It had grounds for complaint.\n&&RestPose', '&&Explain\nWhy was the coffee having a strange day?\n&&Pleased\nToo much grounds for one day. It had grounds for complaint.\n&&RestPose', '&&Explain\nWhat advice did the coffee give?\n&&Pleased\n“Never underestimate grounds.” It had grounds for complaint.\n&&RestPose', '&&Explain\nWhy did the coffee refuse to panic?\n&&Pleased\nIt had grounds under control. It had grounds for complaint.\n&&RestPose', '&&Explain\nWhat made the coffee feel clever?\n&&Pleased\nFinally understanding grounds. It had grounds for complaint.\n&&RestPose', '&&Explain\nWhy was the coffee telling jokes?\n&&Pleased\nIt had material about grounds. It had grounds for complaint.\n&&RestPose', '&&Explain\nWhat did the coffee say after a long day?\n&&Pleased\n“Enough grounds for today.” It had grounds for complaint.\n&&RestPose', '&&Explain\nWhy was the tea smiling?\n&&Pleased\nIt was having a brew-tiful day.\n&&RestPose', '&&Explain\nWhat did the tea say when things got difficult?\n&&Pleased\nIt was having a brew-tiful day. That was its whole explanation.\n&&RestPose', '&&Explain\nWhy did the tea stop arguing?\n&&Pleased\nIt was having a brew-tiful day. There was no point continuing.\n&&RestPose', '&&Explain\nWhat was the tea thinking about?\n&&Pleased\nMostly mug. It was having a brew-tiful day.\n&&RestPose', '&&Explain\nWhy did everyone laugh with the tea?\n&&Pleased\nIt was having a brew-tiful day. Apparently that was funny enough.\n&&RestPose', '&&Explain\nWhat is the tea best known for?\n&&Pleased\nProbably mug. It was having a brew-tiful day.\n&&RestPose', '&&Explain\nWhy did the tea need a break?\n&&Pleased\nIt was having a brew-tiful day. Even a mug needs a rest sometimes.\n&&RestPose', '&&Explain\nWhat excuse did the tea give?\n&&Pleased\nIt blamed the mug. It was having a brew-tiful day.\n&&RestPose', '&&Explain\nWhy was the tea so confident?\n&&Pleased\nIt knew all about mug. It was having a brew-tiful day.\n&&RestPose', '&&Explain\nWhat made the tea laugh?\n&&Pleased\nThe thought of mug. It was having a brew-tiful day.\n&&RestPose', '&&Explain\nWhy did the tea change its mind?\n&&Pleased\nIt reconsidered the mug. It was having a brew-tiful day.\n&&RestPose', '&&Explain\nWhat did the tea learn today?\n&&Pleased\nA surprising amount about mug. It was having a brew-tiful day.\n&&RestPose', '&&Explain\nWhy did the tea get everyone’s attention?\n&&Pleased\nIt mentioned mug, then said, “It was having a brew-tiful day.”\n&&RestPose', '&&Explain\nWhat secret was the tea keeping?\n&&Pleased\nIt would not say, but it involved mug. It was having a brew-tiful day.\n&&RestPose', '&&Explain\nWhy was the tea having a strange day?\n&&Pleased\nToo much mug for one day. It was having a brew-tiful day.\n&&RestPose', '&&Explain\nWhat advice did the tea give?\n&&Pleased\n“Never underestimate mug.” It was having a brew-tiful day.\n&&RestPose', '&&Explain\nWhy did the tea refuse to panic?\n&&Pleased\nIt had mug under control. It was having a brew-tiful day.\n&&RestPose', '&&Explain\nWhat made the tea feel clever?\n&&Pleased\nFinally understanding mug. It was having a brew-tiful day.\n&&RestPose', '&&Explain\nWhy was the tea telling jokes?\n&&Pleased\nIt had material about mug. It was having a brew-tiful day.\n&&RestPose', '&&Explain\nWhat did the tea say after a long day?\n&&Pleased\n“Enough mug for today.” It was having a brew-tiful day.\n&&RestPose'), 'thought': ('&&Explain\nstarting over often becomes clearer after listen before answering.\n&&RestPose', '&&Explain\na difficult problem often becomes clearer after try one smaller step.\n&&RestPose', '&&Explain\na new idea often becomes clearer after write it down before judging it.\n&&RestPose', '&&Explain\nuncertainty often becomes clearer after ask a better question.\n&&RestPose', '&&Explain\na busy day often becomes clearer after finish one thing at a time.\n&&RestPose', '&&Explain\nlearning something unfamiliar often becomes clearer after stay curious a little longer.\n&&RestPose', '&&Explain\nWhen practice, accept an imperfect first attempt may be more useful than another explanation.\n&&RestPose', '&&Explain\nWhen a disagreement, understand the other point of view may be more useful than another explanation.\n&&RestPose', '&&Explain\nWhen an old routine, try a different route may be more useful than another explanation.\n&&RestPose', '&&Explain\nWhen good work, take a proper break afterward may be more useful than another explanation.\n&&RestPose', '&&Explain\nWhen a surprising result, look for what caused it may be more useful than another explanation.\n&&RestPose', '&&Explain\nWhen quiet time, notice what was easy to miss may be more useful than another explanation.\n&&RestPose', '&&Explain\nThere is value in a slow afternoon, especially when enjoy the lack of urgency.\n&&RestPose', '&&Explain\nThere is value in a small success, especially when remember how it started.\n&&RestPose', '&&Explain\nThere is value in a wrong turn, especially when find something useful along the way.\n&&RestPose', '&&Explain\nThere is value in a hard lesson, especially when use it without carrying the frustration.\n&&RestPose', '&&Explain\nThere is value in helping someone, especially when leave them room to decide.\n&&RestPose', '&&Explain\nThere is value in making plans, especially when allow for the unexpected.\n&&RestPose', '&&Explain\nSometimes a long project is simply another way of recognize the progress already made.\n&&RestPose', '&&Explain\nSometimes asking questions is simply another way of listen carefully to the answer.\n&&RestPose', '&&Explain\nSometimes trying again is simply another way of change one thing instead of everything.\n&&RestPose', '&&Explain\nSometimes solving things is simply another way of step away for a few minutes.\n&&RestPose', '&&Explain\nSometimes being prepared is simply another way of adapt when the plan changes.\n&&RestPose', '&&Explain\nSometimes a familiar place is simply another way of look at one detail differently.\n&&RestPose', '&&Explain\nA day feels different when a useful habit and make it easy to repeat.\n&&RestPose', '&&Explain\nA day feels different when a funny mistake and laugh and remember the lesson.\n&&RestPose', '&&Explain\nA day feels different when good timing and wait without losing momentum.\n&&RestPose', '&&Explain\nA day feels different when an unexpected delay and use the extra minute well.\n&&RestPose', '&&Explain\nA day feels different when a blank page and put down the first honest sentence.\n&&RestPose', '&&Explain\nA day feels different when a complicated choice and remove what does not matter.\n&&RestPose', '&&Explain\nIt is easy to overlook a moment of doubt until remember what you already know.\n&&RestPose', "&&Explain\nIt is easy to overlook today's work until leave something easier for tomorrow.\n&&RestPose", '&&Explain\nIt is easy to overlook a new skill until notice small improvements.\n&&RestPose', '&&Explain\nIt is easy to overlook an unanswered question until keep exploring without forcing an answer.\n&&RestPose', '&&Explain\nIt is easy to overlook a conversation until say less and mean it.\n&&RestPose', '&&Explain\nIt is easy to overlook a change in plans until find the part that still works.\n&&RestPose', '&&Explain\nThe quiet part of starting over is learning listen before answering.\n&&RestPose', '&&Explain\nThe quiet part of a difficult problem is learning try one smaller step.\n&&RestPose', '&&Explain\nThe quiet part of a new idea is learning write it down before judging it.\n&&RestPose', '&&Explain\nThe quiet part of uncertainty is learning ask a better question.\n&&RestPose', '&&Explain\nThe quiet part of a busy day is learning finish one thing at a time.\n&&RestPose', '&&Explain\nThe quiet part of learning something unfamiliar is learning stay curious a little longer.\n&&RestPose', '&&Explain\nNot every answer arrives quickly; practice may require accept an imperfect first attempt.\n&&RestPose', '&&Explain\nNot every answer arrives quickly; a disagreement may require understand the other point of view.\n&&RestPose', '&&Explain\nNot every answer arrives quickly; an old routine may require try a different route.\n&&RestPose', '&&Explain\nNot every answer arrives quickly; good work may require take a proper break afterward.\n&&RestPose', '&&Explain\nNot every answer arrives quickly; a surprising result may require look for what caused it.\n&&RestPose', '&&Explain\nNot every answer arrives quickly; quiet time may require notice what was easy to miss.\n&&RestPose', '&&Explain\nA useful question is whether a slow afternoon is helping you enjoy the lack of urgency.\n&&RestPose', '&&Explain\nA useful question is whether a small success is helping you remember how it started.\n&&RestPose', '&&Explain\nA useful question is whether a wrong turn is helping you find something useful along the way.\n&&RestPose', '&&Explain\nA useful question is whether a hard lesson is helping you use it without carrying the frustration.\n&&RestPose', '&&Explain\nA useful question is whether helping someone is helping you leave them room to decide.\n&&RestPose', '&&Explain\nA useful question is whether making plans is helping you allow for the unexpected.\n&&RestPose', '&&Explain\nSmall moments of a long project leave more room for recognize the progress already made.\n&&RestPose', '&&Explain\nSmall moments of asking questions leave more room for listen carefully to the answer.\n&&RestPose', '&&Explain\nSmall moments of trying again leave more room for change one thing instead of everything.\n&&RestPose', '&&Explain\nSmall moments of solving things leave more room for step away for a few minutes.\n&&RestPose', '&&Explain\nSmall moments of being prepared leave more room for adapt when the plan changes.\n&&RestPose', '&&Explain\nSmall moments of a familiar place leave more room for look at one detail differently.\n&&RestPose', '&&Explain\nYou notice more about a useful habit when you stop trying to make it easy to repeat.\n&&RestPose', '&&Explain\nYou notice more about a funny mistake when you stop trying to laugh and remember the lesson.\n&&RestPose', '&&Explain\nYou notice more about good timing when you stop trying to wait without losing momentum.\n&&RestPose', '&&Explain\nYou notice more about an unexpected delay when you stop trying to use the extra minute well.\n&&RestPose', '&&Explain\nYou notice more about a blank page when you stop trying to put down the first honest sentence.\n&&RestPose', '&&Explain\nYou notice more about a complicated choice when you stop trying to remove what does not matter.\n&&RestPose', '&&Explain\nOne way forward is to let a moment of doubt make space for remember what you already know.\n&&RestPose', "&&Explain\nOne way forward is to let today's work make space for leave something easier for tomorrow.\n&&RestPose", '&&Explain\nOne way forward is to let a new skill make space for notice small improvements.\n&&RestPose', '&&Explain\nOne way forward is to let an unanswered question make space for keep exploring without forcing an answer.\n&&RestPose', '&&Explain\nOne way forward is to let a conversation make space for say less and mean it.\n&&RestPose', '&&Explain\nOne way forward is to let a change in plans make space for find the part that still works.\n&&RestPose', '&&Explain\nGood ideas about starting over sometimes appear while listen before answering.\n&&RestPose', '&&Explain\nGood ideas about a difficult problem sometimes appear while try one smaller step.\n&&RestPose', '&&Explain\nGood ideas about a new idea sometimes appear while write it down before judging it.\n&&RestPose', '&&Explain\nGood ideas about uncertainty sometimes appear while ask a better question.\n&&RestPose', '&&Explain\nGood ideas about a busy day sometimes appear while finish one thing at a time.\n&&RestPose', '&&Explain\nGood ideas about learning something unfamiliar sometimes appear while stay curious a little longer.\n&&RestPose', '&&Explain\nThe hardest part of practice may be deciding when to accept an imperfect first attempt.\n&&RestPose', '&&Explain\nThe hardest part of a disagreement may be deciding when to understand the other point of view.\n&&RestPose', '&&Explain\nThe hardest part of an old routine may be deciding when to try a different route.\n&&RestPose', '&&Explain\nThe hardest part of good work may be deciding when to take a proper break afterward.\n&&RestPose', '&&Explain\nThe hardest part of a surprising result may be deciding when to look for what caused it.\n&&RestPose', '&&Explain\nThe hardest part of quiet time may be deciding when to notice what was easy to miss.\n&&RestPose', '&&Explain\nThere is no rule saying a slow afternoon must happen before enjoy the lack of urgency.\n&&RestPose', '&&Explain\nThere is no rule saying a small success must happen before remember how it started.\n&&RestPose', '&&Explain\nThere is no rule saying a wrong turn must happen before find something useful along the way.\n&&RestPose', '&&Explain\nThere is no rule saying a hard lesson must happen before use it without carrying the frustration.\n&&RestPose', '&&Explain\nThere is no rule saying helping someone must happen before leave them room to decide.\n&&RestPose', '&&Explain\nThere is no rule saying making plans must happen before allow for the unexpected.\n&&RestPose', '&&Explain\nA little a long project goes a long way when recognize the progress already made.\n&&RestPose', '&&Explain\nA little asking questions goes a long way when listen carefully to the answer.\n&&RestPose', '&&Explain\nA little trying again goes a long way when change one thing instead of everything.\n&&RestPose', '&&Explain\nA little solving things goes a long way when step away for a few minutes.\n&&RestPose', '&&Explain\nA little being prepared goes a long way when adapt when the plan changes.\n&&RestPose', '&&Explain\nA little a familiar place goes a long way when look at one detail differently.\n&&RestPose', '&&Explain\nWhat looks like a useful habit today might become make it easy to repeat tomorrow.\n&&RestPose', '&&Explain\nWhat looks like a funny mistake today might become laugh and remember the lesson tomorrow.\n&&RestPose', '&&Explain\nWhat looks like good timing today might become wait without losing momentum tomorrow.\n&&RestPose', '&&Explain\nWhat looks like an unexpected delay today might become use the extra minute well tomorrow.\n&&RestPose', '&&Explain\nWhat looks like a blank page today might become put down the first honest sentence tomorrow.\n&&RestPose', '&&Explain\nWhat looks like a complicated choice today might become remove what does not matter tomorrow.\n&&RestPose', '&&Explain\nThe difference between waiting and a moment of doubt is often remember what you already know.\n&&RestPose', "&&Explain\nThe difference between waiting and today's work is often leave something easier for tomorrow.\n&&RestPose", '&&Explain\nThe difference between waiting and a new skill is often notice small improvements.\n&&RestPose', '&&Explain\nThe difference between waiting and an unanswered question is often keep exploring without forcing an answer.\n&&RestPose', '&&Explain\nThe difference between waiting and a conversation is often say less and mean it.\n&&RestPose', '&&Explain\nThe difference between waiting and a change in plans is often find the part that still works.\n&&RestPose', '&&Explain\nIf starting over feels complicated, begin by listen before answering.\n&&RestPose', '&&Explain\nIf a difficult problem feels complicated, begin by try one smaller step.\n&&RestPose', '&&Explain\nIf a new idea feels complicated, begin by write it down before judging it.\n&&RestPose', '&&Explain\nIf uncertainty feels complicated, begin by ask a better question.\n&&RestPose', '&&Explain\nIf a busy day feels complicated, begin by finish one thing at a time.\n&&RestPose', '&&Explain\nIf learning something unfamiliar feels complicated, begin by stay curious a little longer.\n&&RestPose', '&&Explain\nIt is surprising how much practice improves after accept an imperfect first attempt.\n&&RestPose', '&&Explain\nIt is surprising how much a disagreement improves after understand the other point of view.\n&&RestPose', '&&Explain\nIt is surprising how much an old routine improves after try a different route.\n&&RestPose', '&&Explain\nIt is surprising how much good work improves after take a proper break afterward.\n&&RestPose', '&&Explain\nIt is surprising how much a surprising result improves after look for what caused it.\n&&RestPose', '&&Explain\nIt is surprising how much quiet time improves after notice what was easy to miss.\n&&RestPose', '&&Explain\nSome days are better for a slow afternoon; others are better for enjoy the lack of urgency.\n&&RestPose', '&&Explain\nSome days are better for a small success; others are better for remember how it started.\n&&RestPose', '&&Explain\nSome days are better for a wrong turn; others are better for find something useful along the way.\n&&RestPose', '&&Explain\nSome days are better for a hard lesson; others are better for use it without carrying the frustration.\n&&RestPose', '&&Explain\nSome days are better for helping someone; others are better for leave them room to decide.\n&&RestPose', '&&Explain\nSome days are better for making plans; others are better for allow for the unexpected.\n&&RestPose', '&&Explain\nA fresh look at a long project may reveal recognize the progress already made.\n&&RestPose', '&&Explain\nA fresh look at asking questions may reveal listen carefully to the answer.\n&&RestPose', '&&Explain\nA fresh look at trying again may reveal change one thing instead of everything.\n&&RestPose', '&&Explain\nA fresh look at solving things may reveal step away for a few minutes.\n&&RestPose', '&&Explain\nA fresh look at being prepared may reveal adapt when the plan changes.\n&&RestPose', '&&Explain\nA fresh look at a familiar place may reveal look at one detail differently.\n&&RestPose', '&&Explain\nBefore giving up on a useful habit, try make it easy to repeat.\n&&RestPose', '&&Explain\nBefore giving up on a funny mistake, try laugh and remember the lesson.\n&&RestPose', '&&Explain\nBefore giving up on good timing, try wait without losing momentum.\n&&RestPose', '&&Explain\nBefore giving up on an unexpected delay, try use the extra minute well.\n&&RestPose', '&&Explain\nBefore giving up on a blank page, try put down the first honest sentence.\n&&RestPose', '&&Explain\nBefore giving up on a complicated choice, try remove what does not matter.\n&&RestPose', '&&Explain\nThe best thing about a moment of doubt may be the chance to remember what you already know.\n&&RestPose', "&&Explain\nThe best thing about today's work may be the chance to leave something easier for tomorrow.\n&&RestPose", '&&Explain\nThe best thing about a new skill may be the chance to notice small improvements.\n&&RestPose', '&&Explain\nThe best thing about an unanswered question may be the chance to keep exploring without forcing an answer.\n&&RestPose', '&&Explain\nThe best thing about a conversation may be the chance to say less and mean it.\n&&RestPose', '&&Explain\nThe best thing about a change in plans may be the chance to find the part that still works.\n&&RestPose', '&&Explain\nEven ordinary starting over can become interesting when listen before answering.\n&&RestPose', '&&Explain\nEven ordinary a difficult problem can become interesting when try one smaller step.\n&&RestPose', '&&Explain\nEven ordinary a new idea can become interesting when write it down before judging it.\n&&RestPose', '&&Explain\nEven ordinary uncertainty can become interesting when ask a better question.\n&&RestPose', '&&Explain\nEven ordinary a busy day can become interesting when finish one thing at a time.\n&&RestPose', '&&Explain\nEven ordinary learning something unfamiliar can become interesting when stay curious a little longer.\n&&RestPose', '&&Explain\nThere is more than one way to approach practice, including accept an imperfect first attempt.\n&&RestPose', '&&Explain\nThere is more than one way to approach a disagreement, including understand the other point of view.\n&&RestPose', '&&Explain\nThere is more than one way to approach an old routine, including try a different route.\n&&RestPose', '&&Explain\nThere is more than one way to approach good work, including take a proper break afterward.\n&&RestPose', '&&Explain\nThere is more than one way to approach a surprising result, including look for what caused it.\n&&RestPose', '&&Explain\nThere is more than one way to approach quiet time, including notice what was easy to miss.\n&&RestPose', '&&Explain\nA mistake involving a slow afternoon can still teach you enjoy the lack of urgency.\n&&RestPose', '&&Explain\nA mistake involving a small success can still teach you remember how it started.\n&&RestPose', '&&Explain\nA mistake involving a wrong turn can still teach you find something useful along the way.\n&&RestPose', '&&Explain\nA mistake involving a hard lesson can still teach you use it without carrying the frustration.\n&&RestPose', '&&Explain\nA mistake involving helping someone can still teach you leave them room to decide.\n&&RestPose', '&&Explain\nA mistake involving making plans can still teach you allow for the unexpected.\n&&RestPose', '&&Explain\nPatience with a long project makes it easier to notice recognize the progress already made.\n&&RestPose', '&&Explain\nPatience with asking questions makes it easier to notice listen carefully to the answer.\n&&RestPose', '&&Explain\nPatience with trying again makes it easier to notice change one thing instead of everything.\n&&RestPose', '&&Explain\nPatience with solving things makes it easier to notice step away for a few minutes.\n&&RestPose', '&&Explain\nPatience with being prepared makes it easier to notice adapt when the plan changes.\n&&RestPose', '&&Explain\nPatience with a familiar place makes it easier to notice look at one detail differently.\n&&RestPose', '&&Explain\nYou do not have to master a useful habit to appreciate make it easy to repeat.\n&&RestPose', '&&Explain\nYou do not have to master a funny mistake to appreciate laugh and remember the lesson.\n&&RestPose', '&&Explain\nYou do not have to master good timing to appreciate wait without losing momentum.\n&&RestPose', '&&Explain\nYou do not have to master an unexpected delay to appreciate use the extra minute well.\n&&RestPose', '&&Explain\nYou do not have to master a blank page to appreciate put down the first honest sentence.\n&&RestPose', '&&Explain\nYou do not have to master a complicated choice to appreciate remove what does not matter.\n&&RestPose', '&&Explain\nA pause between a moment of doubt and remember what you already know can be useful.\n&&RestPose', "&&Explain\nA pause between today's work and leave something easier for tomorrow can be useful.\n&&RestPose", '&&Explain\nA pause between a new skill and notice small improvements can be useful.\n&&RestPose', '&&Explain\nA pause between an unanswered question and keep exploring without forcing an answer can be useful.\n&&RestPose', '&&Explain\nA pause between a conversation and say less and mean it can be useful.\n&&RestPose', '&&Explain\nA pause between a change in plans and find the part that still works can be useful.\n&&RestPose', '&&Explain\nCuriosity turns starting over into an opportunity for listen before answering.\n&&RestPose', '&&Explain\nCuriosity turns a difficult problem into an opportunity for try one smaller step.\n&&RestPose', '&&Explain\nCuriosity turns a new idea into an opportunity for write it down before judging it.\n&&RestPose', '&&Explain\nCuriosity turns uncertainty into an opportunity for ask a better question.\n&&RestPose', '&&Explain\nCuriosity turns a busy day into an opportunity for finish one thing at a time.\n&&RestPose', '&&Explain\nCuriosity turns learning something unfamiliar into an opportunity for stay curious a little longer.\n&&RestPose', '&&Explain\nThe next time you think about practice, remember accept an imperfect first attempt.\n&&RestPose', '&&Explain\nThe next time you think about a disagreement, remember understand the other point of view.\n&&RestPose', '&&Explain\nThe next time you think about an old routine, remember try a different route.\n&&RestPose', '&&Explain\nThe next time you think about good work, remember take a proper break afterward.\n&&RestPose', '&&Explain\nThe next time you think about a surprising result, remember look for what caused it.\n&&RestPose', '&&Explain\nThe next time you think about quiet time, remember notice what was easy to miss.\n&&RestPose', '&&Explain\nProgress with a slow afternoon is easier to see after enjoy the lack of urgency.\n&&RestPose', '&&Explain\nProgress with a small success is easier to see after remember how it started.\n&&RestPose', '&&Explain\nProgress with a wrong turn is easier to see after find something useful along the way.\n&&RestPose', '&&Explain\nProgress with a hard lesson is easier to see after use it without carrying the frustration.\n&&RestPose', '&&Explain\nProgress with helping someone is easier to see after leave them room to decide.\n&&RestPose', '&&Explain\nProgress with making plans is easier to see after allow for the unexpected.\n&&RestPose', '&&Explain\nThere are days when a long project matters less than recognize the progress already made.\n&&RestPose', '&&Explain\nThere are days when asking questions matters less than listen carefully to the answer.\n&&RestPose', '&&Explain\nThere are days when trying again matters less than change one thing instead of everything.\n&&RestPose', '&&Explain\nThere are days when solving things matters less than step away for a few minutes.\n&&RestPose', '&&Explain\nThere are days when being prepared matters less than adapt when the plan changes.\n&&RestPose', '&&Explain\nThere are days when a familiar place matters less than look at one detail differently.\n&&RestPose', '&&Explain\nThe simple act of a useful habit can lead unexpectedly to make it easy to repeat.\n&&RestPose', '&&Explain\nThe simple act of a funny mistake can lead unexpectedly to laugh and remember the lesson.\n&&RestPose', '&&Explain\nThe simple act of good timing can lead unexpectedly to wait without losing momentum.\n&&RestPose', '&&Explain\nThe simple act of an unexpected delay can lead unexpectedly to use the extra minute well.\n&&RestPose', '&&Explain\nThe simple act of a blank page can lead unexpectedly to put down the first honest sentence.\n&&RestPose', '&&Explain\nThe simple act of a complicated choice can lead unexpectedly to remove what does not matter.\n&&RestPose', '&&Explain\nA better understanding of a moment of doubt starts with remember what you already know.\n&&RestPose', "&&Explain\nA better understanding of today's work starts with leave something easier for tomorrow.\n&&RestPose", '&&Explain\nA better understanding of a new skill starts with notice small improvements.\n&&RestPose', '&&Explain\nA better understanding of an unanswered question starts with keep exploring without forcing an answer.\n&&RestPose', '&&Explain\nA better understanding of a conversation starts with say less and mean it.\n&&RestPose', '&&Explain\nA better understanding of a change in plans starts with find the part that still works.\n&&RestPose', '&&Explain\nYou may not control starting over, but you can still choose listen before answering.\n&&RestPose', '&&Explain\nYou may not control a difficult problem, but you can still choose try one smaller step.\n&&RestPose', '&&Explain\nYou may not control a new idea, but you can still choose write it down before judging it.\n&&RestPose', '&&Explain\nYou may not control uncertainty, but you can still choose ask a better question.\n&&RestPose', '&&Explain\nYou may not control a busy day, but you can still choose finish one thing at a time.\n&&RestPose', '&&Explain\nYou may not control learning something unfamiliar, but you can still choose stay curious a little longer.\n&&RestPose', '&&Explain\nSometimes the sensible response to practice is accept an imperfect first attempt.\n&&RestPose', '&&Explain\nSometimes the sensible response to a disagreement is understand the other point of view.\n&&RestPose', '&&Explain\nSometimes the sensible response to an old routine is try a different route.\n&&RestPose', '&&Explain\nSometimes the sensible response to good work is take a proper break afterward.\n&&RestPose', '&&Explain\nSometimes the sensible response to a surprising result is look for what caused it.\n&&RestPose', '&&Explain\nSometimes the sensible response to quiet time is notice what was easy to miss.\n&&RestPose', '&&Explain\nNothing makes a slow afternoon perfect, but enjoy the lack of urgency can make it worthwhile.\n&&RestPose', '&&Explain\nNothing makes a small success perfect, but remember how it started can make it worthwhile.\n&&RestPose', '&&Explain\nNothing makes a wrong turn perfect, but find something useful along the way can make it worthwhile.\n&&RestPose', '&&Explain\nNothing makes a hard lesson perfect, but use it without carrying the frustration can make it worthwhile.\n&&RestPose', '&&Explain\nNothing makes helping someone perfect, but leave them room to decide can make it worthwhile.\n&&RestPose', '&&Explain\nNothing makes making plans perfect, but allow for the unexpected can make it worthwhile.\n&&RestPose', '&&Explain\nA new perspective on a long project begins when recognize the progress already made.\n&&RestPose', '&&Explain\nA new perspective on asking questions begins when listen carefully to the answer.\n&&RestPose', '&&Explain\nA new perspective on trying again begins when change one thing instead of everything.\n&&RestPose', '&&Explain\nA new perspective on solving things begins when step away for a few minutes.\n&&RestPose', '&&Explain\nA new perspective on being prepared begins when adapt when the plan changes.\n&&RestPose', '&&Explain\nA new perspective on a familiar place begins when look at one detail differently.\n&&RestPose', '&&Explain\nIt takes practice to balance a useful habit with make it easy to repeat.\n&&RestPose', '&&Explain\nIt takes practice to balance a funny mistake with laugh and remember the lesson.\n&&RestPose', '&&Explain\nIt takes practice to balance good timing with wait without losing momentum.\n&&RestPose', '&&Explain\nIt takes practice to balance an unexpected delay with use the extra minute well.\n&&RestPose', '&&Explain\nIt takes practice to balance a blank page with put down the first honest sentence.\n&&RestPose', '&&Explain\nIt takes practice to balance a complicated choice with remove what does not matter.\n&&RestPose', '&&Explain\nThe useful lesson in a moment of doubt may have nothing to do with remember what you already know.\n&&RestPose', "&&Explain\nThe useful lesson in today's work may have nothing to do with leave something easier for tomorrow.\n&&RestPose", '&&Explain\nThe useful lesson in a new skill may have nothing to do with notice small improvements.\n&&RestPose', '&&Explain\nThe useful lesson in an unanswered question may have nothing to do with keep exploring without forcing an answer.\n&&RestPose', '&&Explain\nThe useful lesson in a conversation may have nothing to do with say less and mean it.\n&&RestPose', '&&Explain\nThe useful lesson in a change in plans may have nothing to do with find the part that still works.\n&&RestPose', '&&Explain\nPay attention when starting over; that may be the moment to listen before answering.\n&&RestPose', '&&Explain\nPay attention when a difficult problem; that may be the moment to try one smaller step.\n&&RestPose', '&&Explain\nPay attention when a new idea; that may be the moment to write it down before judging it.\n&&RestPose', '&&Explain\nPay attention when uncertainty; that may be the moment to ask a better question.\n&&RestPose', '&&Explain\nPay attention when a busy day; that may be the moment to finish one thing at a time.\n&&RestPose', '&&Explain\nPay attention when learning something unfamiliar; that may be the moment to stay curious a little longer.\n&&RestPose', '&&Explain\nThe smallest detail in practice can point toward accept an imperfect first attempt.\n&&RestPose', '&&Explain\nThe smallest detail in a disagreement can point toward understand the other point of view.\n&&RestPose', '&&Explain\nThe smallest detail in an old routine can point toward try a different route.\n&&RestPose', '&&Explain\nThe smallest detail in good work can point toward take a proper break afterward.\n&&RestPose', '&&Explain\nThe smallest detail in a surprising result can point toward look for what caused it.\n&&RestPose', '&&Explain\nThe smallest detail in quiet time can point toward notice what was easy to miss.\n&&RestPose', '&&Explain\nIf you keep returning to a slow afternoon, perhaps it is time for enjoy the lack of urgency.\n&&RestPose', '&&Explain\nIf you keep returning to a small success, perhaps it is time for remember how it started.\n&&RestPose', '&&Explain\nIf you keep returning to a wrong turn, perhaps it is time for find something useful along the way.\n&&RestPose', '&&Explain\nIf you keep returning to a hard lesson, perhaps it is time for use it without carrying the frustration.\n&&RestPose', '&&Explain\nIf you keep returning to helping someone, perhaps it is time for leave them room to decide.\n&&RestPose', '&&Explain\nIf you keep returning to making plans, perhaps it is time for allow for the unexpected.\n&&RestPose', '&&Explain\nThere is a certain freedom in a long project without needing to recognize the progress already made.\n&&RestPose', '&&Explain\nThere is a certain freedom in asking questions without needing to listen carefully to the answer.\n&&RestPose', '&&Explain\nThere is a certain freedom in trying again without needing to change one thing instead of everything.\n&&RestPose', '&&Explain\nThere is a certain freedom in solving things without needing to step away for a few minutes.\n&&RestPose', '&&Explain\nThere is a certain freedom in being prepared without needing to adapt when the plan changes.\n&&RestPose', '&&Explain\nThere is a certain freedom in a familiar place without needing to look at one detail differently.\n&&RestPose', '&&Explain\nA thoughtful response to a useful habit usually leaves room for make it easy to repeat.\n&&RestPose', '&&Explain\nA thoughtful response to a funny mistake usually leaves room for laugh and remember the lesson.\n&&RestPose', '&&Explain\nA thoughtful response to good timing usually leaves room for wait without losing momentum.\n&&RestPose', '&&Explain\nA thoughtful response to an unexpected delay usually leaves room for use the extra minute well.\n&&RestPose', '&&Explain\nA thoughtful response to a blank page usually leaves room for put down the first honest sentence.\n&&RestPose', '&&Explain\nA thoughtful response to a complicated choice usually leaves room for remove what does not matter.\n&&RestPose', '&&Explain\nOne good result from a moment of doubt is discovering how to remember what you already know.\n&&RestPose', "&&Explain\nOne good result from today's work is discovering how to leave something easier for tomorrow.\n&&RestPose", '&&Explain\nOne good result from a new skill is discovering how to notice small improvements.\n&&RestPose', '&&Explain\nOne good result from an unanswered question is discovering how to keep exploring without forcing an answer.\n&&RestPose', '&&Explain\nOne good result from a conversation is discovering how to say less and mean it.\n&&RestPose', '&&Explain\nOne good result from a change in plans is discovering how to find the part that still works.\n&&RestPose', '&&Explain\nThe interesting thing about starting over is how often it leads to listen before answering.\n&&RestPose', '&&Explain\nThe interesting thing about a difficult problem is how often it leads to try one smaller step.\n&&RestPose', '&&Explain\nThe interesting thing about a new idea is how often it leads to write it down before judging it.\n&&RestPose', '&&Explain\nThe interesting thing about uncertainty is how often it leads to ask a better question.\n&&RestPose', '&&Explain\nThe interesting thing about a busy day is how often it leads to finish one thing at a time.\n&&RestPose', '&&Explain\nThe interesting thing about learning something unfamiliar is how often it leads to stay curious a little longer.\n&&RestPose', '&&Explain\nInstead of rushing through practice, consider accept an imperfect first attempt.\n&&RestPose', '&&Explain\nInstead of rushing through a disagreement, consider understand the other point of view.\n&&RestPose', '&&Explain\nInstead of rushing through an old routine, consider try a different route.\n&&RestPose', '&&Explain\nInstead of rushing through good work, consider take a proper break afterward.\n&&RestPose', '&&Explain\nInstead of rushing through a surprising result, consider look for what caused it.\n&&RestPose', '&&Explain\nInstead of rushing through quiet time, consider notice what was easy to miss.\n&&RestPose', '&&Explain\nExperience makes a slow afternoon easier, but it also teaches enjoy the lack of urgency.\n&&RestPose', '&&Explain\nExperience makes a small success easier, but it also teaches remember how it started.\n&&RestPose', '&&Explain\nExperience makes a wrong turn easier, but it also teaches find something useful along the way.\n&&RestPose', '&&Explain\nExperience makes a hard lesson easier, but it also teaches use it without carrying the frustration.\n&&RestPose', '&&Explain\nExperience makes helping someone easier, but it also teaches leave them room to decide.\n&&RestPose', '&&Explain\nExperience makes making plans easier, but it also teaches allow for the unexpected.\n&&RestPose', '&&Explain\nA calm approach to a long project can uncover recognize the progress already made.\n&&RestPose', '&&Explain\nA calm approach to asking questions can uncover listen carefully to the answer.\n&&RestPose', '&&Explain\nA calm approach to trying again can uncover change one thing instead of everything.\n&&RestPose', '&&Explain\nA calm approach to solving things can uncover step away for a few minutes.\n&&RestPose', '&&Explain\nA calm approach to being prepared can uncover adapt when the plan changes.\n&&RestPose', '&&Explain\nA calm approach to a familiar place can uncover look at one detail differently.\n&&RestPose', '&&Explain\nIt helps to separate a useful habit from the need to make it easy to repeat.\n&&RestPose', '&&Explain\nIt helps to separate a funny mistake from the need to laugh and remember the lesson.\n&&RestPose', '&&Explain\nIt helps to separate good timing from the need to wait without losing momentum.\n&&RestPose', '&&Explain\nIt helps to separate an unexpected delay from the need to use the extra minute well.\n&&RestPose', '&&Explain\nIt helps to separate a blank page from the need to put down the first honest sentence.\n&&RestPose', '&&Explain\nIt helps to separate a complicated choice from the need to remove what does not matter.\n&&RestPose', '&&Explain\nYou can learn a lot about a moment of doubt by watching how people remember what you already know.\n&&RestPose', "&&Explain\nYou can learn a lot about today's work by watching how people leave something easier for tomorrow.\n&&RestPose", '&&Explain\nYou can learn a lot about a new skill by watching how people notice small improvements.\n&&RestPose', '&&Explain\nYou can learn a lot about an unanswered question by watching how people keep exploring without forcing an answer.\n&&RestPose', '&&Explain\nYou can learn a lot about a conversation by watching how people say less and mean it.\n&&RestPose', '&&Explain\nYou can learn a lot about a change in plans by watching how people find the part that still works.\n&&RestPose', '&&Explain\nSome problems with starting over disappear once you listen before answering.\n&&RestPose', '&&Explain\nSome problems with a difficult problem disappear once you try one smaller step.\n&&RestPose', '&&Explain\nSome problems with a new idea disappear once you write it down before judging it.\n&&RestPose', '&&Explain\nSome problems with uncertainty disappear once you ask a better question.\n&&RestPose', '&&Explain\nSome problems with a busy day disappear once you finish one thing at a time.\n&&RestPose', '&&Explain\nSome problems with learning something unfamiliar disappear once you stay curious a little longer.\n&&RestPose', '&&Explain\nThe point of practice is not always to accept an imperfect first attempt.\n&&RestPose', '&&Explain\nThe point of a disagreement is not always to understand the other point of view.\n&&RestPose', '&&Explain\nThe point of an old routine is not always to try a different route.\n&&RestPose', '&&Explain\nThe point of good work is not always to take a proper break afterward.\n&&RestPose', '&&Explain\nThe point of a surprising result is not always to look for what caused it.\n&&RestPose', '&&Explain\nThe point of quiet time is not always to notice what was easy to miss.\n&&RestPose', '&&Explain\nThere is wisdom in leaving a slow afternoon alone long enough to enjoy the lack of urgency.\n&&RestPose', '&&Explain\nThere is wisdom in leaving a small success alone long enough to remember how it started.\n&&RestPose', '&&Explain\nThere is wisdom in leaving a wrong turn alone long enough to find something useful along the way.\n&&RestPose', '&&Explain\nThere is wisdom in leaving a hard lesson alone long enough to use it without carrying the frustration.\n&&RestPose', '&&Explain\nThere is wisdom in leaving helping someone alone long enough to leave them room to decide.\n&&RestPose', '&&Explain\nThere is wisdom in leaving making plans alone long enough to allow for the unexpected.\n&&RestPose', '&&Explain\nA good beginning for a long project is simply to recognize the progress already made.\n&&RestPose', '&&Explain\nA good beginning for asking questions is simply to listen carefully to the answer.\n&&RestPose', '&&Explain\nA good beginning for trying again is simply to change one thing instead of everything.\n&&RestPose', '&&Explain\nA good beginning for solving things is simply to step away for a few minutes.\n&&RestPose', '&&Explain\nA good beginning for being prepared is simply to adapt when the plan changes.\n&&RestPose', '&&Explain\nA good beginning for a familiar place is simply to look at one detail differently.\n&&RestPose', '&&Explain\nThe memory of a useful habit can be useful when you need to make it easy to repeat.\n&&RestPose', '&&Explain\nThe memory of a funny mistake can be useful when you need to laugh and remember the lesson.\n&&RestPose', '&&Explain\nThe memory of good timing can be useful when you need to wait without losing momentum.\n&&RestPose', '&&Explain\nThe memory of an unexpected delay can be useful when you need to use the extra minute well.\n&&RestPose', '&&Explain\nThe memory of a blank page can be useful when you need to put down the first honest sentence.\n&&RestPose', '&&Explain\nThe memory of a complicated choice can be useful when you need to remove what does not matter.\n&&RestPose', '&&Explain\nA little humor about a moment of doubt makes it easier to remember what you already know.\n&&RestPose', "&&Explain\nA little humor about today's work makes it easier to leave something easier for tomorrow.\n&&RestPose", '&&Explain\nA little humor about a new skill makes it easier to notice small improvements.\n&&RestPose', '&&Explain\nA little humor about an unanswered question makes it easier to keep exploring without forcing an answer.\n&&RestPose', '&&Explain\nA little humor about a conversation makes it easier to say less and mean it.\n&&RestPose', '&&Explain\nA little humor about a change in plans makes it easier to find the part that still works.\n&&RestPose', '&&Explain\nThink of starting over as an invitation to listen before answering.\n&&RestPose', '&&Explain\nThink of a difficult problem as an invitation to try one smaller step.\n&&RestPose', '&&Explain\nThink of a new idea as an invitation to write it down before judging it.\n&&RestPose', '&&Explain\nThink of uncertainty as an invitation to ask a better question.\n&&RestPose', '&&Explain\nThink of a busy day as an invitation to finish one thing at a time.\n&&RestPose', '&&Explain\nThink of learning something unfamiliar as an invitation to stay curious a little longer.\n&&RestPose', '&&Explain\nThe right pace for practice is the one that lets you accept an imperfect first attempt.\n&&RestPose', '&&Explain\nThe right pace for a disagreement is the one that lets you understand the other point of view.\n&&RestPose', '&&Explain\nThe right pace for an old routine is the one that lets you try a different route.\n&&RestPose', '&&Explain\nThe right pace for good work is the one that lets you take a proper break afterward.\n&&RestPose', '&&Explain\nThe right pace for a surprising result is the one that lets you look for what caused it.\n&&RestPose', '&&Explain\nThe right pace for quiet time is the one that lets you notice what was easy to miss.\n&&RestPose', '&&Explain\nEven if a slow afternoon does not work, you still get a chance to enjoy the lack of urgency.\n&&RestPose', '&&Explain\nEven if a small success does not work, you still get a chance to remember how it started.\n&&RestPose', '&&Explain\nEven if a wrong turn does not work, you still get a chance to find something useful along the way.\n&&RestPose', '&&Explain\nEven if a hard lesson does not work, you still get a chance to use it without carrying the frustration.\n&&RestPose', '&&Explain\nEven if helping someone does not work, you still get a chance to leave them room to decide.\n&&RestPose', '&&Explain\nEven if making plans does not work, you still get a chance to allow for the unexpected.\n&&RestPose', '&&Explain\nA clear mind treats a long project differently after recognize the progress already made.\n&&RestPose', '&&Explain\nA clear mind treats asking questions differently after listen carefully to the answer.\n&&RestPose', '&&Explain\nA clear mind treats trying again differently after change one thing instead of everything.\n&&RestPose', '&&Explain\nA clear mind treats solving things differently after step away for a few minutes.\n&&RestPose', '&&Explain\nA clear mind treats being prepared differently after adapt when the plan changes.\n&&RestPose', '&&Explain\nA clear mind treats a familiar place differently after look at one detail differently.\n&&RestPose', '&&Explain\nOne unexpected benefit of a useful habit is learning when to make it easy to repeat.\n&&RestPose', '&&Explain\nOne unexpected benefit of a funny mistake is learning when to laugh and remember the lesson.\n&&RestPose', '&&Explain\nOne unexpected benefit of good timing is learning when to wait without losing momentum.\n&&RestPose', '&&Explain\nOne unexpected benefit of an unexpected delay is learning when to use the extra minute well.\n&&RestPose', '&&Explain\nOne unexpected benefit of a blank page is learning when to put down the first honest sentence.\n&&RestPose', '&&Explain\nOne unexpected benefit of a complicated choice is learning when to remove what does not matter.\n&&RestPose', '&&Explain\nThere is nothing wasted about a moment of doubt if it helps you remember what you already know.\n&&RestPose', "&&Explain\nThere is nothing wasted about today's work if it helps you leave something easier for tomorrow.\n&&RestPose", '&&Explain\nThere is nothing wasted about a new skill if it helps you notice small improvements.\n&&RestPose', '&&Explain\nThere is nothing wasted about an unanswered question if it helps you keep exploring without forcing an answer.\n&&RestPose', '&&Explain\nThere is nothing wasted about a conversation if it helps you say less and mean it.\n&&RestPose', '&&Explain\nThere is nothing wasted about a change in plans if it helps you find the part that still works.\n&&RestPose', '&&Explain\nA habit of starting over becomes stronger when paired with listen before answering.\n&&RestPose', '&&Explain\nA habit of a difficult problem becomes stronger when paired with try one smaller step.\n&&RestPose', '&&Explain\nA habit of a new idea becomes stronger when paired with write it down before judging it.\n&&RestPose', '&&Explain\nA habit of uncertainty becomes stronger when paired with ask a better question.\n&&RestPose', '&&Explain\nA habit of a busy day becomes stronger when paired with finish one thing at a time.\n&&RestPose', '&&Explain\nA habit of learning something unfamiliar becomes stronger when paired with stay curious a little longer.\n&&RestPose', '&&Explain\nThe first impression of practice rarely tells you everything about accept an imperfect first attempt.\n&&RestPose', '&&Explain\nThe first impression of a disagreement rarely tells you everything about understand the other point of view.\n&&RestPose', '&&Explain\nThe first impression of an old routine rarely tells you everything about try a different route.\n&&RestPose', '&&Explain\nThe first impression of good work rarely tells you everything about take a proper break afterward.\n&&RestPose', '&&Explain\nThe first impression of a surprising result rarely tells you everything about look for what caused it.\n&&RestPose', '&&Explain\nThe first impression of quiet time rarely tells you everything about notice what was easy to miss.\n&&RestPose', '&&Explain\nYou might understand a slow afternoon better by trying to enjoy the lack of urgency.\n&&RestPose', '&&Explain\nYou might understand a small success better by trying to remember how it started.\n&&RestPose', '&&Explain\nYou might understand a wrong turn better by trying to find something useful along the way.\n&&RestPose', '&&Explain\nYou might understand a hard lesson better by trying to use it without carrying the frustration.\n&&RestPose', '&&Explain\nYou might understand helping someone better by trying to leave them room to decide.\n&&RestPose', '&&Explain\nYou might understand making plans better by trying to allow for the unexpected.\n&&RestPose', '&&Explain\nA useful day does not require much beyond a long project and recognize the progress already made.\n&&RestPose', '&&Explain\nA useful day does not require much beyond asking questions and listen carefully to the answer.\n&&RestPose', '&&Explain\nA useful day does not require much beyond trying again and change one thing instead of everything.\n&&RestPose', '&&Explain\nA useful day does not require much beyond solving things and step away for a few minutes.\n&&RestPose', '&&Explain\nA useful day does not require much beyond being prepared and adapt when the plan changes.\n&&RestPose', '&&Explain\nA useful day does not require much beyond a familiar place and look at one detail differently.\n&&RestPose', '&&Explain\nThe more familiar a useful habit becomes, the easier it is to recognize make it easy to repeat.\n&&RestPose', '&&Explain\nThe more familiar a funny mistake becomes, the easier it is to recognize laugh and remember the lesson.\n&&RestPose', '&&Explain\nThe more familiar good timing becomes, the easier it is to recognize wait without losing momentum.\n&&RestPose', '&&Explain\nThe more familiar an unexpected delay becomes, the easier it is to recognize use the extra minute well.\n&&RestPose', '&&Explain\nThe more familiar a blank page becomes, the easier it is to recognize put down the first honest sentence.\n&&RestPose', '&&Explain\nThe more familiar a complicated choice becomes, the easier it is to recognize remove what does not matter.\n&&RestPose', '&&Explain\nIt is possible to enjoy a moment of doubt without turning it into remember what you already know.\n&&RestPose', "&&Explain\nIt is possible to enjoy today's work without turning it into leave something easier for tomorrow.\n&&RestPose", '&&Explain\nIt is possible to enjoy a new skill without turning it into notice small improvements.\n&&RestPose', '&&Explain\nIt is possible to enjoy an unanswered question without turning it into keep exploring without forcing an answer.\n&&RestPose', '&&Explain\nIt is possible to enjoy a conversation without turning it into say less and mean it.\n&&RestPose', '&&Explain\nIt is possible to enjoy a change in plans without turning it into find the part that still works.\n&&RestPose', '&&Explain\nAn unexpected moment of starting over can remind you to listen before answering.\n&&RestPose', '&&Explain\nAn unexpected moment of a difficult problem can remind you to try one smaller step.\n&&RestPose', '&&Explain\nAn unexpected moment of a new idea can remind you to write it down before judging it.\n&&RestPose', '&&Explain\nAn unexpected moment of uncertainty can remind you to ask a better question.\n&&RestPose', '&&Explain\nAn unexpected moment of a busy day can remind you to finish one thing at a time.\n&&RestPose', '&&Explain\nAn unexpected moment of learning something unfamiliar can remind you to stay curious a little longer.\n&&RestPose', '&&Explain\nThere is often a better story behind practice than simply accept an imperfect first attempt.\n&&RestPose', '&&Explain\nThere is often a better story behind a disagreement than simply understand the other point of view.\n&&RestPose', '&&Explain\nThere is often a better story behind an old routine than simply try a different route.\n&&RestPose', '&&Explain\nThere is often a better story behind good work than simply take a proper break afterward.\n&&RestPose', '&&Explain\nThere is often a better story behind a surprising result than simply look for what caused it.\n&&RestPose', '&&Explain\nThere is often a better story behind quiet time than simply notice what was easy to miss.\n&&RestPose', '&&Explain\nA careful look at a slow afternoon may be enough to help you enjoy the lack of urgency.\n&&RestPose', '&&Explain\nA careful look at a small success may be enough to help you remember how it started.\n&&RestPose', '&&Explain\nA careful look at a wrong turn may be enough to help you find something useful along the way.\n&&RestPose', '&&Explain\nA careful look at a hard lesson may be enough to help you use it without carrying the frustration.\n&&RestPose', '&&Explain\nA careful look at helping someone may be enough to help you leave them room to decide.\n&&RestPose', '&&Explain\nA careful look at making plans may be enough to help you allow for the unexpected.\n&&RestPose', '&&Explain\nLet a long project be imperfect while you learn to recognize the progress already made.\n&&RestPose', '&&Explain\nLet asking questions be imperfect while you learn to listen carefully to the answer.\n&&RestPose', '&&Explain\nLet trying again be imperfect while you learn to change one thing instead of everything.\n&&RestPose', '&&Explain\nLet solving things be imperfect while you learn to step away for a few minutes.\n&&RestPose', '&&Explain\nLet being prepared be imperfect while you learn to adapt when the plan changes.\n&&RestPose', '&&Explain\nLet a familiar place be imperfect while you learn to look at one detail differently.\n&&RestPose', '&&Explain\nThe useful side of a useful habit appears when you begin to make it easy to repeat.\n&&RestPose', '&&Explain\nThe useful side of a funny mistake appears when you begin to laugh and remember the lesson.\n&&RestPose', '&&Explain\nThe useful side of good timing appears when you begin to wait without losing momentum.\n&&RestPose', '&&Explain\nThe useful side of an unexpected delay appears when you begin to use the extra minute well.\n&&RestPose', '&&Explain\nThe useful side of a blank page appears when you begin to put down the first honest sentence.\n&&RestPose', '&&Explain\nThe useful side of a complicated choice appears when you begin to remove what does not matter.\n&&RestPose', '&&Explain\nA little distance from a moment of doubt sometimes makes it possible to remember what you already know.\n&&RestPose', "&&Explain\nA little distance from today's work sometimes makes it possible to leave something easier for tomorrow.\n&&RestPose", '&&Explain\nA little distance from a new skill sometimes makes it possible to notice small improvements.\n&&RestPose', '&&Explain\nA little distance from an unanswered question sometimes makes it possible to keep exploring without forcing an answer.\n&&RestPose', '&&Explain\nA little distance from a conversation sometimes makes it possible to say less and mean it.\n&&RestPose', '&&Explain\nA little distance from a change in plans sometimes makes it possible to find the part that still works.\n&&RestPose', '&&Explain\nWhen the usual approach to starting over fails, there is still listen before answering.\n&&RestPose', '&&Explain\nWhen the usual approach to a difficult problem fails, there is still try one smaller step.\n&&RestPose', '&&Explain\nWhen the usual approach to a new idea fails, there is still write it down before judging it.\n&&RestPose', '&&Explain\nWhen the usual approach to uncertainty fails, there is still ask a better question.\n&&RestPose', '&&Explain\nWhen the usual approach to a busy day fails, there is still finish one thing at a time.\n&&RestPose', '&&Explain\nWhen the usual approach to learning something unfamiliar fails, there is still stay curious a little longer.\n&&RestPose', '&&Explain\nIt is worth remembering that practice and accept an imperfect first attempt do not have to compete.\n&&RestPose', '&&Explain\nIt is worth remembering that a disagreement and understand the other point of view do not have to compete.\n&&RestPose', '&&Explain\nIt is worth remembering that an old routine and try a different route do not have to compete.\n&&RestPose', '&&Explain\nIt is worth remembering that good work and take a proper break afterward do not have to compete.\n&&RestPose', '&&Explain\nIt is worth remembering that a surprising result and look for what caused it do not have to compete.\n&&RestPose', '&&Explain\nIt is worth remembering that quiet time and notice what was easy to miss do not have to compete.\n&&RestPose', '&&Explain\nThe next step after a slow afternoon does not need to be bigger; it can simply be enjoy the lack of urgency.\n&&RestPose', '&&Explain\nThe next step after a small success does not need to be bigger; it can simply be remember how it started.\n&&RestPose', '&&Explain\nThe next step after a wrong turn does not need to be bigger; it can simply be find something useful along the way.\n&&RestPose', '&&Explain\nThe next step after a hard lesson does not need to be bigger; it can simply be use it without carrying the frustration.\n&&RestPose', '&&Explain\nThe next step after helping someone does not need to be bigger; it can simply be leave them room to decide.\n&&RestPose', '&&Explain\nThe next step after making plans does not need to be bigger; it can simply be allow for the unexpected.\n&&RestPose', '&&Explain\nA quiet morning with a long project can be enough time to think about recognize the progress already made.\n&&RestPose', '&&Explain\nA quiet morning with asking questions can be enough time to think about listen carefully to the answer.\n&&RestPose', '&&Explain\nA quiet morning with trying again can be enough time to think about change one thing instead of everything.\n&&RestPose', '&&Explain\nA quiet morning with solving things can be enough time to think about step away for a few minutes.\n&&RestPose', '&&Explain\nA quiet morning with being prepared can be enough time to think about adapt when the plan changes.\n&&RestPose', '&&Explain\nA quiet morning with a familiar place can be enough time to think about look at one detail differently.\n&&RestPose', '&&Explain\nThere is a difference between knowing about a useful habit and learning how to make it easy to repeat.\n&&RestPose', '&&Explain\nThere is a difference between knowing about a funny mistake and learning how to laugh and remember the lesson.\n&&RestPose', '&&Explain\nThere is a difference between knowing about good timing and learning how to wait without losing momentum.\n&&RestPose', '&&Explain\nThere is a difference between knowing about an unexpected delay and learning how to use the extra minute well.\n&&RestPose', '&&Explain\nThere is a difference between knowing about a blank page and learning how to put down the first honest sentence.\n&&RestPose', '&&Explain\nThere is a difference between knowing about a complicated choice and learning how to remove what does not matter.\n&&RestPose', '&&Explain\nA surprising amount of a moment of doubt comes down to knowing when to remember what you already know.\n&&RestPose', "&&Explain\nA surprising amount of today's work comes down to knowing when to leave something easier for tomorrow.\n&&RestPose", '&&Explain\nA surprising amount of a new skill comes down to knowing when to notice small improvements.\n&&RestPose', '&&Explain\nA surprising amount of an unanswered question comes down to knowing when to keep exploring without forcing an answer.\n&&RestPose', '&&Explain\nA surprising amount of a conversation comes down to knowing when to say less and mean it.\n&&RestPose', '&&Explain\nA surprising amount of a change in plans comes down to knowing when to find the part that still works.\n&&RestPose', '&&Explain\nOne reason to keep starting over simple is to leave energy for listen before answering.\n&&RestPose', '&&Explain\nOne reason to keep a difficult problem simple is to leave energy for try one smaller step.\n&&RestPose', '&&Explain\nOne reason to keep a new idea simple is to leave energy for write it down before judging it.\n&&RestPose', '&&Explain\nOne reason to keep uncertainty simple is to leave energy for ask a better question.\n&&RestPose', '&&Explain\nOne reason to keep a busy day simple is to leave energy for finish one thing at a time.\n&&RestPose', '&&Explain\nOne reason to keep learning something unfamiliar simple is to leave energy for stay curious a little longer.\n&&RestPose', '&&Explain\nIf yesterday was about practice, today can be about accept an imperfect first attempt.\n&&RestPose', '&&Explain\nIf yesterday was about a disagreement, today can be about understand the other point of view.\n&&RestPose', '&&Explain\nIf yesterday was about an old routine, today can be about try a different route.\n&&RestPose', '&&Explain\nIf yesterday was about good work, today can be about take a proper break afterward.\n&&RestPose', '&&Explain\nIf yesterday was about a surprising result, today can be about look for what caused it.\n&&RestPose', '&&Explain\nIf yesterday was about quiet time, today can be about notice what was easy to miss.\n&&RestPose', '&&Explain\nA good conversation about a slow afternoon should leave someone wanting to enjoy the lack of urgency.\n&&RestPose', '&&Explain\nA good conversation about a small success should leave someone wanting to remember how it started.\n&&RestPose', '&&Explain\nA good conversation about a wrong turn should leave someone wanting to find something useful along the way.\n&&RestPose', '&&Explain\nA good conversation about a hard lesson should leave someone wanting to use it without carrying the frustration.\n&&RestPose', '&&Explain\nA good conversation about helping someone should leave someone wanting to leave them room to decide.\n&&RestPose', '&&Explain\nA good conversation about making plans should leave someone wanting to allow for the unexpected.\n&&RestPose', '&&Explain\nThe ordinary rhythm of a long project can make room for recognize the progress already made.\n&&RestPose', '&&Explain\nThe ordinary rhythm of asking questions can make room for listen carefully to the answer.\n&&RestPose', '&&Explain\nThe ordinary rhythm of trying again can make room for change one thing instead of everything.\n&&RestPose', '&&Explain\nThe ordinary rhythm of solving things can make room for step away for a few minutes.\n&&RestPose', '&&Explain\nThe ordinary rhythm of being prepared can make room for adapt when the plan changes.\n&&RestPose', '&&Explain\nThe ordinary rhythm of a familiar place can make room for look at one detail differently.\n&&RestPose', '&&Explain\nYou can take a useful habit seriously without forgetting to make it easy to repeat.\n&&RestPose', '&&Explain\nYou can take a funny mistake seriously without forgetting to laugh and remember the lesson.\n&&RestPose', '&&Explain\nYou can take good timing seriously without forgetting to wait without losing momentum.\n&&RestPose', '&&Explain\nYou can take an unexpected delay seriously without forgetting to use the extra minute well.\n&&RestPose', '&&Explain\nYou can take a blank page seriously without forgetting to put down the first honest sentence.\n&&RestPose', '&&Explain\nYou can take a complicated choice seriously without forgetting to remove what does not matter.\n&&RestPose', '&&Explain\nA difficult moment involving a moment of doubt may still contain a reason to remember what you already know.\n&&RestPose', "&&Explain\nA difficult moment involving today's work may still contain a reason to leave something easier for tomorrow.\n&&RestPose", '&&Explain\nA difficult moment involving a new skill may still contain a reason to notice small improvements.\n&&RestPose', '&&Explain\nA difficult moment involving an unanswered question may still contain a reason to keep exploring without forcing an answer.\n&&RestPose', '&&Explain\nA difficult moment involving a conversation may still contain a reason to say less and mean it.\n&&RestPose', '&&Explain\nA difficult moment involving a change in plans may still contain a reason to find the part that still works.\n&&RestPose', '&&Explain\nThe more you listen during starting over, the more likely you are to notice listen before answering.\n&&RestPose', '&&Explain\nThe more you listen during a difficult problem, the more likely you are to notice try one smaller step.\n&&RestPose', '&&Explain\nThe more you listen during a new idea, the more likely you are to notice write it down before judging it.\n&&RestPose', '&&Explain\nThe more you listen during uncertainty, the more likely you are to notice ask a better question.\n&&RestPose', '&&Explain\nThe more you listen during a busy day, the more likely you are to notice finish one thing at a time.\n&&RestPose', '&&Explain\nThe more you listen during learning something unfamiliar, the more likely you are to notice stay curious a little longer.\n&&RestPose', '&&Explain\nThere is comfort in knowing practice does not prevent you from accept an imperfect first attempt.\n&&RestPose', '&&Explain\nThere is comfort in knowing a disagreement does not prevent you from understand the other point of view.\n&&RestPose', '&&Explain\nThere is comfort in knowing an old routine does not prevent you from try a different route.\n&&RestPose', '&&Explain\nThere is comfort in knowing good work does not prevent you from take a proper break afterward.\n&&RestPose', '&&Explain\nThere is comfort in knowing a surprising result does not prevent you from look for what caused it.\n&&RestPose', '&&Explain\nThere is comfort in knowing quiet time does not prevent you from notice what was easy to miss.\n&&RestPose', '&&Explain\nA simple plan for a slow afternoon is often enough to begin enjoy the lack of urgency.\n&&RestPose', '&&Explain\nA simple plan for a small success is often enough to begin remember how it started.\n&&RestPose', '&&Explain\nA simple plan for a wrong turn is often enough to begin find something useful along the way.\n&&RestPose', '&&Explain\nA simple plan for a hard lesson is often enough to begin use it without carrying the frustration.\n&&RestPose', '&&Explain\nA simple plan for helping someone is often enough to begin leave them room to decide.\n&&RestPose', '&&Explain\nA simple plan for making plans is often enough to begin allow for the unexpected.\n&&RestPose', '&&Explain\nThe best time to reconsider a long project may be after you recognize the progress already made.\n&&RestPose', '&&Explain\nThe best time to reconsider asking questions may be after you listen carefully to the answer.\n&&RestPose', '&&Explain\nThe best time to reconsider trying again may be after you change one thing instead of everything.\n&&RestPose', '&&Explain\nThe best time to reconsider solving things may be after you step away for a few minutes.\n&&RestPose', '&&Explain\nThe best time to reconsider being prepared may be after you adapt when the plan changes.\n&&RestPose', '&&Explain\nThe best time to reconsider a familiar place may be after you look at one detail differently.\n&&RestPose', '&&Explain\nIt is easier to be patient with a useful habit when you remember to make it easy to repeat.\n&&RestPose', '&&Explain\nIt is easier to be patient with a funny mistake when you remember to laugh and remember the lesson.\n&&RestPose', '&&Explain\nIt is easier to be patient with good timing when you remember to wait without losing momentum.\n&&RestPose', '&&Explain\nIt is easier to be patient with an unexpected delay when you remember to use the extra minute well.\n&&RestPose', '&&Explain\nIt is easier to be patient with a blank page when you remember to put down the first honest sentence.\n&&RestPose', '&&Explain\nIt is easier to be patient with a complicated choice when you remember to remove what does not matter.\n&&RestPose', '&&Explain\nA tiny improvement in a moment of doubt is still a reason to keep remember what you already know.\n&&RestPose', "&&Explain\nA tiny improvement in today's work is still a reason to keep leave something easier for tomorrow.\n&&RestPose", '&&Explain\nA tiny improvement in a new skill is still a reason to keep notice small improvements.\n&&RestPose', '&&Explain\nA tiny improvement in an unanswered question is still a reason to keep keep exploring without forcing an answer.\n&&RestPose', '&&Explain\nA tiny improvement in a conversation is still a reason to keep say less and mean it.\n&&RestPose', '&&Explain\nA tiny improvement in a change in plans is still a reason to keep find the part that still works.\n&&RestPose', '&&Explain\nThere are moments when starting over deserves attention and moments when you should listen before answering.\n&&RestPose', '&&Explain\nThere are moments when a difficult problem deserves attention and moments when you should try one smaller step.\n&&RestPose', '&&Explain\nThere are moments when a new idea deserves attention and moments when you should write it down before judging it.\n&&RestPose', '&&Explain\nThere are moments when uncertainty deserves attention and moments when you should ask a better question.\n&&RestPose', '&&Explain\nThere are moments when a busy day deserves attention and moments when you should finish one thing at a time.\n&&RestPose', '&&Explain\nThere are moments when learning something unfamiliar deserves attention and moments when you should stay curious a little longer.\n&&RestPose', '&&Explain\nA useful perspective on practice is to ask what would happen if you accept an imperfect first attempt.\n&&RestPose', '&&Explain\nA useful perspective on a disagreement is to ask what would happen if you understand the other point of view.\n&&RestPose', '&&Explain\nA useful perspective on an old routine is to ask what would happen if you try a different route.\n&&RestPose', '&&Explain\nA useful perspective on good work is to ask what would happen if you take a proper break afterward.\n&&RestPose', '&&Explain\nA useful perspective on a surprising result is to ask what would happen if you look for what caused it.\n&&RestPose', '&&Explain\nA useful perspective on quiet time is to ask what would happen if you notice what was easy to miss.\n&&RestPose', '&&Explain\nThe day does not have to revolve around a slow afternoon; there is always time to enjoy the lack of urgency.\n&&RestPose', '&&Explain\nThe day does not have to revolve around a small success; there is always time to remember how it started.\n&&RestPose', '&&Explain\nThe day does not have to revolve around a wrong turn; there is always time to find something useful along the way.\n&&RestPose', '&&Explain\nThe day does not have to revolve around a hard lesson; there is always time to use it without carrying the frustration.\n&&RestPose', '&&Explain\nThe day does not have to revolve around helping someone; there is always time to leave them room to decide.\n&&RestPose', '&&Explain\nThe day does not have to revolve around making plans; there is always time to allow for the unexpected.\n&&RestPose', '&&Explain\nOne honest observation about a long project can be more useful than trying to recognize the progress already made.\n&&RestPose', '&&Explain\nOne honest observation about asking questions can be more useful than trying to listen carefully to the answer.\n&&RestPose', '&&Explain\nOne honest observation about trying again can be more useful than trying to change one thing instead of everything.\n&&RestPose', '&&Explain\nOne honest observation about solving things can be more useful than trying to step away for a few minutes.\n&&RestPose', '&&Explain\nOne honest observation about being prepared can be more useful than trying to adapt when the plan changes.\n&&RestPose', '&&Explain\nOne honest observation about a familiar place can be more useful than trying to look at one detail differently.\n&&RestPose')}
FUN_LAST_INDEX = {"joke": None, "thought": None}
FUN_LOCK = threading.Lock()


HOP_BY_HOP = {
    "connection", "proxy-connection", "keep-alive", "proxy-authenticate",
    "proxy-authorization", "te", "trailers", "transfer-encoding", "upgrade",
}


def tls_context() -> ssl.SSLContext:
    if VERIFY_TLS:
        return ssl.create_default_context()
    return ssl._create_unverified_context()


def direct_opener():
    """Never route proxy-to-server requests back through the Windows proxy."""
    return urllib.request.build_opener(
        urllib.request.ProxyHandler({}),
        urllib.request.HTTPSHandler(context=tls_context()),
    )


def direct_urlopen(request, timeout=TIMEOUT):
    return direct_opener().open(request, timeout=timeout)

STOCK_CACHE = {}
STOCK_LOCK = threading.RLock()
STOCK_COOLDOWN = 0.0


def fetch_stock_quote(symbol):
    """Get provider-reported quotes; never substitute made-up prices."""
    global STOCK_COOLDOWN
    symbol = symbol.upper().strip()
    if not re.fullmatch(r"[A-Z0-9^][A-Z0-9.^=\-]{0,24}", symbol):
        raise ValueError("Enter a ticker symbol such as AAPL, not a company name.")
    with STOCK_LOCK:
        now = time.monotonic()
        saved = STOCK_CACHE.get(symbol)
        if saved and now - saved[0] < 300:
            return saved[1]
        if now < STOCK_COOLDOWN:
            raise RuntimeError("Quote provider is rate limited. Try again later.")
        url = ("https://query1.finance.yahoo.com/v8/finance/chart/" +
               urllib.parse.quote(symbol, safe="") + "?interval=1d&range=5d")
        request = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0", "Accept": "application/json"})
        try:
            with direct_urlopen(request, timeout=TIMEOUT) as response:
                data = json.loads(response.read(2_000_000).decode("utf-8"))
        except urllib.error.HTTPError as error:
            if error.code == 429:
                STOCK_COOLDOWN = now + 300
            raise RuntimeError("Quote provider unavailable (HTTP %d)." % error.code) from None
        chart = data.get("chart") or {}
        results = chart.get("result") or []
        if not results:
            raise RuntimeError("No quote was returned for " + symbol + ".")
        meta = results[0].get("meta") or {}
        price = meta.get("regularMarketPrice")
        previous = meta.get("chartPreviousClose", meta.get("previousClose"))
        stamp = meta.get("regularMarketTime")
        if not isinstance(price, (int, float)) or not math.isfinite(price) or not isinstance(stamp, (int, float)):
            raise RuntimeError("Quote response is missing a valid price or timestamp.")
        # chartPreviousClose is the close before the requested range, not
        # necessarily yesterday. Use the preceding daily close when available.
        timestamps = results[0].get("timestamp") or []
        indicators = results[0].get("indicators") or {}
        bars = (indicators.get("quote") or [{}])[0]
        closes = bars.get("close") or []
        market_day = datetime.datetime.fromtimestamp(stamp, datetime.timezone.utc).date()
        for bar_time, close in reversed(list(zip(timestamps, closes))):
            if datetime.datetime.fromtimestamp(bar_time, datetime.timezone.utc).date() < market_day and isinstance(close, (int, float)) and math.isfinite(close):
                previous = close
                break
        change = price - previous if isinstance(previous, (int, float)) and math.isfinite(previous) else None
        quote = {"symbol": symbol, "price": price, "change": change,
                 "percent": change / previous * 100 if change is not None and previous else None,
                 "volume": meta.get("regularMarketVolume"), "currency": meta.get("currency", ""),
                 "time": datetime.datetime.fromtimestamp(stamp, datetime.timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")}
        STOCK_CACHE[symbol] = (now, quote)
        return quote


def stock_fields(quote):
    """Native reader scans symbol, then time, price, change, percent, volume."""
    return [quote["symbol"], quote["time"], "%.2f" % quote["price"],
            "%+.2f" % quote["change"] if quote["change"] is not None else "N/A",
            "%+.2f%%" % quote["percent"] if quote["percent"] is not None else "N/A",
            str(quote["volume"]) if isinstance(quote["volume"], int) else "N/A"]



def decode_body(body: bytes, encoding: str | None) -> bytes:
    if not encoding:
        return body
    try:
        if "gzip" in encoding.lower():
            return gzip.decompress(body)
        if "deflate" in encoding.lower():
            try:
                return zlib.decompress(body)
            except zlib.error:
                return zlib.decompress(body, -zlib.MAX_WBITS)
    except Exception:
        log.warning("Could not decompress the response; forwarding it unchanged.")
    return body


def detect_charset(content_type: str, body: bytes) -> str:
    found = re.search(r"charset\s*=\s*[\"']?([^;\"'\s]+)", content_type, re.I)
    if found:
        return found.group(1)
    found = re.search(br"<\?xml[^>]+encoding=[\"']([^\"']+)", body[:300], re.I)
    if found:
        return found.group(1).decode("ascii", "ignore")
    found = re.search(br"<meta\b[^>]*charset\s*=\s*[\"']?([a-z0-9_-]+)", body[:8192], re.I)
    if found:
        return found.group(1).decode("ascii", "ignore")
    if body.startswith(b"\xff\xfe"):
        return "utf-16"
    try:
        body.decode("utf-8")
    except UnicodeDecodeError:
        return "cp1252"
    return "utf-8"


def clean_news_text(value: str) -> str:
    """Decode entities and repair UTF-8 text misread as Windows-1252."""
    value = html.unescape(value)
    for _ in range(2):
        if not any(token in value for token in ("Ã", "Â", "â€", "â€™", "â€œ")):
            break
        try:
            repaired = value.encode("cp1252").decode("utf-8")
        except (UnicodeEncodeError, UnicodeDecodeError):
            break
        if sum(repaired.count(marker) for marker in ("Ã", "Â", "â€")) >= sum(
                value.count(marker) for marker in ("Ã", "Â", "â€")):
            break
        value = repaired
    return value


def web_watching_text(value: str) -> str:
    """Use the ASCII subset of Windows-1252 for the old watcher parser."""
    value = clean_news_text(value).translate(str.maketrans({
        "‘": "'", "’": "'", "“": '"', "”": '"',
        "–": "-", "—": "-", "…": "...", "\u00a0": " ",
    }))
    return unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode("ascii")


def make_legacy_compatible(body: bytes, content_type: str) -> tuple[bytes, str]:
    lowered = content_type.lower()
    is_xml = "xml" in lowered or "rss" in lowered or body.lstrip().startswith(b"<?xml")
    is_html = "text/html" in lowered

    if is_xml and CONVERT_XML:
        source_charset = detect_charset(content_type, body)
        try:
            text = body.decode(source_charset, "replace")
        except LookupError:
            text = body.decode("utf-8", "replace")
        text = text.lstrip("\ufeff")
        declaration = re.match(r"\s*<\?xml\b(.*?)\?>", text, flags=re.I | re.S)
        if declaration:
            original = declaration.group(0)
            if re.search(r"\bencoding\s*=", original, flags=re.I):
                updated = re.sub(r"\bencoding\s*=\s*([\"'])[^\"']+\1",
                                 'encoding="windows-1252"', original, count=1, flags=re.I)
            else:
                updated = original[:-2].rstrip() + ' encoding="windows-1252"?>'
            text = text[:declaration.start()] + updated + text[declaration.end():]
        else:
            text = '<?xml version="1.0" encoding="windows-1252"?>\n' + text
        body = text.encode("cp1252", "xmlcharrefreplace")
        base_type = content_type.split(";", 1)[0] or "application/xml"
        content_type = f"{base_type}; charset=windows-1252"

    if is_html:
        source_charset = detect_charset(content_type, body)
        try:
            text = body.decode(source_charset, "replace").lstrip("\ufeff")
            if REMOVE_SCRIPTS:
                text = re.sub(r"<script\b[^>]*>.*?</script\s*>", "", text, flags=re.I | re.S)
            head = text[:8192]
            if re.search(r"<meta\b[^>]*charset\s*=", head, flags=re.I):
                head = re.sub(r"(<meta\b[^>]*?charset\s*=\s*[\"']?)[a-z0-9_-]+",
                              r"\g<1>windows-1252", head, flags=re.I)
                text = head + text[8192:]
            else:
                text = re.sub(r"<head\b[^>]*>",
                              lambda m: m.group(0) + '<meta charset="windows-1252">',
                              text, count=1, flags=re.I)
            body = text.encode("cp1252", "xmlcharrefreplace")
            content_type = "text/html; charset=windows-1252"
        except (LookupError, UnicodeError):
            pass

    return body, content_type


class NoRedirect(urllib.request.HTTPRedirectHandler):
    pass


class ProxyHandler(socketserver.StreamRequestHandler):

    def send_current_model(self, parsed):
        """Show an NCEP model image, with its actual cycle instead of an invented date."""
        model = parsed.path.strip('/').split('/')[0].lower()
        areas = {'gfs': 'namer', 'nam': 'namer', 'rap': 'conus'}
        area = areas[model]
        query = urllib.parse.parse_qs(parsed.query)
        products = {'500_vort_ht', '850_temp_ht'}
        if model == 'rap':
            products.add('2m_temp_10m_wnd')
        else:
            products.add('10m_wnd_precip')
        product = query.get('product', ['500_vort_ht'])[0]
        if product not in products:
            product = '500_vort_ht'
        hours = (0, 3, 6, 9, 12) if model == 'rap' else (0, 6, 12, 18, 24, 36, 48)
        try:
            hour = int(query.get('hour', ['12' if model != 'rap' else '3'])[0])
        except ValueError:
            hour = hours[0]
        if hour not in hours:
            hour = hours[0]
        guide = ('https://mag.ncep.noaa.gov/model-guidance-model-parameter.php?'
                 + urllib.parse.urlencode({'area': area.upper(),
                                            'group': 'Model Guidance', 'model': model.upper()}))
        try:
            req = urllib.request.Request(guide, headers={'User-Agent': 'Mozilla/5.0'})
            with direct_urlopen(req, timeout=min(TIMEOUT, 20)) as response:
                source = response.read(1500000).decode('utf-8', 'replace')
            cycles = []
            for month, day, year, cycle in re.findall(
                    r'(\d{2})/(\d{2})/(\d{4})\s+(\d{2})\s*UTC', source, re.I):
                moment = datetime.datetime(int(year), int(month), int(day), int(cycle),
                                           tzinfo=datetime.timezone.utc)
                if moment not in cycles:
                    cycles.append(moment)
            cycles.sort(reverse=True)
            now = datetime.datetime.now(datetime.timezone.utc)
            # A cached, old MAG page must never make a 2013 chart look current.
            cycles = [c for c in cycles if datetime.timedelta(0) <= now - c <=
                      datetime.timedelta(hours=8 if model == 'rap' else 48)]
            if not cycles:
                raise ValueError('No recent model cycle reported by NOAA')
            payload = None
            chosen = None
            for cycle in cycles[:4]:
                h = f'{cycle.hour:02d}'
                filename = f'{model}_{area}_{hour:03d}_{product}.gif'
                folder = f'{area}/{product}/' if model == 'gfs' else ''
                url = f'https://mag.ncep.noaa.gov/data/{model}/{h}/{folder}{filename}'
                try:
                    with direct_urlopen(urllib.request.Request(
                            url, headers={'User-Agent': 'Mozilla/5.0'}),
                            timeout=min(TIMEOUT, 20)) as response:
                        candidate = response.read(6000000)
                    if candidate[:6] in (b'GIF87a', b'GIF89a'):
                        payload, chosen = candidate, cycle
                        break
                except (OSError, urllib.error.HTTPError):
                    continue
            if payload is None:
                raise ValueError('NOAA has no image for the requested product and hour')
            links = []
            for p in sorted(products):
                links.append('<a href="?'+urllib.parse.urlencode({'product': p, 'hour': hour})
                             +'">'+html.escape(p)+'</a>')
            hour_links = []
            for h in hours:
                hour_links.append('<a href="?'+urllib.parse.urlencode({'product': product, 'hour': h})
                                  +'">+'+str(h)+'h</a>')
            # Keep the image in memory so legacy browsers receive a normal HTTP GIF.
            key = hashlib.sha256(payload).hexdigest()[:32]
            with MODEL_IMAGES_LOCK:
                if len(MODEL_IMAGES) >= 12:
                    MODEL_IMAGES.pop(next(iter(MODEL_IMAGES)))
                MODEL_IMAGES[key] = payload
            body = ('<div style="font-family:Arial;max-width:1300px">'
                    f'<h2>Current NOAA {model.upper()} model - {area.upper()}</h2>'
                    f'<p>Model run: <b>{chosen:%Y-%m-%d %H}:00 UTC</b>; '
                    f'forecast hour: <b>+{hour}</b>; product: <b>{html.escape(product)}</b>.</p>'
                    '<p>Product: '+' | '.join(links)+'</p><p>Forecast hour: '
                    +' | '.join(hour_links)+'</p>'
                    f'<img alt="NOAA {model.upper()} {html.escape(product)}" '
                    f'src="/model_image?key={key}" style="max-width:100%">'
                    f'<p><a href="{parsed.path}?archive=1">View 2013 Unisys archive</a> | '
                    f'<a href="{html.escape(guide, quote=True)}">NOAA model guidance</a></p></div>')
            self.send_html(200, 'OK', self.weather_shell(body))
        except (OSError, ValueError, urllib.error.HTTPError) as exc:
            log.warning('CURRENT MODEL %s unavailable: %s', model, exc)
            self.send_html(502, 'Model image unavailable', self.weather_shell(
                f'<h2>Current {model.upper()} chart unavailable</h2><p>{html.escape(str(exc))}</p>'
                f'<p><a href="{parsed.path}?archive=1">View labeled 2013 archive</a></p>'))

    def send_live_weather_image(self, kind):
        """Proxy current public weather imagery; never substitute archived 2013 maps."""
        sources = {
            "satellite": "https://cdn.star.nesdis.noaa.gov/GOES19/ABI/CONUS/GEOCOLOR/1250x750.jpg",
            "radar": "https://radar.weather.gov/ridge/standard/CONUS_loop.gif",
            "surface": "https://www.wpc.ncep.noaa.gov/sfc/namussfcwbg.gif",
        }
        source = sources.get(kind)
        if not source:
            self.send_simple(404, "Not Found", "Live weather image not found.")
            return
        req = urllib.request.Request(source, headers={"User-Agent": "CyberBuddyClassicProxy/5.5.52"})
        try:
            with direct_urlopen(req, timeout=min(TIMEOUT, 25)) as response:
                ctype = response.headers.get("Content-Type", "image/jpeg").split(";", 1)[0]
                payload = response.read(10 * 1024 * 1024 + 1)
            if len(payload) > 10 * 1024 * 1024 or ctype not in {"image/jpeg", "image/png", "image/gif", "image/webp"}:
                raise ValueError("Unexpected live map response")
        except (OSError, ValueError, urllib.error.HTTPError) as exc:
            log.warning("LIVE WEATHER IMAGE unavailable kind=%s: %s", kind, exc)
            self.send_simple(502, "Bad Gateway", "Current weather map temporarily unavailable. Click Refresh to try again.")
            return
        self.safe_write((f"HTTP/1.0 200 OK\r\nContent-Type: {ctype}\r\n"
                         "Cache-Control: no-cache, no-store, must-revalidate, max-age=0\r\n"
                         "Pragma: no-cache\r\nExpires: 0\r\n"
                         f"Content-Length: {len(payload)}\r\nConnection: close\r\n\r\n").encode("ascii"))
        self.safe_write(payload)

    def send_live_weather_maps(self, original_url):
        """Interactive current map viewer behind the original Unisys-style local routes."""
        path = urllib.parse.urlsplit(original_url).path.lower()
        if "/radar/" in path:
            selected = "radar"
        elif "/surface/" in path or path.endswith("/analyses.php"):
            selected = "surface"
        else:
            selected = "satellite"

        labels = {
            "satellite": "Satellite Images - GOES-19 GeoColor",
            "radar": "Radar Data - NOAA CONUS Loop",
            "surface": "Surface Analysis - NOAA/WPC",
        }
        routes = {
            "satellite": "/satellite/index.php",
            "radar": "/radar/index.php",
            "surface": "/surface/index.php",
        }
        now = datetime.datetime.now().astimezone()
        stamp = now.strftime("%d/%m/%Y %H:%M:%S %Z")
        nav = " | ".join(
            f'<a href="{routes[key]}">{html.escape(label.split(" - ",1)[0])}</a>'
            for key, label in labels.items())
        content = (
            '<div style="font-family:Arial,Helvetica,sans-serif;max-width:1280px">'
            '<h2>Current Interactive Weather Maps</h2>'
            f'<p><b>Today:</b> {html.escape(stamp)} &nbsp; <b>Product:</b> {html.escape(labels[selected])}</p>'
            f'<p>{nav} | <a href="{routes[selected]}?refresh={int(time.time())}">Refresh now</a></p>'
            '<p>This viewer requests a public weather image when opened. '
            'No January 2013 image is substituted here. The source image timestamp is not verified.</p>'
            f'<p><img id="liveWeatherMap" src="/weather_live_image?kind={selected}&t={int(time.time())}" '
            'alt="Current weather map" style="max-width:100%;height:auto;border:1px solid #666"></p>'
            '<p><button type="button" onclick="refreshWeatherMap()">Refresh image</button> '
            '<label>Auto refresh: <select id="refreshRate" onchange="setWeatherTimer()">'
            '<option value="0">Off</option><option value="60">1 minute</option>'
            '<option value="300" selected>5 minutes</option><option value="600">10 minutes</option>'
            '</select></label> <span id="refreshStatus"></span></p>'
            '<script>'
            'var weatherTimer=null;'
            'function refreshWeatherMap(){var i=document.getElementById("liveWeatherMap");'
            f'i.src="/weather_live_image?kind={selected}&t="+Date.now();'
            'document.getElementById("refreshStatus").innerHTML="Requested: "+new Date().toLocaleString();}'
            'function setWeatherTimer(){if(weatherTimer){clearInterval(weatherTimer);weatherTimer=null;}'
            'var s=parseInt(document.getElementById("refreshRate").value,10);'
            'if(s>0){weatherTimer=setInterval(refreshWeatherMap,s*1000);}'
            'document.getElementById("refreshStatus").innerHTML=s>0?"Auto refresh enabled":"Auto refresh off";}'
            'setWeatherTimer();'
            '</script>'
            '<p><small>Satellite: NOAA/NESDIS GOES-19. Radar: NOAA/NWS. Surface: NOAA/WPC. '
            'The displayed date follows this computer clock and does not certify the image date.</small></p>'
            '</div>')
        self.send_html(200, "OK", self.weather_shell(content))
        log.info("LIVE WEATHER MAP kind=%s date=%s", selected, stamp)

    def send_local_weather_file(self, parsed):
        """Serve a downloaded weather.unisys.com file without contacting Wayback."""
        rel = urllib.parse.unquote(parsed.path or "/index.php").lstrip("/") or "index.php"
        candidate = (WEATHER_SITE / rel).resolve()
        try:
            candidate.relative_to(WEATHER_SITE.resolve())
        except ValueError:
            self.send_simple(403, "Forbidden", "Invalid local weather path.")
            return True
        if candidate.is_dir():
            candidate = candidate / "index.php"
        if not candidate.is_file():
            return False
        suffix = candidate.suffix.lower()
        mime = {".css":"text/css", ".js":"application/javascript", ".png":"image/png",
                ".gif":"image/gif", ".jpg":"image/jpeg", ".jpeg":"image/jpeg",
                ".webp":"image/webp", ".ico":"image/x-icon", ".svg":"image/svg+xml"}.get(suffix)
        payload = candidate.read_bytes()
        if mime and not mime.startswith("text/") and "javascript" not in mime:
            self.safe_write((f"HTTP/1.0 200 OK\r\nContent-Type: {mime}\r\nContent-Length: {len(payload)}\r\n"
                             "Cache-Control: no-cache\r\nConnection: close\r\n\r\n").encode("ascii"))
            self.safe_write(payload)
            return True
        try:
            page = payload.decode("utf-8")
        except UnicodeDecodeError:
            page = payload.decode("cp1252", "replace")
        if suffix in {".php", ".html", ".htm", ""}:
            # The mirror downloader rewrites most links; this catches any absolute Unisys links left over.
            page = re.sub(r'(?i)https?://(?:www\.)?weather\.unisys\.com(?P<path>/[^"\'<> ]*)',
                          lambda m: m.group("path"), page)
            # Archive files are static; keep their capture date clear and
            # provide a live forecast search on every mirrored HTML page.
            notice = ('<div style="background:#fff2cf;border:1px solid #875;padding:7px;'
                      'font:14px Arial">2013 Unisys Weather archive. Charts below are historical. '
                      '<form method="get" action="/forecast.php" style="display:inline">'
                      'Current forecast: <input name="Name" size="17" '
                      'title="City, ZIP code or airport">'
                      '<input type="submit" value="Search"></form> '
                      '<a href="/satellite/index.php">Current satellite</a> | '
                      '<a href="/radar/index.php">Current radar</a> | '
                      '<a href="/surface/index.php">Current surface</a> | '
                      '<a href="/gfs/index.php">Current GFS</a> | '
                      '<a href="/nam/index.php">Current NAM</a> | '
                      '<a href="/rap/index.php">Current RAP</a><br>'
                      '<small>Unofficial Unisys weather continuation by Arthur Tube, '
                      'created on September 26, 2026. Current reports: Open-Meteo. '
                      'Weather maps and model charts: NOAA. '
                      '2013 archive pages are labeled separately.</small></div>')
            page = re.sub(r'<body\b[^>]*>', lambda m: m.group(0) + notice,
                          page, count=1, flags=re.I)
            page = re.sub(r'(<form\b[^>]*\baction\s*=\s*)(["\'])([^"\']*forecast\.(?:php|cgi)[^"\']*)\2',
                          lambda m: m.group(1) + m.group(2) + '/forecast.php' + m.group(2),
                          page, flags=re.I)
            self.send_html(200, "OK", page)
        else:
            data = page.encode("utf-8")
            ctype = mime or "text/plain; charset=utf-8"
            self.safe_write((f"HTTP/1.0 200 OK\r\nContent-Type: {ctype}\r\nContent-Length: {len(data)}\r\n"
                             "Cache-Control: no-cache\r\nConnection: close\r\n\r\n").encode("ascii"))
            self.safe_write(data)
        return True

    def send_weather_archive(self, original_url):
        """Serve a fixed-date Wayback snapshot through this local HTTP proxy."""
        allowed_hosts = {"weather.unisys.com", "www.weather.unisys.com", "www.unisys.com",
                         "unisys.com", "lwf.ncdc.noaa.gov", "www.cpc.noaa.gov",
                         "oceanservice.noaa.gov", "www.lib.noaa.gov", "www.oar.noaa.gov",
                         "www.esrl.noaa.gov", "esrl.noaa.gov"}
        original = urllib.parse.urlsplit(original_url)
        if (original.scheme != "http" or original.hostname not in allowed_hosts or
                original.port not in (None, 80) or original.username or original.password or
                len(original_url) > 2048):
            self.send_simple(400, "Bad Request", "Archive address is not allowed.")
            return
        archived = "https://web.archive.org/web/20130124124126id_/" + original_url
        req = urllib.request.Request(archived, headers={"User-Agent": "CyberBuddyClassicProxy/5.5.48"})
        try:
            with direct_urlopen(req, timeout=min(TIMEOUT, 15)) as response:
                if urllib.parse.urlsplit(response.geturl()).hostname != "web.archive.org":
                    raise ValueError("Archive redirected outside the Wayback Machine")
                content_type = response.headers.get("Content-Type", "text/html")
                payload = response.read(2 * 1024 * 1024 + 1)
            if len(payload) > 2 * 1024 * 1024:
                raise ValueError("Archived page is too large")
        except (OSError, ValueError, urllib.error.HTTPError) as exc:
            log.warning("WEATHER ARCHIVE unavailable for %s: %s", original_url, exc)
            # Offline/local fallback: keep the classic weather interface usable
            # even when the Wayback Machine is temporarily unavailable.
            if original.hostname in {"weather.unisys.com", "www.weather.unisys.com"}:
                try:
                    chrome_path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                               "weather_chrome.html")
                    with open(chrome_path, "r", encoding="utf-8", errors="replace") as fh:
                        fallback = fh.read()
                    notice = (
                        '<div style="margin:8px;padding:8px;border:1px solid #777;'
                        'background:#fff4cc;font-family:Arial,Helvetica,sans-serif">'
                        '<b>Interactive local copy</b> &mdash; the 2013 archived page is '
                        'temporarily unavailable. Navigation remains available locally, and '
                        'weather/map pages use current data where supported.</div>')
                    if re.search(r"<body\b[^>]*>", fallback, flags=re.I):
                        fallback = re.sub(r"(<body\b[^>]*>)", r"\1" + notice, fallback,
                                          count=1, flags=re.I)
                    else:
                        fallback = notice + fallback
                    self.send_html(200, "OK", fallback)
                    return
                except OSError as fallback_exc:
                    log.warning("WEATHER local fallback unavailable: %s", fallback_exc)
            self.send_simple(502, "Bad Gateway",
                             "Archived page temporarily unavailable and no local copy was found.")
            return
        if "html" not in content_type.lower():
            mime = content_type.split(";", 1)[0]
            if mime not in {"image/png", "image/gif", "image/jpeg", "image/webp", "text/css"}:
                self.send_simple(415, "Unsupported Media Type", "Archived file type unavailable.")
                return
            self.safe_write(f"HTTP/1.0 200 OK\r\nContent-Type: {mime}\r\n"
                            f"Content-Length: {len(payload)}\r\nConnection: close\r\n\r\n".encode("ascii"))
            self.safe_write(payload)
            return
        charset_match = re.search(r"charset=([a-zA-Z0-9_-]+)", content_type, re.I)
        charset = charset_match.group(1) if charset_match else "cp1252"
        try:
            page = payload.decode(charset)
        except (LookupError, UnicodeError):
            page = payload.decode("cp1252", "replace")
        page = re.sub(r"<script\b[^>]*>.*?</script\s*>", "", page, flags=re.I | re.S)
        page = re.sub(r"<iframe\b[^>]*>.*?</iframe\s*>", "", page, flags=re.I | re.S)
        page = re.sub(r"\s+on[a-z]+\s*=\s*(['\"]).*?\1", "", page, flags=re.I | re.S)
        def local_link(match):
            url = html.unescape(match.group(3).strip())
            resolved = urllib.parse.urljoin(original_url, url)
            target = urllib.parse.urlsplit(resolved)
            if target.scheme == "http" and target.hostname in {"weather.unisys.com", "www.weather.unisys.com"}:
                local = target.path or "/index.php"
                if target.query:
                    local += "?" + target.query
                if target.fragment:
                    local += "#" + target.fragment
                return match.group(1) + match.group(2) + html.escape(local, quote=True) + match.group(2)
            if target.scheme == "http" and target.hostname in allowed_hosts:
                local = "/weather_archive?url=" + urllib.parse.quote(resolved, safe="")
                return match.group(1) + match.group(2) + html.escape(local, quote=True) + match.group(2)
            if url.lower().startswith(("javascript:", "data:")):
                return match.group(1) + match.group(2) + "#" + match.group(2)
            return match.group(0)
        page = re.sub(r"(\b(?:href|src)\s*=\s*)(['\"])(.*?)\2", local_link, page, flags=re.I | re.S)
        # Forecast forms on archived pages must submit to the live local
        # endpoint; the original 2013 CGI/PHP scripts no longer run.
        page = re.sub(r"(<form\b[^>]*\baction\s*=\s*)(['\"])([^'\"]*forecast\.(?:php|cgi)[^'\"]*)\2",
                      lambda m: m.group(1) + m.group(2) + "/forecast.php" + m.group(2),
                      page, flags=re.I)
        live_search = ('<div style="background:#ffe8c4;padding:8px;border:1px solid #777;">'
                       '<b>Current weather:</b> '
                       '<form method="get" action="/forecast.php" style="display:inline;">'
                       '<input type="text" name="Name" size="20" '
                       'title="City, ZIP code or airport">'
                       '<input type="submit" value="Get Forecast"></form> '
                       '<a href="/forecast.php">Weather Home</a></div>')
        page = re.sub(r"<body\b[^>]*>", lambda m: m.group(0) + live_search,
                      page, count=1, flags=re.I)
        page = re.sub(r"<meta\b[^>]*charset\s*=[^>]*>", "", page, flags=re.I)
        page = re.sub(r"<head\b[^>]*>", lambda m: m.group(0) + '<meta charset="windows-1252">',
                      page, count=1, flags=re.I)
        self.send_html(200, "OK", page)
        log.info("WEATHER ARCHIVE local -> %s", original_url)

    def send_weather_asset(self, name):
        """Serve only images and the stylesheet supplied with the recreation."""
        allowed = {"WMAX.css", "Unisys_logo.gif", "GO.png", "Icon.png", "setup.png", "Sun.png",
                   "Clouds.png", "Foggy.png", "Rain.png", "Snow.png",
                   "Thunder.png", "PartlyCloudy.png", "Moon.png", "MoonCloudy.png",
                   "Sun-s.png", "Clouds-s.png", "Foggy-s.png", "Rain-s.png",
                   "Snow-s.png", "Thunder-s.png", "PartlyCloudy-s.png",
                   "Moon-s.png", "MoonCloudy-s.png"}
        if name not in allowed:
            self.send_simple(404, "Not Found", "Weather asset not found.")
            return
        payload = (WEATHER_ASSETS / name).read_bytes()
        content_type = ("text/css; charset=windows-1252" if name.endswith(".css") else
                        "image/gif" if name.endswith(".gif") else "image/png")
        self.safe_write(f"HTTP/1.0 200 OK\r\nContent-Type: {content_type}\r\n"
                        f"Content-Length: {len(payload)}\r\nConnection: close\r\n\r\n".encode("ascii"))
        self.safe_write(payload)

    def weather_shell(self, content, icon="PartlyCloudy.png"):
        """Put live weather inside the actual downloaded 2013 Unisys forecast page."""
        template = WEATHER_SITE / "forecast.php"
        if template.exists():
            try:
                page = template.read_text(encoding="windows-1252", errors="replace")
                # Match the archived forecast's white content and quiet sidebar.
                # Scope this to the live forecast; the other mirrored pages keep
                # their original downloaded styles.
                forecast_style = ("<style type=\"text/css\">"
                                  "#content{background:#fff;border-color:#fff;}"
                                  "#content .drop table,#content .drop td{background:#fff;}"
                                  "#leftside ul.avmenu li a{background:#fff;border:0;"
                                  "font-weight:normal;font-size:13px;}"
                                  "#leftside ul.avmenu li a.purple{background:#eee;"
                                  "color:#d31145;font-size:14px;font-weight:bold;}"
                                  "</style>")
                page = page.replace('</head>', forecast_style + '</head>', 1)
                marker = '<div id="content">'
                start = page.lower().find(marker.lower())
                # The archived forecast response embeds a second HTML document in
                # #content.  Resume at the original clearboth/footer after it.
                suffix_match = re.search(r'<div class=["\']clearboth["\']',
                                         page[start + len(marker):], re.I) if start >= 0 else None
                if start >= 0 and suffix_match:
                    body_start = start + len(marker)
                    suffix_start = body_start + suffix_match.start()
                    return page[:body_start] + content + page[suffix_start:]
            except OSError as exc:
                log.warning("Could not use archived forecast.php as weather shell: %s", exc)
        # Fallback for installations that do not yet have weather_site/forecast.php.
        chrome = (ROOT / "weather_chrome.html").read_text(encoding="utf-8")
        return ('<!DOCTYPE html><html><head><meta http-equiv="Content-Type" '
                'content="text/html; charset=windows-1252"><title>Unisys Weather</title>'
                '<link rel="stylesheet" href="/weather_assets/WMAX.css"></head><body>'
                + chrome + '<div id="content">' + content +
                '</div><div class="clearboth">&nbsp;</div></div></body></html>')

    def safe_write(self, data: bytes) -> bool:
        try:
            self.wfile.write(data)
            return True
        except (ConnectionAbortedError, ConnectionResetError, BrokenPipeError, OSError):
            log.debug("Legacy client closed the connection before the response was complete")
            return False

    def read_request(self):
        line = self.rfile.readline(65537)
        if not line:
            return None
        if len(line) > 65536:
            raise ValueError("Request line is too long")
        # Some legacy clients send literal spaces in the request target
        # (e.g. /forecast.cgi/Caldas Novas) instead of %20 or +.
        request_line = line.decode("iso-8859-1").strip()
        target_and_method, version = request_line.rsplit(" ", 1)
        method, target = target_and_method.split(" ", 1)
        headers = http.client.parse_headers(self.rfile)
        length = int(headers.get("Content-Length", "0") or "0")
        if length > MAX_BODY_MB * 1024 * 1024:
            raise ValueError("Request body exceeds the configured size limit")
        body = self.rfile.read(length) if length else None
        return method.upper(), target, version, headers, body

    def send_simple(self, status: int, reason: str, text: str):
        payload = text.encode("cp1252", "replace")
        self.safe_write(f"HTTP/1.0 {status} {reason}\r\n".encode("ascii"))
        self.safe_write(b"Content-Type: text/plain; charset=windows-1252\r\n")
        self.safe_write(f"Content-Length: {len(payload)}\r\nConnection: close\r\n\r\n".encode("ascii"))
        self.safe_write(payload)

    def send_html(self, status: int, reason: str, text: str):
        payload = text.encode("cp1252", "xmlcharrefreplace")
        self.safe_write(f"HTTP/1.0 {status} {reason}\r\n".encode("ascii"))
        self.safe_write(b"Content-Type: text/html; charset=windows-1252\r\n")
        self.safe_write(b"Cache-Control: no-cache, no-store, must-revalidate, max-age=0\r\n")
        self.safe_write(b"Pragma: no-cache\r\n")
        self.safe_write(b"Expires: Thu, 01 Jan 1970 00:00:00 GMT\r\n")
        self.safe_write(f"Content-Length: {len(payload)}\r\nConnection: close\r\n\r\n".encode("ascii"))
        self.safe_write(payload)

    def send_xml(self, status: int, reason: str, text: str):
        payload = text.encode("cp1252", "xmlcharrefreplace")
        self.safe_write(f"HTTP/1.0 {status} {reason}\r\n".encode("ascii"))
        self.safe_write(b"Content-Type: text/xml; charset=windows-1252\r\n")
        self.safe_write(b"Cache-Control: no-cache\r\n")
        self.safe_write(f"Content-Length: {len(payload)}\r\nConnection: close\r\n\r\n".encode("ascii"))
        self.safe_write(payload)

    def fetch_news_items(self, feed_url=None):
        feed_url = feed_url or CFG.get(
            "web_watching",
            "news_feed",
            fallback="https://moxie.foxnews.com/google-publisher/latest.xml",
        )
        if (urllib.parse.urlsplit(feed_url).hostname or "").lower().endswith("globo.com"):
            feed_url = "https://moxie.foxnews.com/google-publisher/latest.xml"
        limit = CFG.getint("web_watching", "max_items", fallback=20)
        request = urllib.request.Request(
            feed_url,
            headers={"User-Agent": "CyberBuddyClassicProxy/2.7"},
        )
        opener = direct_opener()
        last_error = None
        for attempt in range(3):
            try:
                with opener.open(request, timeout=TIMEOUT) as response:
                    feed_body = response.read(MAX_BODY_MB * 1024 * 1024 + 1)
                if len(feed_body) > MAX_BODY_MB * 1024 * 1024:
                    raise ValueError("News feed exceeds the configured size limit")
                root = ET.fromstring(feed_body)
                return root.findall(".//item")[:max(1, limit)]
            except (ET.ParseError, http.client.IncompleteRead) as error:
                last_error = error
                log.warning("Incomplete RSS; retry %d/3", attempt + 1)
                time.sleep(0.35)
        raise last_error

    def send_legacy_news_page(self, provider=None):
        configured_feed = CFG.get("web_watching", "news_feed", fallback="https://moxie.foxnews.com/google-publisher/latest.xml")
        feed_url = ("https://moxie.foxnews.com/google-publisher/latest.xml" if provider == "fox" else configured_feed)
        items = self.fetch_news_items(feed_url)
        source = "English News"
        rows = []
        for item in items:
            title = web_watching_text((item.findtext("title") or "Untitled news").strip())
            description = (item.findtext("description") or "").strip()
            description = re.sub(r"<[^>]+>", " ", description)
            description = web_watching_text(description)
            description = re.sub(r"\s+", " ", description).strip()
            link = (item.findtext("link") or "").strip()
            rows.append(
                "<li><b>" + html.escape(title, quote=False) + "</b>"
                + ("<br>" + html.escape(description, quote=False) if description else "")
                + ("<br><a href=\"" + html.escape(urllib.parse.quote(link, safe=":/?#[]@!$&'()*+,;=%-._~"), quote=True) + "\">Read article</a>" if link else "")
                + "</li>"
            )
        page = (
            "<!DOCTYPE html><html><head>"
            "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=windows-1252\">"
            "<title>" + source + "</title></head><body>"
            "<h1>" + source + " headlines</h1>"
            "<ol>" + "".join(rows) + "</ol>"
            "</body></html>"
        )
        self.send_html(200, "OK", page)
        log.info("PAGE CHECK -> 200")

    def send_cyberbuddy_news3(self):
        """Return current RSS headlines in CyberBuddy's original command format."""
        categories = self.fetch_cyberbuddy_news_categories()
        # Keep command ampersands unescaped. A headline is spoken once.
        intro = "Here are some headlines."
        lines = ["&&Read", intro + "\\Pau=800\\"]
        total = 0
        for name, items in categories:
            # The client command uses Internet News; the web page calls it Tech News.
            command_name = "Internet News" if name == "Tech News" else name
            lines.append("$$News=" + command_name)
            seen = set()
            for item in items:
                title = self.cyberbuddy_news_title(item)
                link = (item.findtext("link") or "").strip()
                key = (link or title).casefold()
                if title and key not in seen:
                    seen.add(key)
                    description = re.sub(r"\s+", " ", clean_news_text(html.unescape(
                        re.sub(r"<[^>]*>", " ", item.findtext("description") or "")))).strip()
                    description = self.cyberbuddy_news_description(description, title, item)
                    story = title + (" " + description if description else "")
                    lines.append(html.escape(story, quote=False))
                    total += 1
        page = "\r\n".join(lines) + "\r\n"
        self.send_html(200, "OK", page)
        log.info("CYBERBUDDY NEWS3 -> 200 (%d headlines)", total)

    @staticmethod
    def cyberbuddy_news_source(item):
        """Name the actual feed publisher, without guessing an article's wire author."""
        hostname = (urllib.parse.urlsplit(item.findtext("link") or "").hostname or "").lower()
        source_node = item.find("source")
        source_url = (source_node.get("url", "") if source_node is not None else "")
        source_host = (urllib.parse.urlsplit(source_url).hostname or "").lower()
        if hostname == "news.google.com":
            if source_host in ("apnews.com", "www.apnews.com"):
                return "AP"
            if source_host in ("reuters.com", "www.reuters.com"):
                return "Reuters"
            return ""
        if hostname == "livescience.com" or hostname.endswith(".livescience.com"):
            return "LiveScience"
        if hostname == "foxnews.com" or hostname.endswith(".foxnews.com"):
            return "Fox News"
        if hostname == "foxbusiness.com" or hostname.endswith(".foxbusiness.com"):
            return "Fox Business"
        return re.sub(r"\s+", " ", clean_news_text(item.findtext("source") or "")).strip()

    @classmethod
    def cyberbuddy_news_title(cls, item):
        """Remove publisher suffixes from RSS titles shown to CyberBuddy."""
        title = re.sub(r"\s+", " ", clean_news_text((item.findtext("title") or "").strip()))
        publisher = cls.cyberbuddy_news_source(item)
        if publisher:
            label = "AP News" if publisher == "AP" else publisher
            title = re.sub(r"\s+-\s+(?:" + re.escape(label) +
                           (r"|AP" if publisher == "AP" else "") + r")$", "", title,
                           flags=re.IGNORECASE)
        return title

    @classmethod
    def cyberbuddy_news_description(cls, description, title, item):
        """Discard Google's repeated headline and publisher from RSS summaries."""
        description = description.strip()
        if description.casefold().startswith(title.casefold()):
            description = description[len(title):].lstrip(" .:-\t")
            publisher = cls.cyberbuddy_news_source(item)
            if publisher:
                labels = (publisher, "AP News") if publisher == "AP" else (publisher,)
                if description.casefold() in (label.casefold() for label in labels):
                    return ""
        return description

    def fetch_english_news_sources(self):
        """Use publisher-identified AP/Reuters results; fail back to English RSS."""
        results = []
        for publisher, site in (("AP", "apnews.com"), ("Reuters", "reuters.com")):
            query = urllib.parse.urlencode({
                "q": "site:" + site, "hl": "en-US", "gl": "US", "ceid": "US:en"})
            try:
                items = self.fetch_news_items("https://news.google.com/rss/search?" + query)
                verified = [item for item in items
                            if self.cyberbuddy_news_source(item) == publisher]
                if not verified:
                    log.warning("NEWS %s publisher results could not be verified", publisher)
                results.extend(verified[:8])
            except Exception as error:
                log.warning("NEWS %s search unavailable: %s", publisher, error)
        if not results:
            log.warning("NEWS publisher search unavailable; using configured English feed")
            results = self.fetch_news_items()
        return results

    def fetch_cyberbuddy_news_categories(self):
        """Use current RSS sections; never fill missing sections with old news."""
        base = "https://moxie.foxnews.com/google-publisher/"
        latest = self.fetch_english_news_sources()
        fox = "foxnews.com" in CFG.get("web_watching", "news_feed", fallback="").lower()
        section_items = {}
        if fox:
            for name, url in (("Science News", base + "science.xml"),
                              ("Medical News", base + "health.xml"),
                              ("Tech News", base + "tech.xml"),
                              ("Business News", "https://moxie.foxbusiness.com/google-publisher/latest.xml")):
                try:
                    section_items[name] = self.fetch_news_items(url)[:5]
                except Exception as error:
                    log.warning("NEWS CATEGORY %s unavailable: %s", name, error)
                    section_items[name] = []
        try:
            science = [item for item in self.fetch_news_items(
                "https://www.livescience.com/feeds/all")
                if self.cyberbuddy_news_source(item) == "LiveScience"]
            if science:
                section_items["Science News"] = science[:5]
        except Exception as error:
            log.warning("NEWS LiveScience feed unavailable: %s", error)
        for category, terms in (
            ("Media News", '(television OR cinema OR journalism OR entertainment)'),
            ("Off Beat News", '("odd news" OR "strange news" OR "unusual discovery")'),
        ):
            found = []
            for publisher, domain in (("AP", "apnews.com"),
                                      ("Reuters", "reuters.com")):
                query = urllib.parse.urlencode({
                    "q": "site:" + domain + " " + terms,
                    "hl": "en-US", "gl": "US", "ceid": "US:en"})
                try:
                    found.extend(item for item in self.fetch_news_items(
                        "https://news.google.com/rss/search?" + query)
                        if self.cyberbuddy_news_source(item) == publisher)
                except Exception as error:
                    log.warning("NEWS CATEGORY %s unavailable: %s", category, error)
            section_items[category] = found[:5]
        def section(name, paths):
            if name in section_items:
                return section_items[name]
            return [item for item in latest if any(
                path in (item.findtext("link") or "").lower() for path in paths)][:5]
        return (
            ("Top Stories", latest[:8]),
            ("Media News", section("Media News", ("/media/", "/entertainment/"))),
            ("Business News", section("Business News", ("/business/", "/economy/"))),
            ("Science News", section("Science News", ("/science/",))),
            ("Medical News", section("Medical News", ("/health/",))),
            ("Off Beat News", section("Off Beat News", ("/odd-news/", "/lifestyle/"))),
            ("Tech News", section("Tech News", ("/tech/",))),
        )

    def send_cyberbuddy_newspage(self):
        """Render live RSS in the original CyberBuddy news page's list layout."""
        categories = self.fetch_cyberbuddy_news_categories()
        sections = []
        for name, items in categories:
            rows = []
            seen = set()
            for item in items:
                title = self.cyberbuddy_news_title(item)
                description = clean_news_text(re.sub(
                    r"<[^>]*>", " ", item.findtext("description") or ""))
                description = re.sub(r"\s+", " ", html.unescape(description)).strip()
                link = (item.findtext("link") or "").strip()
                if not title:
                    continue
                key = (link or title).casefold()
                if key in seen:
                    continue
                seen.add(key)
                headline = html.escape(title, quote=False)
                if link.startswith(("https://", "http://")):
                    headline = ('<a href="' + html.escape(link, quote=True) + '">' +
                                headline + '</a>')
                # The 2013 page has headline and synopsis on the same list line.
                if description and description.casefold() != title.casefold():
                    description = self.cyberbuddy_news_description(description, title, item)
                    if description:
                        headline += ' ' + html.escape(description, quote=False)
                rows.append('<li>' + headline + '<br></li>')
            sections.append('<p></p><center><b>' + html.escape(name) + '</b></center><br>' +
                            (''.join(rows) if rows else
                             'No current headlines in this category.<br>'))
        page = ('<html><head><meta http-equiv="Content-Type" '
                'content="text/html; charset=windows-1252"><title>CyberBuddy News</title>'
                '<style type="text/css">td { font-family: verdana,arial,sans-serif; '
                'font-size: 12pt; }</style></head>'
                '<body bgcolor="#FAFAFA" text="#000000">'
                '<center><font size="4" color="red"> - CyberBuddy News Page - '
                '</font></center><p></p><center><table width="80%"><tr><td><br>' +
                ''.join(sections) + '</td></tr></table></center><br><br><p></p>'
                '<center><font size="-2">CyberBuddy News Processor</font></center>'
                '</body></html>')
        self.send_html(200, "OK", page)
        log.info("CYBERBUDDY NEWSPAGE -> 200 (fresh RSS)")

    def send_legacy_weather(self, location="São Paulo", unit_override=None, weather_endpoint="forecast.cgi"):
        """Resolve any world city and fetches live Open-Meteo conditions."""
        # CyberBuddy's old default is simply "Formosa".  Without context,
        # Nominatim can interpret that as Ilha Formosa (Taiwan); the intended
        # Brazilian city is Formosa, Goiás.
        original_location = clean_news_text(location)
        location = original_location
        if location.strip().upper() == "KPIT":
            location = "Pittsburgh International Airport, Pennsylvania, USA"
        if (not location or "formosa" in location.strip().lower()
                and "ilha" not in location.strip().lower()):
            location = "Formosa, Goiás, Brasil"
        english = True
        temperature_display = (unit_override or CFG.get("weather", "temperature_display", fallback="both")).strip().lower()
        if temperature_display not in ("fahrenheit", "celsius", "both"):
            temperature_display = "both"
        geo_common = {"format": "jsonv2", "limit": 1, "addressdetails": 1,
                      "accept-language": "en" if english else "pt-BR"}
        if re.fullmatch(r"\d{5}", location):
            geo_queries = [{"postalcode": location, "countrycodes": "us"},
                           {"q": location + ", United States", "countrycodes": "us"}]
        elif re.fullmatch(r"[A-Za-z]{4}", location):
            # Historic Unisys forecast links commonly use ICAO station IDs
            # (KSEA, KMIA, CYSJ, ...).  Nominatim resolves them more reliably
            # when the request explicitly says airport.
            station = location.upper()
            geo_queries = [{"q": station + " airport"}, {"q": station}]
        else:
            geo_queries = [{"q": location}]
            if location.casefold() in ("brasilia", "brasília"):
                geo_queries.append({"q": "Brasília, Distrito Federal, Brasil", "countrycodes": "br"})
        places = []
        for geo_query in geo_queries:
            geo_url = "https://nominatim.openstreetmap.org/search?" + urllib.parse.urlencode({**geo_common, **geo_query})
            places = cached_geocode(geo_url, "CyberBuddyClassicProxy/6.0 (weather)")
            if places:
                break
        if not places:
            raise ValueError("city not found")
        place = places[0]
        # Never allow the ambiguous Taiwan result for CyberBuddy's default
        # Brazilian Formosa request.
        if "formosa" in original_location.strip().lower() and (
                "taiwan" in place.get("display_name", "").lower()
                or "臺灣" in place.get("display_name", "")):
            geo_url = "https://nominatim.openstreetmap.org/search?" + urllib.parse.urlencode({
                "q": "Formosa, Goiás, Brasil", "format": "jsonv2", "limit": 1,
                "accept-language": "pt-BR", "countrycodes": "br",
            })
            places = cached_geocode(geo_url, "CyberBuddyClassicProxy/6.0 (weather)")
            if not places:
                raise ValueError("Formosa, Goias was not found")
            place = places[0]
        lat, lon = float(place["lat"]), float(place["lon"])
        weather_url = "https://api.open-meteo.com/v1/forecast?" + urllib.parse.urlencode({
            "latitude": lat, "longitude": lon,
            "current": "temperature_2m,relative_humidity_2m,weather_code,cloud_cover,wind_speed_10m,wind_direction_10m,dew_point_2m,apparent_temperature,pressure_msl,visibility,is_day",
            "daily": "weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,wind_speed_10m_max,sunrise,sunset",
            "hourly": "temperature_2m,weather_code,precipitation_probability,precipitation,wind_speed_10m,wind_direction_10m",
            "forecast_days": 8,
            "timezone": "auto", "temperature_unit": "celsius", "wind_speed_unit": "kmh",
        })
        weather, weather_is_stale = cached_forecast(weather_url)
        current = weather.get("current", {})
        labels = {0:"clear",1:"mostly clear",2:"partly cloudy",3:"overcast",45:"fog",48:"fog",51:"light drizzle",53:"drizzle",55:"heavy drizzle",61:"light rain",63:"rain",65:"heavy rain",71:"light snow",73:"snow",75:"heavy snow",80:"rain showers",81:"rain showers",82:"heavy rain showers",95:"thunderstorm",96:"thunderstorm with hail",99:"thunderstorm with hail"}
        city = forecast_place_name(place, original_location)
        condition = labels.get(current.get('weather_code'), 'conditions unavailable')
        skies_condition = condition
        if current.get('weather_code') not in {0, 1, 2, 3, 45, 48}:
            try:
                cloud_cover = float(current['cloud_cover'])
                skies_condition = ("clear" if cloud_cover <= 10 else
                                   "mostly clear" if cloud_cover <= 30 else
                                   "partly cloudy" if cloud_cover <= 65 else
                                   "mostly cloudy" if cloud_cover <= 85 else "overcast")
            except (KeyError, TypeError, ValueError):
                skies_condition = "cloudy"
        temp = current.get('temperature_2m', 'unavailable')
        try:
            temp_speech = str(round(float(temp)))
            temp_f = str(round(float(temp) * 9 / 5 + 32))
        except (TypeError, ValueError):
            temp_speech = str(temp)
            temp_f = "unavailable"
        humidity = current.get('relative_humidity_2m', 'unavailable')
        wind = current.get('wind_speed_10m', 'unavailable')
        degrees = current.get('wind_direction_10m')
        directions = ("north", "north northeast", "northeast", "east northeast",
                      "east", "east southeast", "southeast", "south southeast",
                      "south", "south southwest", "southwest", "west southwest",
                      "west", "west northwest", "northwest", "north northwest")
        try:
            wind_direction = directions[round(float(degrees) / 22.5) % 16]
        except (TypeError, ValueError):
            wind_direction = "unknown direction"
        try:
            wind_mph = str(round(float(wind) / 1.609344))
        except (TypeError, ValueError):
            wind_mph = "unavailable"
        compass = ("N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE",
                   "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW")
        try:
            wind_legacy = f"{compass[round(float(degrees) / 22.5) % 16]} at {round(float(wind) / 1.852)} knt"
        except (TypeError, ValueError):
            wind_legacy = "unavailable"
        def weather_icon(code, small=False, night=False):
            name = ("Moon" if code == 0 and night else
                    "MoonCloudy" if code in {1, 2} and night else
                    "Sun" if code == 0 else "PartlyCloudy" if code in {1, 2} else
                    "Clouds" if code == 3 else "Foggy" if code in {45, 48} else
                    "Snow" if code in {71, 73, 75} else "Thunder" if code in {95, 96, 99} else "Rain")
            return name + ("-s" if small else "") + ".png"
        icon = weather_icon(current.get("weather_code"), night=observation_is_night(current, weather.get('daily', {})))
        # Keep the field names used by the archived Unisys Weather page.  The
        # original CyberBuddy weather reader looks for these labels rather
        # than arbitrary prose.
        if english:
            temperature_text = {
                "fahrenheit": f"{html.escape(temp_f)} F",
                "celsius": f"{html.escape(temp_speech)} C",
                "both": f"{html.escape(temp_f)} F ({html.escape(temp_speech)} C)",
            }[temperature_display]
            observed = current.get("time")
            local_time = ""
            if observed:
                try:
                    stamp = datetime.datetime.fromisoformat(str(observed))
                    zone = html.escape(str(weather.get("timezone_abbreviation") or "local time"))
                    local_time = f"Time: <b>{stamp.strftime('%I:%M %p %d %b %y').lstrip('0')} {zone}</b><br>"
                except ValueError:
                    local_time = f"Time: <b>{html.escape(str(observed))}</b><br>"
            details = place.get("address") or {}
            suffix = ", ".join(filter(None, [details.get("state_code"), details.get("postcode")]))
            location_name = city + (f" ({suffix})" if suffix else "")
            # The 2001 reader expects these exact observation labels in an
            # HTML table, not prose paragraphs authored by the proxy.
            weather_fields = ("<div class=\"drop\"><table align=\"center\"><tr><td width=\"99%\" valign=\"top\"><br>"
                              f"<font face=\"Arial, Helvetica, sans-serif\"><big><b>Latest Observation for {html.escape(location_name, quote=False)}"
                              "</b></big></font><br><table width=\"99%\"><tr><td width=\"100\" valign=\"top\">"
                              f"<p align=\"center\"><img src=\"/weather_assets/{icon}\" width=\"100\" height=\"100\" alt=\"Weather\">"
                              f"<br><font face=\"Arial, Helvetica, sans-serif\"><b>Temp: {temperature_text}</b></font></p>"
                              "</td><td valign=\"top\"><font face=\"Arial, Helvetica, sans-serif\">"
                              f"Site: <b>{html.escape(city, quote=False)} (Open-Meteo)</b><br>"
                              f"{local_time}"
                              f"Temp: <b>{temperature_text}</b><br>"
                              )
            if weather_is_stale:
                weather_fields += "<b>Cached forecast: live weather service temporarily unavailable.</b><br>"
            dew = current.get("dew_point_2m")
            if dew is not None:
                dew_f = round(float(dew) * 9 / 5 + 32)
                dew_c = round(float(dew))
                dew_text = {"fahrenheit": f"{dew_f} F", "celsius": f"{dew_c} C",
                            "both": f"{dew_f} F ({dew_c} C)"}[temperature_display]
                weather_fields += f"Dewpt: <b>{dew_text}</b><br>"
            weather_fields += (f"Rel Hum: <b>{html.escape(str(humidity))}%</b><br>"
                               f"Winds: <b>{html.escape(wind_legacy)}</b><br>")
            apparent = current.get("apparent_temperature")
            if apparent is not None and float(apparent) < float(temp):
                apparent_c = round(float(apparent))
                apparent_f = round(float(apparent) * 9 / 5 + 32)
                apparent_text = {"fahrenheit": f"{apparent_f} F", "celsius": f"{apparent_c} C",
                                 "both": f"{apparent_f} F ({apparent_c} C)"}[temperature_display]
                weather_fields += f"Feels like: <b>{apparent_text}</b><br>"
            pressure = current.get("pressure_msl")
            if pressure is not None:
                weather_fields += f"Pressure (sea level): <b>{float(pressure):.1f} mb</b><br>"
            visibility = current.get("visibility")
            if visibility is not None:
                weather_fields += f"Visibility: <b>{float(visibility) / 1609.344:.1f} mi</b><br>"
            weather_fields += (f"Skies: <b>{html.escape(skies_condition, quote=False)}</b><br>"
                               f"Weather: <b>{html.escape('' if current.get('weather_code') in {0, 1, 2, 3} else condition, quote=False)}</b><br>"
                               "</font></td><td valign=\"top\"><font face=\"Arial, Helvetica, sans-serif\"><b>Almanac</b><br>")
            daily = weather.get("daily", {})
            def daily_at(key, index):
                values = daily.get(key) or []
                return values[index] if index < len(values) else None
            for label, key in (("Sunrise", "sunrise"), ("Sunset", "sunset")):
                value = daily_at(key, 0)
                if value:
                    try:
                        hour = datetime.datetime.fromisoformat(str(value)).strftime("%I:%M %p").lstrip("0")
                    except ValueError:
                        hour = str(value).split('T')[-1]
                    weather_fields += f"{label}: <b>{html.escape(hour)}</b><br>"
            weather_fields += ("</font></td></tr></table><small>Temperature: "
                               f"<a href=\"/{weather_endpoint}/{urllib.parse.quote(original_location, safe='')}?unit=fahrenheit\">Fahrenheit</a> | "
                               f"<a href=\"/{weather_endpoint}/{urllib.parse.quote(original_location, safe='')}?unit=celsius\">Celsius</a> | "
                               f"<a href=\"/{weather_endpoint}/{urllib.parse.quote(original_location, safe='')}?unit=both\">Both</a></small><br>"
                               "<table><tr><td><b>Regional Plots:</b></td><td>Live plots unavailable for this location.</td></tr></table>")
            forecast_html = ""
            days = daily.get("time") or []
            hourly = weather.get("hourly") or {}
            hourly_times = hourly.get("time") or []
            hourly_index = {str(value): index for index, value in enumerate(hourly_times)}
            def hourly_at(day, hour, variable):
                index = hourly_index.get(f"{day}T{hour:02d}:00")
                values = hourly.get(variable) or []
                return values[index] if index is not None and index < len(values) else None
            def forecast_row(icon_name, title, temperature_line, narrative):
                icon_labels = {"Moon-s.png": "Starry", "MoonCloudy-s.png": "Partly Cloudy",
                               "PartlyCloudy-s.png": "Partly Cloudy", "Sun-s.png": "Sunny",
                               "Rain-s.png": "Rainy", "Clouds-s.png": "Cloudy",
                               "Thunder-s.png": "Thunder", "Snow-s.png": "Snow",
                               "Foggy-s.png": "Foggy"}
                icon_alt = html.escape(icon_labels.get(icon_name, "Weather"), quote=True)
                return (f'<tr><td width="15%" align="center"><img src="/weather_assets/{icon_name}" '
                        f'width="50" height="50" alt="{icon_alt}"></td><td width="85%" valign="top">'
                        f'<font face="Arial, Helvetica, sans-serif"><b>{html.escape(title)}<br>'
                        f'{html.escape(temperature_line)}<br></b>{html.escape(narrative)}</font></td></tr>')
            if days:
                night_now = observation_is_night(current, daily)
                try:
                    local_hour = datetime.datetime.fromisoformat(str(current["time"])).hour
                except (KeyError, TypeError, ValueError):
                    local_hour = 12 if night_now else 9
                # The old forecast changes its seven-card window during the
                # afternoon, earlier than the observation icon changes to moon.
                next_day_window = night_now or local_hour >= 12
                def display_temperature(value):
                    try:
                        c = round(float(value))
                        f = round(float(value) * 9 / 5 + 32)
                    except (ValueError, TypeError):
                        return "unavailable"
                    return {"fahrenheit": f"{f} F", "celsius": f"{c} C",
                            "both": f"{f} F ({c} C)"}[temperature_display]
                def summary_degrees(value):
                    """The old seven-column summary prints plain degree numbers."""
                    try:
                        c = float(value)
                        return str(round(c if temperature_display == "celsius" else c * 9 / 5 + 32))
                    except (TypeError, ValueError):
                        return "?"
                def temperature_band(value, plural):
                    try:
                        amount = round(float(value) if temperature_display == "celsius"
                                       else float(value) * 9 / 5 + 32)
                    except (TypeError, ValueError):
                        return "TEMPERATURES UNAVAILABLE"
                    digit = amount % 10
                    band = "LOWER" if digit < 4 else "MID" if digit < 7 else "UPPER"
                    tens = amount - digit
                    if amount < 0:
                        return f"{plural} NEAR {amount}"
                    return f"{plural} IN THE {band} {tens}S"
                def period_temperature_phrase(values, plural, fallback):
                    """Use the original short NWS-style temperature band wording."""
                    readings = [float(v) for v in values if v is not None]
                    if len(readings) < 2:
                        return temperature_band(fallback, plural)
                    low, high = min(readings), max(readings)
                    degrees = lambda v: round(v if temperature_display == "celsius" else v * 9 / 5 + 32)
                    if degrees(high) - degrees(low) < 9:
                        return temperature_band(fallback, plural)
                    # A point forecast's hourly span is not the regional range
                    # in an old NWS text forecast. Avoid a range that conflicts
                    # with the displayed daily high or exaggerates nighttime lows.
                    if ((plural == "HIGHS" and abs(degrees(high) - degrees(fallback)) > 3) or
                            (plural == "LOWS" and degrees(high) - degrees(low) > 15)):
                        return temperature_band(fallback, plural)
                    def range_end(value):
                        amount = degrees(value)
                        if amount < 0:
                            return str(amount)
                        digit = amount % 10
                        if digit < 4:
                            return f"LOWER {amount - digit}S"
                        if digit < 7:
                            return f"MID {amount - digit}S"
                        return f"UPPER {amount - digit}S"
                    first, last = range_end(low), range_end(high)
                    # A point-forecast hourly swing is not the same as the
                    # NWS regional range. Use one band unless both ends are
                    # within the same decade and close to the reported high.
                    if plural == 'HIGHS' and degrees(low) // 10 == degrees(high) // 10:
                        return (f"HIGHS IN THE {first.split()[0]} TO {last}"
                                if first != last else temperature_band(fallback, plural))
                    return temperature_band(fallback, plural)
                def sky_phrase(code, night=False):
                    if night:
                        return {0: "CLEAR", 1: "MOSTLY CLEAR", 2: "PARTLY CLOUDY",
                                3: "CLOUDY"}.get(code, labels.get(code, "CONDITIONS UNAVAILABLE").upper())
                    return {0: "SUNNY", 1: "MOSTLY SUNNY", 2: "PARTLY CLOUDY",
                            3: "CLOUDY"}.get(code, labels.get(code, "CONDITIONS UNAVAILABLE").upper())
                def precip_phrase(code, chance):
                    try:
                        if chance is None or float(chance) < 20:
                            return ""
                    except (TypeError, ValueError):
                        return ""
                    # A wet weather code already names the precipitation in
                    # sky_phrase. Repeating a 100% probability after "RAIN"
                    # or "DRIZZLE" makes the old-style forecast sound broken.
                    if code in {51, 53, 55, 61, 63, 65, 66, 67, 71, 73, 75,
                                77, 80, 81, 82, 85, 86, 95, 96, 99}:
                        return ""
                    event = ("DRIZZLE" if code in {51, 53, 55} else
                             "SNOW" if code in {71, 73, 75, 77, 85, 86} else
                             "THUNDERSTORMS" if code in {95, 96, 99} else "SHOWERS")
                    likelihood = ("A SLIGHT CHANCE OF" if float(chance) < 30 else
                                  "A CHANCE OF" if float(chance) < 55 else
                                  "LIKELY")
                    return (f" {event} LIKELY." if likelihood == "LIKELY" else
                            f" {likelihood} {event}.")
                def thunder_narrative(day, hours):
                    """Describe storms only when the live hourly forecast supports them."""
                    samples = [(hourly_at(day, hour, 'weather_code'),
                                hourly_at(day, hour, 'precipitation_probability'),
                                hourly_at(day, hour, 'precipitation')) for hour in hours]
                    storm = [(code, probability, rain) for code, probability, rain in samples
                             if code in {95, 96, 99}]
                    if not storm:
                        return ''
                    likely = sum((probability or 0) >= 60 for _, probability, _ in storm) >= 2
                    storm_hours = [hour for hour, (code, _, _) in zip(hours, samples)
                                   if code in {95, 96, 99}]
                    timing = (' IN THE EVENING' if min(hours) >= 19 else
                              ' IN THE AFTERNOON' if min(hours) < 19 and
                              min(storm_hours) >= 12 else '')
                    wording = ('NUMEROUS' if likely else 'SCATTERED') + ' SHOWERS AND THUNDERSTORMS'
                    heavy = any(rain is not None and float(rain) >= 8 for _, _, rain in storm)
                    if heavy:
                        wording += '. SOME THUNDERSTORMS MAY PRODUCE HEAVY RAINFALL' + timing
                    return wording + ('' if heavy else timing) + '.'
                def wind_phrase(speed, direction=None):
                    try:
                        speed = float(speed)
                    except (TypeError, ValueError):
                        return ""
                    if speed < 8:
                        return " LIGHT AND VARIABLE WINDS."
                    unit = "KM/H" if temperature_display == "celsius" else "MPH"
                    amount = round(speed if unit == "KM/H" else speed / 1.609344)
                    if direction is None:
                        return f" WINDS AROUND {amount} {unit}."
                    try:
                        directions = ("NORTH", "NORTH NORTHEAST", "NORTHEAST", "EAST NORTHEAST",
                                      "EAST", "EAST SOUTHEAST", "SOUTHEAST", "SOUTH SOUTHEAST",
                                      "SOUTH", "SOUTH SOUTHWEST", "SOUTHWEST", "WEST SOUTHWEST",
                                      "WEST", "WEST NORTHWEST", "NORTHWEST", "NORTH NORTHWEST")
                        compass_point = directions[round(float(direction) / 22.5) % 16]
                    except (TypeError, ValueError):
                        compass_point = ""
                    return f" {compass_point} WINDS AROUND {amount} {unit}."
                def period_wind_phrase(day, hours, ending=None, next_day=None):
                    samples = []
                    for hour in hours:
                        speed = hourly_at(day, hour, "wind_speed_10m")
                        direction = hourly_at(day, hour, "wind_direction_10m")
                        if speed is not None:
                            samples.append((float(speed), direction))
                    if next_day is not None:
                        for hour in range(0, 7):
                            speed = hourly_at(next_day, hour, "wind_speed_10m")
                            direction = hourly_at(next_day, hour, "wind_direction_10m")
                            if speed is not None:
                                samples.append((float(speed), direction))
                    if not samples:
                        return ""
                    unit = "KM/H" if temperature_display == "celsius" else "MPH"
                    def mph(kmh):
                        return round(kmh if unit == "KM/H" else kmh / 1.609344)
                    def wind_range(part):
                        speeds = [mph(s) for s, _ in part]
                        lo, hi = min(speeds), max(speeds)
                        return f"AROUND {hi} {unit}" if hi - lo < 4 else f"{lo} TO {hi} {unit}"
                    def direction_name(value):
                        if value is None:
                            return ""
                        names = ("NORTH", "NORTH NORTHEAST", "NORTHEAST", "EAST NORTHEAST",
                                 "EAST", "EAST SOUTHEAST", "SOUTHEAST", "SOUTH SOUTHEAST",
                                 "SOUTH", "SOUTH SOUTHWEST", "SOUTHWEST", "WEST SOUTHWEST",
                                 "WEST", "WEST NORTHWEST", "NORTHWEST", "NORTH NORTHWEST")
                        return names[round(float(value) / 22.5) % 16]
                    if max(s for s, _ in samples) < 8:
                        return " LIGHT AND VARIABLE WINDS."
                    midpoint = len(samples) // 2
                    early, late = samples[:midpoint], samples[midpoint:]
                    first_dir = direction_name(early[0][1]) if early else ""
                    last_dir = direction_name(late[-1][1]) if late else first_dir
                    first_angle = early[0][1] if early else None
                    last_angle = late[-1][1] if late else None
                    turning = (first_angle is not None and last_angle is not None and
                               abs((float(last_angle) - float(first_angle) + 180) % 360 - 180) >= 45)
                    if first_dir and last_dir and turning and early and late:
                        timing = "AFTER MIDNIGHT" if ending == "night" else "IN THE AFTERNOON"
                        return (f" {first_dir} WINDS {wind_range(early)} SHIFTING TO THE "
                                f"{last_dir} {wind_range(late)} {timing}.")
                    if early and late and abs(mph(max(s for s, _ in late)) -
                                              mph(max(s for s, _ in early))) >= 6:
                        rising = max(s for s, _ in late) > max(s for s, _ in early)
                        timing = "AFTER MIDNIGHT" if ending == "night" else "IN THE AFTERNOON"
                        change = "INCREASING" if rising else "DECREASING"
                        return (f" {first_dir + ' ' if first_dir else ''}WINDS {wind_range(early)} "
                                f"{change} TO {wind_range(late)} {timing}.")
                    return f" {first_dir + ' ' if first_dir else ''}WINDS {wind_range(samples)}."
                rows = []
                periods = []
                for i, day in enumerate(days[:8]):
                    try:
                        label = "TODAY" if i == 0 else datetime.date.fromisoformat(str(day)).strftime("%A").upper()
                    except ValueError:
                        label = html.escape(str(day))
                    high = html.escape(display_temperature(daily_at("temperature_2m_max", i)))
                    low = html.escape(display_temperature(daily_at("temperature_2m_min", i)))
                    description = html.escape(labels.get(daily_at("weather_code", i), "conditions unavailable"))
                    chance = daily_at("precipitation_probability_max", i)
                    wind_max = daily_at("wind_speed_10m_max", i)
                    morning_code = hourly_at(day, 9, "weather_code")
                    afternoon_code = hourly_at(day, 15, "weather_code")
                    # Match the visible daytime period: morning conditions for
                    # TODAY before noon; afternoon conditions for future days.
                    # The daily code may refer to rain overnight instead.
                    preferred_code = morning_code if i == 0 and local_hour < 12 else afternoon_code
                    icon_code = (preferred_code if preferred_code is not None else
                                 afternoon_code if afternoon_code is not None else
                                 morning_code if morning_code is not None else
                                 daily_at("weather_code", i))
                    if any(hourly_at(day, hour, 'weather_code') in {95, 96, 99}
                           for hour in range(8, 19)):
                        icon_code = 95
                    small_icon = weather_icon(icon_code, small=True)
                    # The 2013 Unisys summary displays both HI and LO in every
                    # daily column. Values are live; only the presentation is historic.
                    summary_high = summary_degrees(daily_at("temperature_2m_max", i))
                    summary_low = summary_degrees(daily_at("temperature_2m_min", i))
                    if i > 0:
                        previous_evening = [hourly_at(days[i - 1], hour, "temperature_2m")
                                            for hour in range(18, 24)]
                        next_morning = [hourly_at(day, hour, "temperature_2m")
                                        for hour in range(7)]
                        overnight_values = [float(value) for value in previous_evening + next_morning
                                            if value is not None]
                        if overnight_values:
                            summary_low = summary_degrees(min(overnight_values))
                    # Match the archived page's daytime/evening summary.
                    if i >= (1 if next_day_window else 0) and len(rows) < 7:
                        summary_label = ("TODAY" if i == 0 else
                                         datetime.date.fromisoformat(str(day)).strftime("%A").upper())
                        rows.append(f"<td width=\"14%\" valign=\"top\" align=\"center\"><font face=\"Arial, Helvetica, sans-serif\"><b>{summary_label}<br>"
                                    f"<img src=\"/weather_assets/{small_icon}\" width=\"50\" height=\"50\" alt=\"{description}\"><br>"
                                    f"HI: {summary_high}<br>" +
                                    (f"LO: {summary_low}<br>" if i > 0 or next_day_window else "") +
                                    "</b></font></td>")
                    daytime_storm = thunder_narrative(day, range(8, 19))
                    if daytime_storm:
                        early_sky = morning_code if morning_code in {0, 1, 2, 3} else None
                        detail = ((sky_phrase(early_sky) + '. ' if early_sky is not None
                                   and 'AFTERNOON' in daytime_storm else '') + daytime_storm)
                    elif morning_code is not None and afternoon_code is not None:
                        morning_name = sky_phrase(morning_code)
                        afternoon_name = sky_phrase(afternoon_code)
                        detail = (f"{morning_name} THIS MORNING, THEN {afternoon_name} THIS AFTERNOON."
                                  if morning_name != afternoon_name else f"{morning_name}.")
                    else:
                        detail = f"{sky_phrase(daily_at('weather_code', i))}."
                    if i > 0:
                        old_high, new_high = daily_at("temperature_2m_max", i - 1), daily_at("temperature_2m_max", i)
                        if old_high is not None and new_high is not None:
                            difference = (float(new_high) - float(old_high)) * (1 if temperature_display == "celsius" else 9 / 5)
                            if abs(difference) >= (5 if temperature_display == "celsius" else 9):
                                detail += " WARMER." if difference > 0 else " COOLER."
                    if wind_max is not None:
                        maximum_mph = float(wind_max) / 1.609344
                        if maximum_mph >= 25:
                            detail += " WINDY."
                        elif maximum_mph >= 15:
                            detail += " BREEZY."
                    if not daytime_storm:
                        precipitation = precip_phrase(daily_at("weather_code", i), chance)
                        if precipitation.startswith(' A CHANCE') or precipitation.startswith(' A SLIGHT CHANCE'):
                            detail = detail.rstrip('.') + ' WITH' + precipitation
                        else:
                            detail += precipitation
                    day_hours = range(8, 19)
                    day_temps = [hourly_at(day, hour, "temperature_2m") for hour in day_hours]
                    detail += f" {period_temperature_phrase(day_temps, 'HIGHS', daily_at('temperature_2m_max', i))}."
                    detail += period_wind_phrase(day, day_hours)
                    daytime = {"title": label, "icon": small_icon,
                               "temp": f"HI: {summary_high}",
                               "text": detail, "high": summary_high, "chance": chance}
                    night_code = hourly_at(day, 21, "weather_code")
                    night_chance = hourly_at(day, 21, "precipitation_probability")
                    night_wind = hourly_at(day, 21, "wind_speed_10m")
                    nighttime = None
                    if night_code is not None:
                        evening = [hourly_at(day, hour, "temperature_2m") for hour in range(18, 24)]
                        next_day = days[i + 1] if i + 1 < len(days) else None
                        if next_day:
                            evening += [hourly_at(next_day, hour, "temperature_2m") for hour in range(7)]
                        readings = [float(value) for value in evening if value is not None]
                        night_low = min(readings) if readings else daily_at("temperature_2m_min", i)
                        night_title = "TONIGHT" if i == 0 else label + " NIGHT"
                        night_storm = thunder_narrative(day, range(19, 24))
                        evening_sky = hourly_at(day, 19, 'weather_code')
                        night_text = ((sky_phrase(evening_sky, night=True) + '. '
                                       if night_storm and evening_sky in {0, 1, 2, 3}
                                       and 'IN THE EVENING' not in night_storm else '') +
                                      (night_storm if night_storm else
                                       f"{sky_phrase(night_code, night=True)}."))
                        if next_day and daily_at("temperature_2m_min", i) is not None:
                            old_low = daily_at("temperature_2m_min", i - 1) if i else None
                            if old_low is not None:
                                difference = (float(night_low) - float(old_low)) * (1 if temperature_display == "celsius" else 9 / 5)
                                if difference <= -(5 if temperature_display == "celsius" else 9):
                                    night_text += " COLDER."
                        if not night_storm:
                            precipitation = precip_phrase(night_code, night_chance)
                            if precipitation.startswith(' A CHANCE') or precipitation.startswith(' A SLIGHT CHANCE'):
                                night_text = night_text.rstrip('.') + ' WITH' + precipitation
                            else:
                                night_text += precipitation
                        night_text += f" {period_temperature_phrase(evening, 'LOWS', night_low)}."
                        night_text += period_wind_phrase(day, range(19, 24), ending="night", next_day=next_day)
                        nighttime = {"title": night_title, "icon": weather_icon(night_code, small=True, night=True),
                                     "temp": f"LO: {summary_degrees(night_low)}", "text": night_text,
                                     "low": summary_degrees(night_low), "chance": night_chance,
                                     "condition": sky_phrase(night_code, night=True), "low_c": night_low}
                    periods.append((daytime, nighttime))
                # The detailed sequence follows the afternoon forecast window;
                # the current-observation icon still follows sunrise/sunset.
                narratives = []
                def append_period(item):
                    if item:
                        narratives.append(forecast_row(item["icon"], item["title"],
                                                       item["temp"], item["text"]))
                if periods:
                    if not next_day_window:
                        append_period(periods[0][0])
                    first_night = periods[0][1]
                    if first_night:
                        tonight = dict(first_night)
                        tonight["title"] = "TONIGHT"
                        append_period(tonight)
                    visible_periods = periods[1:8] if next_day_window else periods[1:7]
                    for index, (daytime, nighttime) in enumerate(visible_periods):
                        append_period(daytime)
                        # The last detailed row is the seventh summary day.
                        if index < len(visible_periods) - 1:
                            append_period(nighttime)
                area_name = html.escape(city.upper(), quote=False)
                try:
                    issue_dt = datetime.datetime.fromisoformat(str(current.get("time")))
                    issue_stamp = (issue_dt.strftime("%I%M %p").lstrip("0") + " " +
                                   html.escape(zone) + " " +
                                   issue_dt.strftime("%a %b %d %Y").upper())
                except (ValueError, TypeError):
                    issue_stamp = "CURRENT FORECAST"
                detail_header = (f"{area_name} AREA-<br>"
                                 f"INCLUDING THE CITIES OF...{area_name}<br>" +
                                 f"{issue_stamp}<br><br>")
                forecast_html = ("<hr><font face=\"Arial, Helvetica, sans-serif\"><b>Forecast Summary<br></b></font>"
                                 "<table width=\"100%\" border=\"1\"><tr align=\"center\">" +
                                 "".join(rows) + "</tr></table><br>"
                                 "<font face=\"Arial, Helvetica, sans-serif\"><b>Detailed forecast from Open-Meteo<br></b>" +
                                 detail_header + "</font>" +
                                 "<table width=\"100%\" border=\"1\">" + "".join(narratives) + "</table>")
            forecast_source = "Open-Meteo"
            country = place.get("address", {}).get("country_code", "").lower()
            if country == "us":
                nws_headers = {
                    "User-Agent": "CyberBuddyClassicProxy/6.0 (local-weather-bridge)",
                    "Accept": "application/geo+json"}
                try:
                    alert_url = ("https://api.weather.gov/alerts/active?" +
                                 urllib.parse.urlencode({"point": f"{lat},{lon}"}))
                    alert_request = urllib.request.Request(alert_url, headers=nws_headers)
                    with direct_urlopen(alert_request, timeout=min(TIMEOUT, 6)) as response:
                        active_alerts = json.loads(response.read().decode("utf-8")).get("features", [])
                    weather_fields += "<hr><font face=\"Arial, Helvetica, sans-serif\"><b>Alerts</b><br>"
                    if active_alerts:
                        for feature in active_alerts[:5]:
                            properties = feature.get("properties") or {}
                            event = html.escape(str(properties.get("event") or "Weather alert"))
                            body = str(properties.get("description") or properties.get("headline") or "")
                            statement = next((line.strip() for line in body.splitlines() if line.strip()), "")
                            if len(statement) > 220:
                                statement = statement[:217] + "..."
                            expiry_raw = str(properties.get("ends") or properties.get("expires") or "")
                            try:
                                expiry_dt = datetime.datetime.fromisoformat(expiry_raw.replace("Z", "+00:00"))
                                from zoneinfo import ZoneInfo
                                expiry_dt = expiry_dt.astimezone(ZoneInfo(str(weather.get("timezone"))))
                                expiry = expiry_dt.strftime("%I:%M %p %Z").lstrip("0")
                            except (ValueError, TypeError, KeyError, ImportError):
                                expiry = expiry_raw
                            weather_fields += (f"<b>{event} valid until {html.escape(expiry)}</b><br>"
                                               f"{html.escape(statement)}<br>")
                    else:
                        weather_fields += "No active alerts for this location.<br>"
                    weather_fields += "</font>"
                except (OSError, ValueError, KeyError, TypeError) as exc:
                    log.warning("NWS alerts unavailable for %s: %s", city, exc)
                    weather_fields += "<hr><b>Alerts</b><br>Alerts temporarily unavailable.<br>"
            elif country == "br":
                try:
                    notices = cached_inmet_alerts(place)
                    weather_fields += "<hr><b>Alerts (INMET)</b><br>"
                    translated = {"chuvas intensas": "Heavy Rain", "tempestade": "Thunderstorm",
                                  "vendaval": "High Winds", "baixa umidade": "Low Humidity",
                                  "onda de calor": "Heat Wave", "onda de frio": "Cold Wave",
                                  "geada": "Frost", "acumulado de chuva": "Heavy Rainfall"}
                    for event, until, message in notices:
                        try:
                            from zoneinfo import ZoneInfo
                            until = until.astimezone(ZoneInfo(str(weather.get("timezone"))))
                        except (ValueError, TypeError, KeyError, ImportError):
                            pass
                        until_text = until.strftime("%I:%M %p %Z").lstrip("0")
                        event_name = translated.get(event.casefold(), event)
                        weather_fields += (f"<b>{html.escape(event_name)} valid until "
                                           f"{html.escape(until_text)}</b><br>"
                                           f"{html.escape(message)}<br>")
                    if not notices:
                        weather_fields += "No active INMET alerts confirmed for this location.<br>"
                except (OSError, ValueError, ET.ParseError, KeyError) as exc:
                    log.warning("INMET alerts unavailable for %s: %s", city, exc)
                    weather_fields += "<hr><b>Alerts (INMET)</b><br>Alerts temporarily unavailable.<br>"
            else:
                try:
                    notices = fetch_global_alerts(place)
                    weather_fields += "<hr><b>Alerts (IFRC Alert Hub)</b><br>"
                    if notices is None:
                        weather_fields += "Alert coverage unavailable for this location.<br>"
                    elif not notices:
                        weather_fields += "No active location-matched weather alerts found.<br>"
                    else:
                        for event, until, message in notices:
                            try:
                                from zoneinfo import ZoneInfo
                                until = until.astimezone(ZoneInfo(str(weather.get('timezone'))))
                            except (ValueError, TypeError, KeyError, ImportError):
                                pass
                            expiry = until.strftime('%I:%M %p %Z').lstrip('0')
                            weather_fields += (f"<b>{html.escape(event)} valid until "
                                               f"{html.escape(expiry)}</b><br>"
                                               f"{html.escape(message)}<br>")
                except (OSError, ValueError, TypeError, KeyError, json.JSONDecodeError) as exc:
                    log.warning('IFRC alerts unavailable for %s: %s', city, exc)
                    weather_fields += '<hr><b>Alerts (IFRC Alert Hub)</b><br>Alerts temporarily unavailable.<br>'
            log.info("LEGACY WEATHER summary=%s details=%s location=%s version=%s",
                     forecast_source, forecast_source, city, APP_VERSION)
            weather_fields += forecast_html + "</td></tr></table></div>"
        page = self.weather_shell(weather_fields, icon)
        self.send_html(200, "OK", page)
        log.info("LEGACY WEATHER requested=%s | found=%s | Open-Meteo %.4f,%.4f",
                 original_location or "(default)", city, lat, lon)

    def send_weather_form(self, endpoint="forecast.cgi"):
        """Use the original forecast search form without a duplicate form."""
        if (WEATHER_SITE / "forecast.php").exists():
            content = ('<p>Enter a ZIP code, city name or airport in the '
                       'search box above to get the current forecast.</p>')
        else:
            content = ('<big><b>Get a Forecast</b></big><br>'
                       '<p>Enter a ZIP code, city name or airport.</p>'
                       f'<form method="get" action="/{endpoint}">'
                       '<input type="text" name="Name" size="30">'
                       '<input type="submit" value="Get Forecast Data"></form>')
        page = self.weather_shell(content)
        self.send_html(200, "OK", page)

    def send_legacy_fun(self, kind):
        # Pick a random entry, but avoid immediately repeating the previous one.
        with FUN_LOCK:
            count = len(FUN_ITEMS[kind])
            index = random.SystemRandom().randrange(count)
            if count > 1 and index == FUN_LAST_INDEX[kind]:
                index = (index + random.SystemRandom().randrange(1, count)) % count
            FUN_LAST_INDEX[kind] = index
        text = FUN_ITEMS[kind][index]
        label = "Joke" if kind == "joke" else "Thought"
        # CyberBud.exe counts each $$ line as an entry, then reads
        # following lines until the next marker or EOF. A trailing marker
        # creates an empty selectable entry, so terminate with EOF instead.
        lines = [line.strip() for line in text.strip().splitlines() if line.strip()]
        payload = "$$" + label + "\r\n" + "\r\n".join(lines) + "\r\n"
        self.send_html(200, "OK", payload)
        log.info("LEGACY %s -> local response %d/%d", kind, index + 1, len(FUN_ITEMS[kind]))

    def send_legacy_rss_feed(self):
        items = self.fetch_english_news_sources()
        rows = []
        for item in items:
            title = re.sub(r"\s+", " ", clean_news_text(item.findtext("title") or "Untitled news")).strip()
            description = (item.findtext("description") or "").strip()
            description = re.sub(r"<[^>]+>", " ", description)
            description = clean_news_text(description)
            description = re.sub(r"\s+", " ", description).strip()
            link = (item.findtext("link") or "").strip()
            guid = (item.findtext("guid") or link).strip()
            pub_date = (item.findtext("pubDate") or "").strip()
            rows.append(
                "<item>"
                "<title>" + html.escape(title, quote=False) + "</title>"
                "<description>" + html.escape(description, quote=False) + "</description>"
                "<link>" + html.escape(link) + "</link>"
                + ("<guid isPermaLink=\"false\">" + html.escape(guid) + "</guid>" if guid else "")
                + ("<pubDate>" + html.escape(pub_date) + "</pubDate>" if pub_date else "")
                + "</item>"
            )
        rss = (
            "<?xml version=\"1.0\" encoding=\"windows-1252\"?>"
            "<rss version=\"2.0\"><channel>"
            "<title>CyberBuddy English News</title>"
            "<link>http://thecyberbuddy.com/news/newspage.html</link>"
            "<description>Live English headlines adapted for CyberBuddy</description>"
            + "".join(rows)
            + "</channel></rss>"
        )
        self.send_xml(200, "OK", rss)
        log.info("RSS LEGACY English -> 200 (%d items)", len(items))

    def handle(self):
        try:
            request = self.read_request()
            if request is None:
                return
            method, target, _version, headers, request_body = request

            if method == "CONNECT":
                self.handle_connect(target)
                return

            if method not in {"GET", "HEAD", "POST"}:
                self.send_simple(405, "Method Not Allowed", "Method not allowed.")
                return

            if not urllib.parse.urlsplit(target).scheme:
                host = headers.get("Host")
                if not host:
                    self.send_simple(400, "Bad Request", "Missing Host header.")
                    return
                target = f"http://{host}{target}"

            parsed = urllib.parse.urlsplit(target)
            if parsed.scheme not in {"http", "https"}:
                self.send_simple(400, "Bad Request", "Only HTTP and HTTPS are supported.")
                return

            # The old directory now returns a parked-domain landing-page
            # redirect. Never send chat account details or message bodies there.
            retired_chat_hosts = {"yeayou.com", "www.yeayou.com", "thecyberbuddy.com",
                                  "www.thecyberbuddy.com", "mycyberbuddy.com",
                                  "www.mycyberbuddy.com", "66.135.47.52", "66.135.38.69"}
            if ((parsed.hostname or '').lower() in {'thecyberbuddy.com','www.thecyberbuddy.com','127.0.0.1','localhost','proxy.local'}
                    and parsed.path.lower() in {'/page18.html','/page18.htm'}):
                payload = _invitebuddy_html()
                self.safe_write(('HTTP/1.0 200 OK\r\nContent-Type: text/html; charset=windows-1252\r\n'
                                 'Content-Length: %d\r\nCache-Control: no-store\r\nConnection: close\r\n\r\n' % len(payload)).encode('ascii'))
                if method != 'HEAD': self.safe_write(payload)
                return

            # Original UIN contact-list download. Archived 1111.cbb is exactly:
            # $$UIN1111\r\n
            _uin_cbb_match = re.match(r'^/cgi-bin/UIN/(\d+)\.cbb$', parsed.path, re.I)
            if ((parsed.hostname or '').lower() in retired_chat_hosts or
                    (parsed.hostname or '').lower() in {"127.0.0.1", "localhost", "proxy.local"}) and _uin_cbb_match:
                payload = _chat_uin_cbb(_uin_cbb_match.group(1))
                self.safe_write(("HTTP/1.0 200 OK\r\n"
                                 "Content-Type: application/octet-stream\r\n"
                                 "Content-Disposition: attachment; filename=\"%s.cbb\"\r\n"
                                 "Content-Length: %d\r\n"
                                 "Cache-Control: no-store\r\n"
                                 "Connection: close\r\n\r\n" % (_uin_cbb_match.group(1), len(payload))).encode("ascii"))
                if method != "HEAD": self.safe_write(payload)
                log.warning('LEGACY UIN CONTACT FILE served target=<hidden>')
                return

            # UINlister contact pages use a bare positional query: ?u<UIN>.
            # Handle this BEFORE the generic legacy chat protocol so it can never
            # be mistaken for a CBonline/UIN protocol request and return $$ markers.
            if (parsed.path.lower() == "/cgi-bin/uinlister.exe" and
                    ((parsed.hostname or '').lower() in retired_chat_hosts or
                     (parsed.hostname or '').lower() in {"127.0.0.1", "localhost", "proxy.local"})):
                _raw_uin_query = urllib.parse.unquote_plus(parsed.query or '').strip()
                _contact_match = re.fullmatch(r'[uU](\d+)', _raw_uin_query)
                if _contact_match:
                    payload = _chat_uin_contact_html(_contact_match.group(1))
                    self.safe_write(("HTTP/1.0 200 OK\r\n"
                                     "Content-Type: text/html; charset=windows-1252\r\n"
                                     "Content-Length: %d\r\n"
                                     "Cache-Control: no-store\r\n"
                                     "Connection: close\r\n\r\n" % len(payload)).encode("ascii"))
                    if method != "HEAD": self.safe_write(payload)
                    log.warning('LEGACY UIN DIRECTORY CONTACT PAGE direct-route=yes target=<hidden>')
                    return

            retired_chat_paths = {"/cgi-bin/cbonline2.exe", "/cgi-bin/uinlister.exe",
                                  "/cgi-bin/uinserver.exe", "/cgi-bin/invitebuddy.exe"}
            chat_host = (parsed.hostname or "").lower()
            if (chat_host in retired_chat_hosts or chat_host in {"127.0.0.1", "localhost", "proxy.local"}) and parsed.path.lower() in retired_chat_paths:
                # Version 6.0 IM protocol-discovery handler.  Never forwards private
                # CyberBuddy chat data to the retired public servers.  Instead it
                # records only field NAMES and value lengths so the original wire
                # format can be reconstructed safely from a real CyberBuddy run.
                endpoint = parsed.path.rsplit("/", 1)[-1]
                query_pairs = urllib.parse.parse_qsl(parsed.query, keep_blank_values=True)
                body_text = request_body.decode("iso-8859-1", "replace") if request_body else ""
                body_pairs = urllib.parse.parse_qsl(body_text, keep_blank_values=True)
                def _shape(pairs):
                    return [(k, len(v)) for k, v in pairs]
                log.warning("LEGACY CHAT DISCOVERY method=%s endpoint=%s query_fields=%r body_fields=%r body_bytes=%d; values intentionally hidden",
                            method, endpoint, _shape(query_pairs), _shape(body_pairs), len(request_body or b""))

                # CyberBuddy uses a positional legacy protocol here, not normal
                # key=value form fields. Examples observed from the real client:
                #   CBonline2.exe?L<UIN>&<name>&<version>&<email>&<ip>
                #   UINlister.exe?Y<UIN>&<nickname>&<comments>
                # POST polling can contain a raw UIN followed by CR/LF.
                raw_tokens = [urllib.parse.unquote_plus(x) for x in parsed.query.split('&') if x != '']
                raw_body = body_text.strip('\r\n\x00 ')
                fields = {}
                if endpoint.lower() == 'invitebuddy.exe' and body_text:
                    for _k, _vals in urllib.parse.parse_qs(body_text, keep_blank_values=True).items():
                        fields[_k.lower()] = _vals[-1] if _vals else ''
                if raw_tokens:
                    head = raw_tokens[0]
                    op = head[:1].upper() if head else ''
                    ident = _chat_safe_uin(head[1:] if op.isalpha() else head)
                    fields['action'] = op
                    if ident:
                        if endpoint.lower() == 'cbonline2.exe' and op == 'G':
                            fields['lookupuin'] = ident
                        else:
                            fields['uin'] = ident
                    if endpoint.lower() == 'cbonline2.exe' and op == 'L':
                        if len(raw_tokens) > 1: fields['name'] = raw_tokens[1]
                        if len(raw_tokens) > 2: fields['version'] = raw_tokens[2]
                        if len(raw_tokens) > 3: fields['email'] = raw_tokens[3]
                        if len(raw_tokens) > 4: fields['ip'] = raw_tokens[4]
                    elif endpoint.lower() == 'uinlister.exe' and op == 'Y':
                        if len(raw_tokens) > 1: fields['name'] = raw_tokens[1]
                        if len(raw_tokens) > 2: fields['comments'] = raw_tokens[2]
                    else:
                        # Preserve unknown positional tokens for future protocol
                        # discovery without logging their values.
                        for i, token in enumerate(raw_tokens[1:], 1):
                            fields['arg%d' % i] = token
                elif raw_body and '=' not in raw_body and '&' not in raw_body:
                    # A body consisting only of a UIN is the client's recurring
                    # receive/presence poll. Do not treat normal form-encoded POST
                    # data as a UIN; that would concatenate the entire form into it.
                    fields['uin'] = _chat_safe_uin(raw_body)
                    fields['action'] = 'poll'

                # Also accept conventional form fields if a later client build
                # happens to use them. Positional values take precedence.
                conventional = _chat_fields(query_pairs + body_pairs)
                for k, v in conventional.items():
                    fields.setdefault(k, v)

                log.warning('LEGACY CHAT POSITIONAL endpoint=%s op=%s token_count=%d body_uin=%s; values hidden',
                            endpoint, fields.get('action',''), len(raw_tokens),
                            'yes' if (raw_body and not raw_tokens) else 'no')
                if raw_tokens and fields.get('action','').upper() not in {'L','Y','G'}:
                    log.warning('LEGACY CHAT SEND CANDIDATE endpoint=%s op=%s token_count=%d; values hidden',
                                endpoint, fields.get('action',''), len(raw_tokens))
                if endpoint.lower() == 'invitebuddy.exe':
                    payload = _invitebuddy_safe_response(fields) if method.upper() == 'POST' else _invitebuddy_html()
                    log.warning('LEGACY INVITE BUDDY endpoint=invitebuddy.exe method=%s', method.upper())
                    content_type = 'text/html; charset=windows-1252'
                elif endpoint.lower() == 'uinlister.exe' and fields.get('action','').upper() == 'A':
                    payload = _chat_directory_html()
                    log.warning('LEGACY UIN DIRECTORY live=yes rows_dynamic=yes')
                    content_type = 'text/html; charset=windows-1252'
                elif endpoint.lower() == 'uinlister.exe' and fields.get('action','').upper() == 'U':
                    selected = _chat_safe_uin(raw_tokens[0][1:] if raw_tokens else '')
                    payload = _chat_uin_contact_html(selected)
                    log.warning('LEGACY UIN DIRECTORY CONTACT PAGE target=<hidden>')
                    content_type = 'text/html; charset=windows-1252'
                else:
                    payload = _chat_legacy_response(fields, endpoint)
                    content_type = 'text/plain; charset=windows-1252'
                self.safe_write(("HTTP/1.0 200 OK\r\n"
                                 f"Content-Type: {content_type}\r\n"
                                 f"Content-Length: {len(payload)}\r\n"
                                 "Cache-Control: no-store\r\n"
                                 "Connection: close\r\n\r\n").encode("ascii"))
                if method != "HEAD":
                    self.safe_write(payload)
                return

            if parsed.path == '/model_image' and (parsed.hostname or '').lower() in {
                    '127.0.0.1', 'localhost', 'proxy.local'}:
                key = urllib.parse.parse_qs(parsed.query).get('key', [''])[0]
                with MODEL_IMAGES_LOCK:
                    data = MODEL_IMAGES.get(key)
                if data is None:
                    self.send_simple(404, 'Not Found', 'Reload the model page to fetch its image.')
                else:
                    self.safe_write((f'HTTP/1.0 200 OK\r\nContent-Type: image/gif\r\n'
                                     f'Content-Length: {len(data)}\r\nCache-Control: no-store\r\n'
                                     'Connection: close\r\n\r\n').encode('ascii'))
                    self.safe_write(data)
                return

            # Direct local recreation of the old weather.unisys.com tree.
            # Example: /index.php, /foresetup.php, /satellite/index.php,
            # /gfs/index.php?r=us.  Keep these URLs visible and interactive
            # instead of exposing /weather_archive?url=... in the browser.
            local_weather_pages = {
                "/", "/index.php", "/solutions/index.php", "/mobile/index.php",
                "/info/index.php", "/content.php", "/analyses.php",
                "/satellite/index.php", "/surface/index.php", "/upper_air/index.php",
                "/radar/index.php", "/forehome.php", "/foresetup.php",
                "/mos/index.php", "/nam/index.php", "/gfs/index.php",
                "/gfsx/index.php", "/rap/index.php", "/ecmwf/index.php",
                "/archives.php", "/hurricane/index.php", "/archive/index.php",
                "/usgs/index.php", "/links.php", "/overview.php", "/contactus.php",
            }
            if ((parsed.hostname or "").lower() in {"127.0.0.1", "localhost", "proxy.local"}
                    and parsed.path.lower() in local_weather_pages):
                original_url = "http://weather.unisys.com" + parsed.path
                if parsed.query:
                    original_url += "?" + parsed.query
                archive_path = parsed.path.lower()
                # Current imagery is available for these three products.
                # Model/archive pages retain their own mirrored content.
                if archive_path.endswith("/analyses.php") or archive_path in {
                        "/satellite/index.php", "/surface/index.php", "/radar/index.php"}:
                    self.send_live_weather_maps(original_url)
                elif archive_path in {'/gfs/index.php', '/nam/index.php', '/rap/index.php'} and not urllib.parse.parse_qs(parsed.query).get('archive'):
                    self.send_current_model(parsed)
                elif self.send_local_weather_file(parsed):
                    pass
                else:
                    self.send_html(404, "Local weather page not downloaded", self.weather_shell(
                        '<div style="padding:12px"><h2>Local weather page not downloaded</h2>'
                        '<p>Run <b>DOWNLOAD_UNISYS_2013.bat</b> once, then reload this page.</p>'
                        '<p>This route no longer waits for the Wayback Machine.</p></div>'))
                return

            if parsed.path == "/weather_archive" and parsed.hostname in {
                    "127.0.0.1", "localhost", "proxy.local", "weather.unisys.com",
                    "www.weather.unisys.com"}:
                archive_url = urllib.parse.parse_qs(parsed.query).get("url", [""])[0]
                archive_path = urllib.parse.urlsplit(archive_url).path.lower()
                if archive_path.endswith("/analyses.php") or archive_path in {
                        "/satellite/index.php", "/surface/index.php", "/radar/index.php"}:
                    self.send_live_weather_maps(archive_url)
                else:
                    self.send_weather_archive(archive_url)
                return

            if parsed.path == "/weather_live_maps" and parsed.hostname in {
                    "127.0.0.1", "localhost", "proxy.local", "weather.unisys.com",
                    "www.weather.unisys.com"}:
                kind = urllib.parse.parse_qs(parsed.query).get("kind", ["satellite"])[0]
                fake_url = {"radar": "http://weather.unisys.com/radar/index.php",
                            "surface": "http://weather.unisys.com/surface/index.php"}.get(
                                kind, "http://weather.unisys.com/satellite/index.php")
                self.send_live_weather_maps(fake_url)
                return

            if parsed.path == "/weather_live_image" and parsed.hostname in {
                    "127.0.0.1", "localhost", "proxy.local", "weather.unisys.com",
                    "www.weather.unisys.com"}:
                kind = urllib.parse.parse_qs(parsed.query).get("kind", ["satellite"])[0]
                self.send_live_weather_image(kind)
                return

            # Every nested page and image included in weather_site can be
            # opened through the local proxy, including model and archive
            # subpages that were missing from the short list above.
            # Forecast endpoints are dynamic: a mirrored /forecast.php file
            # must not shadow any live location request.
            if (parsed.hostname or "").lower() in {
                    "127.0.0.1", "localhost", "proxy.local", "weather.unisys.com",
                    "www.weather.unisys.com"} and not re.search(
                    r"/forecast\.(?:cgi|php)(?:/|$)", parsed.path.lower()
                    ) and self.send_local_weather_file(parsed):
                return

            # Keep the original HTML news page available with current headlines.
            if parsed.path.rstrip("/").lower().endswith("/news/newspage.html"):
                try:
                    self.send_cyberbuddy_newspage()
                except Exception as error:
                    log.error("CYBERBUDDY NEWSPAGE: could not get news: %s", error)
                    self.send_simple(502, "Bad Gateway", "News is temporarily unavailable.")
                return

            # CyberBuddy requests both /CyberBuddy/news1.html on yeayou.com
            # and /news/news1.html on thecyberbuddy.com during startup. These
            # files are read as commands, so HTML (including <!DOCTYPE>) is
            # spoken literally. Serve the same live command format as news3.
            news_path = parsed.path.rstrip("/").lower()
            news_host = (parsed.hostname or "").lower()
            legacy_news_hosts = {
                "yeayou.com", "www.yeayou.com",
                "thecyberbuddy.com", "www.thecyberbuddy.com",
                "mycyberbuddy.com", "www.mycyberbuddy.com",
            }
            if (news_path.endswith("/news3.html") or
                    (news_host in legacy_news_hosts and news_path in {
                        "/cyberbuddy/news1.html", "/cyberbuddy/news2.html",
                        "/news/news1.html", "/news/news2.html"})):
                try:
                    self.send_cyberbuddy_news3()
                except Exception as error:
                    log.error("CYBERBUDDY NEWS: could not get news for %s: %s", news_path, error)
                    self.send_html(502, "Bad Gateway", "&&Read\r\nNews is temporarily unavailable.\r\n")
                return


            # The original Yahoo page with s= empty contained a symbol form.
            # Keep its GET form locally so the legacy browser can submit it.
            if (parsed.hostname or "").lower() in {"finance.yahoo.com", "quote.yahoo.com"} \
                    and parsed.path.lower().rstrip("/") in {"/q/cq", "/q"}:
                values = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
                if method == "POST" and request_body:
                    values.update(urllib.parse.parse_qs(request_body.decode("cp1252", "replace"),
                                                         keep_blank_values=True))
                symbols = values.get("s", [""])[0].strip()
                if not symbols:
                    self.send_html(200, "OK", '<html><head><meta http-equiv="Content-Type" '
                                   'content="text/html; charset=windows-1252"><title>Stocks</title></head>'
                                   '<body><h2>Stocks</h2><form method="GET" '
                                   'action="http://finance.yahoo.com/q/cq">'
                                   '<label>Enter Symbol(s): <input type="text" name="s" size="15"></label>'
                                   '<input type="hidden" name="d" value="v1">'
                                   '<input type="submit" value="GO"></form>'
                                   '<p>Examples: AAPL, PETR4.SA, VALE3.SA.</p></body></html>')
                    log.info("LEGACY STOCKS no ticker -> 200 local")
                    return
                if symbols.casefold() in {"apple computer", "apple inc", "apple inc.", "apple"}:
                    self.send_html(200, "OK", '<html><head><meta http-equiv="Content-Type" '
                                   'content="text/html; charset=windows-1252"><title>Stocks</title></head>'
                                   '<body><h2>Stocks</h2><p>"Apple Computer" is a company name, '
                                   'not a ticker symbol. Enter <b>AAPL</b> instead.</p>'
                                   '<form method="GET" action="http://finance.yahoo.com/q/cq">'
                                   '<input name="s" value="AAPL"><input type="hidden" name="d" value="v1">'
                                   '<input type="submit" value="GO"></form></body></html>')
                    log.info("LEGACY STOCKS nome Apple Computer -> orientar AAPL")
                    return
                tickers = list(dict.fromkeys(re.split(r"[,;\s]+", symbols.upper())))
                if len(tickers) > 10:
                    self.send_simple(400, "Bad Request", "Use at most 10 ticker symbols.")
                    return
                quotes, errors = [], []
                for ticker in tickers:
                    if not ticker:
                        continue
                    try:
                        quotes.append(fetch_stock_quote(ticker))
                    except (ValueError, RuntimeError, OSError, KeyError, TypeError) as error:
                        errors.append(str(error))
                if not quotes:
                    self.send_html(502, "Bad Gateway", '<html><body><h2>Quotes unavailable</h2><p>' +
                                   html.escape(" ".join(errors)) + '</p></body></html>')
                    return
                rows = "".join('<tr>' + ''.join('<td>' + html.escape(value) + '</td>'
                                              for value in stock_fields(quote)) + '</tr>'
                               for quote in quotes)
                notes = "".join('<p>' + html.escape(q["symbol"] + ' currency: ' + q["currency"]) + '</p>' for q in quotes)
                self.send_html(200, "OK", '<html><head><title>Stock Quotes</title></head><body>' +
                               '<table><tr><th>Symbol</th><th>Quote time</th><th>Last price</th>' +
                               '<th>Change</th><th>Change %</th><th>Volume</th></tr>' + rows + '</table>' +
                               '<p>Yahoo Finance provider-reported quotes; prices may be delayed. ' +
                               'Times are UTC. No estimate is shown when a quote is unavailable.</p>' + notes +
                               ''.join('<p>' + html.escape(error) + '</p>' for error in errors) +
                               '<form method="GET" action="http://finance.yahoo.com/q/cq">' +
                               '<input name="s"><input type="hidden" name="d" value="v1">' +
                               '<input type="submit" value="GO"></form></body></html>')
                log.info("LEGACY STOCKS -> %d provider quotes", len(quotes))
                return

            # Local files from the user's archived Unisys page; never forward
            # them to the discontinued site or serve arbitrary disk paths.
            weather_hosts = {"weather.unisys.com", "www.weather.unisys.com",
                             "67.98.102.223", "127.0.0.1", "localhost"}
            if (parsed.hostname or "").lower() in weather_hosts and parsed.path.startswith("/weather_assets/"):
                self.send_weather_asset(parsed.path.removeprefix("/weather_assets/"))
                return

            # Replace retired CyberBuddy weather, joke, and thought services.
            path_lower = parsed.path.lower()
            weather_endpoint = next((part for part in ("forecast.cgi", "forecast.php")
                                     if re.search(r"/" + re.escape(part) + r"(?:/|$)", path_lower)), None)
            if weather_endpoint and (parsed.hostname or "").lower() in weather_hosts:
                query_values = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
                if "\ufffd" in str(query_values):
                    query_values = urllib.parse.parse_qs(parsed.query, keep_blank_values=True,
                                                         encoding="cp1252", errors="replace")
                # The 2001 Unisys form submits Name in the POST body. Decode
                # percent escapes as UTF-8 when possible and as Windows-1252
                # for old browsers; do not replace accented letters with '?'.
                form_values = {}
                for pair in (request_body or b"").split(b"&"):
                    if not pair:
                        continue
                    raw_key, _, raw_value = pair.partition(b"=")
                    key = urllib.parse.unquote_to_bytes(raw_key.replace(b"+", b" ")).decode("ascii", "ignore")
                    value_bytes = urllib.parse.unquote_to_bytes(raw_value.replace(b"+", b" "))
                    try:
                        value = value_bytes.decode("utf-8")
                    except UnicodeDecodeError:
                        value = value_bytes.decode("cp1252", "replace")
                    form_values.setdefault(key, []).append(value)
                values = {k.lower(): v for k, v in {**query_values, **form_values}.items()}
                location = (values.get("place", [""])[0]
                            or values.get("location", [""])[0]
                            or values.get("name", [""])[0]
                            or values.get("city", [""])[0]
                            or values.get("zip", [""])[0]
                            or values.get("airport", [""])[0]).strip()
                # Old CyberBuddy variants send the place as a bare query:
                # /forecast.cgi?Goiania, without a field name.
                if not location and parsed.query and "=" not in parsed.query:
                    location = urllib.parse.unquote_plus(parsed.query).strip()
                # The archived Unisys endpoint also accepts /forecast.cgi/<ZIP>,
                # /forecast.cgi/<city>, or /forecast.cgi/<airport>.  Preserve
                # that value instead of silently falling back to Formosa.
                if not location:
                    marker = "/" + weather_endpoint + "/"
                    marker_pos = parsed.path.lower().find(marker)
                    if marker_pos >= 0:
                        suffix = parsed.path[marker_pos + len(marker):]
                        location = urllib.parse.unquote(suffix).strip(" /")
                # The original forecast page may submit a blank Name field
                # while loading its saved/default location. Use a configured
                # city so the 2013 layout contains current weather instead of
                # the archived report or another empty form.
                if not location and "name" in values:
                    location = CFG.get("weather", "default_location", fallback="Formosa, Goiás, Brasil").strip()
                if not location:
                    log.info("LEGACY WEATHER %s %s request has no location", method, parsed.path)
                    self.send_weather_form(weather_endpoint)
                    return
                log.info("LEGACY WEATHER received: %s %s / location=%s", method,
                         parsed.path + ("?" + parsed.query if parsed.query else ""), location)
                unit = values.get("unit", [""])[0].strip().lower()
                try:
                    self.send_legacy_weather(location, unit_override=unit, weather_endpoint=weather_endpoint)
                except RuntimeError as error:
                    self.send_html(503, "Weather temporarily unavailable",
                                   self.weather_shell("<p>" + html.escape(str(error)) + "</p>"))
                return
            fun_host = (parsed.hostname or "").lower() in {
                "yeayou.com", "www.yeayou.com", "66.135.38.69",
                "66.135.47.52", "thecyberbuddy.com", "www.thecyberbuddy.com",
                "mycyberbuddy.com", "www.mycyberbuddy.com",
            }
            if fun_host and (path_lower.endswith("/jokeserver.exe") or path_lower.endswith("/jokeserve.exe")):
                log.info("LEGACY JOKE host=%s query=%s", parsed.hostname, parsed.query)
                self.send_legacy_fun("joke")
                return
            if fun_host and path_lower.endswith("/thoughts.exe"):
                log.info("LEGACY THOUGHT host=%s query=%s", parsed.hostname, parsed.query)
                self.send_legacy_fun("thought")
                return

            # Browsers sometimes send an absolute URL for our own listener to
            # the Windows proxy. Never forward that request back into ourselves.
            local_listener = parsed.hostname in {"127.0.0.1", "localhost", "::1"} and parsed.port == PORT
            if parsed.hostname in {"proxy.local", "cyberbuddy.proxy"} or local_listener:
                if parsed.path.rstrip("/").lower() == "/news":
                    try:
                        self.send_legacy_news_page()
                    except Exception as error:
                        log.error("PAGE CHECK failed: %s", error)
                        self.send_simple(502, "Bad Gateway", "Page temporarily unavailable.")
                    return
                if local_listener and parsed.path not in {"", "/"}:
                    self.send_simple(404, "Not Found", "No such local proxy page.")
                    return
                self.send_simple(
                    200,
                    "OK",
                    f"{APP_NAME} {APP_VERSION} is running on port {PORT}. "
                    "Web Watching: http://proxy.local/news",
                )
                return

            outgoing_headers = {}
            for key, value in headers.items():
                if key.lower() not in HOP_BY_HOP and key.lower() not in {"host", "accept-encoding", "content-length"}:
                    outgoing_headers[key] = value
            outgoing_headers["User-Agent"] = CFG.get(
                "upstream",
                "user_agent",
                fallback="Mozilla/5.0 (Windows NT 10.0; Win64; x64) CyberBuddyClassicProxy/6.0",
            )
            outgoing_headers["Accept-Encoding"] = "identity"

            req = urllib.request.Request(
                target,
                data=request_body,
                headers=outgoing_headers,
                method=method,
            )
            opener = direct_opener()

            try:
                response = opener.open(req, timeout=TIMEOUT)
            except urllib.error.HTTPError as error:
                response = error

            status = response.status
            reason = getattr(response, "reason", "") or ""
            response_body = b"" if method == "HEAD" else response.read(MAX_BODY_MB * 1024 * 1024 + 1)
            if len(response_body) > MAX_BODY_MB * 1024 * 1024:
                self.send_simple(502, "Response Too Large", "The response exceeds the configured size limit.")
                return

            response_body = decode_body(response_body, response.headers.get("Content-Encoding"))
            if parsed.path.lower().endswith(("/cbonline2.exe", "/uinlister.exe", "/uinserver.exe")):
                # Inspect only structural markers. Never log a chat message,
                # login body, UIN, email address or query value.
                marker_found = any(marker in response_body for marker in (b"$$UIN", b"$$SNDTO", b"$$MYIP", b"&&EOT"))
                if status == 405:
                    detail = "server rejected request method; native protocol handler needed"
                elif status == 404:
                    detail = "directory endpoint missing; native protocol handler needed"
                elif status >= 400:
                    detail = "upstream chat service error"
                elif not marker_found:
                    detail = "HTTP response received without known legacy chat markers; message delivery is not confirmed"
                else:
                    detail = "legacy chat markers detected; message delivery still requires two-client verification"
                log.warning("LEGACY CHAT method=%s endpoint=%s status=%s bytes=%d markers=%s: %s",
                            method, parsed.path.rsplit("/", 1)[-1], status,
                            len(response_body), marker_found, detail)

            content_type = response.headers.get("Content-Type", "application/octet-stream")
            response_body, content_type = make_legacy_compatible(response_body, content_type)

            self.wfile.write(f"HTTP/1.0 {status} {reason}\r\n".encode("iso-8859-1", "replace"))
            for key, value in response.headers.items():
                lower = key.lower()
                if lower in HOP_BY_HOP or lower in {"content-length", "content-type", "content-encoding"}:
                    continue
                self.wfile.write(f"{key}: {value}\r\n".encode("iso-8859-1", "replace"))
            self.wfile.write(f"Content-Type: {content_type}\r\n".encode("iso-8859-1", "replace"))
            self.wfile.write(f"Content-Length: {len(response_body)}\r\n".encode("ascii"))
            self.wfile.write(b"Connection: close\r\n\r\n")
            if method != "HEAD":
                self.wfile.write(response_body)
            log.info("%s %s -> %s (%d bytes)", method, urllib.parse.urlunsplit((parsed.scheme, parsed.netloc.rsplit("@", 1)[-1], parsed.path, "[redacted]" if parsed.query else "", "")), status, len(response_body))

        except (ValueError, UnicodeError) as error:
            log.warning("Invalid request from %s: %s", self.client_address[0], error)
            self.send_simple(400, "Bad Request", f"Invalid request: {error}")
        except (urllib.error.URLError, socket.timeout, TimeoutError) as error:
            log_upstream_failure(target if 'target' in locals() else '', error)
            self.send_simple(502, "Bad Gateway", f"Could not access the address: {error}")
        except (ConnectionAbortedError, ConnectionResetError, BrokenPipeError):
            log.debug("Legacy client closed the connection; request finished")
        except Exception as error:
            log.exception("Unexpected error")
            try:
                self.send_simple(500, "Internal Server Error", f"Internal error: {error}")
            except Exception:
                pass

    def handle_connect(self, target: str):
        """Relay HTTPS unchanged so the Windows proxy does not break modern sites."""
        host, separator, port_text = target.rpartition(":")
        if not separator:
            host, port_text = target, "443"
        host = host.strip("[]")
        try:
            port = int(port_text)
        except ValueError:
            self.send_simple(400, "Bad Request", "Invalid HTTPS port.")
            return
        if not host or port < 1 or port > 65535:
            self.send_simple(400, "Bad Request", "Invalid HTTPS destination.")
            return

        if host.lower() in {"127.0.0.1", "localhost", "::1"} and port == PORT:
            self.send_simple(400, "Bad Request", "Cannot tunnel the proxy into itself.")
            return

        upstream = None
        try:
            upstream = socket.create_connection((host, port), timeout=TIMEOUT)
            self.connection.sendall(b"HTTP/1.1 200 Connection Established\r\n\r\n")
            sockets = [self.connection, upstream]
            while True:
                readable, _, exceptional = select.select(sockets, [], sockets, TIMEOUT)
                if exceptional or not readable:
                    break
                for source in readable:
                    data = source.recv(65536)
                    if not data:
                        return
                    destination = upstream if source is self.connection else self.connection
                    destination.sendall(data)
            log.debug("CONNECT %s:%d closed", host, port)
        except (OSError, socket.timeout) as error:
            log_upstream_failure("https://" + host, error)
            if upstream is None:
                try:
                    self.send_simple(502, "Bad Gateway", "Could not open the HTTPS tunnel.")
                except OSError:
                    pass
        finally:
            if upstream is not None:
                try:
                    upstream.close()
                except OSError:
                    pass


class ThreadedTCPServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    allow_reuse_address = True
    daemon_threads = True


class TLSBridgeHandler(socketserver.BaseRequestHandler):
    remote_host = ""
    remote_port = 0
    bridge_name = "TLS"
    failure_reply = b"-ERR Secure bridge unavailable\r\n"

    def handle(self):
        upstream = None
        try:
            raw = socket.create_connection((self.remote_host, self.remote_port), timeout=TIMEOUT)
            upstream = tls_context().wrap_socket(raw, server_hostname=self.remote_host)
            log.info(
                "%s: secure connection established to %s:%d",
                self.bridge_name,
                self.remote_host,
                self.remote_port,
            )
            sockets = [self.request, upstream]
            while True:
                readable, _, exceptional = select.select(sockets, [], sockets, TIMEOUT)
                if exceptional or not readable:
                    break
                for source in readable:
                    data = source.recv(65536)
                    if not data:
                        return
                    destination = upstream if source is self.request else self.request
                    destination.sendall(data)
        except Exception as error:
            log.error("%s: could not establish a secure connection: %s", self.bridge_name, error)
            try:
                self.request.sendall(self.failure_reply)
            except OSError:
                pass
        finally:
            if upstream is not None:
                try:
                    upstream.close()
                except OSError:
                    pass


def decode_mail_header_value(value: bytes) -> bytes:
    """Decode RFC 2047/UTF-8 headers for mail clients from the Windows 98 era."""
    try:
        source = value.decode("ascii")
    except UnicodeDecodeError:
        for charset in ("utf-8", "cp1252"):
            try:
                return value.decode(charset).encode("cp1252", "replace")
            except UnicodeDecodeError:
                continue
        return value.decode("latin-1", "replace").encode("cp1252", "replace")
    pieces = []
    try:
        decoded = email.header.decode_header(source)
    except (LookupError, UnicodeError):
        decoded = [(value, None)]
    for part, charset in decoded:
        if isinstance(part, str):
            pieces.append(part)
            continue
        candidates = [charset, "utf-8", "cp1252"] if charset else ["utf-8", "cp1252"]
        for candidate in candidates:
            if not candidate:
                continue
            try:
                pieces.append(part.decode(candidate))
                break
            except (LookupError, UnicodeError):
                continue
        else:
            pieces.append(part.decode("latin-1", "replace"))
    return "".join(pieces).encode("cp1252", "replace")


def convert_pop3_message_headers(lines: list[bytes]) -> list[bytes]:
    """Return POP3 message lines with readable Windows-1252 mail headers."""
    try:
        separator = lines.index(b"\r\n")
    except ValueError:
        separator = len(lines)

    logical_headers: list[list[bytes]] = []
    for line in lines[:separator]:
        if line[:1] in {b" ", b"\t"} and logical_headers:
            logical_headers[-1].append(line)
        else:
            logical_headers.append([line])

    converted: list[bytes] = []
    for physical in logical_headers:
        first = physical[0].rstrip(b"\r\n")
        if b":" not in first:
            converted.extend(physical)
            continue
        name, value = first.split(b":", 1)
        continuation = [item.strip(b" \t\r\n") for item in physical[1:]]
        unfolded = b" ".join([value.strip()] + continuation)
        decoded_value = decode_mail_header_value(unfolded)
        converted.append(name + b": " + decoded_value + b"\r\n")

    if separator < len(lines):
        converted.append(b"\r\n")
        converted.extend(lines[separator + 1:])
    return converted


class _HTMLTextExtractor(HTMLParser):
    block_tags = {"p", "div", "br", "li", "tr", "h1", "h2", "h3", "h4", "h5", "h6"}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts: list[str] = []
        self.ignored = 0

    def handle_starttag(self, tag, attrs):
        tag = tag.lower()
        if tag in {"script", "style", "head"}:
            self.ignored += 1
        elif tag in self.block_tags:
            self.parts.append("\n")

    def handle_endtag(self, tag):
        tag = tag.lower()
        if tag in {"script", "style", "head"} and self.ignored:
            self.ignored -= 1
        elif tag in self.block_tags:
            self.parts.append("\n")

    def handle_data(self, data):
        if not self.ignored:
            self.parts.append(data)

    def text(self) -> str:
        value = html.unescape("".join(self.parts)).replace("\xa0", " ")
        value = re.sub(r"[ \t]+", " ", value)
        value = re.sub(r" *\n *", "\n", value)
        value = re.sub(r"\n{3,}", "\n\n", value)
        return value.strip()


def _decode_text_part(part) -> str:
    payload = part.get_payload(decode=True)
    if payload is None:
        raw = part.get_payload()
        return raw if isinstance(raw, str) else ""
    candidates = [part.get_content_charset(), "utf-8", "cp1252", "latin-1"]
    for charset in candidates:
        if not charset:
            continue
        try:
            return payload.decode(charset)
        except (LookupError, UnicodeDecodeError):
            continue
    return payload.decode("utf-8", "replace")


def convert_pop3_message_to_legacy(lines: list[bytes]) -> list[bytes]:
    """Flatten a modern MIME e-mail into plain Windows-1252 text."""
    # POP3 dot-stuffing is transport syntax, not part of the message.
    raw_lines = [line[1:] if line.startswith(b"..") else line for line in lines]
    raw_message = b"".join(raw_lines)
    try:
        message = email.parser.BytesParser(policy=email.policy.default).parsebytes(raw_message)
    except Exception:
        return convert_pop3_message_headers(lines)

    plain_parts: list[str] = []
    html_parts: list[str] = []
    parts = message.walk() if message.is_multipart() else [message]
    for part in parts:
        if part.is_multipart() or part.get_content_disposition() == "attachment":
            continue
        kind = part.get_content_type().lower()
        if kind not in {"text/plain", "text/html"}:
            continue
        decoded = _decode_text_part(part)
        if kind == "text/plain" and decoded.strip():
            plain_parts.append(decoded)
        elif kind == "text/html" and decoded.strip():
            extractor = _HTMLTextExtractor()
            try:
                extractor.feed(decoded)
                cleaned = extractor.text()
            except Exception:
                cleaned = re.sub(r"<[^>]+>", " ", decoded)
            if cleaned:
                html_parts.append(cleaned)

    body = "\n\n".join(plain_parts or html_parts).strip()
    if not body:
        body = "This message has no compatible text content."
    body = body.replace("\r\n", "\n").replace("\r", "\n")

    output: list[bytes] = []
    for name in ("From", "To", "Cc", "Date", "Subject", "Reply-To", "Message-ID"):
        values = message.get_all(name, [])
        for value in values:
            encoded = str(value).encode("cp1252", "replace")
            output.append(name.encode("ascii") + b": " + encoded + b"\r\n")
    output.extend([
        b"MIME-Version: 1.0\r\n",
        b"Content-Type: text/plain; charset=windows-1252\r\n",
        b"Content-Transfer-Encoding: 8bit\r\n",
        b"\r\n",
    ])
    for text_line in body.split("\n"):
        wire_line = text_line.encode("cp1252", "replace")
        if wire_line.startswith(b"."):
            wire_line = b"." + wire_line
        output.append(wire_line + b"\r\n")
    return output


class POP3BridgeHandler(socketserver.StreamRequestHandler):
    remote_host = POP3_REMOTE_HOST
    remote_port = POP3_REMOTE_PORT
    bridge_name = "POP3"
    failure_reply = b"-ERR Could not connect to secure POP3 server\r\n"

    @staticmethod
    def is_multiline(command: str, response: bytes) -> bool:
        if not response.startswith(b"+OK"):
            return False
        verb, _, argument = command.partition(" ")
        return verb in {"RETR", "TOP", "CAPA"} or (verb in {"LIST", "UIDL"} and not argument)

    def handle(self):
        upstream = None
        pending_username = None
        pending_password = None
        try:
            raw = socket.create_connection((self.remote_host, self.remote_port), timeout=TIMEOUT)
            upstream = tls_context().wrap_socket(raw, server_hostname=self.remote_host)
            upstream_file = upstream.makefile("rb")
            greeting = upstream_file.readline(65537)
            if not greeting:
                raise ConnectionError("POP3 server did not send a greeting")
            self.wfile.write(greeting)
            self.wfile.flush()
            log.info("POP3: secure connection established to %s:%d", self.remote_host, self.remote_port)

            while True:
                client_line = self.rfile.readline(65537)
                if not client_line:
                    return
                upstream.sendall(client_line)
                command = client_line.decode("ascii", "ignore").strip().upper()
                original_command = client_line.decode("utf-8", "replace").strip()
                verb, _, argument = original_command.partition(" ")
                if verb.upper() == "USER" and argument:
                    pending_username = argument.strip()
                elif verb.upper() == "PASS" and argument:
                    pending_password = argument.strip().replace(" ", "")
                response = upstream_file.readline(65537)
                if not response:
                    return
                self.wfile.write(response)

                if command.startswith("PASS ") and response.startswith(b"+OK"):
                    if pending_username and pending_password:
                        with MAIL_CREDENTIALS_LOCK:
                            MAIL_CREDENTIALS["username"] = pending_username
                            MAIL_CREDENTIALS["password"] = pending_password
                        _save_mail_credentials(pending_username, pending_password)
                        log.info("POP3: temporary credentials are available for SMTP")

                if self.is_multiline(command, response):
                    lines = []
                    while True:
                        line = upstream_file.readline(1024 * 1024 + 1)
                        if not line:
                            return
                        if line == b".\r\n":
                            break
                        lines.append(line)
                    if command.startswith("RETR "):
                        lines = convert_pop3_message_to_legacy(lines)
                    elif command.startswith("TOP "):
                        # CyberBuddy commonly uses TOP with a large line count
                        # instead of RETR when opening/reading a message.
                        pieces = command.split()
                        requested_body_lines = 0
                        if len(pieces) >= 3:
                            try:
                                requested_body_lines = int(pieces[2])
                            except ValueError:
                                pass
                        if requested_body_lines > 0:
                            lines = convert_pop3_message_to_legacy(lines)
                        else:
                            lines = convert_pop3_message_headers(lines)
                    for line in lines:
                        self.wfile.write(line)
                    self.wfile.write(b".\r\n")
                self.wfile.flush()
                if command == "QUIT":
                    return
        except Exception as error:
            log.error("POP3: could not connect or process data securely: %s", error)
            try:
                self.wfile.write(self.failure_reply)
                self.wfile.flush()
            except OSError:
                pass
        finally:
            if upstream is not None:
                try:
                    upstream.close()
                except OSError:
                    pass


class SMTPBridgeHandler(socketserver.StreamRequestHandler):
    """Accept legacy plain SMTP locally and submit it to Gmail with TLS/AUTH."""

    def reply(self, text: str):
        self.wfile.write(text.encode("ascii", "replace") + b"\r\n")
        self.wfile.flush()

    @staticmethod
    def address_from_command(command: str) -> str:
        value = command.split(":", 1)[1].strip() if ":" in command else ""
        value = value.split(" ", 1)[0].strip()
        return value.strip("<>")

    @staticmethod
    def decode_b64(value: str) -> str:
        return base64.b64decode(value.strip()).decode("utf-8", "replace")

    def authenticate_legacy_client(self, command: str) -> bool:
        pieces = command.split()
        mechanism = pieces[1].upper() if len(pieces) > 1 else ""
        try:
            if mechanism == "PLAIN":
                token = pieces[2] if len(pieces) > 2 else ""
                if not token:
                    self.reply("334 ")
                    token = self.rfile.readline(65537).decode("ascii", "ignore").strip()
                decoded = base64.b64decode(token).decode("utf-8", "replace")
                _authorization, username, password = decoded.split("\x00", 2)
            elif mechanism == "LOGIN":
                if len(pieces) > 2:
                    username = self.decode_b64(pieces[2])
                else:
                    self.reply("334 VXNlcm5hbWU6")
                    username = self.decode_b64(self.rfile.readline(65537).decode("ascii", "ignore"))
                self.reply("334 UGFzc3dvcmQ6")
                password = self.decode_b64(self.rfile.readline(65537).decode("ascii", "ignore"))
            else:
                self.reply("504 5.5.4 Use AUTH LOGIN or AUTH PLAIN")
                return False
        except Exception:
            self.reply("501 5.5.2 Invalid authentication data")
            return False

        with MAIL_CREDENTIALS_LOCK:
            MAIL_CREDENTIALS["username"] = username.strip()
            MAIL_CREDENTIALS["password"] = password.strip().replace(" ", "")
        _save_mail_credentials(username.strip(), password.strip().replace(" ", ""))
        self.reply("235 2.7.0 Authentication accepted by local bridge")
        log.info("SMTP: temporary credentials received from the legacy client")
        return True

    def submit_to_gmail(self, sender: str, recipients: list[str], message: bytes):
        with MAIL_CREDENTIALS_LOCK:
            username = MAIL_CREDENTIALS["username"]
            password = MAIL_CREDENTIALS["password"]
        if not username or not password:
            raise PermissionError("use Get Email Now first to provide temporary credentials")

        # Some old clients omit modern headers. Gmail accepts the legacy body
        # once minimum From/To headers are supplied.
        header_block = message.split(b"\r\n\r\n", 1)[0].lower()
        additions = []
        if b"from:" not in header_block:
            additions.append(f"From: {sender or username}\r\n".encode("cp1252", "replace"))
        if b"to:" not in header_block:
            additions.append(f"To: {', '.join(recipients)}\r\n".encode("cp1252", "replace"))
        if additions:
            message = b"".join(additions) + message

        with smtplib.SMTP_SSL(
            SMTP_REMOTE_HOST,
            SMTP_REMOTE_PORT,
            timeout=TIMEOUT,
            context=tls_context(),
        ) as smtp:
            smtp.login(username, password)
            smtp.sendmail(sender or username, recipients, message)

    def handle(self):
        sender = ""
        recipients: list[str] = []
        self.reply("220 CyberBuddy Classic Proxy 2.0 SMTP bridge ready")
        log.info("SMTP: cliente antigo conectado em %s", self.client_address[0])
        while True:
            raw = self.rfile.readline(65537)
            if not raw:
                return
            command = raw.decode("iso-8859-1", "replace").strip()
            upper = command.upper()

            if upper.startswith("EHLO"):
                self.reply("250-CyberBuddy Classic Proxy")
                self.reply("250-AUTH LOGIN PLAIN")
                self.reply("250 8BITMIME")
            elif upper.startswith("HELO"):
                self.reply("250 CyberBuddy Classic Proxy")
            elif upper.startswith("AUTH "):
                self.authenticate_legacy_client(command)
            elif upper.startswith("MAIL FROM:"):
                sender = self.address_from_command(command)
                recipients = []
                self.reply("250 2.1.0 Sender OK")
            elif upper.startswith("RCPT TO:"):
                recipient = self.address_from_command(command)
                if recipient:
                    recipients.append(recipient)
                    self.reply("250 2.1.5 Recipient OK")
                else:
                    self.reply("501 5.1.3 Invalid recipient")
            elif upper == "DATA":
                if not recipients:
                    self.reply("503 5.5.1 Need RCPT TO first")
                    continue
                self.reply("354 End data with <CRLF>.<CRLF>")
                lines = []
                while True:
                    line = self.rfile.readline(1024 * 1024 + 1)
                    if not line or line in {b".\r\n", b".\n"}:
                        break
                    if line.startswith(b".."):
                        line = line[1:]
                    lines.append(line.replace(b"\n", b"\r\n") if not line.endswith(b"\r\n") else line)
                try:
                    self.submit_to_gmail(sender, recipients, b"".join(lines))
                    self.reply("250 2.0.0 Message accepted for delivery")
                    log.info("SMTP: message sent successfully to %d recipient(s)", len(recipients))
                except PermissionError as error:
                    log.error("SMTP: credentials unavailable: %s", error)
                    self.reply("530 5.7.0 Check mail first, then try sending again")
                except smtplib.SMTPAuthenticationError as error:
                    log.error("SMTP: Gmail authentication refused (%s)", error.smtp_code)
                    self.reply("535 5.7.8 Gmail authentication failed")
                except Exception as error:
                    log.error("SMTP: could not send through Gmail: %s", error)
                    self.reply("451 4.3.0 Temporary Gmail submission failure")
                sender = ""
                recipients = []
            elif upper == "RSET":
                sender = ""
                recipients = []
                self.reply("250 2.0.0 Reset OK")
            elif upper == "NOOP":
                self.reply("250 2.0.0 OK")
            elif upper == "QUIT":
                self.reply("221 2.0.0 Bye")
                return
            else:
                self.reply("502 5.5.1 Command not implemented")


def start_bridge(bind: str, port: int, handler, name: str):
    try:
        server = ThreadedTCPServer((bind, port), handler)
    except OSError as error:
        log.error("%s could not start on %s:%d: %s", name, bind, port, error)
        print(f"WARNING: {name} could not start on port {port}: {error}")
        return None
    thread = threading.Thread(target=server.serve_forever, name=name, daemon=True)
    thread.start()
    log.info("%s started on %s:%d", name, bind, port)
    print(f"{name}: {bind}:{port}")
    return server


def main() -> int:
    print(f"{APP_NAME} {APP_VERSION}")
    print(f"Proxy: http://{BIND}:{PORT}")
    print(f"Test: configure the proxy and open http://proxy.local/")
    print(f"Log: {LOG_PATH}")
    print("Press Ctrl+C to stop.\n")
    bridges = []
    if POP3_ENABLED:
        server = start_bridge(POP3_BIND, POP3_LOCAL_PORT, POP3BridgeHandler, "Secure POP3 bridge")
        if server:
            bridges.append(server)
    if SMTP_ENABLED:
        server = start_bridge(SMTP_BIND, SMTP_LOCAL_PORT, SMTPBridgeHandler, "Secure SMTP bridge")
        if server:
            bridges.append(server)
    try:
        with ThreadedTCPServer((BIND, PORT), ProxyHandler) as server:
            log.info("Server started on %s:%d", BIND, PORT)
            server.serve_forever()
    except OSError as error:
        print(f"ERROR: could not use {BIND}:{PORT}: {error}")
        return 1
    except KeyboardInterrupt:
        print("\nProxy stopped.")
    finally:
        for bridge in bridges:
            bridge.shutdown()
            bridge.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
