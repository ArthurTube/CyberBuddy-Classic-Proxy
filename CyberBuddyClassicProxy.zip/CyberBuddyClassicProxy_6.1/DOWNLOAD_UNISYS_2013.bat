@echo off
cd /d "%~dp0"
title UNISYS WEATHER 2013 - FULL LOCAL MIRROR

echo ============================================================
echo  UNISYS WEATHER 2013 - FULL LOCAL MIRROR DOWNLOADER
echo ============================================================
echo Downloads HTML plus linked CSS, JS, images, fonts and media.
echo Existing files may be refreshed. Requests are deliberately paced.
echo.

where py >nul 2>&1
if %errorlevel%==0 (
    py download_unisys_2013.py
    goto done
)

where python >nul 2>&1
if %errorlevel%==0 (
    python download_unisys_2013.py
    goto done
)

echo ERROR: Python could not be found.
echo Try: py --version
pause
exit /b 1

:done
echo.
echo When complete, run START_PROXY.bat and open:
echo http://127.0.0.1:8081/index.php
echo.
echo Download report: weather_site\MIRROR_STATUS.txt
pause
