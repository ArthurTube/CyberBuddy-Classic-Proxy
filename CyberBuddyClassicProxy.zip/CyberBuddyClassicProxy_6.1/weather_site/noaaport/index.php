<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Unisys Weather </title>
<meta name="description" content="The intent of this weather site is to provide a complete source of graphical weather 		information. This is intended to satisfy the needs of the weather professional, but can be a tool for the casual user as well. The graphics and data are displayed as a meteorologist would expect to see. For the novice user, there are detailed explanation pages to guide them through the various plots, charts and images. The data on this site are provided from the National Weather Service via the NOAAPORT satellite data service. All the images are generated using the Weather Processor (WXP) analysis package which is available from Unisys. "/>
<meta name="keywords" content="weather, unisys, unisys weather, weather maps, maps, nam, wrf, GFS, GFSx, hurricane, radar, satellite, surface, upper air" />
<meta name="copyright" content="Unisys Corp - 2011" />
<meta name="author" content="Unisys Corporation" />
<meta name="email" content="technical-support@weather.unisys.com" />
<meta name="Distribution" content="Global" />
<meta name="Rating" content="General" />
<meta name="Robots" content="INDEX,FOLLOW" />
<meta name="Revisit-after" content="7 Days" />
<meta http-equiv="Content-type" content="text/html;charset=UTF-8" />
<meta http-equiv="imagetoolbar" content="no" />
<meta http-equiv="Refresh" content="900" />
<meta http-equiv="X-UA-Compatible" content="IE=8"/>
<link rel="stylesheet" type="text/css" href="/css/WMAX.css" />
</head>
<body>
<div id="wrap">
  <div id="top-menu">
    <ul id="top-navigation" class="inline-navigation-list">
      <li><a href="http://www.unisys.com" title="Unisys Home Page">Unisys.com</a></li>
      <li><a href="/index.php" title="Unisys Weather">Weather Home</a></li>
      <li><a href="/analyses.php" title="Analyses">Analyses</a></li>
      <li><a href="/forehome.php" title="Forecast">Forecasts</a></li>
      <li><a href="/archives.php" title="Archives">Archives</a></li>
      <li><a href="/links.php" title="NOAA Links">NOAA Links</a></li>
      <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
    </ul>
  </div>

  <div id="header"> <a href="http://unisys.com"><img src="/images/Unisys_logo.gif" alt="Unisys" /></a>
    <h1>Unisys Weather</h1>
  </div>

<div id="leftside">
  <ul class="avmenu">
    <li><a href="/index.php" class="purple">Unisys Weather</a></li>
    <li><a href="/index.php"> Weather Home</a></li>
    <li><a href="/solutions/index.php">Weather Solutions</a></li>
    <li><a href="/mobile/index.php"><img id="mobile_icon" src="/mobile/Icon.png" width="24" height="24" alt="Download Unisys Weather Mobile App"/>iPhone App</a></li>
    <li><a href="/info/index.php">Information</a></li>
    <li><a href="/content.php">Contents</a></li>
    <li><a href="/analyses.php" class="purple">Analyses</a></li>
    <li><a href="/satellite/index.php">Satellite Images</a></li>
    <li><a href="/surface/index.php">Surface Data</a></li>
    <li><a href="/upper_air/index.php">Upper Air Data</a></li>
    <li><a href="/radar/index.php">Radar Data</a></li>
    <li><a href="/forehome.php" class="purple">Forecasts</a></li>
    <li><a href="/mos/index.php">Model Statistics</a></li>
    <li><a href="/nam/index.php">NAM/Wrf Model</a></li>
    <li><a href="/gfs/index.php?r=us">GFS/Avn Model</a></li>
    <li><a href="/gfsx/index.php?r=us">GFSx/MRF Model</a></li>
    <li><a href="/rap/index.php">RAP Model</a></li>
    <li><a href="/ecmwf/index.php">ECMWF Model</a></li>
    <li><a href="/archives.php" class="purple">Archive</a></li>
    <li><a href="/hurricane/index.php">Hurricane Data</a></li>
    <li><a href="/archive/index.php">Archive of Images</a></li>
    <li><a href="/usgs/index.php">USGS Maps</a></li>
  </ul>
</div>

<div id="extras">
  <ul class="avmenu">
    <li><a href="/foresetup.php" class="purple">Get a Forecast</a></li>
  </ul>

<script type="text/javascript">
function fsubmit()
{
     document.getElementById("Forecast").submit();
}
</script>

  <form method="get" id="Forecast" action="/forecast.php">
    <p class="center"> Enter a zip code or city name to get forecast:
      <input type="text" name="Name" id="Name" size="15" />
      <br />
      <button type="submit" style="border:none; background-color:transparent;">
         <img src="/images/GO.png" id="Go" alt="Get Forecast Data" style="height:30px;" />
      </button>
      <a href="/foresetup.php"><img src="/images/setup.png" alt="Setup Location" height="30" width="70" /></a> </p>
  </form>
  <script type="text/javascript">
                <!-- HIDE
                var index = document.cookie.indexOf("ZIP")
                var zipcode = 0
                var region = ""
                if( index != -1 ){
                   //zipcode = parseInt( document.cookie.substring(index+4,index+9),10)
                   zipcode = document.cookie.substring(index+4,index+9)
                   var validateZipCode = function() {
                     var zipcodeRegexp = /^\d{5}$/;
                     var zipTest = zipcodeRegexp.test(zipcode);
   
                     if (zipTest == false) {
                       return false;
                     }
                   }
                   validateZipCode();

                    if( ! isNaN(zipcode))

                    document.getElementById('Name').value = zipcode

                   if( zipcode >= 01000 && zipcode <= 19699 )
                      region = "ne"
                   else if( zipcode >= 19700 && zipcode <= 28999 )
                      region = "at"
                   else if( zipcode >= 43000 && zipcode <= 45999 )
                      region = "at"
                   else if( zipcode >= 29000 && zipcode <= 36999 )
                      region = "se"
                   else if( zipcode >= 38600 && zipcode <= 39999 )
                      region = "se"
                   else if( zipcode >= 46000 && zipcode <= 58999 )
                      region = "mw"
                   else if( zipcode >= 60000 && zipcode <= 62999 )
                      region = "mw"
                   else if( zipcode >= 68000 && zipcode <= 69999 )
                      region = "mw"
                   else if( zipcode >= 63000 && zipcode <= 67999 )
                      region = "cp"
                   else if( zipcode >= 71600 && zipcode <= 74999 )
                      region = "cp"
                   else if( zipcode >= 70000 && zipcode <= 71499 )
                      region = "sp"
                   else if( zipcode >= 75000 && zipcode <= 79999 )
                      region = "sp"
                   else if( zipcode >= 59000 && zipcode <= 59999 )
                      region = "nw"
                   else if( zipcode >= 82000 && zipcode <= 83999 )
                      region = "nw"
                   else if( zipcode >= 97000 && zipcode <= 99499 )
                      region = "nw"
                   else if( zipcode >= 80000 && zipcode <= 81999 )
                      region = "sw"
                   else if( zipcode >= 84000 && zipcode <= 96199 )
                      region = "sw"

                   if( region != "" ){
                      document.write( "<table border=\"0\" align=\"center\" class=\"grey\" width=\"100%\">" )
                      document.write( "<tr>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/surface/sfc_map.php?image=sfc&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Sfc" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=\"radar/rad" + region + ".php\">" )
                      document.write( "<a href=/radar/rcm_rad.php?image=rad&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Rad" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=vis&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Vis" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=enh&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>IR" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "</tr></table>" )
                      document.write( "</b>" )
                      }


                   
                   }
                // UNHIDE -->
                </script>
  <ul class="avmenu">
    <li><a href="/links.php" class="purple">NOAA Links</a></li>
    <li><a href="http://lwf.ncdc.noaa.gov/">National Climatic Data Center</a></li>
    <li><a href="http://www.cpc.noaa.gov/">Climate Prediction Center</a></li>
    <li><a href="http://oceanservice.noaa.gov/">National Ocean Service</a></li>
    <li><a href="http://www.lib.noaa.gov/">NOAA Library</a></li>
    <li><a href="http://www.oar.noaa.gov/">NOAA Office of Oceanic and Atmospheric Research</a></li>
    <li><a href="http://www.esrl.noaa.gov/">Earth Systems Research Laboratory</a></li>
    <li><a href="/overview.php" class="purple">About Us</a></li>
    <li><a href="/overview.php" title="Contact Us">Overview</a></li>
    <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
  </ul>
</div>
<div id="content">

<h2>NOAAPORT Ingest System</h2>
<p><i>Updated November 2011</i></p>

<table style="width: 99%; text-align: left;" border="0" cellpadding="2" cellspacing="10">
  <tr>
    <td>
    <h3>Overview:</h3>
    <p>The Unisys NOAAPORT Ingest System is a fully integrated, 
	turn-key system that accepts and processes the complete product 
	set found on the National Weather Service NOAAPORT satellite 
	broadcast service. This includes the GOES, NWSTG, NWSTG2, and 
	OCONUS broadcast channels. The Unisys NOAAPORT Ingest system is 
	also designed to accept and process the Unisys NOAAPORT broadcast 
	channel* that is co-located with the NWS NOAAPORT broadcast, and 
	any future NWS broadcast channels with a simple configuration 
	change.</p> 
	<p>This system runs on an Intel platform using Red Hat 
	Enterprise or CENTOS operating system. It uses standard TCP/IP 
	and NFS/SMB for data access. Our Unisys NOAAPORT Ingest System 
	has gone through rigorous testing at our product development lab 
	and is capable of processing receive data at the anticipated 
	30Mbit/sec data stream. The Unisys NOAAPORT Ingest System can 
	save all the data on local disks, provide product arrival 
	notification (PAN) messages, output the NOAAPORT data as a raw 
	NOAAPORT packet stream, or output the data as familiar WMO 
	bulletins that can be further processed or displayed by Unisys 
	Product Manager or user software</p>
    <br />
	<p><i>*Unisys is the only company to provide a Unisys NOAAPORT 
	channel with commercial weather data to supplement and complete 
	the weather data offered on NOAAPORT.</i></p>
	<br />
	
    <h3>Unisys NOAAPORT Ingest System Description:</h3>
    <p>The Unisys NOAAPORT Ingest System is an Intel based server 
	with hardware and software installed to receive the NOAAPORT 
	satellite broadcast. The Ingest System requires an outdoor antenna 
	system that consists of a C-Band capable satellite dish (size 
	varies with location, roughly 3.7 meters in diameter), an LNB, 
	optional heater blanket, and cabling.</p>
    
	<a href="/images/noaaport_1.gif"><img src="/images/noaaport_1.gif" alt="Ingest Antenna Diagram" style="float:right; padding-left:5px; width:273px; height:150px;"/></a>
	
	<p>The satellite receiver is connected to the outdoor antenna by 
	an RF cable and to the Ingest system by a network cable. The 
	receiver converts the satellite signal to IP multicast which is 
	processed by  the Ingest system.</p>
	
	<p>The ingest software will process each NOAAPORT channel, 
	assembling packet data into a stream and send the data over a 
	reliable TCP/IP socket connection to a set of client processes. 
	Client processes include the Unisys Product Manager or LDM (Local 
	Data Manager from Unidata) both of which reside in the Unisys 
	Noaaport Ingest system. A user can also connect to the Ingest 
	system by IP sockets with their own product manager. The user can 
	receive the data as either raw NOAAPORT frames or as WMO bulletins 
	in a format similar to the old Family of Services (FOS) feed.</p>
    </td>
  </tr>
  <tr>
    <td>
    <h3>Unisys Product Manager</h3>
    
	<p>The Unisys Product Manager is the default product manager and 
	is bundled with the Unisys NOAAPORT Ingest System. All Product 
	Manager processing is user configurable. The Product Manager uses 
	a configuration file to identify products based on WMO headers 
	and saves the output to user defined files on the local hard 
	drives of the Ingest System. The Product Manager supports user 
	defined data output, filenames and directory structures.</p>
	
	<a href="/images/noaaport_2.gif"><img src="/images/noaaport_2.gif" alt="Unisys Product Manager" style="float:right; padding-left:5px; width:234px; height:246px;"/></a>
	
	<p>The default setting divides data by channel (nwstg, nwstg2, 
	goes, oconus, unisys) and then by data type. The data is saved 
	over 4 disks. It organizes text data into data and text 
	directories based on whether it is observations and model output, 
	or manually generated text messages such as watches and warnings. 
	Data go into hourly or multi-hour collections. Binary data goes 
	into directories based on type such as model for GRIB data, BUFR 
	and sat (satellite imagery). Model data is organized by model and 
	grid type with all data going into a single file for easier file 
	manipulation. High resolution 1km satellite imagery is re-sampled 
	into lower resolution 4km images for easier processing. File names 
	are based on time and data type.</p>
	<br />
	<p>To process real-time data such as severe weather warnings, the 
	Product Manager transmits a Product Arrival Notification (PAN) 
	message sent via UDP datagram to a set of user defined clients at 
	the time the product is received. The message contains 
	date/time information, WMO header and location on disk of the 
	product (filename, byte offset and size).</p>
	<br />
	<p>Archiving of the data is done automatically using time 
	stamped file names. The Product Manager uses separate scour 
	processes to remove data off the server. This is user configurable 
	by directory and by file size and/or age.</p>
    </td>
  </tr>
  <tr>
    <td>
    <h3>Unidata LDM Support</h3>
    <p>The NOAAPORT Ingest System supports output to the Local Data 
	Manager (LDM) software system available from Unidata 
	(<a href="http://www.unidata.ucar.edu/software/ldm/">
	www.unidata.ucar.edu/software/ldm/</a>). 64 bit LDM software is 
	supplied with the system. LDM provides product manager 
	functionality comparable to the Unisys Product Manager. In 
	addition, it provides a store and forward function for 
	distributing data in multiple computers/clients.</p>
    </td>
  </tr>
  <tr>
    <td>
    <h3>SNMP Monitoring</h3>
    
	<a href="/images/noaaport_3.jpeg"><img src="/images/noaaport_3.jpeg" alt="MRTG Example" style="float:right; padding-left:5px; width:220px; height:121px;"/></a>
	
	<p>The Unisys Noaaport system is SNMP enabled, and has its own 
	publicly registered OID under Unisys-UnisysWeather. With SNMP you 
	can monitor common functions like CPU utilization, memory usage, 
	disk space, and processes. Our Ingest system will also let you 
	monitor NOAAPORT functions like throughput and frame loss, and 
	provide information about the Novra S300 satellite receiver.</p>
	<br />
	<p>HP Openview, HostMonitor, Nagios, and MRTG are some of the 3rd 
	party tools used for processing SNMP. These tools can also be used 
	for monitoring, alarming, and notification, as well as generating 
	graphs to give you a historical perspective on resources and how 
	they are being used over time. They can send SMS messages and/or 
	email your support staff when a threshold has been reached and 
	something needs attention. With SNMP there is no need to write 
	special monitoring scripts, or be in the dark about an overused 
	resource.</p>
	</td>
  </tr>
  <tr>
    <td>  
    <h3>System Documentation</h3>
    <ul>
      <li>Ingest System Users Guide: <a href="/noaaport/noaaport_ingest.php">(HTML)</a> | <a href="/noaaport/noaaport_ingest.pdf">(PDF)</a></li>
      <li>Product Manager Users Guide: <a href="/noaaport/prodman_users.pdf">(PDF)</a></li>
      <li>Unisys Channel (5th channel) Data Specification and Content: <a href="/noaaport/Unisys_content.php">(HTML)</a> | <a href="/noaaport/NOAAPORT_Unisys_Channel.pdf">(PDF)</a></li>
    </ul>
    </td>
  </tr>
  <tr>
    <td>
    <h3>Contact Information</h3>
    <p><span style="font-weight: bold; color: red">UNISYS WEATHER INFORMATION SYSTEMS</span><br/>
    2476 SWEDESFORD ROAD<br/>
    MALVERN, PA 19355<br/>
    PHONE: 800-610-9473<br/>
    SALES: <a href="mailto:sales-support@weather.unisys.com">sales-support@weather.unisys.com</a><br/>
    TECHNICAL: <a href="mailto:technical-support@weather.unisys.com">technical-support@weather.unisys.com</a><br/></p>
    </td>
  </tr>
  <tr>
    <td>
    <hr />
    <br />
    <p>For more information about the NOAAPORT program, data, or specifications see the  <a href="http://www.nws.noaa.gov/noaaport/html/noaaport.shtml">NWS NOAAPORT</a> user support page.</p>
    </td>
  </tr>
</table>

<div class="clearboth">&nbsp;</div>

</div>

<div id="footer"> <span id="copyright"><small>Copyright &copy; Unisys 2012</small></span>
  <ul class="inline-navigation-list" id="bottom-navigation">
    <li><a href="http://www.unisys.com/unisys/privacy.html" target="_blank">Privacy Notice</a></li>
    <li><a href="http://www.unisys.com/unisys/terms-and-conditions.html" target="_blank">Terms of Use</a></li>
    <li><a href="/contactus.php">Contact Us</a></li>
    <li><a href="http://www.unisys.com/unisys/trademarks.html" target="_blank">Trademarks</a></li>
  </ul>
</div>
</div>
</body>
</html>
