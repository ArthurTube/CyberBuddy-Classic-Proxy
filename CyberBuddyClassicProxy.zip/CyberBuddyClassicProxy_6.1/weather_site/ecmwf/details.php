<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Unisys Weather </title>
<meta name="description" content="The intent of this weather site is to provide a complete source of graphical weather 		information. This is intended to satisfy the needs of the weather professional, but can be a tool for the casual user as well. The graphics and data are displayed as a meteorologist would expect to see. For the novice user, there are detailed explanation pages to guide them through the various plots, charts and images. The data on this site are provided from the National Weather Service via the NOAAPORT satellite data service. All the images are generated using the Weather Processor (WXP) analysis package which is available from Unisys. "/>
<meta name="keywords" content="weather, unisys, unisys weather, weather maps, maps, nam, wrf, GFS, GFSx, hurricane, radar, satellite, surface, upper air" />
<meta name="copyright" content="Unisys Corp - 2011" />
<meta name="author" content="Unisys Corporation" />
<meta name="email" content="technical-support@weather.unisys.com" />
<meta name="Distribution" content="Global" />
<meta name="Rating" content="General" />
<meta name="Robots" content="INDEX,FOLLOW" />
<meta name="Revisit-after" content="7 Days" />
<meta http-equiv="Content-type" content="text/html;charset=UTF-8" />
<meta http-equiv="imagetoolbar" content="no" />
<meta http-equiv="Refresh" content="900" />
<meta http-equiv="X-UA-Compatible" content="IE=8"/>
<link rel="stylesheet" type="text/css" href="/css/WMAX.css" />
</head>
<body>
<div id="wrap">
  <div id="top-menu">
    <ul id="top-navigation" class="inline-navigation-list">
      <li><a href="http://www.unisys.com" title="Unisys Home Page">Unisys.com</a></li>
      <li><a href="/index.php" title="Unisys Weather">Weather Home</a></li>
      <li><a href="/analyses.php" title="Analyses">Analyses</a></li>
      <li><a href="/forehome.php" title="Forecast">Forecasts</a></li>
      <li><a href="/archives.php" title="Archives">Archives</a></li>
      <li><a href="/links.php" title="NOAA Links">NOAA Links</a></li>
      <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
    </ul>
  </div>

  <div id="header"> <a href="http://unisys.com"><img src="/images/Unisys_logo.gif" alt="Unisys" /></a>
    <h1>Unisys Weather</h1>
  </div>

<div id="leftside">
  <ul class="avmenu">
    <li><a href="/index.php" class="purple">Unisys Weather</a></li>
    <li><a href="/index.php"> Weather Home</a></li>
    <li><a href="/solutions/index.php">Weather Solutions</a></li>
    <li><a href="/mobile/index.php"><img id="mobile_icon" src="/mobile/Icon.png" width="24" height="24" alt="Download Unisys Weather Mobile App"/>iPhone App</a></li>
    <li><a href="/info/index.php">Information</a></li>
    <li><a href="/content.php">Contents</a></li>
    <li><a href="/analyses.php" class="purple">Analyses</a></li>
    <li><a href="/satellite/index.php">Satellite Images</a></li>
    <li><a href="/surface/index.php">Surface Data</a></li>
    <li><a href="/upper_air/index.php">Upper Air Data</a></li>
    <li><a href="/radar/index.php">Radar Data</a></li>
    <li><a href="/forehome.php" class="purple">Forecasts</a></li>
    <li><a href="/mos/index.php">Model Statistics</a></li>
    <li><a href="/nam/index.php">NAM/Wrf Model</a></li>
    <li><a href="/gfs/index.php?r=us">GFS/Avn Model</a></li>
    <li><a href="/gfsx/index.php?r=us">GFSx/MRF Model</a></li>
    <li><a href="/rap/index.php">RAP Model</a></li>
    <li><a href="/ecmwf/index.php">ECMWF Model</a></li>
    <li><a href="/archives.php" class="purple">Archive</a></li>
    <li><a href="/hurricane/index.php">Hurricane Data</a></li>
    <li><a href="/archive/index.php">Archive of Images</a></li>
    <li><a href="/usgs/index.php">USGS Maps</a></li>
  </ul>
</div>

<div id="extras">
  <ul class="avmenu">
    <li><a href="/foresetup.php" class="purple">Get a Forecast</a></li>
  </ul>

<script type="text/javascript">
function fsubmit()
{
     document.getElementById("Forecast").submit();
}
</script>

  <form method="get" id="Forecast" action="/forecast.php">
    <p class="center"> Enter a zip code or city name to get forecast:
      <input type="text" name="Name" id="Name" size="15" />
      <br />
      <button type="submit" style="border:none; background-color:transparent;">
         <img src="/images/GO.png" id="Go" alt="Get Forecast Data" style="height:30px;" />
      </button>
      <a href="/foresetup.php"><img src="/images/setup.png" alt="Setup Location" height="30" width="70" /></a> </p>
  </form>
  <script type="text/javascript">
                <!-- HIDE
                var index = document.cookie.indexOf("ZIP")
                var zipcode = 0
                var region = ""
                if( index != -1 ){
                   //zipcode = parseInt( document.cookie.substring(index+4,index+9),10)
                   zipcode = document.cookie.substring(index+4,index+9)
                   var validateZipCode = function() {
                     var zipcodeRegexp = /^\d{5}$/;
                     var zipTest = zipcodeRegexp.test(zipcode);
   
                     if (zipTest == false) {
                       return false;
                     }
                   }
                   validateZipCode();

                    if( ! isNaN(zipcode))

                    document.getElementById('Name').value = zipcode

                   if( zipcode >= 01000 && zipcode <= 19699 )
                      region = "ne"
                   else if( zipcode >= 19700 && zipcode <= 28999 )
                      region = "at"
                   else if( zipcode >= 43000 && zipcode <= 45999 )
                      region = "at"
                   else if( zipcode >= 29000 && zipcode <= 36999 )
                      region = "se"
                   else if( zipcode >= 38600 && zipcode <= 39999 )
                      region = "se"
                   else if( zipcode >= 46000 && zipcode <= 58999 )
                      region = "mw"
                   else if( zipcode >= 60000 && zipcode <= 62999 )
                      region = "mw"
                   else if( zipcode >= 68000 && zipcode <= 69999 )
                      region = "mw"
                   else if( zipcode >= 63000 && zipcode <= 67999 )
                      region = "cp"
                   else if( zipcode >= 71600 && zipcode <= 74999 )
                      region = "cp"
                   else if( zipcode >= 70000 && zipcode <= 71499 )
                      region = "sp"
                   else if( zipcode >= 75000 && zipcode <= 79999 )
                      region = "sp"
                   else if( zipcode >= 59000 && zipcode <= 59999 )
                      region = "nw"
                   else if( zipcode >= 82000 && zipcode <= 83999 )
                      region = "nw"
                   else if( zipcode >= 97000 && zipcode <= 99499 )
                      region = "nw"
                   else if( zipcode >= 80000 && zipcode <= 81999 )
                      region = "sw"
                   else if( zipcode >= 84000 && zipcode <= 96199 )
                      region = "sw"

                   if( region != "" ){
                      document.write( "<table border=\"0\" align=\"center\" class=\"grey\" width=\"100%\">" )
                      document.write( "<tr>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/surface/sfc_map.php?image=sfc&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Sfc" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=\"radar/rad" + region + ".php\">" )
                      document.write( "<a href=/radar/rcm_rad.php?image=rad&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Rad" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=vis&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Vis" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=enh&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>IR" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "</tr></table>" )
                      document.write( "</b>" )
                      }


                   
                   }
                // UNHIDE -->
                </script>
  <ul class="avmenu">
    <li><a href="/links.php" class="purple">NOAA Links</a></li>
    <li><a href="http://lwf.ncdc.noaa.gov/">National Climatic Data Center</a></li>
    <li><a href="http://www.cpc.noaa.gov/">Climate Prediction Center</a></li>
    <li><a href="http://oceanservice.noaa.gov/">National Ocean Service</a></li>
    <li><a href="http://www.lib.noaa.gov/">NOAA Library</a></li>
    <li><a href="http://www.oar.noaa.gov/">NOAA Office of Oceanic and Atmospheric Research</a></li>
    <li><a href="http://www.esrl.noaa.gov/">Earth Systems Research Laboratory</a></li>
    <li><a href="/overview.php" class="purple">About Us</a></li>
    <li><a href="/overview.php" title="Contact Us">Overview</a></li>
    <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
  </ul>
</div>
<div id="content">

<div class="drop">
<h2>ECMWF Model Details </h2>
    <p>
        This directory contains contour plots from the European Center for Medium range Weather
        Forecasting (ECMWF) forecast model. This model runs to 7 days and provides data at 24 hour
        intervals for sea level pressure, 850 mb winds and temperatures and 500 mb heights. These
        plots are generated once a day at 8:45 PM EST. 
   	</p>
    <hr />
    <h2>ECMWF 500 mb Forecast</h2>
    <p>
    	<img src="/ecmwf/images/ecmwf_500_sample.gif" alt="" width="240" height="192" />
        <i><br />Sample ECMWF 500 mb Forecasts</i> 
    </p>
    <p>
        The extended range plots actually show two parameters: 500 mb heights (in color
        contours) and sea level pressure (in black line contours). 
    </p>
    <br />
    	<h3>Sea level pressure</h3>
    <p>
        The sea level pressure field can be used to find low and high pressure systems as well as
        the location of cold fronts. The highs and lows can be located by the white H and L
        symbols on the map. Cold fronts will generally start from areas of low pressure and follow
        the trough of low pressure south and to the west of the low. Rain and/or snow is likely in
        the regions directly around the low and somewhat less likely along the cold front. 
    </p>
    <br />
    <br />
        <h3>500 mb heights</h3>
    <p>
        The 500 mb heights can be used to estimate surface temperatures since height of a pressure
        surface is related to the mean temperature of the air below it. Here is a rough estimate
        of temperatures based on color. The variability is on the order of +-10 degrees F:
        <br />
        <img src="/ecmwf/images/mrf_lgnd.gif" alt="" width="317" height="23" /> 
    </p>
    
    <table border="1" cellspacing="1">
      <tr>
        <td><strong>Height</strong></td>
        <td><strong>Color</strong></td>
        <td><strong>Hi Temp</strong></td>
      </tr>
      <tr>
        <td>5940-6000</td>
        <td>Red</td>
        <td>~90</td>
      </tr>
      <tr>
        <td>5880-5940</td>
        <td>Red Orange</td>
        <td>~84</td>
      </tr>
      <tr>
        <td>5820-5880</td>
        <td>Orange</td>
        <td>~78</td>
      </tr>
      <tr>
        <td>5760-5820</td>
        <td>Yellow Orange</td>
        <td>~72</td>
      </tr>
      <tr>
        <td>5700-5760</td>
        <td>Yellow</td>
        <td>~66</td>
      </tr>
      <tr>
        <td>5640-5700</td>
        <td>Greenish Yellow</td>
        <td>~60</td>
      </tr>
      <tr>
        <td>5580-5640</td>
        <td>Yellowish Green</td>
        <td>~54</td>
      </tr>
      <tr>
        <td>5520-5580</td>
        <td>Green</td>
        <td>~48</td>
      </tr>
      <tr>
        <td>5460-5520</td>
        <td>Cyanish Green</td>
        <td>~42</td>
      </tr>
      <tr>
        <td>5400-5460</td>
        <td>Greenish Cyan</td>
        <td>~36</td>
      </tr>
      <tr>
        <td>5340-5400</td>
        <td>Cyan</td>
        <td>~30</td>
      </tr>
      <tr>
        <td>5280-5340</td>
        <td>Blueish Cyan</td>
        <td>~24</td>
      </tr>
      <tr>
        <td>5220-5280</td>
        <td>Blue Cyan</td>
        <td>~18</td>
      </tr>
      <tr>
        <td>5160-5220</td>
        <td>Cyanish Blue</td>
        <td>~12</td>
      </tr>
      <tr>
        <td>5100-5160</td>
        <td>Blue</td>
        <td>~6</td>
      </tr>
      <tr>
        <td>5040-5100</td>
        <td>Magentaish Blue</td>
        <td>~0</td>
      </tr>
      <tr>
        <td>4980-5040</td>
        <td>Blueish Magenta</td>
        <td>~-6</td>
      </tr>
      <tr>
        <td>4920-4980</td>
        <td>Magenta</td>
        <td>~-12</td>
      </tr>
      <tr>
        <td>4860-4920</td>
        <td>Medium Magenta</td>
        <td>~-18</td>
      </tr>
      <tr>
        <td>4800-4860</td>
        <td>Dark Magenta</td>
        <td>~-24</td>
      </tr>
    </table>
    <p>Modify these by: </p>
    <table border="1">
      <tr>
        <td><strong>Type of conditions</strong></td>
        <td><strong>Modify by</strong></td>
      </tr>
      <tr>
        <td>Deserts</td>
        <td>+20</td>
      </tr>
      <tr>
        <td>Mid Summer</td>
        <td>+10</td>
      </tr>
      <tr>
        <td>Tropics</td>
        <td>+5</td>
      </tr>
      <tr>
        <td>Spring/Fall</td>
        <td>0</td>
      </tr>
      <tr>
        <td>Cloud cover</td>
        <td>-5</td>
      </tr>
      <tr>
        <td>Rainy areas</td>
        <td>-10</td>
      </tr>
      <tr>
        <td>Near Low Press</td>
        <td>-10</td>
      </tr>
      <tr>
        <td>Wintertime</td>
        <td>-10</td>
      </tr>
      <tr>
        <td>Snow cover</td>
        <td>-10</td>
      </tr>
      <tr>
        <td>Arctic Winter</td>
        <td>-20</td>
      </tr>
    </table>
    <p>
        <strong><a href="/ecmwf/ecmwf.html"> Current Images</a> </strong>
    </p>
    <hr />
    <h2>ECMWF 850 mb Forecast</h2>
    <p>
        <img src="/ecmwf/images/ecmwf_850_sample.gif" alt="" width="240" height="192" />
        <br /> /<i>Sample ECMWF 850 mb Forecasts</i> 
    </p>
    <p>
        The 850 mb chart details weather conditions at the 850 mb level or around 5000 feet
        above sea level. The parameters plotted are temperatures in Celsius (in color contours),
        and winds plotted as vectors. 
    </p>
    <br />
        <h3>850 mb temperatures</h3> 
    <p>
        The temperature field shows where warm and cold air are
        located. Temperatures at this level do not show the diurnal temperature changes from
        morning low to afternoon high we see at the earth's surface. You can determine potential
        afternoon highs from these temperatures by adding: 15C in the summer, 12C in spring and
        fall, and 9C in the winter and converting to Fahrenheit. For example, if the 850 temp is
        4C in summer, the afternoon temperature could reach 4+15=19C=67F. This algorithm does not
        work in the western third of the country due to its high altitude. 
    </p>
    <p>
        The 850 temperature is also a decent indicator of the type of precipitation. Since most
        precipitation forms at 5000 feet or above, a temperature of freezing (0 Celsius) or below
        would indicate snow whereas a temperature above freezing would indicate rain. 
    </p>
       <br />
        <h3>850 mb wind vector field</h3>
    <p>
        The vector field shows wind direction and speed. Often this can be used to qualitatively
        show areas of convergence and divergence. In the middle and upper levels of the
        troposphere, this can be an indicator of existing upward (from divergence) or downward
        (from convergence) air motion. Upward motion is often linked to precipitation and downward
        to clear skies. 
    </p>
    <br />
    <p>
        <small>(<b>NOTE:</b> The wind data are only broadcast out to 3 days and for a range of latitude
        from 35 south to 35 north.)</small> 
    </p>
    <p>
        <strong><a href="/ecmwf/ecmwf.html">Current Images</a> </strong>
	</p>
    </div>
<div class="clearboth">&nbsp;</div>

</div>

<div id="footer"> <span id="copyright"><small>Copyright &copy; Unisys 2012</small></span>
  <ul class="inline-navigation-list" id="bottom-navigation">
    <li><a href="http://www.unisys.com/unisys/privacy.html" target="_blank">Privacy Notice</a></li>
    <li><a href="http://www.unisys.com/unisys/terms-and-conditions.html" target="_blank">Terms of Use</a></li>
    <li><a href="/contactus.php">Contact Us</a></li>
    <li><a href="http://www.unisys.com/unisys/trademarks.html" target="_blank">Trademarks</a></li>
  </ul>
</div>
</div>
</body>
</html>
