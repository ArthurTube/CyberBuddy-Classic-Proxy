<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Unisys Weather  - Upper Air Sounding Plots</title>
<meta name="description" content="The intent of this weather site is to provide a complete source of graphical weather 		information. This is intended to satisfy the needs of the weather professional, but can be a tool for the casual user as well. The graphics and data are displayed as a meteorologist would expect to see. For the novice user, there are detailed explanation pages to guide them through the various plots, charts and images. The data on this site are provided from the National Weather Service via the NOAAPORT satellite data service. All the images are generated using the Weather Processor (WXP) analysis package which is available from Unisys. "/>
<meta name="keywords" content="weather, unisys, unisys weather, weather maps, maps, nam, wrf, GFS, GFSx, hurricane, radar, satellite, surface, upper air" />
<meta name="copyright" content="Unisys Corp - 2011" />
<meta name="author" content="Unisys Corporation" />
<meta name="email" content="technical-support@weather.unisys.com" />
<meta name="Distribution" content="Global" />
<meta name="Rating" content="General" />
<meta name="Robots" content="INDEX,FOLLOW" />
<meta name="Revisit-after" content="7 Days" />
<meta http-equiv="Content-type" content="text/html;charset=UTF-8" />
<meta http-equiv="imagetoolbar" content="no" />
<meta http-equiv="Refresh" content="900" />
<meta http-equiv="X-UA-Compatible" content="IE=8"/>
<link rel="stylesheet" type="text/css" href="/css/WMAX.css" />
</head>
<body>
<div id="wrap">
  <div id="top-menu">
    <ul id="top-navigation" class="inline-navigation-list">
      <li><a href="http://www.unisys.com" title="Unisys Home Page">Unisys.com</a></li>
      <li><a href="/index.php" title="Unisys Weather">Weather Home</a></li>
      <li><a href="/analyses.php" title="Analyses">Analyses</a></li>
      <li><a href="/forehome.php" title="Forecast">Forecasts</a></li>
      <li><a href="/archives.php" title="Archives">Archives</a></li>
      <li><a href="/links.php" title="NOAA Links">NOAA Links</a></li>
      <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
    </ul>
  </div>

  <div id="header"> <a href="http://unisys.com"><img src="/images/Unisys_logo.gif" alt="Unisys" /></a>
    <h1>Unisys Weather</h1>
  </div>

<div id="leftside">
  <ul class="avmenu">
    <li><a href="/index.php" class="purple">Unisys Weather</a></li>
    <li><a href="/index.php"> Weather Home</a></li>
    <li><a href="/solutions/index.php">Weather Solutions</a></li>
    <li><a href="/mobile/index.php"><img id="mobile_icon" src="/mobile/Icon.png" width="24" height="24" alt="Download Unisys Weather Mobile App"/>iPhone App</a></li>
    <li><a href="/info/index.php">Information</a></li>
    <li><a href="/content.php">Contents</a></li>
    <li><a href="/analyses.php" class="purple">Analyses</a></li>
    <li><a href="/satellite/index.php">Satellite Images</a></li>
    <li><a href="/surface/index.php">Surface Data</a></li>
    <li><a href="/upper_air/index.php">Upper Air Data</a></li>
    <li><a href="/radar/index.php">Radar Data</a></li>
    <li><a href="/forehome.php" class="purple">Forecasts</a></li>
    <li><a href="/mos/index.php">Model Statistics</a></li>
    <li><a href="/nam/index.php">NAM/Wrf Model</a></li>
    <li><a href="/gfs/index.php?r=us">GFS/Avn Model</a></li>
    <li><a href="/gfsx/index.php?r=us">GFSx/MRF Model</a></li>
    <li><a href="/rap/index.php">RAP Model</a></li>
    <li><a href="/ecmwf/index.php">ECMWF Model</a></li>
    <li><a href="/archives.php" class="purple">Archive</a></li>
    <li><a href="/hurricane/index.php">Hurricane Data</a></li>
    <li><a href="/archive/index.php">Archive of Images</a></li>
    <li><a href="/usgs/index.php">USGS Maps</a></li>
  </ul>
</div>

<div id="extras">
  <ul class="avmenu">
    <li><a href="/foresetup.php" class="purple">Get a Forecast</a></li>
  </ul>

<script type="text/javascript">
function fsubmit()
{
     document.getElementById("Forecast").submit();
}
</script>

  <form method="get" id="Forecast" action="/forecast.php">
    <p class="center"> Enter a zip code or city name to get forecast:
      <input type="text" name="Name" id="Name" size="15" />
      <br />
      <button type="submit" style="border:none; background-color:transparent;">
         <img src="/images/GO.png" id="Go" alt="Get Forecast Data" style="height:30px;" />
      </button>
      <a href="/foresetup.php"><img src="/images/setup.png" alt="Setup Location" height="30" width="70" /></a> </p>
  </form>
  <script type="text/javascript">
                <!-- HIDE
                var index = document.cookie.indexOf("ZIP")
                var zipcode = 0
                var region = ""
                if( index != -1 ){
                   //zipcode = parseInt( document.cookie.substring(index+4,index+9),10)
                   zipcode = document.cookie.substring(index+4,index+9)
                   var validateZipCode = function() {
                     var zipcodeRegexp = /^\d{5}$/;
                     var zipTest = zipcodeRegexp.test(zipcode);
   
                     if (zipTest == false) {
                       return false;
                     }
                   }
                   validateZipCode();

                    if( ! isNaN(zipcode))

                    document.getElementById('Name').value = zipcode

                   if( zipcode >= 01000 && zipcode <= 19699 )
                      region = "ne"
                   else if( zipcode >= 19700 && zipcode <= 28999 )
                      region = "at"
                   else if( zipcode >= 43000 && zipcode <= 45999 )
                      region = "at"
                   else if( zipcode >= 29000 && zipcode <= 36999 )
                      region = "se"
                   else if( zipcode >= 38600 && zipcode <= 39999 )
                      region = "se"
                   else if( zipcode >= 46000 && zipcode <= 58999 )
                      region = "mw"
                   else if( zipcode >= 60000 && zipcode <= 62999 )
                      region = "mw"
                   else if( zipcode >= 68000 && zipcode <= 69999 )
                      region = "mw"
                   else if( zipcode >= 63000 && zipcode <= 67999 )
                      region = "cp"
                   else if( zipcode >= 71600 && zipcode <= 74999 )
                      region = "cp"
                   else if( zipcode >= 70000 && zipcode <= 71499 )
                      region = "sp"
                   else if( zipcode >= 75000 && zipcode <= 79999 )
                      region = "sp"
                   else if( zipcode >= 59000 && zipcode <= 59999 )
                      region = "nw"
                   else if( zipcode >= 82000 && zipcode <= 83999 )
                      region = "nw"
                   else if( zipcode >= 97000 && zipcode <= 99499 )
                      region = "nw"
                   else if( zipcode >= 80000 && zipcode <= 81999 )
                      region = "sw"
                   else if( zipcode >= 84000 && zipcode <= 96199 )
                      region = "sw"

                   if( region != "" ){
                      document.write( "<table border=\"0\" align=\"center\" class=\"grey\" width=\"100%\">" )
                      document.write( "<tr>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/surface/sfc_map.php?image=sfc&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Sfc" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=\"radar/rad" + region + ".php\">" )
                      document.write( "<a href=/radar/rcm_rad.php?image=rad&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Rad" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=vis&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Vis" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=enh&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>IR" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "</tr></table>" )
                      document.write( "</b>" )
                      }


                   
                   }
                // UNHIDE -->
                </script>
  <ul class="avmenu">
    <li><a href="/links.php" class="purple">NOAA Links</a></li>
    <li><a href="http://lwf.ncdc.noaa.gov/">National Climatic Data Center</a></li>
    <li><a href="http://www.cpc.noaa.gov/">Climate Prediction Center</a></li>
    <li><a href="http://oceanservice.noaa.gov/">National Ocean Service</a></li>
    <li><a href="http://www.lib.noaa.gov/">NOAA Library</a></li>
    <li><a href="http://www.oar.noaa.gov/">NOAA Office of Oceanic and Atmospheric Research</a></li>
    <li><a href="http://www.esrl.noaa.gov/">Earth Systems Research Laboratory</a></li>
    <li><a href="/overview.php" class="purple">About Us</a></li>
    <li><a href="/overview.php" title="Contact Us">Overview</a></li>
    <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
  </ul>
</div>
<div id="content">
<table><tr><td class="seventy"><h2>Upper Air Sounding Plots</h2>
<a href="/upper_air/skew/ua_sound.php?type=no&city=kiad&region=ma&t=cur&expanddiv=hide_bar"><img src="/upper_air/images/skew_KIAD.gif" border="0" alt="Current SkewT from Washington DC" height="192" width="240" /></a><br /><i>Current SkewT from Washington DC</i>
<br /><br />
<p>
This directory contains vertical sounding plots from individual
balloons. These are plots of temperature, dewpoint and winds with
height. The soundings cover most of the available sites in the US
and parts of southern Canada. There is also a listing of sounding
data (in text form) including most major indices.  These data update
once every 12 hours at around 10:45 EST.
</p>
<br />
<br />
<b>
<a href="/upper_air/skew/details.php">More Information</a><br />
</b>
</td>

<td class="twenty">
<table>
  <tr><th>Other Pages</th></tr>
  <tr><td><a href="/upper_air/mandatory.php">Mandatory Level Plots</a></td></tr>
    <tr><td><a href="/upper_air/height.php">Constant Height Plots</a></td></tr>
    <tr><td><a href="/upper_air/hemisphere.php">Hemispheric Plots</a></td></tr>
    <tr><td><a href="/upper_air/contour.php">Contour Plots</a></td></tr>
   <tr><td><a href="/upper_air/skew/index.php">Upper Air Sounding Plots</a></td></tr>
</table>
</td>
</tr>
</table>
<table>
<tr>
<td align="center">
<map id="skewt_map" name="skewt_map">
<area shape="rect" coords="190,  35, 221,  52" href="/upper_air/skew/ua_sound.php?type=no&city=cwlo&region=sc&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="  7, 146,  37, 162" href="/upper_air/skew/ua_sound.php?type=no&city=kvbg&region=sw&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="370,  27, 405,  45" href="/upper_air/skew/ua_sound.php?type=no&city=cyoy&region=sc&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="372, 276, 405, 295" href="/upper_air/skew/ua_sound.php?type=no&city=keyw&region=se&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="386, 259, 412, 278" href="/upper_air/skew/ua_sound.php?type=no&city=kmia&region=se&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="370, 231, 402, 248" href="/upper_air/skew/ua_sound.php?type=no&city=kxmr&region=se&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="359, 248, 386, 263" href="/upper_air/skew/ua_sound.php?type=no&city=ktbw&region=se&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="202, 283, 233, 299" href="/upper_air/skew/ua_sound.php?type=no&city=kbro&region=sp&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="207, 263, 238, 281" href="/upper_air/skew/ua_sound.php?type=no&city=kcrp&region=sp&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="357, 214, 384, 231" href="/upper_air/skew/ua_sound.php?type=no&city=kjax&region=se&t=cur&expanddiv=hide_bar" alt="" />

<area shape="rect" coords="334, 221, 359, 239" href="/upper_air/skew/ua_sound.php?type=no&city=ktlh&region=se&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="280, 231, 305, 246" href="/upper_air/skew/ua_sound.php?type=no&city=klix&region=sp&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="302, 197, 327, 214" href="/upper_air/skew/ua_sound.php?type=no&city=keet&region=se&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="272, 209, 303, 227" href="/upper_air/skew/ua_sound.php?type=no&city=kjan&region=se&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="244, 237, 278, 254" href="/upper_air/skew/ua_sound.php?type=no&city=klch&region=sp&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="237, 209, 268, 228" href="/upper_air/skew/ua_sound.php?type=no&city=kshv&region=sp&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="204, 207, 240, 224" href="/upper_air/skew/ua_sound.php?type=no&city=kfwd&region=sp&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="171, 240, 200, 261" href="/upper_air/skew/ua_sound.php?type=no&city=kdrt&region=sp&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="159, 212, 191, 231" href="/upper_air/skew/ua_sound.php?type=no&city=kmaf&region=sp&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="122, 209, 153, 227" href="/upper_air/skew/ua_sound.php?type=no&city=kepz&region=sp&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="248, 184, 278, 202" href="/upper_air/skew/ua_sound.php?type=no&city=klzk&region=cp&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="208, 181, 234, 200" href="/upper_air/skew/ua_sound.php?type=no&city=koun&region=cp&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="165, 179, 195, 198" href="/upper_air/skew/ua_sound.php?type=no&city=kama&region=sp&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="323, 190, 350, 206" href="/upper_air/skew/ua_sound.php?type=no&city=kffcm&region=se&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="360, 181, 395, 202" href="/upper_air/skew/ua_sound.php?type=no&city=kchs&region=se&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="386, 155, 421, 171" href="/upper_air/skew/ua_sound.php?type=no&city=kmhx&region=ma&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="355, 153, 382, 169" href="/upper_air/skew/ua_sound.php?type=no&city=kgso&region=ma&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="295, 161, 330, 182" href="/upper_air/skew/ua_sound.php?type=no&city=kbna&region=cp&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="237, 158, 266, 179" href="/upper_air/skew/ua_sound.php?type=no&city=ksgf&region=cp&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="181, 153, 214, 172" href="/upper_air/skew/ua_sound.php?type=no&city=kddc&region=cp&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="124, 174, 155, 197" href="/upper_air/skew/ua_sound.php?type=no&city=kabq&region=sw&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords=" 80, 197, 111, 215" href="/upper_air/skew/ua_sound.php?type=no&city=ktus&region=sw&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords=" 78, 163, 109, 180" href="/upper_air/skew/ua_sound.php?type=no&city=kfsx&region=sw&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords=" 26, 174,  59, 191" href="/upper_air/skew/ua_sound.php?type=no&city=knkx&region=sw&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="151, 129, 177, 149" href="/upper_air/skew/ua_sound.php?type=no&city=kdnr&region=sw&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="120, 131, 149, 148" href="/upper_air/skew/ua_sound.php?type=no&city=kgjt&region=sw&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords=" 52, 142,  82, 159" href="/upper_air/skew/ua_sound.php?type=no&city=kdra&region=sw&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="222, 141, 251, 157" href="/upper_air/skew/ua_sound.php?type=no&city=ktop&region=cp&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="350, 139, 376, 154" href="/upper_air/skew/ua_sound.php?type=no&city=krnk&region=ma&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="392, 120, 415, 137" href="/upper_air/skew/ua_sound.php?type=no&city=kwal&region=ma&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="407,  66, 435,  86" href="/upper_air/skew/ua_sound.php?type=no&city=kchh&region=ne&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="367, 116, 390, 131" href="/upper_air/skew/ua_sound.php?type=no&city=kiad&region=ma&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="320, 127, 345, 143" href="/upper_air/skew/ua_sound.php?type=no&city=kiln&region=ma&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="344, 110, 366, 125" href="/upper_air/skew/ua_sound.php?type=no&city=kpit&region=ne&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="390,  86, 419, 104" href="/upper_air/skew/ua_sound.php?type=no&city=kokx&region=ne&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="397,  16, 422,  31" href="/upper_air/skew/ua_sound.php?type=no&city=kcar&region=ne&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="395,  46, 426,  65" href="/upper_air/skew/ua_sound.php?type=no&city=kgyx&region=ne&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="376,  71, 403,  88" href="/upper_air/skew/ua_sound.php?type=no&city=kalb&region=ne&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="340,  80, 372,  98" href="/upper_air/skew/ua_sound.php?type=no&city=kbuf&region=ne&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="309,  91, 340, 109" href="/upper_air/skew/ua_sound.php?type=no&city=kdtx&region=mw&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="  7, 108,  39, 128" href="/upper_air/skew/ua_sound.php?type=no&city=koak&region=sw&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords=" 99, 106, 124, 127" href="/upper_air/skew/ua_sound.php?type=no&city=kslc&region=sw&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords=" 69,  99,  98, 118" href="/upper_air/skew/ua_sound.php?type=no&city=keko&region=sw&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="255, 109, 286, 128" href="/upper_air/skew/ua_sound.php?type=no&city=kdvn&region=mw&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="296,  69, 324,  86" href="/upper_air/skew/ua_sound.php?type=no&city=kapx&region=mw&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="274,  82, 299, 100" href="/upper_air/skew/ua_sound.php?type=no&city=kgrb&region=mw&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords=" 35,  99,  66, 118" href="/upper_air/skew/ua_sound.php?type=no&city=krev&region=sw&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="233,  79, 263,  96" href="/upper_air/skew/ua_sound.php?type=no&city=kmpx&region=mw&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="217, 117, 247, 136" href="/upper_air/skew/ua_sound.php?type=no&city=koax&region=mw&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="181, 114, 213, 135" href="/upper_air/skew/ua_sound.php?type=no&city=klbf&region=mw&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="204,  76, 228,  92" href="/upper_air/skew/ua_sound.php?type=no&city=kabr&region=mw&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="233,  45, 264,  61" href="/upper_air/skew/ua_sound.php?type=no&city=kinl&region=mw&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="188,  64, 213,  81" href="/upper_air/skew/ua_sound.php?type=no&city=kbis&region=mw&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="166,  85, 197, 104" href="/upper_air/skew/ua_sound.php?type=no&city=krap&region=mw&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="129,  93, 157, 109" href="/upper_air/skew/ua_sound.php?type=no&city=kriw&region=nw&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords=" 77,  75, 103,  92" href="/upper_air/skew/ua_sound.php?type=no&city=kboi&region=nw&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords=" 18,  63,  49,  81" href="/upper_air/skew/ua_sound.php?type=no&city=kmfr&region=nw&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="149,  44, 175,  62" href="/upper_air/skew/ua_sound.php?type=no&city=kggw&region=nw&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="118,  45, 144,  61" href="/upper_air/skew/ua_sound.php?type=no&city=ktfx&region=nw&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords=" 78,  31, 105,  47" href="/upper_air/skew/ua_sound.php?type=no&city=kgeg&region=nw&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords=" 36,  40,  64,  57" href="/upper_air/skew/ua_sound.php?type=no&city=ksle&region=nw&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords=" 44,  10,  66,  27" href="/upper_air/skew/ua_sound.php?type=no&city=kuil&region=nw&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords=" 47,   8,  69,  25" href="/upper_air/skew/ua_sound.php?type=no&city=cyzt&region=sc&t=cur&expanddiv=hide_bar" alt="" />
<area shape="rect" coords="274, 127, 296, 143" href="/upper_air/skew/ua_sound.php?type=no&city=kilx&region=mw&t=cur&expanddiv=hide_bar" alt="" />
<area coords="0,0,10000,10000" alt="" /></map>
<img src="/upper_air/skew/station.gif" usemap="#skewt_map" ismap="ismap" alt="Click on map to get sounding" height="300" width="450" />
</td>
</tr>
</table>
<table width="100%">
<tr>
  <th width="33%" >
     Southern Canada
  </th>
  <th width="33%" >
     Midwest
  </th>
  <th width="33%" >
     New England
  </th>
</tr>
<tr>
  <td width="33%"  valign="top">
    <b>
    <a href="/upper_air/skew/ua_sound.php?type=no&city=cywa&region=sc&t=cur&expanddiv=hide_bar"><small>+Petawawa ON-CN (YWA-71625)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=cwpl&region=sc&t=cur&expanddiv=hide_bar"><small>+Pickle Lake ON-CN (WPL-71845)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=cwlo&region=sc&t=cur&expanddiv=hide_bar"><small>+Shilo MN-CN (WLO-71853)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=cyoy&region=sc&t=cur&expanddiv=hide_bar"><small>+Valcartier QB-CN (YOY-71716)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=cyzt&region=sc&t=cur&expanddiv=hide_bar"><small>+Port Hardy BC-CN (YOY-71203)</small></a><br />
    </b>
  </td>
  <td width="33%"  valign="top">
    <b>
    <a href="/upper_air/skew/ua_sound.php?type=no&city=kabr&region=mw&t=cur&expanddiv=hide_bar"><small>+Aberdeen SD (ABR-72659)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=kbis&region=mw&t=cur&expanddiv=hide_bar"><small>+Bismarck ND (BIS-72764)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=kdtx&region=mw&t=cur&expanddiv=hide_bar"><small>+Detroit MI (DTX-72632)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=kapx&region=mw&t=cur&expanddiv=hide_bar"><small>+Gaylord MI (APX-72634)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=kgrb&region=mw&t=cur&expanddiv=hide_bar"><small>+Green Bay WI (GRB-72645)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=kinl&region=mw&t=cur&expanddiv=hide_bar"><small>+Internation Falls MN (INL-72747)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=kilx&region=mw&t=cur&expanddiv=hide_bar"><small>+Lincoln IL (ILX-74560)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=klbf&region=mw&t=cur&expanddiv=hide_bar"><small>+North Platte NE (LBF-72562)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=kmpx&region=mw&t=cur&expanddiv=hide_bar"><small>+Minneapolis MN (MPX-72649)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=koax&region=mw&t=cur&expanddiv=hide_bar"><small>+Omaha NE (OAX-72558)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=krap&region=mw&t=cur&expanddiv=hide_bar"><small>+Rapid City SD (RAP-72662)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=kdvn&region=mw&t=cur&expanddiv=hide_bar"><small>+Quad Cities IA (DVN-74455)</small></a><br />
    </b>
  </td>
  <td width="33%"  valign="top">
    <b>
    <a href="/upper_air/skew/ua_sound.php?type=no&city=kalb&region=ne&t=cur&expanddiv=hide_bar"><small>+Albany NY (ALB-72518)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=kokx&region=ne&t=cur&expanddiv=hide_bar"><small>+Brookhaven NY (OKX-72501)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=kbuf&region=ne&t=cur&expanddiv=hide_bar"><small>+Buffalo NY (BUF-72528)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=kcar&region=ne&t=cur&expanddiv=hide_bar"><small>+Caribou ME (CAR-72712)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=kchh&region=ne&t=cur&expanddiv=hide_bar"><small>+Chatham MA (CHH-74494)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=kgyx&region=ne&t=cur&expanddiv=hide_bar"><small>+Gray ME (GYX-74389)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=kpit&region=ne&t=cur&expanddiv=hide_bar"><small>+Pittsburgh PA (PIT-72520)</small></a><br />
    </b>
  </td>
</tr>
<tr>
  <th width="33%" >
     Northwest
  </th>
  <th width="33%" >
     Central Plains
  </th>
  <th width="33%" >
     Mid Atlantic
  </th>
</tr>
<tr>
  <td width="33%"  valign="top">
    <b>
    <a href="/upper_air/skew/ua_sound.php?type=no&city=kboi&region=nw&t=cur&expanddiv=hide_bar"><small>+Boise ID (BOI-72681)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=kggw&region=nw&t=cur&expanddiv=hide_bar"><small>+Glasgow MT (GGW-72768)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=ktfx&region=nw&t=cur&expanddiv=hide_bar"><small>+Great Falls MT (TFX-72776)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=kmfr&region=nw&t=cur&expanddiv=hide_bar"><small>+Medford OR (MFR-72597)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=kuil&region=nw&t=cur&expanddiv=hide_bar"><small>+Quillayute WA (UIL-72797)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=kriw&region=nw&t=cur&expanddiv=hide_bar"><small>+Riverton WY (RIW-72673)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=ksle&region=nw&t=cur&expanddiv=hide_bar"><small>+Salem OR (SLE-72694)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=kgeg&region=nw&t=cur&expanddiv=hide_bar"><small>+Spokane WA (GEG-72785)</small></a><br />
    </b>
  </td>
  <td width="33%"  valign="top">
    <b>
    <a href="/upper_air/skew/ua_sound.php?type=no&city=kddc&region=cp&t=cur&expanddiv=hide_bar"><small>+Dodge City KS (DDC-72451)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=klzk&region=cp&t=cur&expanddiv=hide_bar"><small>+Little Rock AR (LZK-72340)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=kbna&region=cp&t=cur&expanddiv=hide_bar"><small>+Nashville TN (BNA-72327)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=koun&region=cp&t=cur&expanddiv=hide_bar"><small>+Norman OK (OUN-72357)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=ksgf&region=cp&t=cur&expanddiv=hide_bar"><small>+Springfield MO (SGF-72440)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=ktop&region=cp&t=cur&expanddiv=hide_bar"><small>+Topeka KS (TOP-72456)</small></a><br />
    </b>
  </td>
  <td width="33%"  valign="top">
    <b>
    <a href="/upper_air/skew/ua_sound.php?type=no&city=kgso&region=ma&t=cur&expanddiv=hide_bar"><small>+Greensboro NC (GSO-72317)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=kmhx&region=ma&t=cur&expanddiv=hide_bar"><small>+Morehead City NC (MHX-72305)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=krnk&region=ma&t=cur&expanddiv=hide_bar"><small>+Roanoke VA (RNK-72318)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=kwal&region=ma&t=cur&expanddiv=hide_bar"><small>+Wallops Island MD (WAL-72402)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=kiad&region=ma&t=cur&expanddiv=hide_bar"><small>+Washington DC (IAD-72403)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=klin&region=ma&t=cur&expanddiv=hide_bar"><small>+Wilmington OH (ILN-72426)</small></a><br />
    </b>
  </td>
</tr>
<tr>
  <th width="33%" >
     Southwest
  </th>
  <th width="33%" >
     Southern Plains
  </th>
  <th width="33%" >
     Southeast
  </th>
</tr>
<tr>
  <td width="33%"  valign="top">
    <b>
    <a href="/upper_air/skew/ua_sound.php?type=no&city=kabq&region=sw&t=cur&expanddiv=hide_bar"><small>+Albuquerque NM (ABQ-72365)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=kdnr&region=sw&t=cur&expanddiv=hide_bar"><small>+Denver CO (DNR-72469)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=keko&region=sw&t=cur&expanddiv=hide_bar"><small>+Elko NV (EKO-72582)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=kfsx&region=sw&t=cur&expanddiv=hide_bar"><small>+Flagstaff AZ (FSX-72376)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=kgjt&region=sw&t=cur&expanddiv=hide_bar"><small>+Grand Junction CO (GJT-72476)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=kdra&region=sw&t=cur&expanddiv=hide_bar"><small>+Mercury NV (DRA-72387)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=koak&region=sw&t=cur&expanddiv=hide_bar"><small>+Oakland CA (OAK-72493)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=krev&region=sw&t=cur&expanddiv=hide_bar"><small>+Reno NV (REV-72489)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=kslc&region=sw&t=cur&expanddiv=hide_bar"><small>+Salt Lake City UT (SLC-72572)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=knkx&region=sw&t=cur&expanddiv=hide_bar"><small>+San Diego CA (NKX-72293)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=ktus&region=sw&t=cur&expanddiv=hide_bar"><small>+Tucson AZ (TUS-72274)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=kvbg&region=sw&t=cur&expanddiv=hide_bar"><small>+Vandenberg CA (VBG-74606)</small></a><br />
    </b>
</td>
<td width="33%"  valign="top">
    <b>
    <a href="/upper_air/skew/ua_sound.php?type=no&city=kama&region=sp&t=cur&expanddiv=hide_bar"><small>+Amarillo TX (AMA-72363)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=kbro&region=sp&t=cur&expanddiv=hide_bar"><small>+Brownsville TX (BRO-72250)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=kcrp&region=sp&t=cur&expanddiv=hide_bar"><small>+Corpus Christi TX (CRP-72251)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=kdrt&region=sp&t=cur&expanddiv=hide_bar"><small>+Del Rio TX (DRT-72261)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=kepz&region=sp&t=cur&expanddiv=hide_bar"><small>+El Paso TX (EPZ-72364)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=kfwd&region=sp&t=cur&expanddiv=hide_bar"><small>+Fort Worth TX (FWD-72249)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=klch&region=sp&t=cur&expanddiv=hide_bar"><small>+Lake Charles LA (LCH-72240)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=kmaf&region=sp&t=cur&expanddiv=hide_bar"><small>+Midland TX (MAF-72265)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=klix&region=sp&t=cur&expanddiv=hide_bar"><small>+Slidell LA (LIX-72233)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=kshv&region=sp&t=cur&expanddiv=hide_bar"><small>+Shreveport LA (SHV-72248)</small></a><br />
    </b>
  </td>
  <td width="33%"  valign="top">
    <b>
    <a href="/upper_air/skew/ua_sound.php?type=no&city=kxmr&region=se&t=cur&expanddiv=hide_bar"><small>+Cape Canaveral FL (XMR-74794)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=kchs&region=se&t=cur&expanddiv=hide_bar"><small>+Charleston SC (CHS-72208)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=kjan&region=se&t=cur&expanddiv=hide_bar"><small>+Jackson MS (JAN-72235)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=kjax&region=se&t=cur&expanddiv=hide_bar"><small>+Jacksonville FL (JAX-72206)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=keyw&region=se&t=cur&expanddiv=hide_bar"><small>+Key West FL (EYW-72201)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=kmia&region=se&t=cur&expanddiv=hide_bar"><small>+Miami FL (MIA-72202)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=kffcm&region=se&t=cur&expanddiv=hide_bar"><small>+Peachtree City GA (FFC-72215)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=keet&region=se&t=cur&expanddiv=hide_bar"><small>+Shelby Co AL (EET-72230)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=ktlh&region=se&t=cur&expanddiv=hide_bar"><small>+Tallahassee FL (TLH-72214)</small></a><br />
    <a href="/upper_air/skew/ua_sound.php?type=no&city=ktbw&region=se&t=cur&expanddiv=hide_bar"><small>+Tampa Bay FL (TBW-72210)</small></a><br />
    </b>
  </td>
</tr>
</table>

<b>
<a href="/upper_air/index.php">Return to Upper Air Page</a><br />
<a href="/index.php">Return to Unisys Main Page</a>
</b><br />

<div class="clearboth">&nbsp;</div>

</div>

<div id="footer"> <span id="copyright"><small>Copyright &copy; Unisys 2012</small></span>
  <ul class="inline-navigation-list" id="bottom-navigation">
    <li><a href="http://www.unisys.com/unisys/privacy.html" target="_blank">Privacy Notice</a></li>
    <li><a href="http://www.unisys.com/unisys/terms-and-conditions.html" target="_blank">Terms of Use</a></li>
    <li><a href="/contactus.php">Contact Us</a></li>
    <li><a href="http://www.unisys.com/unisys/trademarks.html" target="_blank">Trademarks</a></li>
  </ul>
</div>
</div>
</body>
</html>


