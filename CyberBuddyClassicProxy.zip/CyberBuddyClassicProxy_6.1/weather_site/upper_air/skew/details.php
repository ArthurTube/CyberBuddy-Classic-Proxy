<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Unisys Weather  - Upper Air Sounding Details</title>
<meta name="description" content="The intent of this weather site is to provide a complete source of graphical weather 		information. This is intended to satisfy the needs of the weather professional, but can be a tool for the casual user as well. The graphics and data are displayed as a meteorologist would expect to see. For the novice user, there are detailed explanation pages to guide them through the various plots, charts and images. The data on this site are provided from the National Weather Service via the NOAAPORT satellite data service. All the images are generated using the Weather Processor (WXP) analysis package which is available from Unisys. "/>
<meta name="keywords" content="weather, unisys, unisys weather, weather maps, maps, nam, wrf, GFS, GFSx, hurricane, radar, satellite, surface, upper air" />
<meta name="copyright" content="Unisys Corp - 2011" />
<meta name="author" content="Unisys Corporation" />
<meta name="email" content="technical-support@weather.unisys.com" />
<meta name="Distribution" content="Global" />
<meta name="Rating" content="General" />
<meta name="Robots" content="INDEX,FOLLOW" />
<meta name="Revisit-after" content="7 Days" />
<meta http-equiv="Content-type" content="text/html;charset=UTF-8" />
<meta http-equiv="imagetoolbar" content="no" />
<meta http-equiv="Refresh" content="900" />
<meta http-equiv="X-UA-Compatible" content="IE=8"/>
<link rel="stylesheet" type="text/css" href="/css/WMAX.css" />
</head>
<body>
<div id="wrap">
  <div id="top-menu">
    <ul id="top-navigation" class="inline-navigation-list">
      <li><a href="http://www.unisys.com" title="Unisys Home Page">Unisys.com</a></li>
      <li><a href="/index.php" title="Unisys Weather">Weather Home</a></li>
      <li><a href="/analyses.php" title="Analyses">Analyses</a></li>
      <li><a href="/forehome.php" title="Forecast">Forecasts</a></li>
      <li><a href="/archives.php" title="Archives">Archives</a></li>
      <li><a href="/links.php" title="NOAA Links">NOAA Links</a></li>
      <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
    </ul>
  </div>

  <div id="header"> <a href="http://unisys.com"><img src="/images/Unisys_logo.gif" alt="Unisys" /></a>
    <h1>Unisys Weather</h1>
  </div>

<div id="leftside">
  <ul class="avmenu">
    <li><a href="/index.php" class="purple">Unisys Weather</a></li>
    <li><a href="/index.php"> Weather Home</a></li>
    <li><a href="/solutions/index.php">Weather Solutions</a></li>
    <li><a href="/mobile/index.php"><img id="mobile_icon" src="/mobile/Icon.png" width="24" height="24" alt="Download Unisys Weather Mobile App"/>iPhone App</a></li>
    <li><a href="/info/index.php">Information</a></li>
    <li><a href="/content.php">Contents</a></li>
    <li><a href="/analyses.php" class="purple">Analyses</a></li>
    <li><a href="/satellite/index.php">Satellite Images</a></li>
    <li><a href="/surface/index.php">Surface Data</a></li>
    <li><a href="/upper_air/index.php">Upper Air Data</a></li>
    <li><a href="/radar/index.php">Radar Data</a></li>
    <li><a href="/forehome.php" class="purple">Forecasts</a></li>
    <li><a href="/mos/index.php">Model Statistics</a></li>
    <li><a href="/nam/index.php">NAM/Wrf Model</a></li>
    <li><a href="/gfs/index.php?r=us">GFS/Avn Model</a></li>
    <li><a href="/gfsx/index.php?r=us">GFSx/MRF Model</a></li>
    <li><a href="/rap/index.php">RAP Model</a></li>
    <li><a href="/ecmwf/index.php">ECMWF Model</a></li>
    <li><a href="/archives.php" class="purple">Archive</a></li>
    <li><a href="/hurricane/index.php">Hurricane Data</a></li>
    <li><a href="/archive/index.php">Archive of Images</a></li>
    <li><a href="/usgs/index.php">USGS Maps</a></li>
  </ul>
</div>

<div id="extras">
  <ul class="avmenu">
    <li><a href="/foresetup.php" class="purple">Get a Forecast</a></li>
  </ul>

<script type="text/javascript">
function fsubmit()
{
     document.getElementById("Forecast").submit();
}
</script>

  <form method="get" id="Forecast" action="/forecast.php">
    <p class="center"> Enter a zip code or city name to get forecast:
      <input type="text" name="Name" id="Name" size="15" />
      <br />
      <button type="submit" style="border:none; background-color:transparent;">
         <img src="/images/GO.png" id="Go" alt="Get Forecast Data" style="height:30px;" />
      </button>
      <a href="/foresetup.php"><img src="/images/setup.png" alt="Setup Location" height="30" width="70" /></a> </p>
  </form>
  <script type="text/javascript">
                <!-- HIDE
                var index = document.cookie.indexOf("ZIP")
                var zipcode = 0
                var region = ""
                if( index != -1 ){
                   //zipcode = parseInt( document.cookie.substring(index+4,index+9),10)
                   zipcode = document.cookie.substring(index+4,index+9)
                   var validateZipCode = function() {
                     var zipcodeRegexp = /^\d{5}$/;
                     var zipTest = zipcodeRegexp.test(zipcode);
   
                     if (zipTest == false) {
                       return false;
                     }
                   }
                   validateZipCode();

                    if( ! isNaN(zipcode))

                    document.getElementById('Name').value = zipcode

                   if( zipcode >= 01000 && zipcode <= 19699 )
                      region = "ne"
                   else if( zipcode >= 19700 && zipcode <= 28999 )
                      region = "at"
                   else if( zipcode >= 43000 && zipcode <= 45999 )
                      region = "at"
                   else if( zipcode >= 29000 && zipcode <= 36999 )
                      region = "se"
                   else if( zipcode >= 38600 && zipcode <= 39999 )
                      region = "se"
                   else if( zipcode >= 46000 && zipcode <= 58999 )
                      region = "mw"
                   else if( zipcode >= 60000 && zipcode <= 62999 )
                      region = "mw"
                   else if( zipcode >= 68000 && zipcode <= 69999 )
                      region = "mw"
                   else if( zipcode >= 63000 && zipcode <= 67999 )
                      region = "cp"
                   else if( zipcode >= 71600 && zipcode <= 74999 )
                      region = "cp"
                   else if( zipcode >= 70000 && zipcode <= 71499 )
                      region = "sp"
                   else if( zipcode >= 75000 && zipcode <= 79999 )
                      region = "sp"
                   else if( zipcode >= 59000 && zipcode <= 59999 )
                      region = "nw"
                   else if( zipcode >= 82000 && zipcode <= 83999 )
                      region = "nw"
                   else if( zipcode >= 97000 && zipcode <= 99499 )
                      region = "nw"
                   else if( zipcode >= 80000 && zipcode <= 81999 )
                      region = "sw"
                   else if( zipcode >= 84000 && zipcode <= 96199 )
                      region = "sw"

                   if( region != "" ){
                      document.write( "<table border=\"0\" align=\"center\" class=\"grey\" width=\"100%\">" )
                      document.write( "<tr>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/surface/sfc_map.php?image=sfc&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Sfc" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=\"radar/rad" + region + ".php\">" )
                      document.write( "<a href=/radar/rcm_rad.php?image=rad&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Rad" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=vis&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Vis" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=enh&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>IR" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "</tr></table>" )
                      document.write( "</b>" )
                      }


                   
                   }
                // UNHIDE -->
                </script>
  <ul class="avmenu">
    <li><a href="/links.php" class="purple">NOAA Links</a></li>
    <li><a href="http://lwf.ncdc.noaa.gov/">National Climatic Data Center</a></li>
    <li><a href="http://www.cpc.noaa.gov/">Climate Prediction Center</a></li>
    <li><a href="http://oceanservice.noaa.gov/">National Ocean Service</a></li>
    <li><a href="http://www.lib.noaa.gov/">NOAA Library</a></li>
    <li><a href="http://www.oar.noaa.gov/">NOAA Office of Oceanic and Atmospheric Research</a></li>
    <li><a href="http://www.esrl.noaa.gov/">Earth Systems Research Laboratory</a></li>
    <li><a href="/overview.php" class="purple">About Us</a></li>
    <li><a href="/overview.php" title="Contact Us">Overview</a></li>
    <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
  </ul>
</div>
<div id="content">
<h2>Upper Air Sounding Details</h2>

<p>Upper air soundings are plotted data from balloons. The 
balloon records temperature, humidity and winds and these are plotted versus 
pressure/height to give details on the vertical structure of the atmosphere. 
The type of plot is called a SkewT and a set of SkewTs are available for 
most US stations. These are updated once every 12 hours at roughly 10:00 
EST.</p>

<hr width="99%" />
<a name="skew"></a><h3>SkewT Plots</h3>

<p><img src="/upper_air/images/skew_sample.gif" alt="Sample SkewT plot" height="320" width="400" /><br/><i>Sample SkewT plot</i> </p>

<p>A Skew T plot is a standard plot used by meteorologists 
to analyze data from a balloon sounding. This is a plot of temperature with 
height as denoted by pressure. </p>

<p><img src="/upper_air/images/skew_lgnd.gif" height="163" width="207" alt="Legend" /><br/>
The pressure lines are plotted horizontally in blue and are also on an 
inverse log scale.  The concept of Skew T means that the temperature is 
not plotted vertically but angles off to the right at a 45 degree angle. 
The temperature lines of the Skew T are in blue. The green lines are called 
dry adiabats. The light blue dashed lines are saturation adiabats.  The 
yellow dashed lines are lines of constant mixing ratio. </p>

<p>The sounding is plotted as two white lines. The right 
line is the temperature profile.  The left line is the dewpoint profile.</p>

<p>The winds are plotted as wind barbs with height (see 
below) on the right edge of the plot.<br/>
<img src="/upper_air/images/skew_winds.gif" height="254" width="72" alt="Skew Winds" /> 
<img src="/upper_air/images/winds_lgnd.gif" height="255" width="148" alt="Legend" /></p>

<p>The sounding also has height information plotted at the 
left, next to the pressure:<br/>
<img src="/upper_air/images/skew_hght.gif" alt="Skew_Hght" height="203" width="86" /></p>

<p>Specific sounding related parameters are plotted in the 
upper right. These values are:</p>

<table border="1">
  <tr>
     <td valign="top"><img src="/upper_air/images/skew_data.gif" height="850" width="90" alt="Skew Data" /></td>
     <td>
       <ul>
       <li><b>TP:</b> Tropopause level (mb) </li>
       <li><b>MW:</b> Max wind level (mb) </li>
       <li><b>FRZ:</b> Lowest freezing level (mb) or BG for below ground </li>
       <li><b>WB0:</b> Wet bulb zero (mb) or BG </li>
       <li><b>PW:</b> Precipitable water (in) </li>
       <li><b>RH:</b> Mean RH surface to 500 mb (%) </li>
       <li><b>MAXT:</b> Estimated max temperature (C) using a 150mb layer </li>
       <li><b>TH:</b> 1000-500mb thickness (m) </li>
       <li><b>L57:</b> 700-500mb lapse rate (C/km) </li>
       <li><b>LCL:</b> Lift condensation level (mb) from surface data </li>
       <li><b>LI:</b> Lifted index (C) using 100 mean layer above surface </li>
       <li><b>SI:</b> Showalter index (C) </li>
       <li><b>TT:</b> Total totals index </li>
       <li><b>KI:</b> K index </li>
       <li><b>SW:</b> Sweat index </li>
       <li><b>EI:</b> Energy index <br/>
       <p><b>-PARCEL- </b><br/>
       This is a parcel trajectory (the yellow line on the sounding) based 
       on 100 mb mean layer. </p>
       </li>
       <li><b>CAPE:</b> Convective available potential energy </li>
       <li><b>CINH:</b> Convective inhibition (open ended) </li>
       <li><b>LCL:</b> Lift condensation level (mb) </li>
       <li><b>CAP:</b> Cap strength (C) </li>
       <li><b>LFC:</b> Level free convection (mb) </li>
       <li><b>EL:</b> Equilibrium level (mb) </li>
       <li><b>MPL:</b> Maximum parcel level (mb) 
       <p><b>-WIND- </b><br/>
       Wind parameters</p>
       </li>
       <li><b>STM:</b> Estimated storm motion (knts) from 0-6000m AG mean layer, spd 75% of
       mean, dir 30 deg veer from mean. </li>
       <li><b>HEL:</b> Storm relative helicity 0-3000m AG (total value) </li>
       <li><b>SHR+:</b> Positive shear magnitude 0-3000m AG (sum of veering shear values) </li>
       <li><b>SRDS:</b> Storm relative directional shear 0-3000m AG (directional difference
       of storm relative winds) </li>
       <li><b>EHI:</b> Energy helicity index (prop to positive helicity * CAPE) </li>
       <li><b>BRN:</b> Bulk Richardson number 500-6000m AG (prop to CAPE/bulk shear) </li>
       <li><b>BSHR:</b> Bulk shear value (magnitude of shear over layer) </li>
       </ul>
     </td>
  </tr>
</table>

<p><img src="/upper_air/images/skew_parcel.gif" alt=" SkewT plot with parcel trajectory (solid yellow)" height="192" width="240" /><br/><i> SkewT plot with parcel trajectory (solid yellow)</i> </p>

<p>Sounding diagrams provide a important means for determining 
the stability of the atmosphere above a specific location. By using the 
concept of an air parcel, lifting it or lowering it and comparing the 
resulting parcel conditions to the conditions of the surrounding environment 
as defined by the balloon sounding. </p>

<p>Parcels of unsaturated air tend to follow the dry adiabat 
lines (green lines) as they ascend or descend. The saturation adiabats (light 
blue) lines show how parcels saturated with water vapor will ascend or 
descend. Descending parcels will tend to unsaturate immediately. The mixing 
ratio lines (yellow) relate to the amount of water vapor in a parcel in grams 
of water vapor per kilograms of dry air. Parcels of air attempt to maintain 
a constant mixing ratio as they ascend or descend. Generally, a parcel will 
rise, following the dry adiabat until it saturates. This occurs when dry 
adiabat crosses the initial mixing ratio line. This is considered the LCL. 
If lifting continues, the parcel cools following the saturation adiabat. If 
the parcel descends, it will always follow the dry adiabat as it will 
immediately unsaturate if saturated. By then comparing the parcel temperature 
to the environment, you can determine whether it is stable (parcel cooler) or
unstable (parcel warmer). An unstable parcel will accelerate upwards and is 
the primary means for thunderstorm development. A stable parcel will 
decelerate and eventually descend. This is the typical atmospheric condition 
and it the primary condition in high pressure areas. The descending air 
desaturates the atmosphere and leads to clearing skies and calm conditions. 
</p>
<div class="clearboth">&nbsp;</div>

</div>

<div id="footer"> <span id="copyright"><small>Copyright &copy; Unisys 2012</small></span>
  <ul class="inline-navigation-list" id="bottom-navigation">
    <li><a href="http://www.unisys.com/unisys/privacy.html" target="_blank">Privacy Notice</a></li>
    <li><a href="http://www.unisys.com/unisys/terms-and-conditions.html" target="_blank">Terms of Use</a></li>
    <li><a href="/contactus.php">Contact Us</a></li>
    <li><a href="http://www.unisys.com/unisys/trademarks.html" target="_blank">Trademarks</a></li>
  </ul>
</div>
</div>
</body>
</html>
