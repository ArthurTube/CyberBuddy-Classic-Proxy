<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Unisys Weather  - Surface Data Details</title>
<meta name="description" content="The intent of this weather site is to provide a complete source of graphical weather 		information. This is intended to satisfy the needs of the weather professional, but can be a tool for the casual user as well. The graphics and data are displayed as a meteorologist would expect to see. For the novice user, there are detailed explanation pages to guide them through the various plots, charts and images. The data on this site are provided from the National Weather Service via the NOAAPORT satellite data service. All the images are generated using the Weather Processor (WXP) analysis package which is available from Unisys. "/>
<meta name="keywords" content="weather, unisys, unisys weather, weather maps, maps, nam, wrf, GFS, GFSx, hurricane, radar, satellite, surface, upper air" />
<meta name="copyright" content="Unisys Corp - 2011" />
<meta name="author" content="Unisys Corporation" />
<meta name="email" content="technical-support@weather.unisys.com" />
<meta name="Distribution" content="Global" />
<meta name="Rating" content="General" />
<meta name="Robots" content="INDEX,FOLLOW" />
<meta name="Revisit-after" content="7 Days" />
<meta http-equiv="Content-type" content="text/html;charset=UTF-8" />
<meta http-equiv="imagetoolbar" content="no" />
<meta http-equiv="Refresh" content="900" />
<meta http-equiv="X-UA-Compatible" content="IE=8"/>
<link rel="stylesheet" type="text/css" href="/css/WMAX.css" />
</head>
<body>
<div id="wrap">
  <div id="top-menu">
    <ul id="top-navigation" class="inline-navigation-list">
      <li><a href="http://www.unisys.com" title="Unisys Home Page">Unisys.com</a></li>
      <li><a href="/index.php" title="Unisys Weather">Weather Home</a></li>
      <li><a href="/analyses.php" title="Analyses">Analyses</a></li>
      <li><a href="/forehome.php" title="Forecast">Forecasts</a></li>
      <li><a href="/archives.php" title="Archives">Archives</a></li>
      <li><a href="/links.php" title="NOAA Links">NOAA Links</a></li>
      <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
    </ul>
  </div>

  <div id="header"> <a href="http://unisys.com"><img src="/images/Unisys_logo.gif" alt="Unisys" /></a>
    <h1>Unisys Weather</h1>
  </div>

<div id="leftside">
  <ul class="avmenu">
    <li><a href="/index.php" class="purple">Unisys Weather</a></li>
    <li><a href="/index.php"> Weather Home</a></li>
    <li><a href="/solutions/index.php">Weather Solutions</a></li>
    <li><a href="/mobile/index.php"><img id="mobile_icon" src="/mobile/Icon.png" width="24" height="24" alt="Download Unisys Weather Mobile App"/>iPhone App</a></li>
    <li><a href="/info/index.php">Information</a></li>
    <li><a href="/content.php">Contents</a></li>
    <li><a href="/analyses.php" class="purple">Analyses</a></li>
    <li><a href="/satellite/index.php">Satellite Images</a></li>
    <li><a href="/surface/index.php">Surface Data</a></li>
    <li><a href="/upper_air/index.php">Upper Air Data</a></li>
    <li><a href="/radar/index.php">Radar Data</a></li>
    <li><a href="/forehome.php" class="purple">Forecasts</a></li>
    <li><a href="/mos/index.php">Model Statistics</a></li>
    <li><a href="/nam/index.php">NAM/Wrf Model</a></li>
    <li><a href="/gfs/index.php?r=us">GFS/Avn Model</a></li>
    <li><a href="/gfsx/index.php?r=us">GFSx/MRF Model</a></li>
    <li><a href="/rap/index.php">RAP Model</a></li>
    <li><a href="/ecmwf/index.php">ECMWF Model</a></li>
    <li><a href="/archives.php" class="purple">Archive</a></li>
    <li><a href="/hurricane/index.php">Hurricane Data</a></li>
    <li><a href="/archive/index.php">Archive of Images</a></li>
    <li><a href="/usgs/index.php">USGS Maps</a></li>
  </ul>
</div>

<div id="extras">
  <ul class="avmenu">
    <li><a href="/foresetup.php" class="purple">Get a Forecast</a></li>
  </ul>

<script type="text/javascript">
function fsubmit()
{
     document.getElementById("Forecast").submit();
}
</script>

  <form method="get" id="Forecast" action="/forecast.php">
    <p class="center"> Enter a zip code or city name to get forecast:
      <input type="text" name="Name" id="Name" size="15" />
      <br />
      <button type="submit" style="border:none; background-color:transparent;">
         <img src="/images/GO.png" id="Go" alt="Get Forecast Data" style="height:30px;" />
      </button>
      <a href="/foresetup.php"><img src="/images/setup.png" alt="Setup Location" height="30" width="70" /></a> </p>
  </form>
  <script type="text/javascript">
                <!-- HIDE
                var index = document.cookie.indexOf("ZIP")
                var zipcode = 0
                var region = ""
                if( index != -1 ){
                   //zipcode = parseInt( document.cookie.substring(index+4,index+9),10)
                   zipcode = document.cookie.substring(index+4,index+9)
                   var validateZipCode = function() {
                     var zipcodeRegexp = /^\d{5}$/;
                     var zipTest = zipcodeRegexp.test(zipcode);
   
                     if (zipTest == false) {
                       return false;
                     }
                   }
                   validateZipCode();

                    if( ! isNaN(zipcode))

                    document.getElementById('Name').value = zipcode

                   if( zipcode >= 01000 && zipcode <= 19699 )
                      region = "ne"
                   else if( zipcode >= 19700 && zipcode <= 28999 )
                      region = "at"
                   else if( zipcode >= 43000 && zipcode <= 45999 )
                      region = "at"
                   else if( zipcode >= 29000 && zipcode <= 36999 )
                      region = "se"
                   else if( zipcode >= 38600 && zipcode <= 39999 )
                      region = "se"
                   else if( zipcode >= 46000 && zipcode <= 58999 )
                      region = "mw"
                   else if( zipcode >= 60000 && zipcode <= 62999 )
                      region = "mw"
                   else if( zipcode >= 68000 && zipcode <= 69999 )
                      region = "mw"
                   else if( zipcode >= 63000 && zipcode <= 67999 )
                      region = "cp"
                   else if( zipcode >= 71600 && zipcode <= 74999 )
                      region = "cp"
                   else if( zipcode >= 70000 && zipcode <= 71499 )
                      region = "sp"
                   else if( zipcode >= 75000 && zipcode <= 79999 )
                      region = "sp"
                   else if( zipcode >= 59000 && zipcode <= 59999 )
                      region = "nw"
                   else if( zipcode >= 82000 && zipcode <= 83999 )
                      region = "nw"
                   else if( zipcode >= 97000 && zipcode <= 99499 )
                      region = "nw"
                   else if( zipcode >= 80000 && zipcode <= 81999 )
                      region = "sw"
                   else if( zipcode >= 84000 && zipcode <= 96199 )
                      region = "sw"

                   if( region != "" ){
                      document.write( "<table border=\"0\" align=\"center\" class=\"grey\" width=\"100%\">" )
                      document.write( "<tr>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/surface/sfc_map.php?image=sfc&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Sfc" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=\"radar/rad" + region + ".php\">" )
                      document.write( "<a href=/radar/rcm_rad.php?image=rad&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Rad" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=vis&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Vis" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=enh&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>IR" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "</tr></table>" )
                      document.write( "</b>" )
                      }


                   
                   }
                // UNHIDE -->
                </script>
  <ul class="avmenu">
    <li><a href="/links.php" class="purple">NOAA Links</a></li>
    <li><a href="http://lwf.ncdc.noaa.gov/">National Climatic Data Center</a></li>
    <li><a href="http://www.cpc.noaa.gov/">Climate Prediction Center</a></li>
    <li><a href="http://oceanservice.noaa.gov/">National Ocean Service</a></li>
    <li><a href="http://www.lib.noaa.gov/">NOAA Library</a></li>
    <li><a href="http://www.oar.noaa.gov/">NOAA Office of Oceanic and Atmospheric Research</a></li>
    <li><a href="http://www.esrl.noaa.gov/">Earth Systems Research Laboratory</a></li>
    <li><a href="/overview.php" class="purple">About Us</a></li>
    <li><a href="/overview.php" title="Contact Us">Overview</a></li>
    <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
  </ul>
</div>
<div id="content">

<h2>Surface Data Details</h2>
<p>Surface data is reported hourly from places like airports 
and automated observing platforms. The types of plots using surface data 
include a composite surface map, weather depiction for aviation, regional 
plots for the US, Canada, Mexico and Alaska.  Contoured analyses of various 
parameters including temperature and pressure. Finaly, there are meteograms 
which are time cross-sections for individual cities. These data are updated
hourly at around 30 minutes past the hour. </p>

<hr width="99%"/>
<a name="sfc_map"></a><h3>Composite Surface Map</h3>

<p><img src="/surface/images/sfc_map_sample.gif" alt="Sample_surface_map" border="0" height="262" width="362" /><br/><i>Sample_surface_map</i></p>

<p>The composite surface map portrays as much information 
about surface weather conditions as possible. This composite map contain 
the following analyses: <br/>
<a href="#radar"> <b> Radar summary</b></a> (color filled/stippled areas), <br/>
<a href="#surface"> <b> Surface data plot</b></a> (composite station model), <br/>
<a href="#fronts"> <b> Frontal locations</b></a> (in various bold lines) and <br/>
<a href="#press"> <b> Pressure contours</b></a> (in thin blue lines). </p>

<a name="radar"></a><h3>Radar Summary Plot</h3>

<p>The radar summary displays areas where precipitation is 
falling based on returns from a weather radar. The intensity is based on color 
where: <br/>
<img src="/radar/images/radar_lgnd.gif" alt="Radar Legend" height="103" width="148" /> </p>

<table bgcolor="gray" border="1">
  <tr>
    <td><b>Color</b></td>
    <td><b>Intensity</b></td>
    <td><b>Description</b></td>
  </tr>
  <tr>
    <td><b>Blue</b></td>
    <td>Light</td>
    <td>light rain or snow</td>
  </tr>
  <tr>
    <td><b>Cyan</b></td>
    <td>Moderate</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td><b>Green</b></td>
    <td>Heavy</td>
    <td>light thunderstorms/moderate rain showers</td>
  </tr>
  <tr>
    <td><b>Yellow</b></td>
    <td>Very Heavy</td>
    <td>moderate thunderstorms</td>
  </tr>
  <tr>
    <td><b>Red</b></td>
    <td>Intense</td>
    <td>potential flooding rains/severe thunderstorms</td>
  </tr>
  <tr>
    <td><b>Magenta</b></td>
    <td>Extreme</td>
    <td>flooding rains</td>
  </tr>
</table>

<a name="surface"></a><h3>Surface Data Plot</h3>

<p>The surface data plot gives the following information: <br/>
<img src="/images/sfc_plot_lgnd.gif" height="88" width="358" alt="Legend" /></p>

<table bgcolor="gray" border="1">
  <tr>
    <td><b>Data</b></td>
    <td><b>Description</b></td>
  </tr>
  <tr>
    <td>temperature (F)</td>
    <td>plotted upper left</td>
  </tr>
  <tr>
    <td>present weather</td>
    <td>symbol plotted center left (see below)</td>
  </tr>
  <tr>
    <td>dewpoint (F)</td>
    <td>plotted lower left</td>
  </tr>
  <tr>
    <td>pressure (.1 mb-coded)</td>
    <td>plotted upper right as last 3 digits (987=998.7mb, 024=1002.4mb)</td>
  </tr>
  <tr>
    <td>cloud cover</td>
    <td>center circle. white fill indicates % cloud coverage (see below)</td>
  </tr>
  <tr>
    <td>winds</td>
    <td>wind barb (see below)</td>
  </tr>
</table>

<a name="symbols"></a><h3>Weather Symbols</h3>

<p><img src="/images/weather_lgnd.gif" height="210" width="484" alt="Legend" /> </p>

<p><img src="/images/cloud_lgnd.gif" height="248" width="123" alt="Legend" />&nbsp;
<img src="/images/winds_lgnd.gif" height="255" width="148" alt="Legend" /></p>

<a name="fronts"></a><h3>Frontal Location Plot</h3>

<p>Frontal locations are denoted by bold lines in the following colors: <br/>
<img src="/surface/images/sfc_front_sample.gif" height="105" width="168" alt="Legend" />&nbsp;
<img src="/images/front_lgnd.gif" height="98" width="148" alt="Legend" /></p>

<p>High and Low pressure systems are plotted with <b>
H</b> and <b>L</b> and the associated pressure in millibars is 
displayed below the letter. </p>

<p><b>NOTE:</b> Frontal data are only available every 
3 hours so fronts may not exactly match the weather conditions. A label at 
the bottom left denotes what time the fronts are valid. </p>

<a name="press"></a><h3>Pressure/Isobar Contours</h3>

<p>The pressure contours (or isobars) are plotted as blue 
lines every 4 millibars and indicate positioning and extent of various 
pressure systems. </p>

<hr width="99%" />

<a name="depict"></a><h3>Surface Weather Depiction</h3>

<p><img src="/surface/images/sfc_depict_sample.gif" alt="Sample depiction" height="236" width="361" /><br/><i>Sample depiction</i></p>

<p>The weather depiction chart is a composite chart aimed 
at aviation.  The data plotted are: </p>

<p>
<a href="#rule"> <b> Flight rule depiction</b></a> (color filled/hatched
areas), <br/>
<a href="#depict_data"> <b> Depiction data plot</b></a> (composite model), <br/>
<a href="#fronts"> <b> Frontal locations</b></a> (in various bold lines) </p>

<a name="rule"></a><h4>Flight Rule Depiction</h4>

<p>Shaded and hatched areas represent current flight 
rules: </p>
<table bgcolor="gray" border="1">
  <tr>
    <td><b>Plotted</b></td>
    <td><b>Rules</b></td>
    <td><b>Comments</b></td>
  </tr>
  <tr>
    <td>gray solid</td>
    <td>IFR</td>
    <td>Ceiling &lt; 1000 ft or Visibility &lt; 3 miles</td>
  </tr>
  <tr>
    <td>gray hatched</td>
    <td>MVFR</td>
    <td>Ceiling &lt; 3000 ft or Visibility &lt; 5 miles</td>
  </tr>
  <tr>
    <td>clear/black</td>
    <td>VFR</td>
    <td>Not IFR or MVFR</td>
  </tr>
</table>

<a name="depict_data"></a><h4>Depiction Data Plot</h4>

<table bgcolor="gray" border="1">
  <tr>
    <td><b>Data</b></td>
    <td><b>Description</b></td>
  </tr>
  <tr>
    <td>cloud cover</td>
    <td>center circle. white fill indicates % cloud coverage (see symbols above)</td>
  </tr>
  <tr>
    <td>present weather</td>
    <td>symbol left center (see symbols above)</td>
  </tr>
  <tr>
    <td>cloud ceiling</td>
    <td>below (in 100s feet)</td>
  </tr>
</table>

<p>
<a href="#symbols"> <b> Weather Symbols</b></a> </p>

<a name="front"></a><h4>Frontal Location</h4>

<p>The frontal analysis is also added to aid in determining general 
weather conditions. <br/>
<a href="#fronts"> <b> Fronts</b></a> </p>

<hr width="99%" />

<a name="front_plot"></a><h3>Frontal Location</h3>

<p>Plot of frontal locations for most of North America. Frontal locations 
are denoted by bold lines in the following colors: </p>

<p><img src="/surface/images/sfc_front_sample.gif" height="105" width="168" alt="Sample" />&nbsp;
<img src="/images/front_lgnd.gif" height="98" width="148" alt="Legend" /> </p>

<p>High and Low pressure systems are plotted with 
<b>H</b> and <b>L</b> and the associated pressure in millibars 
is displayed below the letter. </p>

<hr width="99%"/>

<a name="regional"></a><h3>Regional Data Plots</h3>

<p><img src="/surface/images/sfc_reg_sample.gif" alt="Sample regional plot" height="199" width="292" /><br/><i>Sample regional plot</i> </p>

<p>These are simple data plots for various regions of the 
US, Canada and Mexico. The information plotted is using the surface station 
plot. <br/>
<a href="#surface"> <b> Surface Data Plot</b></a> </p>

<hr width="99%"/>

<a name="contour"></a><h3>Contour Plots</h3>

<p><a name="con_temp"></a><b>US Temperature Contour</b> <br/>
Contour plot of temperatures (F) for the contiguous US. </p>

<p><a name="con_temp_na"></a><b>North America Temperature Contour</b><br/>
Contour plot of temperatures (F) for North America. </p>

<p><a name="con_24temp"></a><b>24 hour Temperature Change</b><br/>
Contour plot of the temperature change from current hour to the same hour 
the previous day for the contiguous US. Areas below 0 represent where the 
temperatures are currently colder and reflect the passage of a cold front. 
Areas above 0 represent where the temperatures are warmer and often reflect 
the passage of a warm front. </p>

<p><a name="con_wchill"></a><b>US Wind Chill Contour</b><br/>
Contour plot of wind chill temperatures (F) for the contiguous US. The wind 
chill is the effective temperature of the skin from heat loss due to winds at 
cold temperatures. Wind chill temperatures less than -20F are considered low, 
temperatures less than -40F are extreme and temperatures less than -60F are 
considered dangerous. </p>

<p><a name="con_heat"></a><b>US Heat Index Contour</b><br/>
Contour plot of heat index temperatures (F) for the contiguous US. The heat 
index is the effective temperature of the skin due to the inhibiting effect 
of humidity to allow the body to cool through sweating and evaporation. 
Heat index values of greater than 90F are considered high, index values 
greater than 100F are extreme and index values greater than 110F are 
considered dangerous. </p>

<p><a name="con_pres"></a><b>US Pressure Contour</b><br/>
Contour plot of sea level pressure (mb) for the contiguous US. The maximum 
and minimum values reflect the location of high and low pressure systems. </p>

<p><a name="con_3pres"></a><b>3 hour Pressure Change</b><br/>
Contour plot of the change in pressure from the current hour to 3 hours 
previous for the contiguous US. This is a good indicator of the movement 
and intensification of pressure systems. If the pressure change is negative 
in the region of a low pressure system (see above chart), the low is 
deepening. If the negative pressure change is out in front of the low 
pressure system, it indicates movement. The location of the maximum pressure
drops indicate the possible direction of the low pressure system. </p>

<p><a name="con_dewp"></a><b>US Dewpoint Contour</b><br/>
Contour plot of the dewpoint temperature (F) for the contiguous US. The 
dewpoint temperature indicates the amount of moisture (or humidity) in the 
atmosphere. The amount of moisture in the atmosphere can affect how you feel 
and is used in the heat index computation (see above). Dewpoints above 65 
reflect humid conditions. Summer dewpoints can reach the low 80s. Dewpoints 
above 50 mean that there is enough moisture in the atmosphere to generate 
thunderstorms. The higher the dewpoint, the easier storms form and the 
more potent they can become. An additional factor of low level wind 
convergence is also needed to help storms form (see below). Intense storms 
can form at dewpoints of 55 if the right conditions are in place including 
high convergence values. </p>

<p><a name="con_qconv"></a><b>US Moisture Convergence</b><br/>
Contour plot of the convergence of surface winds weighted by the moisture 
in the atmosphere represented by the surface specific humidity. Positive 
areas represent where winds are converging and thus forcing upward motion. 
Negative areas often reflect the presence of sinking motion. Since this is 
weighted by the moisture, high values of convergence can often represent 
areas where forced convection (possible thunderstorms) may occur. </p>

<div class="clearboth">&nbsp;</div>

</div>

<div id="footer"> <span id="copyright"><small>Copyright &copy; Unisys 2012</small></span>
  <ul class="inline-navigation-list" id="bottom-navigation">
    <li><a href="http://www.unisys.com/unisys/privacy.html" target="_blank">Privacy Notice</a></li>
    <li><a href="http://www.unisys.com/unisys/terms-and-conditions.html" target="_blank">Terms of Use</a></li>
    <li><a href="/contactus.php">Contact Us</a></li>
    <li><a href="http://www.unisys.com/unisys/trademarks.html" target="_blank">Trademarks</a></li>
  </ul>
</div>
</div>
</body>
</html>
