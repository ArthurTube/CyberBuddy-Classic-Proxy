<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Unisys Weather </title>
<meta name="description" content="The intent of this weather site is to provide a complete source of graphical weather 		information. This is intended to satisfy the needs of the weather professional, but can be a tool for the casual user as well. The graphics and data are displayed as a meteorologist would expect to see. For the novice user, there are detailed explanation pages to guide them through the various plots, charts and images. The data on this site are provided from the National Weather Service via the NOAAPORT satellite data service. All the images are generated using the Weather Processor (WXP) analysis package which is available from Unisys. "/>
<meta name="keywords" content="weather, unisys, unisys weather, weather maps, maps, nam, wrf, GFS, GFSx, hurricane, radar, satellite, surface, upper air" />
<meta name="copyright" content="Unisys Corp - 2011" />
<meta name="author" content="Unisys Corporation" />
<meta name="email" content="technical-support@weather.unisys.com" />
<meta name="Distribution" content="Global" />
<meta name="Rating" content="General" />
<meta name="Robots" content="INDEX,FOLLOW" />
<meta name="Revisit-after" content="7 Days" />
<meta http-equiv="Content-type" content="text/html;charset=UTF-8" />
<meta http-equiv="imagetoolbar" content="no" />
<meta http-equiv="Refresh" content="900" />
<meta http-equiv="X-UA-Compatible" content="IE=8"/>
<link rel="stylesheet" type="text/css" href="/css/WMAX.css" />
</head>
<body>
<div id="wrap">
  <div id="top-menu">
    <ul id="top-navigation" class="inline-navigation-list">
      <li><a href="http://www.unisys.com" title="Unisys Home Page">Unisys.com</a></li>
      <li><a href="/index.php" title="Unisys Weather">Weather Home</a></li>
      <li><a href="/analyses.php" title="Analyses">Analyses</a></li>
      <li><a href="/forehome.php" title="Forecast">Forecasts</a></li>
      <li><a href="/archives.php" title="Archives">Archives</a></li>
      <li><a href="/links.php" title="NOAA Links">NOAA Links</a></li>
      <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
    </ul>
  </div>

  <div id="header"> <a href="http://unisys.com"><img src="/images/Unisys_logo.gif" alt="Unisys" /></a>
    <h1>Unisys Weather</h1>
  </div>

<div id="leftside">
  <ul class="avmenu">
    <li><a href="/index.php" class="purple">Unisys Weather</a></li>
    <li><a href="/index.php"> Weather Home</a></li>
    <li><a href="/solutions/index.php">Weather Solutions</a></li>
    <li><a href="/mobile/index.php"><img id="mobile_icon" src="/mobile/Icon.png" width="24" height="24" alt="Download Unisys Weather Mobile App"/>iPhone App</a></li>
    <li><a href="/info/index.php">Information</a></li>
    <li><a href="/content.php">Contents</a></li>
    <li><a href="/analyses.php" class="purple">Analyses</a></li>
    <li><a href="/satellite/index.php">Satellite Images</a></li>
    <li><a href="/surface/index.php">Surface Data</a></li>
    <li><a href="/upper_air/index.php">Upper Air Data</a></li>
    <li><a href="/radar/index.php">Radar Data</a></li>
    <li><a href="/forehome.php" class="purple">Forecasts</a></li>
    <li><a href="/mos/index.php">Model Statistics</a></li>
    <li><a href="/nam/index.php">NAM/Wrf Model</a></li>
    <li><a href="/gfs/index.php?r=us">GFS/Avn Model</a></li>
    <li><a href="/gfsx/index.php?r=us">GFSx/MRF Model</a></li>
    <li><a href="/rap/index.php">RAP Model</a></li>
    <li><a href="/ecmwf/index.php">ECMWF Model</a></li>
    <li><a href="/archives.php" class="purple">Archive</a></li>
    <li><a href="/hurricane/index.php">Hurricane Data</a></li>
    <li><a href="/archive/index.php">Archive of Images</a></li>
    <li><a href="/usgs/index.php">USGS Maps</a></li>
  </ul>
</div>

<div id="extras">
  <ul class="avmenu">
    <li><a href="/foresetup.php" class="purple">Get a Forecast</a></li>
  </ul>

<script type="text/javascript">
function fsubmit()
{
     document.getElementById("Forecast").submit();
}
</script>

  <form method="get" id="Forecast" action="/forecast.php">
    <p class="center"> Enter a zip code or city name to get forecast:
      <input type="text" name="Name" id="Name" size="15" />
      <br />
      <button type="submit" style="border:none; background-color:transparent;">
         <img src="/images/GO.png" id="Go" alt="Get Forecast Data" style="height:30px;" />
      </button>
      <a href="/foresetup.php"><img src="/images/setup.png" alt="Setup Location" height="30" width="70" /></a> </p>
  </form>
  <script type="text/javascript">
                <!-- HIDE
                var index = document.cookie.indexOf("ZIP")
                var zipcode = 0
                var region = ""
                if( index != -1 ){
                   //zipcode = parseInt( document.cookie.substring(index+4,index+9),10)
                   zipcode = document.cookie.substring(index+4,index+9)
                   var validateZipCode = function() {
                     var zipcodeRegexp = /^\d{5}$/;
                     var zipTest = zipcodeRegexp.test(zipcode);
   
                     if (zipTest == false) {
                       return false;
                     }
                   }
                   validateZipCode();

                    if( ! isNaN(zipcode))

                    document.getElementById('Name').value = zipcode

                   if( zipcode >= 01000 && zipcode <= 19699 )
                      region = "ne"
                   else if( zipcode >= 19700 && zipcode <= 28999 )
                      region = "at"
                   else if( zipcode >= 43000 && zipcode <= 45999 )
                      region = "at"
                   else if( zipcode >= 29000 && zipcode <= 36999 )
                      region = "se"
                   else if( zipcode >= 38600 && zipcode <= 39999 )
                      region = "se"
                   else if( zipcode >= 46000 && zipcode <= 58999 )
                      region = "mw"
                   else if( zipcode >= 60000 && zipcode <= 62999 )
                      region = "mw"
                   else if( zipcode >= 68000 && zipcode <= 69999 )
                      region = "mw"
                   else if( zipcode >= 63000 && zipcode <= 67999 )
                      region = "cp"
                   else if( zipcode >= 71600 && zipcode <= 74999 )
                      region = "cp"
                   else if( zipcode >= 70000 && zipcode <= 71499 )
                      region = "sp"
                   else if( zipcode >= 75000 && zipcode <= 79999 )
                      region = "sp"
                   else if( zipcode >= 59000 && zipcode <= 59999 )
                      region = "nw"
                   else if( zipcode >= 82000 && zipcode <= 83999 )
                      region = "nw"
                   else if( zipcode >= 97000 && zipcode <= 99499 )
                      region = "nw"
                   else if( zipcode >= 80000 && zipcode <= 81999 )
                      region = "sw"
                   else if( zipcode >= 84000 && zipcode <= 96199 )
                      region = "sw"

                   if( region != "" ){
                      document.write( "<table border=\"0\" align=\"center\" class=\"grey\" width=\"100%\">" )
                      document.write( "<tr>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/surface/sfc_map.php?image=sfc&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Sfc" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=\"radar/rad" + region + ".php\">" )
                      document.write( "<a href=/radar/rcm_rad.php?image=rad&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Rad" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=vis&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Vis" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=enh&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>IR" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "</tr></table>" )
                      document.write( "</b>" )
                      }


                   
                   }
                // UNHIDE -->
                </script>
  <ul class="avmenu">
    <li><a href="/links.php" class="purple">NOAA Links</a></li>
    <li><a href="http://lwf.ncdc.noaa.gov/">National Climatic Data Center</a></li>
    <li><a href="http://www.cpc.noaa.gov/">Climate Prediction Center</a></li>
    <li><a href="http://oceanservice.noaa.gov/">National Ocean Service</a></li>
    <li><a href="http://www.lib.noaa.gov/">NOAA Library</a></li>
    <li><a href="http://www.oar.noaa.gov/">NOAA Office of Oceanic and Atmospheric Research</a></li>
    <li><a href="http://www.esrl.noaa.gov/">Earth Systems Research Laboratory</a></li>
    <li><a href="/overview.php" class="purple">About Us</a></li>
    <li><a href="/overview.php" title="Contact Us">Overview</a></li>
    <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
  </ul>
</div>
<div id="content">

  <h2>Analyses Pages</h2>
  <ul class="nobullet">
    <li><a href="/satellite/index.php" class="purple">Satellite</a></li>
    <li>
      <ul class="nobullet">
        <li><a href="/satellite/visible.php" class="red"> Visible Images</a> - Images selectable by region including loop</li>
        <li><a href="/satellite/infrared.php" class="red"> Infrared Images</a> - Images selectable by region including loop</li>
        <li><a href="/satellite/infrared_enh.php" class="red"> Enhanced Infrared Images</a> - Images selectable by region including loop</li>
        <li><a href="/satellite/water_vapor.php" class="red"> Water Vapor Images</a> - Images selectable by region including loop</li>
        <li><a href="/satellite/composite.php" class="red"> Composite Images</a></li>
        <li>
          <ul>
            <li><a href="/satellite/sat_sfc.php?inv=0&t=cur"> Satellite Surface Map</a> - IR Satellite + Surface Map</li>
            <li><a href="/satellite/sat_rad.php?inv=0&t=cur"> IR Satellite and Radar Map</a></li>
          </ul>
        </li>
      </ul>
    </li>
    <li><a href="/surface/index.php" class="purple"> Surface</a></li>
    <li>
      <ul class="nobullet">
        <li><a href="/surface/composite.php" class="red"> Composite Maps</a></li>
        <li>
          <ul>
            <li><a href="/surface/sfc_map.php?inv=0&t=cur&region=us"> Surface Map</a></li>
            <li><a href="/surface/sfc_depict.php?inv=0&t=cur"> Weather Depiction</a> - Aviation weather chart (IFR, VFR)</li>
            <li><a href="/surface/sfc_fronts.php?inv=0&t=cur"> Fronts</a> - Current frontal positions</li>
          </ul>
        </li>
        <li><a href="/surface/regional.php" class="red"> Regional Data Plots</a> - Surface (station model) plots by region</li>
        <li><a href="/surface/contour.php" class="red"> Contour Plots</a></li>
        <li>
          <ul>
            <li><a href="/surface/sfc_con.php?image=te&inv=0&t=cur"> US Temperature</a></li>
            <li><a href="/surface/sfc_con.php?image=na&inv=0&t=cur"> N Amer Temperature</a></li>
            <li><a href="/surface/sfc_con.php?image=24&inv=0&t=cur"> US 24 hr Temperature Change</a></li>
            <li><a href="/surface/sfc_con.php?image=wc&inv=0&t=cur"> US Wind Chill</a></li>
            <li><a href="/surface/sfc_con.php?image=he&inv=0&t=cur"> US Heat Index</a></li>
            <li><a href="/surface/sfc_con.php?image=pr&inv=0&t=cur"> US SL Pressure</a></li>
            <li><a href="/surface/sfc_con.php?image=3p&inv=0&t=cur"> US 3 hr Pressure Change</a></li>
            <li><a href="/surface/sfc_con.php?image=de&inv=0&t=cur"> US Dewpoint</a></li>
            <li><a href="/surface/sfc_con.php?image=ws&inv=0&t=cur"> US Wind Speed</a></li>
            <li><a href="/surface/sfc_con.php?image=st&inv=0&t=cur"> US Wind Streamlines</a></li>
            <li><a href="/surface/sfc_con.php?image=qc&inv=0&t=cur"> US Moisture Convergence</a></li>
          </ul>
        </li>
        <li><a href="/surface/daily.php" class="red"> Daily Plots</a></li>
        <li>
          <ul>
            <li><a href="/surface/sfc_daily.php?plot=htp&inv=0&t=cur"> US High Temperature</a></li>
            <li><a href="/surface/sfc_daily.php?plot=ltp&inv=0&t=cur"> US Low Temperature</a></li>
            <li><a href="/surface/sfc_daily.php?plot=24p&inv=0&t=cur"> US Daily Precipitation</a></li>
            <li><a href="/surface/sfc_daily.php?plot=mop&inv=0&t=cur"> US Monthly Precipitation</a> - Precipitation for the month so far</li>
            <li><a href="/surface/sfc_daily.php?plot=snc&inv=0&t=cur"> US Snow Cover</a></li>
            <li><a href="/surface/sfc_daily.php?plot=ssd&inv=0&t=cur"> SST Plot</a> - Sea Surface Temperatures</li>
            <li><a href="/surface/sfc_daily.php?plot=ssa&inv=0&t=cur"> SST Anomaly</a> - SST temperature anomalies</li>
          </ul>
        </li>
        <li><a href="/surface/meteogram/index.php" class="red"> Surface Meteograms</a> - Time series plots for specific stations of temperature, pressure, winds, weather. Plots selectable by city.</li>
      </ul>
    </li>
    <li><a href="/upper_air/index.php" class="purple"> Upper Air</a></li>
    <li>
      <ul class="nobullet">
        <li><a href="/upper_air/mandatory.php" class="red"> Mandatory Level Plots</a> - Plots at various pressure levels</li>
        <li><a href="/upper_air/height.php" class="red"> Constant Height Plots</a> - Plots at various height levels</li>
        <li><a href="/upper_air/hemisphere.php" class="red"> Hemispheric Plots</a> - Hemisphere plots of 500mb height/SL pressure, 850mb heights/temperatures, 300mb winds/heights.</li>
        <li><a href="/upper_air/contour.php" class="red"> Contour Plots</a></li>
        <li>
          <ul>
            <li><a href="/upper_air/ua_cont.php?plot=500&inv=0&t=cur"> 500mb Height</a></li>
            <li><a href="/upper_air/ua_cont.php?plot=850&inv=0&t=cur"> 850mb Temperature</a></li>
            <li><a href="/upper_air/ua_cont.php?plot=thi&inv=0&t=cur"> 1000-500mb Thickness</a></li>
            <li><a href="/upper_air/ua_cont.php?plot=300&inv=0&t=cur"> 300mb Wind Speed</a></li>
            <li><a href="/upper_air/ua_cont.php?plot=str&inv=0&t=cur"> 300mb Streamlines</a></li>
            <li><a href="/upper_air/ua_cont.php?plot=pre&inv=0&t=cur"> Precipitable Water</a></li>
            <li><a href="/upper_air/ua_cont.php?plot=lif&inv=0&t=cur"> Lifted Index</a> - Stability index</li>
            <li><a href="/upper_air/ua_cont.php?plot=tt&inv=0&t=cur"> Total Totals Index</a></li>
            <li><a href="/upper_air/ua_cont.php?plot=ki&inv=0&t=cur"> K Index</a></li>
            <li><a href="/upper_air/ua_cont.php?plot=cap&inv=0&t=cur"> CAPE</a> - Convective Available Potential Energy</li>
            <li><a href="/upper_air/ua_cont.php?plot=hel&inv=0&t=cur"> Helicity</a></li>
          </ul>
        </li>
        <li><a href="/upper_air/skew/index.php" class="red"> Sounding Plots (SkewT)</a> - Upper air sounding plot (temperature vs height). Plots selectable by site/city.</li>
      </ul>
    </li>
    <li><a href="/radar/index.php" class="purple"> Radar</a></li>
    <li>
      <ul class="nobullet">
        <li><a href="/radar/rcm_rad.php?inv=0&t=cur&region=us" class="red"> RCM Plots</a> - (Radar Coded Messages) A radar mosaic based on RCM site radar data. Plots selectable by region including loop.</li>
      </ul>
    </li>
  </ul>
<div class="clearboth">&nbsp;</div>

</div>

<div id="footer"> <span id="copyright"><small>Copyright &copy; Unisys 2012</small></span>
  <ul class="inline-navigation-list" id="bottom-navigation">
    <li><a href="http://www.unisys.com/unisys/privacy.html" target="_blank">Privacy Notice</a></li>
    <li><a href="http://www.unisys.com/unisys/terms-and-conditions.html" target="_blank">Terms of Use</a></li>
    <li><a href="/contactus.php">Contact Us</a></li>
    <li><a href="http://www.unisys.com/unisys/trademarks.html" target="_blank">Trademarks</a></li>
  </ul>
</div>
</div>
</body>
</html>
