<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Unisys Weather </title>
<meta name="description" content="The intent of this weather site is to provide a complete source of graphical weather 		information. This is intended to satisfy the needs of the weather professional, but can be a tool for the casual user as well. The graphics and data are displayed as a meteorologist would expect to see. For the novice user, there are detailed explanation pages to guide them through the various plots, charts and images. The data on this site are provided from the National Weather Service via the NOAAPORT satellite data service. All the images are generated using the Weather Processor (WXP) analysis package which is available from Unisys. "/>
<meta name="keywords" content="weather, unisys, unisys weather, weather maps, maps, nam, wrf, GFS, GFSx, hurricane, radar, satellite, surface, upper air" />
<meta name="copyright" content="Unisys Corp - 2011" />
<meta name="author" content="Unisys Corporation" />
<meta name="email" content="technical-support@weather.unisys.com" />
<meta name="Distribution" content="Global" />
<meta name="Rating" content="General" />
<meta name="Robots" content="INDEX,FOLLOW" />
<meta name="Revisit-after" content="7 Days" />
<meta http-equiv="Content-type" content="text/html;charset=UTF-8" />
<meta http-equiv="imagetoolbar" content="no" />
<meta http-equiv="Refresh" content="900" />
<meta http-equiv="X-UA-Compatible" content="IE=8"/>
<link rel="stylesheet" type="text/css" href="/css/WMAX.css" />
</head>
<body>
<div id="wrap">
  <div id="top-menu">
    <ul id="top-navigation" class="inline-navigation-list">
      <li><a href="http://www.unisys.com" title="Unisys Home Page">Unisys.com</a></li>
      <li><a href="/index.php" title="Unisys Weather">Weather Home</a></li>
      <li><a href="/analyses.php" title="Analyses">Analyses</a></li>
      <li><a href="/forehome.php" title="Forecast">Forecasts</a></li>
      <li><a href="/archives.php" title="Archives">Archives</a></li>
      <li><a href="/links.php" title="NOAA Links">NOAA Links</a></li>
      <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
    </ul>
  </div>

  <div id="header"> <a href="http://unisys.com"><img src="/images/Unisys_logo.gif" alt="Unisys" /></a>
    <h1>Unisys Weather</h1>
  </div>

<div id="leftside">
  <ul class="avmenu">
    <li><a href="/index.php" class="purple">Unisys Weather</a></li>
    <li><a href="/index.php"> Weather Home</a></li>
    <li><a href="/solutions/index.php">Weather Solutions</a></li>
    <li><a href="/mobile/index.php"><img id="mobile_icon" src="/mobile/Icon.png" width="24" height="24" alt="Download Unisys Weather Mobile App"/>iPhone App</a></li>
    <li><a href="/info/index.php">Information</a></li>
    <li><a href="/content.php">Contents</a></li>
    <li><a href="/analyses.php" class="purple">Analyses</a></li>
    <li><a href="/satellite/index.php">Satellite Images</a></li>
    <li><a href="/surface/index.php">Surface Data</a></li>
    <li><a href="/upper_air/index.php">Upper Air Data</a></li>
    <li><a href="/radar/index.php">Radar Data</a></li>
    <li><a href="/forehome.php" class="purple">Forecasts</a></li>
    <li><a href="/mos/index.php">Model Statistics</a></li>
    <li><a href="/nam/index.php">NAM/Wrf Model</a></li>
    <li><a href="/gfs/index.php?r=us">GFS/Avn Model</a></li>
    <li><a href="/gfsx/index.php?r=us">GFSx/MRF Model</a></li>
    <li><a href="/rap/index.php">RAP Model</a></li>
    <li><a href="/ecmwf/index.php">ECMWF Model</a></li>
    <li><a href="/archives.php" class="purple">Archive</a></li>
    <li><a href="/hurricane/index.php">Hurricane Data</a></li>
    <li><a href="/archive/index.php">Archive of Images</a></li>
    <li><a href="/usgs/index.php">USGS Maps</a></li>
  </ul>
</div>

<div id="extras">
  <ul class="avmenu">
    <li><a href="/foresetup.php" class="purple">Get a Forecast</a></li>
  </ul>

<script type="text/javascript">
function fsubmit()
{
     document.getElementById("Forecast").submit();
}
</script>

  <form method="get" id="Forecast" action="/forecast.php">
    <p class="center"> Enter a zip code or city name to get forecast:
      <input type="text" name="Name" id="Name" size="15" />
      <br />
      <button type="submit" style="border:none; background-color:transparent;">
         <img src="/images/GO.png" id="Go" alt="Get Forecast Data" style="height:30px;" />
      </button>
      <a href="/foresetup.php"><img src="/images/setup.png" alt="Setup Location" height="30" width="70" /></a> </p>
  </form>
  <script type="text/javascript">
                <!-- HIDE
                var index = document.cookie.indexOf("ZIP")
                var zipcode = 0
                var region = ""
                if( index != -1 ){
                   //zipcode = parseInt( document.cookie.substring(index+4,index+9),10)
                   zipcode = document.cookie.substring(index+4,index+9)
                   var validateZipCode = function() {
                     var zipcodeRegexp = /^\d{5}$/;
                     var zipTest = zipcodeRegexp.test(zipcode);
   
                     if (zipTest == false) {
                       return false;
                     }
                   }
                   validateZipCode();

                    if( ! isNaN(zipcode))

                    document.getElementById('Name').value = zipcode

                   if( zipcode >= 01000 && zipcode <= 19699 )
                      region = "ne"
                   else if( zipcode >= 19700 && zipcode <= 28999 )
                      region = "at"
                   else if( zipcode >= 43000 && zipcode <= 45999 )
                      region = "at"
                   else if( zipcode >= 29000 && zipcode <= 36999 )
                      region = "se"
                   else if( zipcode >= 38600 && zipcode <= 39999 )
                      region = "se"
                   else if( zipcode >= 46000 && zipcode <= 58999 )
                      region = "mw"
                   else if( zipcode >= 60000 && zipcode <= 62999 )
                      region = "mw"
                   else if( zipcode >= 68000 && zipcode <= 69999 )
                      region = "mw"
                   else if( zipcode >= 63000 && zipcode <= 67999 )
                      region = "cp"
                   else if( zipcode >= 71600 && zipcode <= 74999 )
                      region = "cp"
                   else if( zipcode >= 70000 && zipcode <= 71499 )
                      region = "sp"
                   else if( zipcode >= 75000 && zipcode <= 79999 )
                      region = "sp"
                   else if( zipcode >= 59000 && zipcode <= 59999 )
                      region = "nw"
                   else if( zipcode >= 82000 && zipcode <= 83999 )
                      region = "nw"
                   else if( zipcode >= 97000 && zipcode <= 99499 )
                      region = "nw"
                   else if( zipcode >= 80000 && zipcode <= 81999 )
                      region = "sw"
                   else if( zipcode >= 84000 && zipcode <= 96199 )
                      region = "sw"

                   if( region != "" ){
                      document.write( "<table border=\"0\" align=\"center\" class=\"grey\" width=\"100%\">" )
                      document.write( "<tr>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/surface/sfc_map.php?image=sfc&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Sfc" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=\"radar/rad" + region + ".php\">" )
                      document.write( "<a href=/radar/rcm_rad.php?image=rad&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Rad" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=vis&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Vis" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=enh&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>IR" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "</tr></table>" )
                      document.write( "</b>" )
                      }


                   
                   }
                // UNHIDE -->
                </script>
  <ul class="avmenu">
    <li><a href="/links.php" class="purple">NOAA Links</a></li>
    <li><a href="http://lwf.ncdc.noaa.gov/">National Climatic Data Center</a></li>
    <li><a href="http://www.cpc.noaa.gov/">Climate Prediction Center</a></li>
    <li><a href="http://oceanservice.noaa.gov/">National Ocean Service</a></li>
    <li><a href="http://www.lib.noaa.gov/">NOAA Library</a></li>
    <li><a href="http://www.oar.noaa.gov/">NOAA Office of Oceanic and Atmospheric Research</a></li>
    <li><a href="http://www.esrl.noaa.gov/">Earth Systems Research Laboratory</a></li>
    <li><a href="/overview.php" class="purple">About Us</a></li>
    <li><a href="/overview.php" title="Contact Us">Overview</a></li>
    <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
  </ul>
</div>
<div id="content">


<h2>Weather Services and Solutions</h2>

<table border="0" cellspacing="0" width="99%" cellpadding="5">
  <tr valign="top">
    <td width="330" valign="top">
    <p>
    <b>Smooth Operations, Weather or Not!</b><br/>
    How many times has the weather thrown a curve ball at your business?<br/>
    <b><br/>
    </b>If the weather affects your organization and its customers, then the more information
    you can gather about changing weather conditions -- with as much accuracy and advanced
    warning as possible -- the better you're able to manage your operations.<br/>
    <b><br/>
    </b>Weather is no longer the unpredictable business variable. With advanced, powerful
    technology, you can anticipate changes in the weather and keep one step ahead of Mother
    Nature.<br/>
    <br/>
    With Unisys Data and Display solutions, your employees can access real-time weather
    information from easy-to-use desktop workstations. Using NEXRAD radar, satellite, weather
    charts and reports, and much more, Unisys Weather solutions give your employees the tools
    to take advantage of the weather rather than falling victim to it.</p></td>
    <td width="230" valign="top">
    <p align="left"><strong>Weather Solutions</strong></p>
    <ul>
      <li><strong><a href="/wxmax/index.php">WeatherMAX</a></strong></li>
      <li><a href="/noaaport/index.php"><strong>NOAAPORT</strong></a></li>
      <li><strong>Unisys NOAAPORT Channel</strong></li>
      <li><a href="/news/internet_customers.php"><strong>Internet Weather Delivery</strong></a></li>
      <li><font face="Arial, Helvetica, sans-serif" color="#000000">SkyView</font></li>
      <li><a href="/wxp/wxp5/Overview.php"><strong>WXP</strong></a>
	<ul>
          <li><a href="/wxp/wxp5/Overview.php">Overview</a></li>
          <li><a href="/wxp/index.php">Online Documentation</a></li>
        </ul>
      </li>
    </ul>
    <p align="center"><img src="/solutions/storm.gif" width="219" height="112" alt="Storm"/> </p>
    <p align="center"><i>Weather is no longer the unpredictable business variable.</i></p></td>
  </tr>
  <tr>
    <td width="330" valign="top"></td>
    <td width="230" valign="top">&nbsp;</td>
  </tr>
</table>

<table border="0" cellspacing="0" cellpadding="5" width="99%">
  <tr valign="top">
    <td width="230" valign="middle"><p align="center"><img src="/solutions/andrew.gif" width="128" height="103" alt="Hurricane Andrew" /></p><p><i>Now your employees can access real-time weather information -- straight from their desktops.<br/>
    ...and more than 5000 organizations worldwide are doing just that!</i></p></td>
    <td width="330"><p>Unisys weather solutions
    also allow you to customize weather displays to meet your needs. Graphical readouts can be
    configured to show meteorological patterns in entire countries, specific regions, and even
    down to your local area. And if your business is affected more by wind speeds than by
    barometric pressure, Unisys can design the system to meet those needs by focusing on the
    factors that are most important to you. What's more, data can be delivered using dial-up,
    land lines, satellite, and the Internet - you choose the delivery channel most appropriate
    to your business.</p>

    <p>More than 5,000 organizations around
    the world -- from aviation, television, and agriculture to radio, recreation, and
    government -- are using the Unisys Data and Display solution to monitor weather
    conditions. Don't let weather catch your business off guard - Unisys weather solutions may
    be the answer you're looking for!</p></td>
  </tr>
</table>

<table border="0" cellspacing="0" width="99%" cellpadding="5">
  <tr valign="top">
    <td width="330">
    The Unisys series of weather systems -- <ul>
      <li><strong><a href="/wxmax/index.php">WeatherMAX</a></strong></li>
      <li><a href="/noaaport/index.php"><strong>NOAAPORT</strong></a></li>
      <li>SkyView</li>
      <li><strong><a href="/wxp/wxp5/Overview.php">WXP</a></strong></li>
    </ul>
    <p>might not be able to tame the weather
    beast, but they can give you a full picture of the weather and how it will affect your
    business.</p> <br/>
    <br/>
    For more information about these and other weather solutions, 
    e-mail <a href="mailto:sales-support@weather.unisys.com">sales-support@weather.unisys.com</a>
    <br/></td>
    <td width="230" valign="middle"><p align="center"><img src="/solutions/hurricane.gif" width="156" height="117" alt="Hurricane" /></p><br/>
    <br/>
    <i><font color="0000ff">We may not be able to tame the weather, but we can help to
    minimize its effect on your business.</font></i></td>
  </tr>
</table>

<div class="clearboth">&nbsp;</div>

</div>

<div id="footer"> <span id="copyright"><small>Copyright &copy; Unisys 2012</small></span>
  <ul class="inline-navigation-list" id="bottom-navigation">
    <li><a href="http://www.unisys.com/unisys/privacy.html" target="_blank">Privacy Notice</a></li>
    <li><a href="http://www.unisys.com/unisys/terms-and-conditions.html" target="_blank">Terms of Use</a></li>
    <li><a href="/contactus.php">Contact Us</a></li>
    <li><a href="http://www.unisys.com/unisys/trademarks.html" target="_blank">Trademarks</a></li>
  </ul>
</div>
</div>
</body>
</html>
