<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Unisys Weather </title>
<meta name="description" content="The intent of this weather site is to provide a complete source of graphical weather 		information. This is intended to satisfy the needs of the weather professional, but can be a tool for the casual user as well. The graphics and data are displayed as a meteorologist would expect to see. For the novice user, there are detailed explanation pages to guide them through the various plots, charts and images. The data on this site are provided from the National Weather Service via the NOAAPORT satellite data service. All the images are generated using the Weather Processor (WXP) analysis package which is available from Unisys. "/>
<meta name="keywords" content="weather, unisys, unisys weather, weather maps, maps, nam, wrf, GFS, GFSx, hurricane, radar, satellite, surface, upper air" />
<meta name="copyright" content="Unisys Corp - 2011" />
<meta name="author" content="Unisys Corporation" />
<meta name="email" content="technical-support@weather.unisys.com" />
<meta name="Distribution" content="Global" />
<meta name="Rating" content="General" />
<meta name="Robots" content="INDEX,FOLLOW" />
<meta name="Revisit-after" content="7 Days" />
<meta http-equiv="Content-type" content="text/html;charset=UTF-8" />
<meta http-equiv="imagetoolbar" content="no" />
<meta http-equiv="Refresh" content="900" />
<meta http-equiv="X-UA-Compatible" content="IE=8"/>
<link rel="stylesheet" type="text/css" href="/css/WMAX.css" />
</head>
<body>
<div id="wrap">
  <div id="top-menu">
    <ul id="top-navigation" class="inline-navigation-list">
      <li><a href="http://www.unisys.com" title="Unisys Home Page">Unisys.com</a></li>
      <li><a href="/index.php" title="Unisys Weather">Weather Home</a></li>
      <li><a href="/analyses.php" title="Analyses">Analyses</a></li>
      <li><a href="/forehome.php" title="Forecast">Forecasts</a></li>
      <li><a href="/archives.php" title="Archives">Archives</a></li>
      <li><a href="/links.php" title="NOAA Links">NOAA Links</a></li>
      <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
    </ul>
  </div>

  <div id="header"> <a href="http://unisys.com"><img src="/images/Unisys_logo.gif" alt="Unisys" /></a>
    <h1>Unisys Weather</h1>
  </div>

<div id="leftside">
  <ul class="avmenu">
    <li><a href="/index.php" class="purple">Unisys Weather</a></li>
    <li><a href="/index.php"> Weather Home</a></li>
    <li><a href="/solutions/index.php">Weather Solutions</a></li>
    <li><a href="/mobile/index.php"><img id="mobile_icon" src="/mobile/Icon.png" width="24" height="24" alt="Download Unisys Weather Mobile App"/>iPhone App</a></li>
    <li><a href="/info/index.php">Information</a></li>
    <li><a href="/content.php">Contents</a></li>
    <li><a href="/analyses.php" class="purple">Analyses</a></li>
    <li><a href="/satellite/index.php">Satellite Images</a></li>
    <li><a href="/surface/index.php">Surface Data</a></li>
    <li><a href="/upper_air/index.php">Upper Air Data</a></li>
    <li><a href="/radar/index.php">Radar Data</a></li>
    <li><a href="/forehome.php" class="purple">Forecasts</a></li>
    <li><a href="/mos/index.php">Model Statistics</a></li>
    <li><a href="/nam/index.php">NAM/Wrf Model</a></li>
    <li><a href="/gfs/index.php?r=us">GFS/Avn Model</a></li>
    <li><a href="/gfsx/index.php?r=us">GFSx/MRF Model</a></li>
    <li><a href="/rap/index.php">RAP Model</a></li>
    <li><a href="/ecmwf/index.php">ECMWF Model</a></li>
    <li><a href="/archives.php" class="purple">Archive</a></li>
    <li><a href="/hurricane/index.php">Hurricane Data</a></li>
    <li><a href="/archive/index.php">Archive of Images</a></li>
    <li><a href="/usgs/index.php">USGS Maps</a></li>
  </ul>
</div>

<div id="extras">
  <ul class="avmenu">
    <li><a href="/foresetup.php" class="purple">Get a Forecast</a></li>
  </ul>

<script type="text/javascript">
function fsubmit()
{
     document.getElementById("Forecast").submit();
}
</script>

  <form method="get" id="Forecast" action="/forecast.php">
    <p class="center"> Enter a zip code or city name to get forecast:
      <input type="text" name="Name" id="Name" size="15" />
      <br />
      <button type="submit" style="border:none; background-color:transparent;">
         <img src="/images/GO.png" id="Go" alt="Get Forecast Data" style="height:30px;" />
      </button>
      <a href="/foresetup.php"><img src="/images/setup.png" alt="Setup Location" height="30" width="70" /></a> </p>
  </form>
  <script type="text/javascript">
                <!-- HIDE
                var index = document.cookie.indexOf("ZIP")
                var zipcode = 0
                var region = ""
                if( index != -1 ){
                   //zipcode = parseInt( document.cookie.substring(index+4,index+9),10)
                   zipcode = document.cookie.substring(index+4,index+9)
                   var validateZipCode = function() {
                     var zipcodeRegexp = /^\d{5}$/;
                     var zipTest = zipcodeRegexp.test(zipcode);
   
                     if (zipTest == false) {
                       return false;
                     }
                   }
                   validateZipCode();

                    if( ! isNaN(zipcode))

                    document.getElementById('Name').value = zipcode

                   if( zipcode >= 01000 && zipcode <= 19699 )
                      region = "ne"
                   else if( zipcode >= 19700 && zipcode <= 28999 )
                      region = "at"
                   else if( zipcode >= 43000 && zipcode <= 45999 )
                      region = "at"
                   else if( zipcode >= 29000 && zipcode <= 36999 )
                      region = "se"
                   else if( zipcode >= 38600 && zipcode <= 39999 )
                      region = "se"
                   else if( zipcode >= 46000 && zipcode <= 58999 )
                      region = "mw"
                   else if( zipcode >= 60000 && zipcode <= 62999 )
                      region = "mw"
                   else if( zipcode >= 68000 && zipcode <= 69999 )
                      region = "mw"
                   else if( zipcode >= 63000 && zipcode <= 67999 )
                      region = "cp"
                   else if( zipcode >= 71600 && zipcode <= 74999 )
                      region = "cp"
                   else if( zipcode >= 70000 && zipcode <= 71499 )
                      region = "sp"
                   else if( zipcode >= 75000 && zipcode <= 79999 )
                      region = "sp"
                   else if( zipcode >= 59000 && zipcode <= 59999 )
                      region = "nw"
                   else if( zipcode >= 82000 && zipcode <= 83999 )
                      region = "nw"
                   else if( zipcode >= 97000 && zipcode <= 99499 )
                      region = "nw"
                   else if( zipcode >= 80000 && zipcode <= 81999 )
                      region = "sw"
                   else if( zipcode >= 84000 && zipcode <= 96199 )
                      region = "sw"

                   if( region != "" ){
                      document.write( "<table border=\"0\" align=\"center\" class=\"grey\" width=\"100%\">" )
                      document.write( "<tr>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/surface/sfc_map.php?image=sfc&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Sfc" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=\"radar/rad" + region + ".php\">" )
                      document.write( "<a href=/radar/rcm_rad.php?image=rad&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Rad" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=vis&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Vis" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=enh&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>IR" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "</tr></table>" )
                      document.write( "</b>" )
                      }


                   
                   }
                // UNHIDE -->
                </script>
  <ul class="avmenu">
    <li><a href="/links.php" class="purple">NOAA Links</a></li>
    <li><a href="http://lwf.ncdc.noaa.gov/">National Climatic Data Center</a></li>
    <li><a href="http://www.cpc.noaa.gov/">Climate Prediction Center</a></li>
    <li><a href="http://oceanservice.noaa.gov/">National Ocean Service</a></li>
    <li><a href="http://www.lib.noaa.gov/">NOAA Library</a></li>
    <li><a href="http://www.oar.noaa.gov/">NOAA Office of Oceanic and Atmospheric Research</a></li>
    <li><a href="http://www.esrl.noaa.gov/">Earth Systems Research Laboratory</a></li>
    <li><a href="/overview.php" class="purple">About Us</a></li>
    <li><a href="/overview.php" title="Contact Us">Overview</a></li>
    <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
  </ul>
</div>
<div id="content">

<h2 align="center">Contents Page</h2>
  <h2>Forecast Pages</h2>
  <ul class="nobullet">
    <li><a href="/mos/index.php" class="purple">Model Statistics</a> - Model derived forecasts for individual cities based on statistical relations</li>
    <li>
      <ul class="nobullet">
        <li><a href="/mos/nam.php" class="red"> NAM Plots</a> - Short term forecasts from NAM model out to 60 hours</li>
        <li>
          <ul>
            <li><a href="/mos/mos.php?inv=0&t=24h&region=us"> Surface Plots</a> - Station model plots with precipitation contours. Plots selectable by forecast time.</li>
            <li><a href="/mos/mos_depict.php?inv=0&t=24h"> Weather Depiction Plots</a> - Forecasted weather depiction charts (IFR, VFR).</li>
          </ul>
        </li>
        <li><a href="/mos/meteogram/index.php" class="red"> NAM Meteograms</a> - Forecasted time series (out to 60 hours) plots for specific stations of temperature, pressure, winds, weather. Plots selectable by city.</li>
        <li><a href="/mos/gfs.php" class="red"> GFS Plots</a> - Medium range forecasts from GFS model out to 8 days</li>
        <li>
          <ul>
            <li><a href="/mos/mos_gfs.php?plot=gfs&t=4p&inv=0"> Maximum Temperature and Probability of Precipitation</a> - Plots selectable by forecast day</li>
            <li><a href="/mos/mos_gfs.php?plot=gfs_dep&t=4p&inv=0"> Maximum Temperature Departure from Normal</a> - Plots selectable by forecast day</li>
            <li><a href="/mos/mos_gfs.php?plot=gfs_min&t=4p&inv=0"> Minimum Temperature</a> - Plots selectable by forecast day</li>
            <li><a href="/mos/mos_gfs.php?plot=gfs_min_dep&t=4p&inv=0"> Minimum Temperature Departure from Normal</a> - Plots selectable by forecast day</li>
          </ul>
        </li>
      </ul>
    </li>

    <li><a href="/nam/index.php" class="purple"> NAM/WRF Model</a> - Regional forecast model with data every 6 hours out to 60 hours for US and surrounding areas</li>
    <li>
      <ul class="nobullet">
        <li><a href="/nam/pres.php" class="red"> SL Pressure/Precipitation Plots</a> - Filled contours of 12 hour precipitation overlaid with sea level pressure and 1000-500 mb thickness. Plots selectable by forecast time, 4 panel (12,24,36,48hr) and loop.</li>
        <li><a href="/nam/sfc.php" class="red"> Surface Plots</a> - Filled contours of 2m temperature overlaid with 10m winds, convergence (shaded) and 2m dewpoint. Plots selectable by forecast time and 4 panel (12,24,36,48hr).</li>
        <li><a href="/nam/1000.php" class="red"> 1000mb Plots</a> - Filled contours of 1000mb temperature overlaid with 1000mb winds, convergence (shaded) and 1000mb dewpoint. Plots selectable by forecast time and 4 panel (12,24,36,48hr).</li>
        <li><a href="/nam/850.php" class="red"> 850mb Plots</a> - Filled contours of 850mb temperature overlaid with 850mb height and wind vectors. Plots selectable by forecast time, 4 panel (12,24,36,48hr) and loop.</li>
        <li><a href="/nam/700.php" class="red"> 700mb Plots</a> - Filled contours of 700mb vertical velocity overlaid with 700mb height and wind vectors.  Plots selectable by forecast time and 4 panel (12,24,36,48hr).</li>
        <li><a href="/nam/500.php" class="red"> 500mb Plots</a> - Filled contours of 500mb absolute vorticity overlaid with 500mb height and wind vectors.  Plots selectable by forecast time and 4 panel (12,24,36,48hr).</li>
        <li><a href="/nam/300.php" class="red"> 300mb Plots</a> - Filled contours of 300mb wind speed overlaid with 300mb height and wind vectors. Plots selectable by forecast time, 4 panel (12,24,36,48hr) and loop.</li>
        <li><a href="/nam/rh.php" class="red"> Relative Humidity/Lifted Index Plots</a> - Filled contours of 850-500mb mean relative humidity overlaid with lifted index (shaded for negative). Plots selectable by forecast time, 4 panel (12,24,36,48hr) and loop.</li>
        <li><a href="/nam/4panel.php" class="red"> 4 Panel Plots</a> - A 4 panel plot with 850mb data (upper left), 300mb data (upper right), SL Pressure/Precipitation data (lower left) and Relative Humidity/Lifted Index data (lower right). Plots selectable by forecast time.</li>
        <li><a href="/nam/winter.php" class="red"> Winter Plots</a> - A 4 panel plot of surface temperature (upper left), wind chill (upper right), precipitation type (lower left) and snowfall accumulation (lower right). Plots selectable by forecast time on 3 hour increments.</li>
        <li><a href="/nam/misc.php" class="red"> Miscellaneous Plots</a> </li>
        <li>
          <ul>
            <li><a href="/nam/nam_misc.php?inv=0&plot=cape"> CAPE Plot</a> - A 4 panel plot of CAPE (12,24,36,48hr)</li>
            <li><a href="/nam/nam_misc.php?inv=0&plot=heli"> Helicity Plot</a> - A 4 panel plot of Helicity (12,24,36,48hr)</li>
            <li><a href="/nam/nam_misc.php?inv=0&plot=ehi"> EHI Plot</a> - A 4 panel plot of Energy Helicity Index (12,24,36,48hr)</li>
            <li><a href="/nam/nam_misc.php?inv=0&plot=prec"> 48 hour Precipitation</a> - 48 hour accumulated precipitation.</li>
            <li><a href="/nam/nam_misc.php?inv=0&plot=snow"> 48 hour Snowfall</a> - 48 hour accumulated snowfall.</li>
          </ul>
        </li>
      </ul>
    </li>
    <li><a href="/gfs/index.php" class="purple"> GFS Model</a> - Forecast model with global data every 12 hours out to 72 hours</li>
    <li>
      <ul class="nobullet">
        <li><a href="/gfs/index.php?r=us" class="red"> United States</a></li>
        <li>
          <ul>
            <li><a href="/gfs/gfs.php?inv=0&plot=pres&region=us&t=4p1"> SL Pressure/Precipitation Plots</a> - Filled contours of 12 hour precipitation overlaid with sea level pressure and 1000-500 mb thickness. Plots selectable by forecast time, 6 panel (12,24,36,48,60,72hr).</li>
            <li><a href="/gfs/gfs.php?inv=0&plot=1000&region=us&t=4p1"> 1000mb Plots</a> - Filled contours of 1000mb temperature overlaid with 1000mb winds, convergence (shaded) and 1000mb dewpoint. Plots selectable by forecast time and 6 panel (12,24,36,48,60,72hr).</li>
            <li><a href="/gfs/gfs.php?inv=0&plot=850&region=us&t=4p1"> 850mb Plots</a> - Filled contours of 850mb temperature overlaid with 850mb height and wind vectors. Plots selectable by forecast time, 6 panel (12,24,36,48,60,72hr)</li>
            <li><a href="/gfs/gfs.php?inv=0&plot=700&region=us&t=4p1"> 700mb Plots</a> - Filled contours of 700mb vertical velocity overlaid with 700mb height and wind vectors.  Plots selectable by forecast time and 6 panel (12,24,36,48,60,72hr).</li>
            <li><a href="/gfs/gfs.php?inv=0&plot=500&region=us&t=4p1"> 500mb Plots</a> - Filled contours of 500mb absolute vorticity overlaid with 500mb height and wind vectors.  Plots selectable by forecast time and 6 panel (12,24,36,48,60,72hr).</li>
            <li><a href="/gfs/gfs.php?inv=0&plot=300&region=us&t=4p1"> 300mb Plots</a> - Filled contours of 300mb wind speed overlaid with 300mb height and wind vectors. Plots selectable by forecast time, 6 panel (12,24,36,48,60,72hr)</li>
            <li><a href="/gfs/gfs.php?inv=0&plot=rh&region=us&t=4p1"> Relative Humidity/Showalter Index Plots</a> - Filled contours of 850-500mb mean relative humidity overlaid with Showalter index (shaded for negative). Plots selectable by forecast time, 6 panel (12,24,36,48,60,72hr)</li>
            <li><a href="/gfs/gfs.php?inv=0&plot=4p&region=us&t=ini"> 4 Panel Plots</a> - A 4 panel plot with 850mb data (upper left), 300mb data (upper right), SL Pressure/Precipitation data (lower left) and Relative Humidity/Showalter Index data (lower right). Plots selectable by forecast time.</li>
            <li><a href="/gfs/misc.php?inv=0&plot=misc&region=us&t=48h"> Miscellaneous Plots</a> - Plots of 48 hour accumulated precipitation.</li>
          </ul>
        </li>
        <li><a href="/gfs/index.php?r=eu" class="red"> Europe</a></li>
        <li>
          <ul class="nobullet">
            <li><a href="/gfs/index.php?r=eu"> 6 Panel Plots</a></li>
            <li>
              <ul>
                <li><a href="/gfs/gfs.php?inv=0&plot=pres&region=eu&t=4p1"> SL Pressure/Precipitation Plot</a></li>
                <li><a href="/gfs/gfs.php?inv=0&plot=1000&region=eu&t=4p1"> 1000mb Plots</a></li>
                <li><a href="/gfs/gfs.php?inv=0&plot=850&region=eu&t=4p1"> 850mb Plots</a></li>
                <li><a href="/gfs/gfs.php?inv=0&plot=700&region=eu&t=4p1"> 700mb Plots</a></li>
                <li><a href="/gfs/gfs.php?inv=0&plot=500&region=eu&t=4p1"> 500mb Plots</a></li>
                <li><a href="/gfs/gfs.php?inv=0&plot=300&region=eu&t=4p1"> 300mb Plots</a></li>
                <li><a href="/gfs/gfs.php?inv=0&plot=rh&region=eu&t=4p1"> Relative Humidity/Showalter Index Plots</a></li>
              </ul>
            </li>
            <li><a href="/gfs/gfs.php?inv=0&plot=4p&region=eu&t=ini"> 4 Panel Plots</a> - A 4 panel plot with 850mb data (upper left), 300mb data (upper right), SL Pressure/Precipitation data (lower left) and Relative Humidity/Showalter Index data (lower right). Plots selectable by forecast time.</li>
          </ul>
        </li>
        <li><a href="/gfs/index.php?r=ea" class="red"> East Asia</a></li>
        <li>
          <ul class="nobullet">
            <li><a href="/gfs/index.php?r=ea"> 6 Panel Plots</a></li>
            <li>
              <ul>
                <li><a href="/gfs/gfs.php?inv=0&plot=pres&region=ea&t=4p1"> SL Pressure/Precipitation Plot</a></li>
                <li><a href="/gfs/gfs.php?inv=0&plot=1000&region=ea&t=4p1"> 1000mb Plots</a></li>
                <li><a href="/gfs/gfs.php?inv=0&plot=850&region=ea&t=4p1"> 850mb Plots</a></li>
                <li><a href="/gfs/gfs.php?inv=0&plot=700&region=ea&t=4p1"> 700mb Plots</a></li>
                <li><a href="/gfs/gfs.php?inv=0&plot=500&region=ea&t=4p1"> 500mb Plots</a></li>
                <li><a href="/gfs/gfs.php?inv=0&plot=300&region=ea&t=4p1"> 300mb Plots</a></li>
                <li><a href="/gfs/gfs.php?inv=0&plot=rh&region=ea&t=4p1"> Relative Humidity/Showalter Index Plots</a></li>
              </ul>
            </li>
            <li><a href="/gfs/gfs.php?inv=0&plot=4p&region=ea&t=ini"> 4 Panel Plots</a> - A 4 panel plot with 850mb data (upper left), 300mb data (upper right), SL Pressure/Precipitation data (lower left) and Relative Humidity/Showalter Index data (lower right). Plots selectable by forecast time.</li>
          </ul>
        </li>
        <li><a href="/gfs/index.php?r=sa" class="red"> South America</a></li>
        <li>
          <ul class="nobullet">
            <li><a href="/gfs/index.php?r=sa"> 6 Panel Plots</a></li>
            <li>
              <ul>
                <li><a href="/gfs/gfs.php?inv=0&plot=pres&region=sa&t=4p1"> SL Pressure/Precipitation Plot</a></li>
                <li><a href="/gfs/gfs.php?inv=0&plot=1000&region=sa&t=4p1"> 1000mb Plots</a></li>
                <li><a href="/gfs/gfs.php?inv=0&plot=850&region=sa&t=4p1"> 850mb Plots</a></li>
                <li><a href="/gfs/gfs.php?inv=0&plot=700&region=sa&t=4p1"> 700mb Plots</a></li>
                <li><a href="/gfs/gfs.php?inv=0&plot=500&region=sa&t=4p1"> 500mb Plots</a></li>
                <li><a href="/gfs/gfs.php?inv=0&plot=300&region=sa&t=4p1"> 300mb Plots</a></li>
                <li><a href="/gfs/gfs.php?inv=0&plot=rh&region=sa&t=4p1"> Relative Humidity/Showalter Index Plots</a></li>
              </ul>
            </li>
            <li><a href="/gfs/gfs.php?inv=0&plot=4p&region=sa&t=ini"> 4 Panel Plots</a> - A 4 panel plot with 850mb data (upper left), 300mb data (upper right), SL Pressure/Precipitation data (lower left) and Relative Humidity/Showalter Index data (lower right). Plots selectable by forecast time.</li>
          </ul>
        </li>
        <li><a href="/gfs/index.php?r=au" class="red"> Australia</a></li>
        <li>
          <ul class="nobullet">
            <li><a href="/gfs/index.php?r=au"> 6 Panel Plots</a></li>
            <li>
              <ul>
                <li><a href="/gfs/gfs.php?inv=0&plot=pres&region=au&t=4p1"> SL Pressure/Precipitation Plot</a></li>
                <li><a href="/gfs/gfs.php?inv=0&plot=1000&region=au&t=4p1"> 1000mb Plots</a></li>
                <li><a href="/gfs/gfs.php?inv=0&plot=850&region=au&t=4p1"> 850mb Plots</a></li>
                <li><a href="/gfs/gfs.php?inv=0&plot=700&region=au&t=4p1"> 700mb Plots</a></li>
                <li><a href="/gfs/gfs.php?inv=0&plot=500&region=au&t=4p1"> 500mb Plots</a></li>
                <li><a href="/gfs/gfs.php?inv=0&plot=300&region=au&t=4p1"> 300mb Plots</a></li>
                <li><a href="/gfs/gfs.php?inv=0&plot=rh&region=au&t=4p1"> Relative Humidity/Showalter Index Plots</a></li>
              </ul>
            </li>
            <li><a href="/gfs/gfs.php?inv=0&plot=4p&region=au&t=ini"> 4 Panel Plots</a> - A 4 panel plot with 850mb data (upper left), 300mb data (upper right), SL Pressure/Precipitation data (lower left) and Relative Humidity/Showalter Index data (lower right). Plots selectable by forecast time.</li>
          </ul>
        </li>
      </ul>
    </li> 
    <li><a href="/ruc/index.php" class="purple"> RUC Model</a> - (Rapid Update Cycle) Forecast model with data every 6 hours out to 24 hours. </li>
    <li>
      <ul class="nobullet">
        <li class="red">RUC Analyses</li>
        <li>
          <ul>
            <li><a href="/ruc/ruc.php?plot=pres&t=in&inv=0"> SL Pressure/Precipitation Plot</a></li>
            <li><a href="/ruc/ruc.php?plot=1000&t=in&inv=0"> 1000mb Plots</a></li>
            <li><a href="/ruc/ruc.php?plot=850&t=in&inv=0"> 850mb Plots</a></li>
            <li><a href="/ruc/ruc.php?plot=700&t=in&inv=0"> 700mb Plots</a></li>
            <li><a href="/ruc/ruc.php?plot=500&t=in&inv=0"> 500mb Plots</a></li>
            <li><a href="/ruc/ruc.php?plot=300&t=in&inv=0"> 300mb Plots</a></li>
            <li><a href="/ruc/ruc.php?plot=rh&t=in&inv=0"> Relative Humidity/Showalter Index Plots</a></li>
          </ul>
        </li>
        <li class="red"> RUC 4 Panel Plots - A 4 panel plot of 3,6,9,12hr forecasts.</li>
        <li>
          <ul>
            <li><a href="/ruc/ruc.php?plot=pres&t=4p&inv=0"> SL Pressure/Precipitation Plot</a></li>
            <li><a href="/ruc/ruc.php?plot=1000&t=4p&inv=0"> 1000mb Plots</a></li>
            <li><a href="/ruc/ruc.php?plot=850&t=4p&inv=0"> 850mb Plots</a></li>
            <li><a href="/ruc/ruc.php?plot=700&t=4p&inv=0"> 700mb Plots</a></li>
            <li><a href="/ruc/ruc.php?plot=500&t=4p&inv=0"> 500mb Plots</a></li>
            <li><a href="/ruc/ruc.php?plot=300&t=4p&inv=0"> 300mb Plots</a></li>
            <li><a href="/ruc/ruc.php?plot=rh&t=4p&inv=0"> Relative Humidity/Showalter Index Plots</a></li>
          </ul>
        </li>
      </ul>
    </li>
    <li><a href="/gfsx/index.php?r=us" class="purple"> GFSX Model</a> - GFS Extended Forecast) Forecast model with global data every 12 hours out to 10 days.</li>
    <li>
      <ul class="nobullet">
        <li><a href="/gfsx/index.php?r=us" class="red"> North America</a></li>
        <li>
          <ul>
            <li><a href="/gfsx/gfsx.php?inv=0&plot=hght&region=us&t=ini"> 500mb Height/SL Pressure Plots</a> - Filled contours of 500mb height overlaid with sea level pressure. Plots selectable by forecast time, 9 panel (3-10day) and loop.</li>
            <li><a href="/gfsx/gfsx.php?inv=0&plot=pres&region=us&t=ini"> SL Pressure/Precipitation Plots</a> - Filled contours of 12 hour precipitation overlaid with sea level pressure and 1000-500 mb thickness. Plots selectable by forecast time, 9 panel (3-10day) and loop.</li>
            <li><a href="/gfsx/gfsx.php?inv=0&plot=850&region=us&t=ini"> 850mb Plots</a> - Filled contours of 850mb temperature overlaid with 850mb height and wind vectors. Plots selectable by forecast time, 9 panel (3-10day) and loop.</li>
            <li><a href="/gfsx/gfsx.php?inv=0&plot=300&region=us&t=ini"> 300mb Plots</a> - Filled contours of 300mb wind speed overlaid with 300mb height and wind vectors. Plots selectable by forecast time, 9 panel (3-10day) and loop.</li>
            <li><a href="/gfsx/gfsx.php?inv=0&plot=rel&region=us&t=ini"> Relative Humidity/Showalter Index Plots</a> - Filled contours of 850-500mb mean relative humidity overlaid with Showalter index (shaded for negative). Plots selectable by forecast time, 9 panel (3-10day) and loop.</li>
            <li><a href="/gfsx/gfsx.php?inv=0&plot=4p&region=us&t=ini"> 4 Panel Plots</a> - A 4 panel plot with 850mb data (upper left), 300mb data (upper right), SL Pressure/Precipitation data (lower left) and Relative Humidity/Showalter Index data (lower right). Plots selectable by forecast time.</li>
          </ul>
        </li>
        <li><a href="/gfsx/index.php?r=eu" class="red"> Europe</a></li>
        <li>
          <ul>
            <li><a href="/gfsx/gfsx.php?inv=0&plot=hght&region=eu&t=ini"> 500mb Height/SL Pressure Plots</a> - Filled contours of 500mb height overlaid with sea level pressure. Plots selectable by forecast time, 9 panel (3-10day) and loop.</li>
            <li><a href="/gfsx/gfsx.php?inv=0&plot=pres&region=eu&t=ini"> SL Pressure/Precipitation Plots</a> - Filled contours of 12 hour precipitation overlaid with sea level pressure and 1000-500 mb thickness. Plots selectable by forecast time, 9 panel (3-10day) and loop.</li>
            <li><a href="/gfsx/gfsx.php?inv=0&plot=850&region=eu&t=ini"> 850mb Plots</a> - Filled contours of 850mb temperature overlaid with 850mb height and wind vectors. Plots selectable by forecast time, 9 panel (3-10day) and loop.</li>
            <li><a href="/gfsx/gfsx.php?inv=0&plot=300&region=eu&t=ini"> 300mb Plots</a> - Filled contours of 300mb wind speed overlaid with 300mb height and wind vectors. Plots selectable by forecast time, 9 panel (3-10day) and loop.</li>
            <li><a href="/gfsx/gfsx.php?inv=0&plot=rel&region=eu&t=ini"> Relative Humidity/Showalter Index Plots</a> - Filled contours of 850-500mb mean relative humidity overlaid with Showalter index (shaded for negative). Plots selectable by forecast time, 9 panel (3-10day) and loop.</li>
            <li><a href="/gfsx/gfsx.php?inv=0&plot=4p&region=eu&t=ini"> 4 Panel Plots</a> - A 4 panel plot with 850mb data (upper left), 300mb data (upper right), SL Pressure/Precipitation data (lower left) and Relative Humidity/Showalter Index data (lower right). Plots selectable by forecast time.</li>
          </ul>
        </li>
        <li><a href="/gfsx/index.php?r=ea" class="red"> East Asia</a></li>
        <li>
          <ul>
            <li><a href="/gfsx/gfsx.php?inv=0&plot=hght&region=ea&t=ini"> 500mb Height/SL Pressure Plots</a> - Filled contours of 500mb height overlaid with sea level pressure presented as a 9 panel (3-10day) chart.</li>
          </ul>
        </li>
        <li><a href="/gfsx/index.php?r=sa" class="red"> South America</a></li>
        <li>
          <ul>
            <li><a href="/gfsx/index.php?r=sa"> 500mb Height/SL Pressure Plots</a> - Filled contours of 500mb height overlaid with sea level pressure presented as a 9 panel (3-10day) chart.</li>
          </ul>
        </li>
        <li><a href="/gfsx/index.php?r=au" class="red"> Australia</a></li>
        <li>
          <ul>
            <li><a href="/gfsx/index.php?r=au"> 500mb Height/SL Pressure Plots</a> - Filled contours of 500mb height overlaid with sea level pressure presented as a 9 panel (3-10day) chart.</li>
          </ul>
        </li>
        <li><a href="/gfsx/index.php?r=nh" class="red"> Northern Hemisphere</a></li>
        <li>
          <ul>
            <li><a href="/gfsx/index.php?r=nh"> 500mb Height/SL Pressure Plots</a> - Filled contours of 500mb height overlaid with sea level pressure. Plots are selectable by time and 9 panel (3-10day) chart.</li>
          </ul>
        </li>
      </ul>
    </li>
    <li><a href="/ecmwf/index.php" class="purple"> ECMWF Model</a> - (European Center for Medium Range Forecasting) Forecast model with data every day out to 10 days.</li>
    <li>
      <ul class="nobullet">
        <li><a href="/ecmwf/index.php" class="red"> United States</a></li>
        <li>
          <ul>
            <li><a href="/ecmwf/index.php"> 500mb Height/SL Pressure Plots</a> - Filled contours of 500mb height overlaid with sea level pressure. Plots selectable by forecast time and 4 panel (3,4,5,6day).</li>
          </ul>
        </li>
        <li><a href="/ecmwf/index_eur.php" class="red"> Europe</a></li>
        <li>
          <ul>
            <li><a href="/ecmwf/index_eur.php"> 500mb Height/SL Pressure Plots</a> - Filled contours of 500mb height overlaid with sea level pressure. Plots selectable by forecast time and 4 panel (3,4,5,6day) .</li>
          </ul>
        </li>
      </ul>
    </li>
  </ul>
  
  <h2>Analyses Pages</h2>
  <ul class="nobullet">
    <li><a href="/satellite/index.php" class="purple">Satellite</a></li>
    <li>
      <ul class="nobullet">
        <li><a href="/satellite/visible.php" class="red"> Visible Images</a> -Images selectable by region including loop</li>
        <li><a href="/satellite/infrared.php" class="red"> Infrared Images</a> - Images selectable by region including loop</li>
        <li><a href="/satellite/infrared_enh.php" class="red"> Enhanced Infrared Images</a> - Images selectable by region including loop</li>
        <li><a href="/satellite/water_vapor.php" class="red"> Water Vapor Images</a> - Images selectable by region including loop</li>
        <li><a href="/satellite/composite.php" class="red"> Composite Images</a></li>
        <li>
          <ul>
            <li><a href="/satellite/sat_sfc.php?inv=0&t=cur"> Satellite Surface Map</a> - IR Satellite + Surface Map</li>
            <li><a href="/satellite/sat_rad.php?inv=0&t=cur"> IR Satellite and Radar Map</a></li>
          </ul>
        </li>
      </ul>
    </li>
    <li><a href="/surface/index.php" class="purple"> Surface</a></li>
    <li>
      <ul class="nobullet">
        <li><a href="/surface/composite.php" class="red"> Composite Maps</a></li>
        <li>
          <ul>
            <li><a href="/surface/sfc_map.php?inv=0&t=cur&region=us"> Surface Map</a></li>
            <li><a href="/surface/sfc_depict.php?inv=0&t=cur"> Weather Depiction</a> - Aviation weather chart (IFR, VFR)</li>
            <li><a href="/surface/sfc_fronts.php?inv=0&t=cur"> Fronts</a> - Current frontal positions</li>
          </ul>
        </li>
        <li><a href="/surface/regional.php" class="red"> Regional Data Plots</a> - Surface (station model) plots by region</li>
        <li><a href="/surface/contour.php" class="red"> Contour Plots</a></li>
        <li>
          <ul>
            <li><a href="/surface/sfc_con.php?image=te&inv=0&t=cur"> US Temperature</a></li>
            <li><a href="/surface/sfc_con.php?image=na&inv=0&t=cur"> N Amer Temperature</a></li>
            <li><a href="/surface/sfc_con.php?image=24&inv=0&t=cur"> US 24 hr Temperature Change</a></li>
            <li><a href="/surface/sfc_con.php?image=wc&inv=0&t=cur"> US Wind Chill</a></li>
            <li><a href="/surface/sfc_con.php?image=he&inv=0&t=cur"> US Heat Index</a></li>
            <li><a href="/surface/sfc_con.php?image=pr&inv=0&t=cur"> US SL Pressure</a></li>
            <li><a href="/surface/sfc_con.php?image=3p&inv=0&t=cur"> US 3 hr Pressure Change</a></li>
            <li><a href="/surface/sfc_con.php?image=de&inv=0&t=cur"> US Dewpoint</a></li>
            <li><a href="/surface/sfc_con.php?image=ws&inv=0&t=cur"> US Wind Speed</a></li>
            <li><a href="/surface/sfc_con.php?image=st&inv=0&t=cur"> US Wind Streamlines</a></li>
            <li><a href="/surface/sfc_con.php?image=qc&inv=0&t=cur"> US Moisture Convergence</a></li>
          </ul>
        </li>
        <li><a href="/surface/daily.php" class="red"> Daily Plots</a></li>
        <li>
          <ul>
            <li><a href="/surface/sfc_daily.php?plot=htp&inv=0&t=cur"> US High Temperature</a></li>
            <li><a href="/surface/sfc_daily.php?plot=ltp&inv=0&t=cur"> US Low Temperature</a></li>
            <li><a href="/surface/sfc_daily.php?plot=24p&inv=0&t=cur"> US Daily Precipitation</a></li>
            <li><a href="/surface/sfc_daily.php?plot=mop&inv=0&t=cur"> US Monthly Precipitation</a> - Precipitation for the month so far</li>
            <li><a href="/surface/sfc_daily.php?plot=snc&inv=0&t=cur"> US Snow Cover</a></li>
            <li><a href="/surface/sfc_daily.php?plot=ssd&inv=0&t=cur"> SST Plot</a> - Sea Surface Temperatures</li>
            <li><a href="/surface/sfc_daily.php?plot=ssa&inv=0&t=cur"> SST Anomaly</a> - SST temperature anomalies</li>
          </ul>
        </li>
        <li><a href="/surface/meteogram/index.php" class="red"> Surface Meteograms</a> - Time series plots for specific stations of temperature, pressure, winds, weather. Plots selectable by city.</li>
      </ul>
    </li>
    <li><a href="/upper_air/index.php" class="purple"> Upper Air</a></li>
    <li>
      <ul class="nobullet">
        <li><a href="/upper_air/mandatory.php" class="red"> Mandatory Level Plots</a> - Plots at various pressure levels</li>
        <li><a href="/upper_air/height.php" class="red"> Constant Height Plots</a> - Plots at various height levels</li>
        <li><a href="/upper_air/hemisphere.php" class="red"> Hemispheric Plots</a> - Hemisphere plots of 500mb height/SL pressure, 850mb heights/temperatures, 300mb winds/heights.</li>
        <li><a href="/upper_air/contour.php" class="red"> Contour Plots</a></li>
        <li>
          <ul>
            <li><a href="/upper_air/ua_cont.php?plot=500&inv=0&t=cur"> 500mb Height</a></li>
            <li><a href="/upper_air/ua_cont.php?plot=850&inv=0&t=cur"> 850mb Temperature</a></li>
            <li><a href="/upper_air/ua_cont.php?plot=thi&inv=0&t=cur"> 1000-500mb Thickness</a></li>
            <li><a href="/upper_air/ua_cont.php?plot=300&inv=0&t=cur"> 300mb Wind Speed</a></li>
            <li><a href="/upper_air/ua_cont.php?plot=str&inv=0&t=cur"> 300mb Streamlines</a></li>
            <li><a href="/upper_air/ua_cont.php?plot=pre&inv=0&t=cur"> Precipitable Water</a></li>
            <li><a href="/upper_air/ua_cont.php?plot=lif&inv=0&t=cur"> Lifted Index</a> - Stability index</li>
            <li><a href="/upper_air/ua_cont.php?plot=tt&inv=0&t=cur"> Total Totals Index</a></li>
            <li><a href="/upper_air/ua_cont.php?plot=ki&inv=0&t=cur"> K Index</a></li>
            <li><a href="/upper_air/ua_cont.php?plot=cap&inv=0&t=cur"> CAPE</a> - Convective Available Potential Energy</li>
            <li><a href="/upper_air/ua_cont.php?plot=hel&inv=0&t=cur"> Helicity</a></li>
          </ul>
        </li>
        <li><a href="/upper_air/skew/index.php" class="red"> Sounding Plots (SkewT)</a> - Upper air sounding plot (temperature vs height). Plots selectable by site/city.</li>
      </ul>
    </li>
    <li><a href="/radar/index.php" class="purple"> Radar</a></li>
    <li>
      <ul class="nobullet">
        <li><a href="/radar/rcm_rad.php?inv=0&t=cur&region=us" class="red"> RCM Plots</a> - (Radar Coded Messages) A radar mosaic based on RCM site radar data. Plots selectable by region including loop.</li>
      </ul>
    </li>
  </ul>


  <h2>Archives</h2>
  <ul class="nobullet">
    <li><a href="/hurricane/index.php" class="purple"> Hurricane Data</a> - A comprehensive list of current hurricanes and typhoons as well as an extended archive of past storms.</li>
    <li>
      <ul class="nobullet">
        <li><a href="/hurricane/atlantic/2009/index.html" class="red"> Atlantic Hurricanes</a></li>
        <li>
          <ul>
            <li><a href="/hurricane/atlantic/2009/index.html"> Current year</a></li>
            <li><a href="/hurricane/atlantic/index.html"> Archive (1851-2008)</a></li>
          </ul>
        </li>
        <li><a href="/hurricane/e_pacific/2009/index.html" class="red"> Eastern Pacific Hurricanes</a></li>
        <li>
          <ul>
            <li><a href="/hurricane/e_pacific/2009/index.html" > Current year</a></li>
            <li><a href="/hurricane/e_pacific/index.html"> Archive (1949-2008)</a></li>
          </ul>
        </li>
        <li><a href="/hurricane/w_pacific/2009/index.html" class="red"> Western Pacific Hurricanes</a></li>
        <li>
          <ul>
            <li><a href="/hurricane/w_pacific/2009/index.html"> Current year</a></li>
            <li><a href="/hurricane/w_pacific/index.html"> Archive (1945-2007)</a></li>
          </ul>
        </li>
        <li><a href="/hurricane/s_pacific/2009/index.html" class="red"> Southern Pacific Hurricanes</a></li>
        <li>
          <ul>
            <li><a href="/hurricane/s_pacific/2009/index.html"> Current year</a></li>
          </ul>
        </li>
        <li><a href="/hurricane/s_indian/2009/index.html" class="red"> Southern Indian Hurricanes</a></li>
        <li>
          <ul>
            <li><a href="/hurricane/s_indian/2009/index.html"> Current year</a></li>
            <li><a href="/hurricane/s_indian/index.html"> Archive (1945-2003)</a></li>
          </ul>
        </li>
        <li><a href="/hurricane/n_indian/2009/index.html" class="red"> Northern Indian Hurricanes</a></li>
        <li>
          <ul>
            <li><a href="/hurricane/n_indian/2009/index.html"> Current year</a></li>
            <li><a href="/hurricane/n_indian/index.html"> Archive (1945-2003)</a></li>
          </ul>
        </li>
      </ul>
    </li>
    <li><a href="/archive/index.php" class="purple"> Archive of Images</a> - A long term archive of images stored on a 12 hour basis.</li>
    <li>
      <ul class="nobullet">
        <li><a href="/archive/sfc_map/index.php" class="red"> Surface Map</a> - Surface map including station model, fronts, radar and SL pressure contours.</li>
        <li><a href="/archive/sat_ir/index.php" class="red"> Infrared Satellite Image</a> - Infrared satellite image.</li>
        <li><a href="/archive/eta_init/index.php" class="red"> Upper Air Charts</a> - This is a 4 panel plot from the NAM model analysis with 850mb data (upper left), 300mb data (upper right), SL Pressure/Precipitation data (lower left) and Relative Humidity/Showalter Index data (lower right).</li>
        <li><a href="/archive/sst/index.php" class="red"> SST Plot</a> - Sea Surface Temperature plots (including anomalies) archived on a weekly basis.</li>
      </ul>
    </li>
    <li><a href="/usgs/index.php" class="purple"> USGS Maps</a> - A set of USGS maps made from DEM (Digital Elevation Model) data and overlaid with roads from the DLG (Digital Line Graph) data set. </li>
  </ul>
<div class="clearboth">&nbsp;</div>

</div>

<div id="footer"> <span id="copyright"><small>Copyright &copy; Unisys 2012</small></span>
  <ul class="inline-navigation-list" id="bottom-navigation">
    <li><a href="http://www.unisys.com/unisys/privacy.html" target="_blank">Privacy Notice</a></li>
    <li><a href="http://www.unisys.com/unisys/terms-and-conditions.html" target="_blank">Terms of Use</a></li>
    <li><a href="/contactus.php">Contact Us</a></li>
    <li><a href="http://www.unisys.com/unisys/trademarks.html" target="_blank">Trademarks</a></li>
  </ul>
</div>
</div>
</body>
</html>
