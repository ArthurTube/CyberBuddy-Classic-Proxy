<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Unisys Weather </title>
<meta name="description" content="The intent of this weather site is to provide a complete source of graphical weather 		information. This is intended to satisfy the needs of the weather professional, but can be a tool for the casual user as well. The graphics and data are displayed as a meteorologist would expect to see. For the novice user, there are detailed explanation pages to guide them through the various plots, charts and images. The data on this site are provided from the National Weather Service via the NOAAPORT satellite data service. All the images are generated using the Weather Processor (WXP) analysis package which is available from Unisys. "/>
<meta name="keywords" content="weather, unisys, unisys weather, weather maps, maps, nam, wrf, GFS, GFSx, hurricane, radar, satellite, surface, upper air" />
<meta name="copyright" content="Unisys Corp - 2011" />
<meta name="author" content="Unisys Corporation" />
<meta name="email" content="technical-support@weather.unisys.com" />
<meta name="Distribution" content="Global" />
<meta name="Rating" content="General" />
<meta name="Robots" content="INDEX,FOLLOW" />
<meta name="Revisit-after" content="7 Days" />
<meta http-equiv="Content-type" content="text/html;charset=UTF-8" />
<meta http-equiv="imagetoolbar" content="no" />
<meta http-equiv="Refresh" content="900" />
<meta http-equiv="X-UA-Compatible" content="IE=8"/>
<link rel="stylesheet" type="text/css" href="/css/WMAX.css" />

<link rel="stylesheet" type="text/css" href="/css/amstabs.css" />

</head>
<body>
<div id="wrapwide">
<div>
  <ul id="top-navigation" class="inline-navigation-list">
    <li><a href="http://www.unisys.com" title="Unisys">Unisys.com</a></li>
    <li><a href="/index.php" title="Unisys Weather">Weather Home</a></li>
    <li><a href="/analyses.php" title="Analyses">Analyses</a></li>
    <li><a href="/forehome.php" title="Forecast">Forecasts</a></li>
    <li><a href="/links.php" title="NOAA Links">NOAA Links</a></li>
    <li><a href="/archives.php" title="Archives">Archives</a></li>
    <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
  </ul>
</div>

<div id="header"> <a href="http://unisys.com"><img src="/images/Unisys_logo.gif" alt="Unisys" /></a>
  <h1>Unisys Weather</h1>
</div>

<div id="leftside">
  <ul class="avmenu">
    <li><a href="/index.php" class="purple">Unisys Weather</a></li>
    <li><a href="/index.php"> Weather Home</a></li>
    <li><a href="/solutions/index.php">Weather Solutions</a></li>
    <li><a href="/mobile/index.php"><img id="mobile_icon" src="/mobile/Icon.png" width="24" height="24" alt="Download Unisys Weather Mobile App"/>iPhone App</a></li>
    <li><a href="/info/index.php">Information</a></li>
    <li><a href="/content.php">Contents</a></li>
    <li><a href="/analyses.php" class="purple">Analyses</a></li>
    <li><a href="/satellite/index.php">Satellite Images</a></li>
    <li><a href="/surface/index.php">Surface Data</a></li>
    <li><a href="/upper_air/index.php">Upper Air Data</a></li>
    <li><a href="/radar/index.php">Radar Data</a></li>
    <li><a href="/forehome.php" class="purple">Forecasts</a></li>
    <li><a href="/mos/index.php">Model Statistics</a></li>
    <li><a href="/nam/index.php">NAM/Wrf Model</a></li>
    <li><a href="/gfs/index.php?r=us">GFS/Avn Model</a></li>
    <li><a href="/gfsx/index.php?r=us">GFSx/MRF Model</a></li>
    <li><a href="/rap/index.php">RAP Model</a></li>
    <li><a href="/ecmwf/index.php">ECMWF Model</a></li>
    <li><a href="/archives.php" class="purple">Archive</a></li>
    <li><a href="/hurricane/index.php">Hurricane Data</a></li>
    <li><a href="/archive/index.php">Archive of Images</a></li>
    <li><a href="/usgs/index.php">USGS Maps</a></li>
  </ul>
</div>

<div id="extras">
  <ul class="avmenu">
    <li><a href="/foresetup.php" class="purple">Get a Forecast</a></li>
  </ul>

<script type="text/javascript">
function fsubmit()
{
     document.getElementById("Forecast").submit();
}
</script>

  <form method="get" id="Forecast" action="/forecast.php">
    <p class="center"> Enter a zip code or city name to get forecast:
      <input type="text" name="Name" id="Name" size="15" />
      <br />
      <button type="submit" style="border:none; background-color:transparent;">
         <img src="/images/GO.png" id="Go" alt="Get Forecast Data" style="height:30px;" />
      </button>
      <a href="/foresetup.php"><img src="/images/setup.png" alt="Setup Location" height="30" width="70" /></a> </p>
  </form>
  <script type="text/javascript">
                <!-- HIDE
                var index = document.cookie.indexOf("ZIP")
                var zipcode = 0
                var region = ""
                if( index != -1 ){
                   //zipcode = parseInt( document.cookie.substring(index+4,index+9),10)
                   zipcode = document.cookie.substring(index+4,index+9)
                   var validateZipCode = function() {
                     var zipcodeRegexp = /^\d{5}$/;
                     var zipTest = zipcodeRegexp.test(zipcode);
   
                     if (zipTest == false) {
                       return false;
                     }
                   }
                   validateZipCode();

                    if( ! isNaN(zipcode))

                    document.getElementById('Name').value = zipcode

                   if( zipcode >= 01000 && zipcode <= 19699 )
                      region = "ne"
                   else if( zipcode >= 19700 && zipcode <= 28999 )
                      region = "at"
                   else if( zipcode >= 43000 && zipcode <= 45999 )
                      region = "at"
                   else if( zipcode >= 29000 && zipcode <= 36999 )
                      region = "se"
                   else if( zipcode >= 38600 && zipcode <= 39999 )
                      region = "se"
                   else if( zipcode >= 46000 && zipcode <= 58999 )
                      region = "mw"
                   else if( zipcode >= 60000 && zipcode <= 62999 )
                      region = "mw"
                   else if( zipcode >= 68000 && zipcode <= 69999 )
                      region = "mw"
                   else if( zipcode >= 63000 && zipcode <= 67999 )
                      region = "cp"
                   else if( zipcode >= 71600 && zipcode <= 74999 )
                      region = "cp"
                   else if( zipcode >= 70000 && zipcode <= 71499 )
                      region = "sp"
                   else if( zipcode >= 75000 && zipcode <= 79999 )
                      region = "sp"
                   else if( zipcode >= 59000 && zipcode <= 59999 )
                      region = "nw"
                   else if( zipcode >= 82000 && zipcode <= 83999 )
                      region = "nw"
                   else if( zipcode >= 97000 && zipcode <= 99499 )
                      region = "nw"
                   else if( zipcode >= 80000 && zipcode <= 81999 )
                      region = "sw"
                   else if( zipcode >= 84000 && zipcode <= 96199 )
                      region = "sw"

                   if( region != "" ){
                      document.write( "<table border=\"0\" align=\"center\" class=\"grey\" width=\"100%\">" )
                      document.write( "<tr>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/surface/sfc_map.php?image=sfc&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Sfc" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=\"radar/rad" + region + ".php\">" )
                      document.write( "<a href=/radar/rcm_rad.php?image=rad&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Rad" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=vis&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Vis" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=enh&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>IR" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "</tr></table>" )
                      document.write( "</b>" )
                      }


                   
                   }
                // UNHIDE -->
                </script>
  <ul class="avmenu">
    <li><a href="/links.php" class="purple">NOAA Links</a></li>
    <li><a href="http://lwf.ncdc.noaa.gov/">National Climatic Data Center</a></li>
    <li><a href="http://www.cpc.noaa.gov/">Climate Prediction Center</a></li>
    <li><a href="http://oceanservice.noaa.gov/">National Ocean Service</a></li>
    <li><a href="http://www.lib.noaa.gov/">NOAA Library</a></li>
    <li><a href="http://www.oar.noaa.gov/">NOAA Office of Oceanic and Atmospheric Research</a></li>
    <li><a href="http://www.esrl.noaa.gov/">Earth Systems Research Laboratory</a></li>
    <li><a href="/overview.php" class="purple">About Us</a></li>
    <li><a href="/overview.php" title="Contact Us">Overview</a></li>
    <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
  </ul>
</div>
<div id="content">

<h2>USGS Digitial Elevation Maps</h2>
<p>
These maps are based on the 1 minute USGS digital elevation (DEM) database which
is available via FTP or CD-ROM. The data was read in and decoded into a WXP grid file and
contoured with WXP's contour program. Some of the maps are also overlaid with state,
county outlines, roads, and rivers. This information is derived from the USGS
digital line graph (DLG) database.
</p>
<p><b>USGS Digitial Elevation Maps</b></p>
<p>
<a href="/usgs/relief.php"> <b>Grayscale relief maps</b></a> - highlights elevation giving a 3 dimensional appearance.<br/>
<a href="/usgs/3sec/index.php"> <b>High resolution DEM maps (3 second resolution)</b></a>
</p>
<p>
<map id="usgs_map" name="usgs_map">
<area shape="rect" coords="572,386,641,479" href="/usgs/usgs-30-80.gif" alt=""/>
<area shape="rect" coords="511,386,576,478" href="/usgs/usgs-30-85.gif" alt=""/>
<area shape="rect" coords="447,387,511,479" href="/usgs/usgs-30-90.gif" alt=""/>
<area shape="rect" coords="383,386,447,479" href="/usgs/usgs-30-95.gif" alt=""/>
<area shape="rect" coords="318,387,383,480" href="/usgs/usgs-30-100.gif" alt=""/>
<area shape="rect" coords="254,387,319,478" href="/usgs/usgs-30-105.gif" alt=""/>
<area shape="rect" coords="190,387,256,478" href="/usgs/usgs-30-110.gif" alt=""/>
<area shape="rect" coords="576,299,640,390" href="/usgs/usgs-35-80.gif" alt=""/>
<area shape="rect" coords="511,298,575,389" href="/usgs/usgs-35-85.gif" alt=""/>
<area shape="rect" coords="445,298,512,389" href="/usgs/usgs-35-90.gif" alt=""/>
<area shape="rect" coords="382,298,447,388" href="/usgs/usgs-35-95.gif" alt=""/>
<area shape="rect" coords="318,299,384,389" href="/usgs/usgs-35-100.gif" alt=""/>
<area shape="rect" coords="254,298,320,390" href="/usgs/usgs-35-105.gif" alt=""/>
<area shape="rect" coords="189,297,255,389" href="/usgs/usgs-35-110.gif" alt=""/>
<area shape="rect" coords="127,298,191,390" href="/usgs/usgs-35-115.gif" alt=""/>
<area shape="rect" coords="62,298,128,388" href="/usgs/usgs-35-120.gif" alt=""/>
<area shape="rect" coords="0,298,64,389" href="/usgs/usgs-35-125.gif" alt=""/>
<area shape="rect" coords="638,211,702,300" href="/usgs/usgs-40-75.gif" alt=""/>
<area shape="rect" coords="575,210,640,299" href="/usgs/usgs-40-80.gif" alt=""/>
<area shape="rect" coords="511,211,576,300" href="/usgs/usgs-40-85.gif" alt=""/>
<area shape="rect" coords="447,210,512,300" href="/usgs/usgs-40-90.gif" alt=""/>
<area shape="rect" coords="383,210,448,301" href="/usgs/usgs-40-95.gif" alt=""/>
<area shape="rect" coords="319,210,383,300" href="/usgs/usgs-40-100.gif" alt=""/>
<area shape="rect" coords="255,210,320,300" href="/usgs/usgs-40-105.gif" alt=""/>
<area shape="rect" coords="192,209,255,300" href="/usgs/usgs-40-110.gif" alt=""/>
<area shape="rect" coords="128,210,192,301" href="/usgs/usgs-40-115.gif" alt=""/>
<area shape="rect" coords="63,210,128,300" href="/usgs/usgs-40-120.gif" alt=""/>
<area shape="rect" coords="0,211,64,300" href="/usgs/usgs-40-125.gif" alt=""/>
<area shape="rect" coords="703,121,767,212" href="/usgs/usgs-45-70.gif" alt=""/>
<area shape="rect" coords="639,122,703,210" href="/usgs/usgs-45-75.gif" alt=""/>
<area shape="rect" coords="575,121,639,212" href="/usgs/usgs-45-80.gif" alt=""/>
<area shape="rect" coords="510,122,576,212" href="/usgs/usgs-45-85.gif" alt=""/>
<area shape="rect" coords="446,122,512,212" href="/usgs/usgs-45-90.gif" alt=""/>
<area shape="rect" coords="383,122,447,212" href="/usgs/usgs-45-95.gif" alt=""/>
<area shape="rect" coords="319,122,384,212" href="/usgs/usgs-45-100.gif" alt=""/>
<area shape="rect" coords="254,122,321,212" href="/usgs/usgs-45-105.gif" alt=""/>
<area shape="rect" coords="192,123,255,212" href="/usgs/usgs-45-110.gif" alt=""/>
<area shape="rect" coords="127,120,193,212" href="/usgs/usgs-45-115.gif" alt=""/>
<area shape="rect" coords="62,123,128,212" href="/usgs/usgs-45-120.gif" alt=""/>
<area shape="rect" coords="0,122,63,211" href="/usgs/usgs-45-125.gif" alt=""/>
<area shape="rect" coords="703,34,767,123" href="/usgs/usgs-50-70.gif" alt=""/>
<area shape="rect" coords="640,34,703,123" href="/usgs/usgs-50-75.gif" alt=""/>
<area shape="rect" coords="576,33,638,123" href="/usgs/usgs-50-80.gif" alt=""/>
<area shape="rect" coords="510,33,576,124" href="/usgs/usgs-50-85.gif" alt=""/>
<area shape="rect" coords="447,34,511,123" href="/usgs/usgs-50-90.gif" alt=""/>
<area shape="rect" coords="383,33,447,124" href="/usgs/usgs-50-95.gif" alt=""/>
<area shape="rect" coords="319,34,384,123" href="/usgs/usgs-50-100.gif" alt=""/>
<area shape="rect" coords="255,33,318,123" href="/usgs/usgs-50-105.gif" alt=""/>
<area shape="rect" coords="193,33,256,124" href="/usgs/usgs-50-110.gif" alt=""/>
<area shape="rect" coords="126,32,192,122" href="/usgs/usgs-50-115.gif" alt=""/>
<area shape="rect" coords="64,33,127,122" href="/usgs/usgs-50-120.gif" alt=""/>
<area shape="rect" coords="1,33,61,123" href="/usgs/usgs-50-125.gif" alt=""/>
</map>
<img src="/usgs/usgs-US.gif" usemap="#usgs_map" alt="Click on image to get map" border="0" height="512" width="768"/>
</p>
<p><b>Click anywhere on the map to get a more detailed map. </b></p>
<p>The elevations correspond to the following legend: </p>
<p><img src="/usgs/legend.gif" height="75" width="660" alt="Map Legend" /> </p>
<p>Overlaid on the elevation map are data from the USGS DLG (Digital Line Graphics)
database. The database offers locations of states, counties, roads, railroads, parks,
forests, rivers and lakes. Plotted on these maps are: <br/>
<b>White</b> - State, country, coast outlines<br/>
<b>Gray</b> - County outlines<br/>
<b>Black</b> - Rivers and major streams<br/>
<b>Red</b> - US Highways<br/>
<b>Light red</b> - Interstate Highways<br/>
<b>Magenta</b> - National Parks and Monuments<br/>
</p>


<div class="clearboth">&nbsp;</div>

</div>

<div id="footer"> <span id="copyright"><small>Copyright &copy; Unisys 2012</small></span>
  <ul class="inline-navigation-list" id="bottom-navigation">
    <li><a href="http://www.unisys.com/unisys/privacy.html" target="_blank">Privacy Notice</a></li>
    <li><a href="http://www.unisys.com/unisys/terms-and-conditions.html" target="_blank">Terms of Use</a></li>
    <li><a href="/contactus.php">Contact Us</a></li>
    <li><a href="http://www.unisys.com/unisys/trademarks.html" target="_blank">Trademarks</a></li>
  </ul>
</div>
</div>
</body>
</html>
