<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Unisys Weather  - Radar Data Details</title>
<meta name="description" content="The intent of this weather site is to provide a complete source of graphical weather 		information. This is intended to satisfy the needs of the weather professional, but can be a tool for the casual user as well. The graphics and data are displayed as a meteorologist would expect to see. For the novice user, there are detailed explanation pages to guide them through the various plots, charts and images. The data on this site are provided from the National Weather Service via the NOAAPORT satellite data service. All the images are generated using the Weather Processor (WXP) analysis package which is available from Unisys. "/>
<meta name="keywords" content="weather, unisys, unisys weather, weather maps, maps, nam, wrf, GFS, GFSx, hurricane, radar, satellite, surface, upper air" />
<meta name="copyright" content="Unisys Corp - 2011" />
<meta name="author" content="Unisys Corporation" />
<meta name="email" content="technical-support@weather.unisys.com" />
<meta name="Distribution" content="Global" />
<meta name="Rating" content="General" />
<meta name="Robots" content="INDEX,FOLLOW" />
<meta name="Revisit-after" content="7 Days" />
<meta http-equiv="Content-type" content="text/html;charset=UTF-8" />
<meta http-equiv="imagetoolbar" content="no" />
<meta http-equiv="Refresh" content="900" />
<meta http-equiv="X-UA-Compatible" content="IE=8"/>
<link rel="stylesheet" type="text/css" href="/css/WMAX.css" />
</head>
<body>
<div id="wrap">
  <div id="top-menu">
    <ul id="top-navigation" class="inline-navigation-list">
      <li><a href="http://www.unisys.com" title="Unisys Home Page">Unisys.com</a></li>
      <li><a href="/index.php" title="Unisys Weather">Weather Home</a></li>
      <li><a href="/analyses.php" title="Analyses">Analyses</a></li>
      <li><a href="/forehome.php" title="Forecast">Forecasts</a></li>
      <li><a href="/archives.php" title="Archives">Archives</a></li>
      <li><a href="/links.php" title="NOAA Links">NOAA Links</a></li>
      <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
    </ul>
  </div>

  <div id="header"> <a href="http://unisys.com"><img src="/images/Unisys_logo.gif" alt="Unisys" /></a>
    <h1>Unisys Weather</h1>
  </div>

<div id="leftside">
  <ul class="avmenu">
    <li><a href="/index.php" class="purple">Unisys Weather</a></li>
    <li><a href="/index.php"> Weather Home</a></li>
    <li><a href="/solutions/index.php">Weather Solutions</a></li>
    <li><a href="/mobile/index.php"><img id="mobile_icon" src="/mobile/Icon.png" width="24" height="24" alt="Download Unisys Weather Mobile App"/>iPhone App</a></li>
    <li><a href="/info/index.php">Information</a></li>
    <li><a href="/content.php">Contents</a></li>
    <li><a href="/analyses.php" class="purple">Analyses</a></li>
    <li><a href="/satellite/index.php">Satellite Images</a></li>
    <li><a href="/surface/index.php">Surface Data</a></li>
    <li><a href="/upper_air/index.php">Upper Air Data</a></li>
    <li><a href="/radar/index.php">Radar Data</a></li>
    <li><a href="/forehome.php" class="purple">Forecasts</a></li>
    <li><a href="/mos/index.php">Model Statistics</a></li>
    <li><a href="/nam/index.php">NAM/Wrf Model</a></li>
    <li><a href="/gfs/index.php?r=us">GFS/Avn Model</a></li>
    <li><a href="/gfsx/index.php?r=us">GFSx/MRF Model</a></li>
    <li><a href="/rap/index.php">RAP Model</a></li>
    <li><a href="/ecmwf/index.php">ECMWF Model</a></li>
    <li><a href="/archives.php" class="purple">Archive</a></li>
    <li><a href="/hurricane/index.php">Hurricane Data</a></li>
    <li><a href="/archive/index.php">Archive of Images</a></li>
    <li><a href="/usgs/index.php">USGS Maps</a></li>
  </ul>
</div>

<div id="extras">
  <ul class="avmenu">
    <li><a href="/foresetup.php" class="purple">Get a Forecast</a></li>
  </ul>

<script type="text/javascript">
function fsubmit()
{
     document.getElementById("Forecast").submit();
}
</script>

  <form method="get" id="Forecast" action="/forecast.php">
    <p class="center"> Enter a zip code or city name to get forecast:
      <input type="text" name="Name" id="Name" size="15" />
      <br />
      <button type="submit" style="border:none; background-color:transparent;">
         <img src="/images/GO.png" id="Go" alt="Get Forecast Data" style="height:30px;" />
      </button>
      <a href="/foresetup.php"><img src="/images/setup.png" alt="Setup Location" height="30" width="70" /></a> </p>
  </form>
  <script type="text/javascript">
                <!-- HIDE
                var index = document.cookie.indexOf("ZIP")
                var zipcode = 0
                var region = ""
                if( index != -1 ){
                   //zipcode = parseInt( document.cookie.substring(index+4,index+9),10)
                   zipcode = document.cookie.substring(index+4,index+9)
                   var validateZipCode = function() {
                     var zipcodeRegexp = /^\d{5}$/;
                     var zipTest = zipcodeRegexp.test(zipcode);
   
                     if (zipTest == false) {
                       return false;
                     }
                   }
                   validateZipCode();

                    if( ! isNaN(zipcode))

                    document.getElementById('Name').value = zipcode

                   if( zipcode >= 01000 && zipcode <= 19699 )
                      region = "ne"
                   else if( zipcode >= 19700 && zipcode <= 28999 )
                      region = "at"
                   else if( zipcode >= 43000 && zipcode <= 45999 )
                      region = "at"
                   else if( zipcode >= 29000 && zipcode <= 36999 )
                      region = "se"
                   else if( zipcode >= 38600 && zipcode <= 39999 )
                      region = "se"
                   else if( zipcode >= 46000 && zipcode <= 58999 )
                      region = "mw"
                   else if( zipcode >= 60000 && zipcode <= 62999 )
                      region = "mw"
                   else if( zipcode >= 68000 && zipcode <= 69999 )
                      region = "mw"
                   else if( zipcode >= 63000 && zipcode <= 67999 )
                      region = "cp"
                   else if( zipcode >= 71600 && zipcode <= 74999 )
                      region = "cp"
                   else if( zipcode >= 70000 && zipcode <= 71499 )
                      region = "sp"
                   else if( zipcode >= 75000 && zipcode <= 79999 )
                      region = "sp"
                   else if( zipcode >= 59000 && zipcode <= 59999 )
                      region = "nw"
                   else if( zipcode >= 82000 && zipcode <= 83999 )
                      region = "nw"
                   else if( zipcode >= 97000 && zipcode <= 99499 )
                      region = "nw"
                   else if( zipcode >= 80000 && zipcode <= 81999 )
                      region = "sw"
                   else if( zipcode >= 84000 && zipcode <= 96199 )
                      region = "sw"

                   if( region != "" ){
                      document.write( "<table border=\"0\" align=\"center\" class=\"grey\" width=\"100%\">" )
                      document.write( "<tr>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/surface/sfc_map.php?image=sfc&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Sfc" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=\"radar/rad" + region + ".php\">" )
                      document.write( "<a href=/radar/rcm_rad.php?image=rad&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Rad" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=vis&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Vis" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=enh&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>IR" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "</tr></table>" )
                      document.write( "</b>" )
                      }


                   
                   }
                // UNHIDE -->
                </script>
  <ul class="avmenu">
    <li><a href="/links.php" class="purple">NOAA Links</a></li>
    <li><a href="http://lwf.ncdc.noaa.gov/">National Climatic Data Center</a></li>
    <li><a href="http://www.cpc.noaa.gov/">Climate Prediction Center</a></li>
    <li><a href="http://oceanservice.noaa.gov/">National Ocean Service</a></li>
    <li><a href="http://www.lib.noaa.gov/">NOAA Library</a></li>
    <li><a href="http://www.oar.noaa.gov/">NOAA Office of Oceanic and Atmospheric Research</a></li>
    <li><a href="http://www.esrl.noaa.gov/">Earth Systems Research Laboratory</a></li>
    <li><a href="/overview.php" class="purple">About Us</a></li>
    <li><a href="/overview.php" title="Contact Us">Overview</a></li>
    <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
  </ul>
</div>
<div id="content">
<h2>Radar Data Details</h2>

<p>There are several types of radar data including Manually 
Digitized Radar (MDR), Radar Coded Messages (RCM) and NEXRAD data (NIDS). 
These data come from meteorological radars placed at various locations across 
the US. The RCM messages are combined into a national mosaic which is what 
is presented below. The images are updated twice an hour at :05 and :35.</p>

<hr />
<a name="rcm"></a><h3>Radar Coded Message Plots</h3>

<p>These data come from NEXRAD doppler radars placed at 
various locations across the US.  Each radar site reports a digitized 
assessment of the precipitation echoes displayed on the radar summary. 
Precipitation intensity is determined based on a scale from 1 (light) to 6 
(extremely heavy). This information is recorded on a grid which covers the 
country and has a spacing of around 12 kilometers. This is coarse compared to 
the radar which can get detail of around 1 kilometer. The radar also reports 
echo tops, storm movement, hail probability and location of tornado vortex 
signatures (TVS) and mesocylones (MESO). Both TVS and MESO indicate the 
location of rotating areas of winds within the thunderstorm complex. TVS 
signatures are more concentrated and can indicate the potential for the 
development of a tornado.</p>

<p>Also, the National Weather Service provides information 
about severe weather watch boxes (either Severe Thunderstorm or Tornado) 
which can then be plotted on the radar summary. These data are updated twice 
an hour at 15 and 45 past the hour. </p>

<a name="composite"></a><h3>Composite Radar Summary</h3>

<p><img src="/radar/images/rcm_sample.gif" alt="RCM_Sample" height="209" width="310" /></p>

<p><img src="/radar/images/rcm_legend.gif" alt="Sample composite radar summary" height="19" width="352" /><br/><i>Sample composite radar summary</i> </p>

<p>The composite radar summary is a plot of most of the 
available information broadcast as part of the RCM radar data. </p>

<p><b>Radar summary</b><br/>
The first plot is the actual radar summary. The radar summary displays areas 
where precipitation is falling. The intensity is based on color where:<br/>
<img src="/radar/images/radar_lgnd.gif" alt="Radar_Lgnd" height="103" width="148" /> </p>

<table border="1">
  <tr>
    <td><b>Color</b></td>
    <td><b>Dbz</b></td>
    <td><b>Intensity</b></td>
    <td><b>Description</b></td>
  </tr>
  <tr>
    <td><b>DGreen</b></td>
    <td>~20</td>
    <td>Light</td>
    <td>light rain or snow</td>
  </tr>
  <tr>
    <td><b>MGreen</b></td>
    <td>~30</td>
    <td>Moderate</td>
    <td></td>
  </tr>
  <tr>
    <td><b>BGreen</b></td>
    <td>~40</td>
    <td>Heavy</td>
    <td>light thunderstorms/moderate rain showers</td>
  </tr>
  <tr>
    <td><b>Yellow</b></td>
    <td>~45</td>
    <td>Very Heavy</td>
    <td>moderate thunderstorms</td>
  </tr>
  <tr>
    <td><b>Orange</b></td>
    <td>~50</td>
    <td>Intense</td>
    <td>potential flooding rains/strong thunderstorms</td>
  </tr>
  <tr>
    <td><b>Red</b></td>
    <td>&gt;55</td>
    <td>Extreme</td>
    <td>flooding rains/potential severe thunderstorm</td>
  </tr>
</table>

<p>Radar sites that don't report precipitation can report 
either: </p>

<p>
<b>NE</b> - No echos/precipitation within the radar range.<br/>
<b>NA</b> - Radar data not available.<br/>
<b>OM</b> - Radar inoperative due to maintenance.</p>

<p><b>Storm movement</b><br/>
The next type of data is the individual storm movement which is plotted as 
a wind barb (See Weather Symbol Legend). This indicates how fast and in what 
direction the individual storms are moving. </p>

<p><b>Precipitation tops</b><br/>
The next type of data is the precipitation tops which are plotted over the 
top as a number in 100s of feet. This is the maximum altitude of the 
precipitation as seen by the radar.  This can range from 10,000 feet in 
snow showers to 20,000 with rain showers to 40,000 feet with thunderstorms. 
Severe thunderstorm tops can reach 50,000 to 70,000 feet. </p>

<p><b>Severe weather watch boxes</b><br/>
The last type of data are the severe weather watch boxes. The area covered 
by the watch is enclosed by a white box. The watch number and type as well 
as the expiration time are also listed.</p>

<table border="1">
  <tr>
    <td><b>T335<br/> to 5Z</b></td>
    <td valign="top">Specifies a tornado watch #335 which expires at 5Z</td>
  </tr>
  <tr>
    <td><b>S336<br/> to 8Z</b></td>
    <td valign="top">Specifies a severe thunderstorm watch #336 which expires at 8Z</td>
  </tr>
</table>
<div class="clearboth">&nbsp;</div>

</div>

<div id="footer"> <span id="copyright"><small>Copyright &copy; Unisys 2012</small></span>
  <ul class="inline-navigation-list" id="bottom-navigation">
    <li><a href="http://www.unisys.com/unisys/privacy.html" target="_blank">Privacy Notice</a></li>
    <li><a href="http://www.unisys.com/unisys/terms-and-conditions.html" target="_blank">Terms of Use</a></li>
    <li><a href="/contactus.php">Contact Us</a></li>
    <li><a href="http://www.unisys.com/unisys/trademarks.html" target="_blank">Trademarks</a></li>
  </ul>
</div>
</div>
</body>
</html>
