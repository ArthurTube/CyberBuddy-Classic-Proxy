<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Unisys Weather </title>
<meta name="description" content="The intent of this weather site is to provide a complete source of graphical weather 		information. This is intended to satisfy the needs of the weather professional, but can be a tool for the casual user as well. The graphics and data are displayed as a meteorologist would expect to see. For the novice user, there are detailed explanation pages to guide them through the various plots, charts and images. The data on this site are provided from the National Weather Service via the NOAAPORT satellite data service. All the images are generated using the Weather Processor (WXP) analysis package which is available from Unisys. "/>
<meta name="keywords" content="weather, unisys, unisys weather, weather maps, maps, nam, wrf, GFS, GFSx, hurricane, radar, satellite, surface, upper air" />
<meta name="copyright" content="Unisys Corp - 2011" />
<meta name="author" content="Unisys Corporation" />
<meta name="email" content="technical-support@weather.unisys.com" />
<meta name="Distribution" content="Global" />
<meta name="Rating" content="General" />
<meta name="Robots" content="INDEX,FOLLOW" />
<meta name="Revisit-after" content="7 Days" />
<meta http-equiv="Content-type" content="text/html;charset=UTF-8" />
<meta http-equiv="imagetoolbar" content="no" />
<meta http-equiv="Refresh" content="900" />
<meta http-equiv="X-UA-Compatible" content="IE=8"/>
<link rel="stylesheet" type="text/css" href="/css/WMAX.css" />
</head>
<body>
<div id="wrap">
  <div id="top-menu">
    <ul id="top-navigation" class="inline-navigation-list">
      <li><a href="http://www.unisys.com" title="Unisys Home Page">Unisys.com</a></li>
      <li><a href="/index.php" title="Unisys Weather">Weather Home</a></li>
      <li><a href="/analyses.php" title="Analyses">Analyses</a></li>
      <li><a href="/forehome.php" title="Forecast">Forecasts</a></li>
      <li><a href="/archives.php" title="Archives">Archives</a></li>
      <li><a href="/links.php" title="NOAA Links">NOAA Links</a></li>
      <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
    </ul>
  </div>

  <div id="header"> <a href="http://unisys.com"><img src="/images/Unisys_logo.gif" alt="Unisys" /></a>
    <h1>Unisys Weather</h1>
  </div>

<div id="leftside">
  <ul class="avmenu">
    <li><a href="/index.php" class="purple">Unisys Weather</a></li>
    <li><a href="/index.php"> Weather Home</a></li>
    <li><a href="/solutions/index.php">Weather Solutions</a></li>
    <li><a href="/mobile/index.php"><img id="mobile_icon" src="/mobile/Icon.png" width="24" height="24" alt="Download Unisys Weather Mobile App"/>iPhone App</a></li>
    <li><a href="/info/index.php">Information</a></li>
    <li><a href="/content.php">Contents</a></li>
    <li><a href="/analyses.php" class="purple">Analyses</a></li>
    <li><a href="/satellite/index.php">Satellite Images</a></li>
    <li><a href="/surface/index.php">Surface Data</a></li>
    <li><a href="/upper_air/index.php">Upper Air Data</a></li>
    <li><a href="/radar/index.php">Radar Data</a></li>
    <li><a href="/forehome.php" class="purple">Forecasts</a></li>
    <li><a href="/mos/index.php">Model Statistics</a></li>
    <li><a href="/nam/index.php">NAM/Wrf Model</a></li>
    <li><a href="/gfs/index.php?r=us">GFS/Avn Model</a></li>
    <li><a href="/gfsx/index.php?r=us">GFSx/MRF Model</a></li>
    <li><a href="/rap/index.php">RAP Model</a></li>
    <li><a href="/ecmwf/index.php">ECMWF Model</a></li>
    <li><a href="/archives.php" class="purple">Archive</a></li>
    <li><a href="/hurricane/index.php">Hurricane Data</a></li>
    <li><a href="/archive/index.php">Archive of Images</a></li>
    <li><a href="/usgs/index.php">USGS Maps</a></li>
  </ul>
</div>

<div id="extras">
  <ul class="avmenu">
    <li><a href="/foresetup.php" class="purple">Get a Forecast</a></li>
  </ul>

<script type="text/javascript">
function fsubmit()
{
     document.getElementById("Forecast").submit();
}
</script>

  <form method="get" id="Forecast" action="/forecast.php">
    <p class="center"> Enter a zip code or city name to get forecast:
      <input type="text" name="Name" id="Name" size="15" />
      <br />
      <button type="submit" style="border:none; background-color:transparent;">
         <img src="/images/GO.png" id="Go" alt="Get Forecast Data" style="height:30px;" />
      </button>
      <a href="/foresetup.php"><img src="/images/setup.png" alt="Setup Location" height="30" width="70" /></a> </p>
  </form>
  <script type="text/javascript">
                <!-- HIDE
                var index = document.cookie.indexOf("ZIP")
                var zipcode = 0
                var region = ""
                if( index != -1 ){
                   //zipcode = parseInt( document.cookie.substring(index+4,index+9),10)
                   zipcode = document.cookie.substring(index+4,index+9)
                   var validateZipCode = function() {
                     var zipcodeRegexp = /^\d{5}$/;
                     var zipTest = zipcodeRegexp.test(zipcode);
   
                     if (zipTest == false) {
                       return false;
                     }
                   }
                   validateZipCode();

                    if( ! isNaN(zipcode))

                    document.getElementById('Name').value = zipcode

                   if( zipcode >= 01000 && zipcode <= 19699 )
                      region = "ne"
                   else if( zipcode >= 19700 && zipcode <= 28999 )
                      region = "at"
                   else if( zipcode >= 43000 && zipcode <= 45999 )
                      region = "at"
                   else if( zipcode >= 29000 && zipcode <= 36999 )
                      region = "se"
                   else if( zipcode >= 38600 && zipcode <= 39999 )
                      region = "se"
                   else if( zipcode >= 46000 && zipcode <= 58999 )
                      region = "mw"
                   else if( zipcode >= 60000 && zipcode <= 62999 )
                      region = "mw"
                   else if( zipcode >= 68000 && zipcode <= 69999 )
                      region = "mw"
                   else if( zipcode >= 63000 && zipcode <= 67999 )
                      region = "cp"
                   else if( zipcode >= 71600 && zipcode <= 74999 )
                      region = "cp"
                   else if( zipcode >= 70000 && zipcode <= 71499 )
                      region = "sp"
                   else if( zipcode >= 75000 && zipcode <= 79999 )
                      region = "sp"
                   else if( zipcode >= 59000 && zipcode <= 59999 )
                      region = "nw"
                   else if( zipcode >= 82000 && zipcode <= 83999 )
                      region = "nw"
                   else if( zipcode >= 97000 && zipcode <= 99499 )
                      region = "nw"
                   else if( zipcode >= 80000 && zipcode <= 81999 )
                      region = "sw"
                   else if( zipcode >= 84000 && zipcode <= 96199 )
                      region = "sw"

                   if( region != "" ){
                      document.write( "<table border=\"0\" align=\"center\" class=\"grey\" width=\"100%\">" )
                      document.write( "<tr>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/surface/sfc_map.php?image=sfc&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Sfc" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=\"radar/rad" + region + ".php\">" )
                      document.write( "<a href=/radar/rcm_rad.php?image=rad&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Rad" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=vis&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Vis" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=enh&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>IR" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "</tr></table>" )
                      document.write( "</b>" )
                      }


                   
                   }
                // UNHIDE -->
                </script>
  <ul class="avmenu">
    <li><a href="/links.php" class="purple">NOAA Links</a></li>
    <li><a href="http://lwf.ncdc.noaa.gov/">National Climatic Data Center</a></li>
    <li><a href="http://www.cpc.noaa.gov/">Climate Prediction Center</a></li>
    <li><a href="http://oceanservice.noaa.gov/">National Ocean Service</a></li>
    <li><a href="http://www.lib.noaa.gov/">NOAA Library</a></li>
    <li><a href="http://www.oar.noaa.gov/">NOAA Office of Oceanic and Atmospheric Research</a></li>
    <li><a href="http://www.esrl.noaa.gov/">Earth Systems Research Laboratory</a></li>
    <li><a href="/overview.php" class="purple">About Us</a></li>
    <li><a href="/overview.php" title="Contact Us">Overview</a></li>
    <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
  </ul>
</div>
<div id="content">

<font face="Arial, Helvetica, sans-serif"><big><b>Date/Time Information</b></big></font>

<p><font face="Arial, Helvetica, sans-serif"><small>All times listed on the plots will have the following format: </small></font></p>

<pre>   12Z 14 OCT 01
   HHZ DD MMM YY
      where: HH is the Universal Time
             DD is the day of the month
            MMM is the month of the year
             YY is the year.</pre>

<p><font face="Arial, Helvetica, sans-serif"><small>Some plots will have a valid time listed such as: </small></font></p>

<pre>24 hour Eta valid 12Z 14 FEB 02</pre>

<p><font face="Arial, Helvetica, sans-serif"><small>The first part specifies how many hours beyond the initial 
time of observation the forecast is valid for. The label Eta specifies this 
is an Eta model result. The date/time data specifies the valid time, not the 
initial time. </small></font></p>

<p><font face="Arial, Helvetica, sans-serif"><small>Some plots will have local time listed such as: </small></font></p>

<pre>4:00 PM EST [2100Z] 14 FEB 02</pre>

<p><font face="Arial, Helvetica, sans-serif"><small>The plot is valid for 4PM EST on February 14.  The value is 
brackets is the current Universal time (2100Z).</small></font></p>

<p><font face="Arial, Helvetica, sans-serif"><b>UTC - Universal Time </b></font></p>

<p><font face="Arial, Helvetica, sans-serif"><small>All weather information is tagged with the time of its 
observation or of its validity (for a forecast). For consistency, this is 
alway done using Greenwich Mean Time or Universal Time (UTC or Zulu time). 
</small></font></p>

<p><font face="Arial, Helvetica, sans-serif"><b>Time Zones </b></font></p>

<p><font face="Arial, Helvetica, sans-serif"><small>The Time Zones across North America and Pacific from East 
to West are: </small></font></p>

<pre>            Standard  Daylight Savings
              Time         Time
Atlantic       AST -4       ADT -3
Eastern        EST -5       EDT -4
Central        CST -6       CDT -5
Mountain       MST -7       MDT -6
Pacific        PST -8       PDT -7
Alaska
Hawaii</pre>

<p><font face="Arial, Helvetica, sans-serif"><small>GMT time can be derived from any local time using the following table: </small></font></p>

<pre>Standard time: 

    GMT     ATL  EST  CST  MST  PST  ALA  HAW
difference   -4   -5   -6   -7   -8   -9  -10
    00       8P*  7P*  6P*  5P*  4P*  3P*  2P*
    01       9P*  8P*  7P*  6P*  5P*  4P*  3P*
    02      10P*  9P*  8P*  7P*  6P*  5P*  4P*
    03      11P* 10P*  9P*  8P*  7P*  6P*  5P*
    04      12A  11P* 10P*  9P*  8P*  7P*  6P*
    05       1A  12A  11P* 10P*  9P*  8P*  7P*
    06       2A   1A  12A  11P* 10P*  9P*  8P*
    07       3A   2A   1A  12A  11P* 10P*  9P*
    08       4A   3A   2A   1A  12A  11P* 10P*
    09       5A   4A   3A   2A   1A  12A  11P*
    10       6A   5A   4A   3A   2A   1A  12A
    11       7A   6A   5A   4A   3A   2A   1A
    12       8A   7A   6A   5A   4A   3A   2A
    13       9A   8A   7A   6A   5A   4A   3A
    14      10A   9A   8A   7A   6A   5A   4A
    15      11A  10A   9A   8A   7A   6A   5A
    16      12P  11A  10A   9A   8A   7A   6A
    17       1P  12P  11A  10A   9A   8A   7A
    18       2P   1P  12P  11A  10A   9A   8A
    19       3P   2P   1P  12P  11A  10A   9A
    20       4P   3P   2P   1P  12P  11A  10A
    21       5P   4P   3P   2P   1P  12P  11A
    22       6P   5P   4P   3P   2P   1P  12P
    23       7P   6P   5P   4P   3P   2P   1P

* represents previous day
  (i.e. 03 hours 23 January 93 is 8PM-MST 22 January)</pre>

<p><font face="Arial, Helvetica, sans-serif"><small>Summertime (Daylight savings time) for those states that 
observe daylight savings time.  For those that do not, use the standard time 
table all year: </small></font></p>

<pre>    GMT     EDT  CDT  MDT  PDT
difference   -4   -5   -6   -7
    00       8P*  7P*  6P*  5P*
    01       9P*  8P*  7P*  6P*
    02      10P*  9P*  8P*  7P*
    03      11P* 10P*  9P*  8P*
    04      12A  11P* 10P*  9P*
    05       1A  12A  11P* 10P*
    06       2A   1A  12A  11P*
    07       3A   2A   1A  12A
    08       4A   3A   2A   1A
    09       5A   4A   3A   2A
    10       6A   5A   4A   3A
    11       7A   6A   5A   4A
    12       8A   7A   6A   5A
    13       9A   8A   7A   6A
    14      10A   9A   8A   7A
    15      11A  10A   9A   8A
    16      12P  11A  10A   9A
    17       1P  12P  11A  10A
    18       2P   1P  12P  11A
    19       3P   2P   1P  12P
    20       4P   3P   2P   1P
    21       5P   4P   3P   2P
    22       6P   5P   4P   3P
    23       7P   6P   5P   4P

* represents previous day
  (i.e. 03 hours 23 June is 9PM-MDT 22 June)</pre>

<div class="clearboth">&nbsp;</div>

</div>

<div id="footer"> <span id="copyright"><small>Copyright &copy; Unisys 2012</small></span>
  <ul class="inline-navigation-list" id="bottom-navigation">
    <li><a href="http://www.unisys.com/unisys/privacy.html" target="_blank">Privacy Notice</a></li>
    <li><a href="http://www.unisys.com/unisys/terms-and-conditions.html" target="_blank">Terms of Use</a></li>
    <li><a href="/contactus.php">Contact Us</a></li>
    <li><a href="http://www.unisys.com/unisys/trademarks.html" target="_blank">Trademarks</a></li>
  </ul>
</div>
</div>
</body>
</html>
