<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Unisys Weather </title>
<meta name="description" content="The intent of this weather site is to provide a complete source of graphical weather 		information. This is intended to satisfy the needs of the weather professional, but can be a tool for the casual user as well. The graphics and data are displayed as a meteorologist would expect to see. For the novice user, there are detailed explanation pages to guide them through the various plots, charts and images. The data on this site are provided from the National Weather Service via the NOAAPORT satellite data service. All the images are generated using the Weather Processor (WXP) analysis package which is available from Unisys. "/>
<meta name="keywords" content="weather, unisys, unisys weather, weather maps, maps, nam, wrf, GFS, GFSx, hurricane, radar, satellite, surface, upper air" />
<meta name="copyright" content="Unisys Corp - 2011" />
<meta name="author" content="Unisys Corporation" />
<meta name="email" content="technical-support@weather.unisys.com" />
<meta name="Distribution" content="Global" />
<meta name="Rating" content="General" />
<meta name="Robots" content="INDEX,FOLLOW" />
<meta name="Revisit-after" content="7 Days" />
<meta http-equiv="Content-type" content="text/html;charset=UTF-8" />
<meta http-equiv="imagetoolbar" content="no" />
<meta http-equiv="Refresh" content="900" />
<meta http-equiv="X-UA-Compatible" content="IE=8"/>
<link rel="stylesheet" type="text/css" href="/css/WMAX.css" />
</head>
<body>
<div id="wrap">
  <div id="top-menu">
    <ul id="top-navigation" class="inline-navigation-list">
      <li><a href="http://www.unisys.com" title="Unisys Home Page">Unisys.com</a></li>
      <li><a href="/index.php" title="Unisys Weather">Weather Home</a></li>
      <li><a href="/analyses.php" title="Analyses">Analyses</a></li>
      <li><a href="/forehome.php" title="Forecast">Forecasts</a></li>
      <li><a href="/archives.php" title="Archives">Archives</a></li>
      <li><a href="/links.php" title="NOAA Links">NOAA Links</a></li>
      <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
    </ul>
  </div>

  <div id="header"> <a href="http://unisys.com"><img src="/images/Unisys_logo.gif" alt="Unisys" /></a>
    <h1>Unisys Weather</h1>
  </div>

<div id="leftside">
  <ul class="avmenu">
    <li><a href="/index.php" class="purple">Unisys Weather</a></li>
    <li><a href="/index.php"> Weather Home</a></li>
    <li><a href="/solutions/index.php">Weather Solutions</a></li>
    <li><a href="/mobile/index.php"><img id="mobile_icon" src="/mobile/Icon.png" width="24" height="24" alt="Download Unisys Weather Mobile App"/>iPhone App</a></li>
    <li><a href="/info/index.php">Information</a></li>
    <li><a href="/content.php">Contents</a></li>
    <li><a href="/analyses.php" class="purple">Analyses</a></li>
    <li><a href="/satellite/index.php">Satellite Images</a></li>
    <li><a href="/surface/index.php">Surface Data</a></li>
    <li><a href="/upper_air/index.php">Upper Air Data</a></li>
    <li><a href="/radar/index.php">Radar Data</a></li>
    <li><a href="/forehome.php" class="purple">Forecasts</a></li>
    <li><a href="/mos/index.php">Model Statistics</a></li>
    <li><a href="/nam/index.php">NAM/Wrf Model</a></li>
    <li><a href="/gfs/index.php?r=us">GFS/Avn Model</a></li>
    <li><a href="/gfsx/index.php?r=us">GFSx/MRF Model</a></li>
    <li><a href="/rap/index.php">RAP Model</a></li>
    <li><a href="/ecmwf/index.php">ECMWF Model</a></li>
    <li><a href="/archives.php" class="purple">Archive</a></li>
    <li><a href="/hurricane/index.php">Hurricane Data</a></li>
    <li><a href="/archive/index.php">Archive of Images</a></li>
    <li><a href="/usgs/index.php">USGS Maps</a></li>
  </ul>
</div>

<div id="extras">
  <ul class="avmenu">
    <li><a href="/foresetup.php" class="purple">Get a Forecast</a></li>
  </ul>

<script type="text/javascript">
function fsubmit()
{
     document.getElementById("Forecast").submit();
}
</script>

  <form method="get" id="Forecast" action="/forecast.php">
    <p class="center"> Enter a zip code or city name to get forecast:
      <input type="text" name="Name" id="Name" size="15" />
      <br />
      <button type="submit" style="border:none; background-color:transparent;">
         <img src="/images/GO.png" id="Go" alt="Get Forecast Data" style="height:30px;" />
      </button>
      <a href="/foresetup.php"><img src="/images/setup.png" alt="Setup Location" height="30" width="70" /></a> </p>
  </form>
  <script type="text/javascript">
                <!-- HIDE
                var index = document.cookie.indexOf("ZIP")
                var zipcode = 0
                var region = ""
                if( index != -1 ){
                   //zipcode = parseInt( document.cookie.substring(index+4,index+9),10)
                   zipcode = document.cookie.substring(index+4,index+9)
                   var validateZipCode = function() {
                     var zipcodeRegexp = /^\d{5}$/;
                     var zipTest = zipcodeRegexp.test(zipcode);
   
                     if (zipTest == false) {
                       return false;
                     }
                   }
                   validateZipCode();

                    if( ! isNaN(zipcode))

                    document.getElementById('Name').value = zipcode

                   if( zipcode >= 01000 && zipcode <= 19699 )
                      region = "ne"
                   else if( zipcode >= 19700 && zipcode <= 28999 )
                      region = "at"
                   else if( zipcode >= 43000 && zipcode <= 45999 )
                      region = "at"
                   else if( zipcode >= 29000 && zipcode <= 36999 )
                      region = "se"
                   else if( zipcode >= 38600 && zipcode <= 39999 )
                      region = "se"
                   else if( zipcode >= 46000 && zipcode <= 58999 )
                      region = "mw"
                   else if( zipcode >= 60000 && zipcode <= 62999 )
                      region = "mw"
                   else if( zipcode >= 68000 && zipcode <= 69999 )
                      region = "mw"
                   else if( zipcode >= 63000 && zipcode <= 67999 )
                      region = "cp"
                   else if( zipcode >= 71600 && zipcode <= 74999 )
                      region = "cp"
                   else if( zipcode >= 70000 && zipcode <= 71499 )
                      region = "sp"
                   else if( zipcode >= 75000 && zipcode <= 79999 )
                      region = "sp"
                   else if( zipcode >= 59000 && zipcode <= 59999 )
                      region = "nw"
                   else if( zipcode >= 82000 && zipcode <= 83999 )
                      region = "nw"
                   else if( zipcode >= 97000 && zipcode <= 99499 )
                      region = "nw"
                   else if( zipcode >= 80000 && zipcode <= 81999 )
                      region = "sw"
                   else if( zipcode >= 84000 && zipcode <= 96199 )
                      region = "sw"

                   if( region != "" ){
                      document.write( "<table border=\"0\" align=\"center\" class=\"grey\" width=\"100%\">" )
                      document.write( "<tr>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/surface/sfc_map.php?image=sfc&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Sfc" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=\"radar/rad" + region + ".php\">" )
                      document.write( "<a href=/radar/rcm_rad.php?image=rad&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Rad" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=vis&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Vis" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=enh&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>IR" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "</tr></table>" )
                      document.write( "</b>" )
                      }


                   
                   }
                // UNHIDE -->
                </script>
  <ul class="avmenu">
    <li><a href="/links.php" class="purple">NOAA Links</a></li>
    <li><a href="http://lwf.ncdc.noaa.gov/">National Climatic Data Center</a></li>
    <li><a href="http://www.cpc.noaa.gov/">Climate Prediction Center</a></li>
    <li><a href="http://oceanservice.noaa.gov/">National Ocean Service</a></li>
    <li><a href="http://www.lib.noaa.gov/">NOAA Library</a></li>
    <li><a href="http://www.oar.noaa.gov/">NOAA Office of Oceanic and Atmospheric Research</a></li>
    <li><a href="http://www.esrl.noaa.gov/">Earth Systems Research Laboratory</a></li>
    <li><a href="/overview.php" class="purple">About Us</a></li>
    <li><a href="/overview.php" title="Contact Us">Overview</a></li>
    <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
  </ul>
</div>
<div id="content">

<h2>First Time User Information</h2>

<p>Welcome to the Unisys Weather Server. The intent of this weather site is to provide a complete source of graphical weather information. This is intended to satisfy the needs of the weather professional but can be a tool for the casual user as well. The graphics and data are displayed as a meteorologist would expect to see. For the novice user, there are detailed explanation pages to guide them through the various plots, charts and images. The URL for this site is <a href="/index.php"><b>http://weather.unisys.com</b></a>. Once connected to the home page, you can traverse through the available documents, sub-documents and images.</p>

<hr/>

<h2>Navigation</h2>

<p>This server is composed of several pages that organize the site into menu and image pages.  The menu pages are there to guide you to the images.  Each image page has a set of links to related image pages.</p>

<h3>Menu Pages</h3>

<p>Menu pages are split up into 3 columns.  The left column is a table of contents.  This will guide you to other sections of the site based on data type:</p>

<table border="0" width="150" cellspacing="0" cellpadding="2">
  <tr>
    <td valign="top" width="100%" bgcolor="#f4f4f4">
    <a href="/index.html"><font face="Arial, Helvetica, sans-serif" color="#76298E"><small><b>Unisys Weather</b></small></font></a>
    </td>
  </tr>
  <tr>
    <td valign="top" width="100%" bgcolor="#b0b0d0">
    <a href="/index.html"><font face="Arial, Helvetica, sans-serif" color="#000000"><small><small><b>Home</b></small></small></font></a><br/>
    <a href="/info/index.html"><font face="Arial, Helvetica, sans-serif" color="#000000"><small><small><b>Information</b></small></small></font></a><br/>
    <a href="/content.html"><font face="Arial, Helvetica, sans-serif" color="#000000"><small><small><b>Contents</b></small></small></font></a><br/>
  </td></tr>
  <tr>
    <td valign="top" width="100%" bgcolor="#f4f4f4">
    <font face="Arial, Helvetica, sans-serif" color="#76298E"><small><b>Analyses</b></small></font>
    </td>
  </tr>
  <tr><td valign="top" width="100%" bgcolor="#b0b0d0">
    <a href="/satellite/index.html"><font face="Arial, Helvetica, sans-serif" color="#000000"><small><small><b>Satellite Images</b></small></small></font></a><br/>
    <a href="/surface/index.html"><font face="Arial, Helvetica, sans-serif" color="#000000"><small><small><b>Surface Data</b></small></small></font></a><br/>
    <a href="/upper_air/index.html"><font face="Arial, Helvetica, sans-serif" color="#000000"><small><small><b>Upper Air Data</b></small></small></font></a><br/>
    <a href="/radar/index.html"><font face="Arial, Helvetica, sans-serif" color="#000000"><small><small><b>Radar Data</b></small></small></font></a><br/>
  </td></tr>
  <tr>
    <td valign="top" width="100%" bgcolor="#f4f4f4">
    <font face="Arial, Helvetica, sans-serif" color="#76298E"><small><b>Forecasts</b></small></font>
    </td>
  </tr>
  <tr>
    <td valign="top" width="100%" bgcolor="#b0b0d0">
    <a href="/mos/index.html"><font face="Arial, Helvetica, sans-serif" color="#000000"><small><small><b>Model Statistics</b></small></small></font></a><br/>
    <a href="/nam/index.html"><font face="Arial, Helvetica, sans-serif" color="#000000"><small><small><b>NAM/Wrf Model</b></small></small></font></a><br/>
    <a href="/gfs/index.html"><font face="Arial, Helvetica, sans-serif" color="#000000"><small><small><b>GFS/Avn Model</b></small></small></font></a><br/>
    <a href="/gfsx/index.html"><font face="Arial, Helvetica, sans-serif" color="#000000"><small><small><b>GFSx/MRF Model</b></small></small></font></a><br/>
    <a href="/ruc/index.html"><font face="Arial, Helvetica, sans-serif" color="#000000"><small><small><b>RUC Model</b></small></small></font></a><br/>
    <a href="/ecmwf/index.html"><font face="Arial, Helvetica, sans-serif" color="#000000"><small><small><b>ECMWF Model</b></small></small></font></a><br/>
    </td>
  </tr>
  <tr>
    <td valign="top" width="100%" bgcolor="#f4f4f4">
    <font face="Arial, Helvetica, sans-serif" color="#76298E"><small><b>Archive</b></small></font>
    </td>
  </tr>
  <tr>
    <td valign="top" width="100%" bgcolor="#b0b0d0">
    <a href="/hurricane/index.html"><font face="Arial, Helvetica, sans-serif" color="#000000"><small><small><b>Hurricane Data</b></small></small></font></a><br/>
    <a href="/archive/index.html"><font face="Arial, Helvetica, sans-serif" color="#000000"><small><small><b>Archive of Images</b></small></small></font></a><br/>
    <a href="/usgs/index.html"><font face="Arial, Helvetica, sans-serif" color="#000000"><small><small><b>USGS Maps</b></small></small></font></a><br/>
    </td>
  </tr>
</table>
<!--
<p><font face="Arial, Helvetica, sans-serif"><small>Just below the table of contents will be a web form to get local weather. It will look like:</small></font></p>

<table width="150">
  <tr>
    <td>
    <form method="get" name="Forecast" action="/forecast.pl">
    <p align="center"><font face="Arial, Helvetica, sans-serif"><small><b>Enter a zip code or city name to get forecast:</b></small></font><br/>
    <input type="text" name="Name" size="15"/><br/>
    <input style="border:0px; height:20px; width:31px;" type="image" alt="Get Forecast Data" name="Go" src="/images/GO.gif"/><a href="/foresetup.html"><img src="/images/SETUP.gif" border="0" alt="Setup Location" height="20" width="60"/></a></p>
    </form>
    </td>
  </tr>
</table>
-->
<p><font face="Arial, Helvetica, sans-serif"><small>You can enter a zip code, city name such as "Topeka, KS", a 4 letter METAR/ICAO identifier such as "KTOP", or a latitude and longitude such as "40,-100". To set a default, go to the "SETUP" page and that will it up so that that location will pop up in the box when the page loads.</small></font></p>

<p><font face="Arial, Helvetica, sans-serif"><small>The center column is an information column.  Generally this describes the type of data, shows a small thumbnail image and gives links to more information.  The "More information" pages detail the contents of each image including types of data, how they are plotted and descriptions of any symbols used.</small></font></p>

<p><font face="Arial, Helvetica, sans-serif"><small>The right column contains links to sub-menu pages and links to image pages.</small></font></p>

<table border="0" width="150" cellspacing="0" cellpadding="2">
  <tr>
    <td valign="top" width="100%" bgcolor="#f4f4f4">
    <font face="Arial, Helvetica, sans-serif" color="#76298E"><small><b>Plots</b></small></font>
    </td>
  </tr>
  <tr>
    <td valign="top" width="100%" bgcolor="#b0e0f0">
    <a href="/surface/sfc_con_temp.html"><font face="Arial, Helvetica, sans-serif"><small><small><b>US Temperature</b></small></small></font></a><br/>
    <a href="/surface/sfc_con_temp_na.html"><font face="Arial, Helvetica, sans-serif"><small><small><b>N Amer Temperature</b></small></small></font></a><br/>
    <a href="/surface/sfc_con_24temp.html"><font face="Arial, Helvetica, sans-serif"><small><small><b>24hr Temp Change</b></small></small></font></a><br/>
    <a href="/surface/sfc_con_wchill.html"><font face="Arial, Helvetica, sans-serif"><small><small><b>Wind Chill</b></small></small></font></a><br/>
    <a href="/surface/sfc_con_heat.html"><font face="Arial, Helvetica, sans-serif"><small><small><b>Heat Index</b></small></small></font></a><br/>
    <a href="/surface/sfc_con_pres.html"><font face="Arial, Helvetica, sans-serif"><small><small><b>SL Pressure</b></small></small></font></a><br/>
    <a href="/surface/sfc_con_3pres.html"><font face="Arial, Helvetica, sans-serif"><small><small><b>3hr Pres Change</b></small></small></font></a><br/>
    <a href="/surface/sfc_con_dewp.html"><font face="Arial, Helvetica, sans-serif"><small><small><b>Dewpoint</b></small></small></font></a><br/>
    <a href="/surface/sfc_con_wspd.html"><font face="Arial, Helvetica, sans-serif"><small><small><b>Wind Speed</b></small></small></font></a><br/>
    <a href="/surface/sfc_con_stream.html"><font face="Arial, Helvetica, sans-serif"><small><small><b>Wind Streamlines</b></small></small></font></a><br/>
    <a href="/surface/sfc_con_qconv.html"><font face="Arial, Helvetica, sans-serif"><small><small><b>Moist Conv</b></small></small></font></a><br/>
    </td>
  </tr>
  <tr>
    <td valign="top" width="100%" bgcolor="#f4f4f4">
    <font face="Arial, Helvetica, sans-serif" color="#76298E"><small><b>Index</b></small></font>
    </td>
  </tr>
  <tr>
    <td valign="top" width="100%" bgcolor="#b0e0f0">
    <a href="/surface/composite.html"><font face="Arial, Helvetica, sans-serif"><small><small><b>Composite Plots</b></small></small></font></a><br/>
    <a href="/surface/regional.html"><font face="Arial, Helvetica, sans-serif"><small><small><b>Regional Plots</b></small></small></font></a><br/>
    <a href="/surface/contour.html"><font face="Arial, Helvetica, sans-serif"><small><small><b>Contour Plots</b></small></small></font></a><br/>
    <a href="/surface/daily.html"><font face="Arial, Helvetica, sans-serif"><small><small><b>Daily Plots</b></small></small></font></a><br/>
    <a href="/surface/meteogram/index.html"><font face="Arial, Helvetica, sans-serif"><small><small><b>Surface Meteograms</b></small></small></font></a><br/>
    </td>
  </tr>
  <tr>
    <td valign="top" width="100%" bgcolor="#f4f4f4">
    <font face="Arial, Helvetica, sans-serif" color="#76298E"><small><b>Information</b></small></font>
    </td>
  </tr>
  <tr>
    <td valign="top" width="100%" bgcolor="#b0e0f0">
    <a href="/logs/surface"><font face="Arial, Helvetica, sans-serif"><small><small><b>Update Status</b></small></small></font></a><br/>
    </td>
  </tr>
</table>

<p><font face="Arial, Helvetica, sans-serif"><small>The "Plots" section will take you to image pages.  The "Index" section will take you to other sub-menu pages.  The "Information" section will take you to specific information pages on the generation of the images such as an update status.  The update status page gives you the times each image was last generated. </small></font></p>

<h3><font face="Arial, Helvetica, sans-serif">Image Pages</font></h3>

<p><font face="Arial, Helvetica, sans-serif"><small>Image pages contain the actual images.  Each image page is split into three sections.  The top section is the menubar section.  This links to other similar images for quick navigation through the site.</small></font></p>

<table border="0" cellpadding="2">
  <tr>
    <td valign="top" bgcolor="#505070"><font face="Arial, Helvetica, sans-serif" color="white"><small><b>PLOT</b></small></font></td>
    <td valign="top" bgcolor="#f0d0d0"><font face="Arial, Helvetica, sans-serif" color="#FF0000"><small><b>Temp</b></small></font></td>
    <td valign="top" bgcolor="#b0b0d0"><a href="#"><font face="Arial, Helvetica, sans-serif"><small><b>NA-Temp</b></small></font></a></td>
    <td valign="top" bgcolor="#b0b0d0"><a href="#"><font face="Arial, Helvetica, sans-serif"><small><b>24-Temp</b></small></font></a></td>
    <td valign="top" bgcolor="#b0b0d0"><a href="#"><font face="Arial, Helvetica, sans-serif"><small><b>WChill</b></small></font></a></td>
    <td valign="top" bgcolor="#b0b0d0"><a href="#"><font face="Arial, Helvetica, sans-serif"><small><b>Heat</b></small></font></a></td>
    <td valign="top" bgcolor="#b0b0d0"><a href="#"><font face="Arial, Helvetica, sans-serif"><small><b>Pres</b></small></font></a></td>
    <td valign="top" bgcolor="#b0b0d0"><a href="#"><font face="Arial, Helvetica, sans-serif"><small><b>3-Pres</b></small></font></a></td>
    <td valign="top" bgcolor="#b0b0d0"><a href="#"><font face="Arial, Helvetica, sans-serif"><small><b>Dewp</b></small></font></a></td>
    <td valign="top" bgcolor="#b0b0d0"><a href="#"><font face="Arial, Helvetica, sans-serif"><small><b>Wspd</b></small></font></a></td>
    <td valign="top" bgcolor="#b0b0d0"><a href="#"><font face="Arial, Helvetica, sans-serif"><small><b>Stream</b></small></font></a></td>
    <td valign="top" bgcolor="#b0b0d0"><a href="#"><font face="Arial, Helvetica, sans-serif"><small><b>QConv</b></small></font></a></td>
    <td valign="top" bgcolor="#505070"><font face="Arial, Helvetica, sans-serif" color="white"><small><b>TYPE</b></small></font></td>
    <td valign="top" bgcolor="#f0d0d0"><font face="Arial, Helvetica, sans-serif" color="#FF0000"><small><b>Norm</b></small></font></td>
    <td valign="top" bgcolor="#b0b0d0"><a href="#"><font face="Arial, Helvetica, sans-serif"><small><b>Inv</b></small></font></a></td>
  </tr>
</table>

<table border="0" cellpadding="2">
  <tr>
    <td valign="top" bgcolor="#505070"><font face="Arial, Helvetica, sans-serif" color="white"><small><b>TIME</b></small></font></td>
    <td valign="top" bgcolor="#f0d0d0"><font face="Arial, Helvetica, sans-serif" color="#FF0000"><small><b>Current</b></small></font></td>
    <td valign="top" bgcolor="#b0b0d0"><a href="#"><font face="Arial, Helvetica, sans-serif"><small><b>-1hr</b></small></font></a></td>
    <td valign="top" bgcolor="#b0b0d0"><a href="#"><font face="Arial, Helvetica, sans-serif"><small><b>-2hr</b></small></font></a></td>
    <td valign="top" bgcolor="#b0b0d0"><a href="#"><font face="Arial, Helvetica, sans-serif"><small><b>-3hr</b></small></font></a></td>
    <td valign="top" bgcolor="#b0b0d0"><a href="#"><font face="Arial, Helvetica, sans-serif"><small><b>-4hr</b></small></font></a></td>
    <td valign="top" bgcolor="#b0b0d0"><a href="#"><font face="Arial, Helvetica, sans-serif"><small><b>-5hr</b></small></font></a></td>
    <td valign="top" bgcolor="#b0b0d0"><a href="#"><font face="Arial, Helvetica, sans-serif"><small><b>-6hr</b></small></font></a></td>
    <td valign="top" bgcolor="#b0b0d0"><a href="#"><font face="Arial, Helvetica, sans-serif"><small><b>-7hr</b></small></font></a></td>
    <td valign="top" bgcolor="#b0b0d0"><a href="#"><font face="Arial, Helvetica, sans-serif"><small><b>-8hr</b></small></font></a></td>
    <td valign="top" bgcolor="#b0b0d0"><a href="#"><font face="Arial, Helvetica, sans-serif"><small><b>-9hr</b></small></font></a></td>
    <td valign="top" bgcolor="#b0b0d0"><a href="#"><font face="Arial, Helvetica, sans-serif"><small><b>-10hr</b></small></font></a></td>
    <td valign="top" bgcolor="#b0b0d0"><a href="#"><font face="Arial, Helvetica, sans-serif"><small><b>-11hr</b></small></font></a></td>
    <td valign="top" bgcolor="#b0b0d0"><a href="#"><font face="Arial, Helvetica, sans-serif"><small><b>-12hr</b></small></font></a></td>
  </tr>
</table>

<p><font face="Arial, Helvetica, sans-serif"><small>The menu bar links to plots from other regions, other models, to other similar plots, to inverted plots (white background), and
to archived images from previous hours.</small></font></p>

<p><font face="Arial, Helvetica, sans-serif"><small>The second section is the image itself (see below).</small></font></p>

<p><font face="Arial, Helvetica, sans-serif"><small>The last section of the image page is a description section. In some cases, additional information to help interpret the plot will be contained in this section.  The details pages will be more complete (see More information in the menu pages).</small></font></p>

<h3><font face="Arial, Helvetica, sans-serif">Images</font></h3>

<img src="/surface/sfc_con_temp.gif" height="512" width="640" alt="Surface Temp"/>

<p><font face="Arial, Helvetica, sans-serif"><small>  The image will have a header bar with plot description in the upper left and valid time in the upper right.  The units the parameter is plotted in is denoted in brackets "[F]".  The valid time is always given in universal (UTC) time but can include local time in some regional plots. See the time information page for more information</small></font></p>

<p><font face="Arial, Helvetica, sans-serif"><small><b><a href="/info/time.php"><img src="/images/gforw.gif" width="13" height="13" alt="Go forward" border="0"/> Date/Time Information</a></b></small></font></p>

<p><font face="Arial, Helvetica, sans-serif"><small>The image itself contains data, either colored as in a satellite image or radar plot, color filled as in temperature contours, or plotted as in surface station model plots.  A maps is overlaid for reference.</small></font></p>

<p><font face="Arial, Helvetica, sans-serif"><small>The bottom part of the image contains some specific information about the plot.  There could be a color bar in the lower left which matches colors to actual data values such as in a color fill temperature plot.  In the lower right could be contouring parameters such as max, min values in the grid and the contour interval.</small></font></p>

<p><font face="Arial, Helvetica, sans-serif"><small><b>Auto-Refresh</b> - Each image page has a refresh time associated with it.  This corresponds to how often the image is updated on the web server.  The refresh will reload the page with the latest image. This makes sure that the latest image is always displaying</small></font></p>

<p><font face="Arial, Helvetica, sans-serif"><small><b>NOTE:</b> Because many of these images are cached in the browser, the image that appears may not reflect the latest possible image.  The browser will often display the cached image rather than the latest. If the image appears old, hit the <b>Reload</b> button to update the image.  Some browsers like Firefox might not refresh the image even with a reload. Using shift-reload might update the image.</small></font></p>

<h3><font face="Arial, Helvetica, sans-serif">Details Pages</font></h3>

<p><font face="Arial, Helvetica, sans-serif"><small>For each type of plot, there are details pages which explain each image in more detail.  To access these pages, look for the "More information" link on each menu page:</small></font></p>

<p><font face="Arial, Helvetica, sans-serif"><small><b><a href="/surface/details.php"><img src="/images/gforw.gif" width="13" height="13" alt="Go forward" border="0"/> More Information</a></b></small></font></p>

<div class="clearboth">&nbsp;</div>

</div>

<div id="footer"> <span id="copyright"><small>Copyright &copy; Unisys 2012</small></span>
  <ul class="inline-navigation-list" id="bottom-navigation">
    <li><a href="http://www.unisys.com/unisys/privacy.html" target="_blank">Privacy Notice</a></li>
    <li><a href="http://www.unisys.com/unisys/terms-and-conditions.html" target="_blank">Terms of Use</a></li>
    <li><a href="/contactus.php">Contact Us</a></li>
    <li><a href="http://www.unisys.com/unisys/trademarks.html" target="_blank">Trademarks</a></li>
  </ul>
</div>
</div>
</body>
</html>
