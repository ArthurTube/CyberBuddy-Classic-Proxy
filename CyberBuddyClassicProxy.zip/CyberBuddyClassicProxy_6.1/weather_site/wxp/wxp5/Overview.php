<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Unisys Weather </title>
<meta name="description" content="The intent of this weather site is to provide a complete source of graphical weather 		information. This is intended to satisfy the needs of the weather professional, but can be a tool for the casual user as well. The graphics and data are displayed as a meteorologist would expect to see. For the novice user, there are detailed explanation pages to guide them through the various plots, charts and images. The data on this site are provided from the National Weather Service via the NOAAPORT satellite data service. All the images are generated using the Weather Processor (WXP) analysis package which is available from Unisys. "/>
<meta name="keywords" content="weather, unisys, unisys weather, weather maps, maps, nam, wrf, GFS, GFSx, hurricane, radar, satellite, surface, upper air" />
<meta name="copyright" content="Unisys Corp - 2011" />
<meta name="author" content="Unisys Corporation" />
<meta name="email" content="technical-support@weather.unisys.com" />
<meta name="Distribution" content="Global" />
<meta name="Rating" content="General" />
<meta name="Robots" content="INDEX,FOLLOW" />
<meta name="Revisit-after" content="7 Days" />
<meta http-equiv="Content-type" content="text/html;charset=UTF-8" />
<meta http-equiv="imagetoolbar" content="no" />
<meta http-equiv="Refresh" content="900" />
<meta http-equiv="X-UA-Compatible" content="IE=8"/>
<link rel="stylesheet" type="text/css" href="/css/WMAX.css" />
</head>
<body>
<div id="wrap">
  <div id="top-menu">
    <ul id="top-navigation" class="inline-navigation-list">
      <li><a href="http://www.unisys.com" title="Unisys Home Page">Unisys.com</a></li>
      <li><a href="/index.php" title="Unisys Weather">Weather Home</a></li>
      <li><a href="/analyses.php" title="Analyses">Analyses</a></li>
      <li><a href="/forehome.php" title="Forecast">Forecasts</a></li>
      <li><a href="/archives.php" title="Archives">Archives</a></li>
      <li><a href="/links.php" title="NOAA Links">NOAA Links</a></li>
      <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
    </ul>
  </div>

  <div id="header"> <a href="http://unisys.com"><img src="/images/Unisys_logo.gif" alt="Unisys" /></a>
    <h1>Unisys Weather</h1>
  </div>

<div id="leftside">
  <ul class="avmenu">
    <li><a href="/index.php" class="purple">Unisys Weather</a></li>
    <li><a href="/index.php"> Weather Home</a></li>
    <li><a href="/solutions/index.php">Weather Solutions</a></li>
    <li><a href="/mobile/index.php"><img id="mobile_icon" src="/mobile/Icon.png" width="24" height="24" alt="Download Unisys Weather Mobile App"/>iPhone App</a></li>
    <li><a href="/info/index.php">Information</a></li>
    <li><a href="/content.php">Contents</a></li>
    <li><a href="/analyses.php" class="purple">Analyses</a></li>
    <li><a href="/satellite/index.php">Satellite Images</a></li>
    <li><a href="/surface/index.php">Surface Data</a></li>
    <li><a href="/upper_air/index.php">Upper Air Data</a></li>
    <li><a href="/radar/index.php">Radar Data</a></li>
    <li><a href="/forehome.php" class="purple">Forecasts</a></li>
    <li><a href="/mos/index.php">Model Statistics</a></li>
    <li><a href="/nam/index.php">NAM/Wrf Model</a></li>
    <li><a href="/gfs/index.php?r=us">GFS/Avn Model</a></li>
    <li><a href="/gfsx/index.php?r=us">GFSx/MRF Model</a></li>
    <li><a href="/rap/index.php">RAP Model</a></li>
    <li><a href="/ecmwf/index.php">ECMWF Model</a></li>
    <li><a href="/archives.php" class="purple">Archive</a></li>
    <li><a href="/hurricane/index.php">Hurricane Data</a></li>
    <li><a href="/archive/index.php">Archive of Images</a></li>
    <li><a href="/usgs/index.php">USGS Maps</a></li>
  </ul>
</div>

<div id="extras">
  <ul class="avmenu">
    <li><a href="/foresetup.php" class="purple">Get a Forecast</a></li>
  </ul>

<script type="text/javascript">
function fsubmit()
{
     document.getElementById("Forecast").submit();
}
</script>

  <form method="get" id="Forecast" action="/forecast.php">
    <p class="center"> Enter a zip code or city name to get forecast:
      <input type="text" name="Name" id="Name" size="15" />
      <br />
      <button type="submit" style="border:none; background-color:transparent;">
         <img src="/images/GO.png" id="Go" alt="Get Forecast Data" style="height:30px;" />
      </button>
      <a href="/foresetup.php"><img src="/images/setup.png" alt="Setup Location" height="30" width="70" /></a> </p>
  </form>
  <script type="text/javascript">
                <!-- HIDE
                var index = document.cookie.indexOf("ZIP")
                var zipcode = 0
                var region = ""
                if( index != -1 ){
                   //zipcode = parseInt( document.cookie.substring(index+4,index+9),10)
                   zipcode = document.cookie.substring(index+4,index+9)
                   var validateZipCode = function() {
                     var zipcodeRegexp = /^\d{5}$/;
                     var zipTest = zipcodeRegexp.test(zipcode);
   
                     if (zipTest == false) {
                       return false;
                     }
                   }
                   validateZipCode();

                    if( ! isNaN(zipcode))

                    document.getElementById('Name').value = zipcode

                   if( zipcode >= 01000 && zipcode <= 19699 )
                      region = "ne"
                   else if( zipcode >= 19700 && zipcode <= 28999 )
                      region = "at"
                   else if( zipcode >= 43000 && zipcode <= 45999 )
                      region = "at"
                   else if( zipcode >= 29000 && zipcode <= 36999 )
                      region = "se"
                   else if( zipcode >= 38600 && zipcode <= 39999 )
                      region = "se"
                   else if( zipcode >= 46000 && zipcode <= 58999 )
                      region = "mw"
                   else if( zipcode >= 60000 && zipcode <= 62999 )
                      region = "mw"
                   else if( zipcode >= 68000 && zipcode <= 69999 )
                      region = "mw"
                   else if( zipcode >= 63000 && zipcode <= 67999 )
                      region = "cp"
                   else if( zipcode >= 71600 && zipcode <= 74999 )
                      region = "cp"
                   else if( zipcode >= 70000 && zipcode <= 71499 )
                      region = "sp"
                   else if( zipcode >= 75000 && zipcode <= 79999 )
                      region = "sp"
                   else if( zipcode >= 59000 && zipcode <= 59999 )
                      region = "nw"
                   else if( zipcode >= 82000 && zipcode <= 83999 )
                      region = "nw"
                   else if( zipcode >= 97000 && zipcode <= 99499 )
                      region = "nw"
                   else if( zipcode >= 80000 && zipcode <= 81999 )
                      region = "sw"
                   else if( zipcode >= 84000 && zipcode <= 96199 )
                      region = "sw"

                   if( region != "" ){
                      document.write( "<table border=\"0\" align=\"center\" class=\"grey\" width=\"100%\">" )
                      document.write( "<tr>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/surface/sfc_map.php?image=sfc&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Sfc" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=\"radar/rad" + region + ".php\">" )
                      document.write( "<a href=/radar/rcm_rad.php?image=rad&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Rad" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=vis&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Vis" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=enh&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>IR" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "</tr></table>" )
                      document.write( "</b>" )
                      }


                   
                   }
                // UNHIDE -->
                </script>
  <ul class="avmenu">
    <li><a href="/links.php" class="purple">NOAA Links</a></li>
    <li><a href="http://lwf.ncdc.noaa.gov/">National Climatic Data Center</a></li>
    <li><a href="http://www.cpc.noaa.gov/">Climate Prediction Center</a></li>
    <li><a href="http://oceanservice.noaa.gov/">National Ocean Service</a></li>
    <li><a href="http://www.lib.noaa.gov/">NOAA Library</a></li>
    <li><a href="http://www.oar.noaa.gov/">NOAA Office of Oceanic and Atmospheric Research</a></li>
    <li><a href="http://www.esrl.noaa.gov/">Earth Systems Research Laboratory</a></li>
    <li><a href="/overview.php" class="purple">About Us</a></li>
    <li><a href="/overview.php" title="Contact Us">Overview</a></li>
    <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
  </ul>
</div>
<div id="content">

<h2> WXP, The Weather Processor</h2>

<br/>         
<h3>Overview:</h3>
<img src="/wxp/wxp5/sat_sfc_map.gif" alt="sat_sfc_map.gif (55439 bytes)" border="2" height="312" width="468" style="float:right;"/>
<p>WXP, the Weather Processor, is a suite of programs/toolkit for analyzing and displaying meteorological data and satellite images. WXP originated at Purdue University but is now being developed by Unisys. It is intended to be an general purpose weather visualization tool for near-realtime and archived meteorological data.<br/>
The software package handles data broadcast directly by the National Weather Service, reads in and files the data, decodes and parses the information and finally visualizes the data in a variety of formats. The primary audience for the package are meteorologists but is also developed to provide non-meteorologists the ability to view the data with varying degrees of complexity.</p>

<br/><br/>
<h3>Features: </h3>
<ul>
  <li>
  Ingest of National Weather Service (NWS) Data Feeds<br/>
  WXP offers data ingest programs which will read and save data from either old FOS (Family of Services) or NOAAPORT. The Unisys NOAAPORT ingest system is idealy suited to provide data to WXP.
  </li>
  <li>
  Full Range of Data Types<br/>
  Use WXP to view and analyze:
  </li>
  <li class="nobullet">
    <ul>
      <li>Surface observations (SAO, METAR, SYNOP, SHIP, BUOY, DRIBU, CMAN)</li>
      <li>Upper-air (TTAA, TTBB, TTCC, TTDD, PPAA, PPBB, PPDD, UUAA, UUBB, UUCC, UUDD)</li>
      <li>Model Output Statistical (MOS/FOUS from NAM, GFS and other models)</li>
      <li>Radar (MDR, RCM, NIDS (including NOAAPORT), WSI NOWRad, Kavouras Mosaic, Unisys Mosaic)</li>
      <li>Satellite imagery (McIDAS AREA, NOAAPORT, Unisys Images)</li>
      <li>Gridded numerical forecasts (GRIB from NCEP and NOAAPORT as well as most generic GRIB v1 and v2 products).</li>
      <li>NLDN and NAPLN lightning data</li>
      <li>Profiler data</li>
      <li>SHEF, CLIMAT, hurricane data parsing</li>
      <li>Text data such as watches, warnings, advisories and forecasts.</li>
    </ul>
  </li>
  <li> 
  Decoders and Parsers<br/>
  WXP provides programs to decode data types such as METAR, SYNOP, Upper Air and GRIB data. &nbsp;Also, WXP provides parsing programs to select specific text products from ingested data files such as forecasts, advisories and warnings.
  </li>
  <li>
  Standard Meteorological Analysis Programs<br/>
  WXP includes routines for standard meteorological analyses:
  </li>
  <li class="nobullet">
    <ul>
      <li>Plotting and contouring (line and color-fill) of all data types</li>
      <li>Regional, CONUS and international plotting of surface and upper air data</li>
      <li>Plot station models for surface and upper air</li>
      <li>Plots all general surface information including max/min temperature, precipitation and snow cover</li>
      <li>Plots meteogram (time series of surface data) of observations and forecasts using MOS data</li>
      <li>Plot upper air data on any pressure, height or isentropic level including freezing and tropopause levels</li>
      <li>Plot upper air parameters for a specific level or layer</li>
      <li>Plots most common used sounding and stability indices including LI, KI, precipitable water, CAPE, Helicity and shear</li>
      <li>Plots derived parameters such as vorticity, convergence, isentropic lifting and Q vectors</li>
      <li>Plots soundings using SkewT, Emagrams and Stuves</li>
      <li>Plots, enhances and remaps satellite images</li>
      <li>Plots MDR, RCM, NIDS radar data including vendor and WXP generated radar mosaics</li>
      <li>Plots raw and derived GRIB model data </li>
    </ul>
  </li>
  <li>
  Output Devices<br/>
  WXP offers direct output to X windows and Win32 (Windows NT/XP), hardcopy output for Postscript and HPGL/PCL5, and metafile output. Also, WXP programs can directly generate GIF and PNG files.
  </li>
  <li>
  Image Overlays<br/>
  WXP allows you to overlay graphic analyses based on a predetermined projection domain. This also includes navigated satellite images. Overlay products can be printed using PostScript and HPGL/PCL5 output programs.
  </li>
  <li>
  Animation<br/>
  WXP can animate plots based on time (last 5 hours of data) or on forecast (every 6 hours into future).&nbsp; Up to 200 frames can be used.
  </li>
  <li>
  Multiple Interfaces<br/>
  WXP provides a set of simple text menus to quickly generate plots.&nbsp; WXP is best used in scripts using the command line interface to create tailored graphics including overlays, loops and multipanel plots. Tailored plots can be automatically saved to image files for use on web servers.&nbsp; A mouse-driven interface is available for interactive zoom, sounding modification and loop control.
  </li>
</ul>

<hr size="2" width="100%"/>

<h3>Platforms: </h3>

<h4>UNIX/Linux</h4>
<ul>
  <li>X86 systems running CentOS-5, RHEL3, and RHEL5</li>
</ul>

<p style="font-size:1.25em">Minimum platform requirements are:</p>

<ul>
  <li>256 MB RAM</li>
  <li>350 MB hard disk for binaries and database files</li>
  <li>2+ GB for realtime data storage (server space).</li>
  <li>X11 Display System (standard on all systems)</li>
</ul>
<hr/>

<table border="0" width="100%">
  <tr>
    <td width="50%">
    <h3>Product Sales and Information:</h3>
    <p style="font-size:1em;">Unisys Weather Information Services<br/>
    ATTN: Sales<br/>
    2476 Swedesford Road<br/>
    Malvern, PA 19355<br/>
    Email: <a style="font-size:.90em;" href="mailto:sales-support@weather.unisys.com">sales-support@weather.unisys.com</a><br/>
    Phone: 800-610-9473 </p>
    <p> Call for Price Quote</p>
    </td>
    <td valign="top" width="50%">
    <h3>Technical Information: </h3>
    <p style="font-size:1em;">Unisys Weather Information Services<br/>
    ATTN: Meteorology<br/>
    2476 Swedesford Road<br/>
    Malvern, PA 19355<br/>
    Email: <a style="font-size:.90em;" href="mailto:technical-support@weather.unisys.com">technical-support@weather.unisys.com</a><br/>
    Phone: 800-610-9473</p>
    </td>
  </tr>
</table>

<hr size="2" width="100%"/>

<h3>Distribution:</h3>
<p>Unisys licenses and distributes WXP. Binary only licenses are available for UNIX and Windows 95/98/NT platforms on a single machine or site license basis. Please call 800-610-9473 for specific pricing and license information.</p>
<br/>
<p>WXP (binaries and database files) is available online from a password protected web site.<br/>
Current database files are available from Unisys Web server at <a href="/wxp/etc"> http://weather.unisys.com/wxp/etc</a>.</p>
<br/>
<p>Documentation is available in HTML, PDF and hardcopy formats.</p>

<br/>
<h3>For More Information: </h3>
<p>Visit the WXP Web server (<a href="/index.php">http://weather.unisys.com</a>) for samples of WXP output.</p>
<p>Visit the WXP documentation site: (<a href="/wxp/index.php">http://weather.unisys.com/wxp/index.php</a>) for information on WXP and online documentation on the package.</p>

<hr/>

<p>For further information about WXP, email <a href="mailto:technical-support@weather.unisys.com">technical-support@weather.unisys.com<br /></a></p>

<div class="clearboth">&nbsp;</div>

</div>

<div id="footer"> <span id="copyright"><small>Copyright &copy; Unisys 2012</small></span>
  <ul class="inline-navigation-list" id="bottom-navigation">
    <li><a href="http://www.unisys.com/unisys/privacy.html" target="_blank">Privacy Notice</a></li>
    <li><a href="http://www.unisys.com/unisys/terms-and-conditions.html" target="_blank">Terms of Use</a></li>
    <li><a href="/contactus.php">Contact Us</a></li>
    <li><a href="http://www.unisys.com/unisys/trademarks.html" target="_blank">Trademarks</a></li>
  </ul>
</div>
</div>
</body>
</html>
