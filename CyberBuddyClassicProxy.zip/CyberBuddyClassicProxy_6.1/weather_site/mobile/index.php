<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Unisys Weather
</title>
<meta name="description" content="The intent of this weather site is to provide a complete source of graphical weather 		information. This is intended to satisfy the needs of the weather professional, but can be a tool for the casual user as well. The graphics and data are displayed as a meteorologist would expect to see. For the novice user, there are detailed explanation pages to guide them through the various plots, charts and images. The data on this site are provided from the National Weather Service via the NOAAPORT satellite data service. All the images are generated using the Weather Processor (WXP) analysis package which is available from Unisys. "/>
<meta name="keywords" content="weather, unisys, unisys weather, weather maps, maps, nam, wrf, GFS, GFSx, hurricane, radar, satellite, surface, upper air">
</meta>
<meta name="copyright" content="Unisys Corp - 2010" />
<meta name="author" content="Unisys Corporation" />
<meta name="email" content="technical-support@weather.unisys.com" />
<meta name="Charset" content="UTF-8" />
<meta name="Distribution" content="Global" />
<meta name="Rating" content="General" />
<meta name="Robots" content="INDEX,FOLLOW" />
<meta name="Revisit-after" content="7 Days" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" type="text/css" href="/css/NOAA.css" />
</head>
<body>
<div id="wrap">
<div>
  <ul id="top-navigation" class="inline-navigation-list">
    <li><a href="http://www.unisys.com" title="Unisys Home Page">Unisys.com</a></li>
    <li><a href="/index.php" title="Unisys Weather">Weather Home</a></li>
    <li><a href="/analyses.php" title="Analyses">Analyses</a></li>
    <li><a href="/forehome.php" title="Forecast">Forecasts</a></li>
    <li><a href="/archives.php" title="Archives">Archives</a></li>
    <li><a href="/links.php" title="NOAA Links">NOAA Links</a></li>
    <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
  </ul>
</div>
<div id="header"> <a href="http://unisys.com"><img src="/images/Unisys_logo.gif" alt="Unisys"></a>
  <h1>Unisys Weather</h1>
</div>

<div align="center" class="dropfull">

<div align="center">
<div align="left">
<h4>The Unisys Weather Enthusiast App</h4>
</div>
<table class="center">
<tr>
	<td>
		<h2>view</h2>
        <img src="/mobile/2-Home.png" height="292" width="150"/>
	</td>
	<td>
		<h2>precision dial</h2>
		<img src="/mobile/4-Dial.png" height="292" width="150"/>
	</td>
	<td>
		<h2>browse & add</h2>
		<img src="/mobile/5-Add.png" height="292" width="150"/>
	</td>
	<td>
		<h2>manage</h2>
		<img src="/mobile/6-Grid.png" height="292" width="150"/>
	</td>
	<td>
		<h2>forecast</h2>
		<img src="/mobile/7-Forecast.png" height="292" width="150"/>
	</td>
</tr>
</table>
</div>
</div>
<br />
<div id="mobileright">
	<h2><big>Designed for the iPhone<small>&#0153</small> and iPod Touch<small><small>&#0174</small></small> </big></h2>
	<br />
	<p>The Unisys Weather Enthusiast App allows you to view weather in a whole new way!  
	Access to thousands of constantly updated images is now at your fingertips.  
	Quickly add, view, and alter images on the fly using this innovative weather tracking tool. 
	Now you can predict the weather just like the pros!
	</p>

	<h2><small>Unisys Advantage</small></h2>
	<ul>
		<li>Unisys Weather puts over 4000 up-to-date images in the palm of your hand</li>
		<li>More than 5,000 organizations around the world use the Unisys Data and Display solution to monitor weather conditions</li> 
		<li>Unisys Weather solutions allow you to customize weather displays to meet your needs</li>
	</ul>

	<p>
	<h2><small>Features:</small></h2>
	<ul>
		<li>Fully interactive Grid Screen lets you rearrange images as desired</li>
		<li>Innovative Precision Dial gives you the power to quickly change the image you are looking at</li>
		<li>Quickly save and send your favorite images</li>
		<li>Flip through and compare images selected by you</li>
		<li>Edit image criteria on the fly using the innovative Precision Dial</li>
		<li>Rearrange images any way you like in the custom Grid Screen</li>
	</ul>
	</p>
	</div>
	<div id="mobileleft">
	<p align="center">
	<a href="http://itunes.apple.com/us/app/unisys-weather-enthusiast/id430698582?mt=8"><img src="/mobile/App_Store.png" height="114" width="310" /></a>
	<br/>
	<img src="/mobile/WebsiteImage.png" width="300" height="300" />
	</p>
	<p align="center"><i>Unisys Weather Enthusiast App</i></p>
</div>

<div>
<hr>
<p>
<h2>Categories of Weather Images Available</h2>

<ul>
	<li><b>Satellite Images: </b>  Including Infrared, Enhanced Infrared, Visible, Satellite/Radar Composite and Water Vapor.  Images are available from the current time to 12 hours in the past in 1 hour increments.</li>
	<li><b>Radar Images: </b>  Including national and regional mosaics available from the current time to 6 hours in the past in 30 minute increments.</li>
	<li><b>Surface Data: </b>  Including Daily Precipitation, High Temperature, High Temperature Contour, Low Temperature, Low Temperature Contour, Monthly Precipitation, Snow Cover, Sea Surface Temperature Anomaly, Sea Surface Temperature, Surface Depiction, Surface Fronts, Regional and National Surface Maps.  Images are available from the current time to 12 hours in the past in 1 hour increments.</li>
	<li><b>Upper Air Data: </b>  Including Constant Height Plots and Contours and Mandatory Height Plots.  Images are available from the current time to 72 hours in the past in 12 hour increments.</li> 
	<li><b>Forecast Model Data: </b></li>
	<ul>
		<li><b>RUC:</b>  Including the 4 Panel and Initial plots.</li>
		<li><b>ECMWF: </b>  Including the 3 day, 4 day, 5 day, 6 day and 4 Panel Plots for North America and Europe.</li>
		<li><b>GFS: </b>  Including; the 4 Panel, 300mb, 400mb, 500mb, 700mb, 850mb, 1000mb, Pressure/Precipitation and Relative Humidity plots for the current time to 5 days in the future in 12 hour increments.</li>
		<li><b>GFSx: </b>  Including; the 4 Panel, 300mb, 400mb, 500mb, 700mb, 850mb, 1000mb, Pressure/Precipitation, Height/SLP and Relative Humidity plots for the current time to 10 days in the future in 12 hour increments.</li>
		<li><b>NAM: </b>  Including the 4 Panel, 300mb, 400mb, 500mb, 700mb, 850mb, 1000mb, Pressure/Precipitation, Surface and Relative Humidity plots for the current time to 60 hours  in the future in 12 hour increments.</li>
		<li><b>MOS: </b>  Including the GFS MOS, MOS Depiction and the NAM MOS plots.  Forecast plots are available for the current time through 60 hours in the future for the NAM model and 8 days in the future for the GFS model in 12 hour increments.</li>
	</ul>
</ul>
</p>

<p align="right">
<a href="/mobile/faq.php"><b>Fequently Asked Questions</b></a>
<br />
<a href="mailto:mobileappsupport@unisys.com"><b>Technical Support</b></a>
<br />
<a href="/mobile/terms.php"><b>Terms of Use</b></a>
</p>
</div>


<div class="clearboth">&nbsp;</div>

</div>

<div id="footer"> <span id="copyright"><small>Copyright &copy; Unisys 2012</small></span>
  <ul class="inline-navigation-list" id="bottom-navigation">
    <li><a href="http://www.unisys.com/unisys/privacy.html" target="_blank">Privacy Notice</a></li>
    <li><a href="http://www.unisys.com/unisys/terms-and-conditions.html" target="_blank">Terms of Use</a></li>
    <li><a href="/contactus.php">Contact Us</a></li>
    <li><a href="http://www.unisys.com/unisys/trademarks.html" target="_blank">Trademarks</a></li>
  </ul>
</div>
</div>
</body>
</html>
 
