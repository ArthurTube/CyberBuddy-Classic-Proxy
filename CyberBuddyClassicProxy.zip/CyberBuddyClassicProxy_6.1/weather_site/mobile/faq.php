<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Unisys Weather
</title>
<meta name="description" content="The intent of this weather site is to provide a complete source of graphical weather 		information. This is intended to satisfy the needs of the weather professional, but can be a tool for the casual user as well. The graphics and data are displayed as a meteorologist would expect to see. For the novice user, there are detailed explanation pages to guide them through the various plots, charts and images. The data on this site are provided from the National Weather Service via the NOAAPORT satellite data service. All the images are generated using the Weather Processor (WXP) analysis package which is available from Unisys. "/>
<meta name="keywords" content="weather, unisys, unisys weather, weather maps, maps, nam, wrf, GFS, GFSx, hurricane, radar, satellite, surface, upper air">
</meta>
<meta name="copyright" content="Unisys Corp - 2010" />
<meta name="author" content="Unisys Corporation" />
<meta name="email" content="technical-support@weather.unisys.com" />
<meta name="Charset" content="UTF-8" />
<meta name="Distribution" content="Global" />
<meta name="Rating" content="General" />
<meta name="Robots" content="INDEX,FOLLOW" />
<meta name="Revisit-after" content="7 Days" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" type="text/css" href="/css/NOAA.css" />
</head>
<body>
<div id="wrap">
<div>
  <ul id="top-navigation" class="inline-navigation-list">
    <li><a href="http://www.unisys.com" title="Unisys Home Page">Unisys.com</a></li>
    <li><a href="/index.php" title="Unisys Weather">Weather Home</a></li>
    <li><a href="/analyses.php" title="Analyses">Analyses</a></li>
    <li><a href="/forehome.php" title="Forecast">Forecasts</a></li>
    <li><a href="/archives.php" title="Archives">Archives</a></li>
    <li><a href="/links.php" title="NOAA Links">NOAA Links</a></li>
    <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
  </ul>
</div>
<div id="header"> <a href="http://unisys.com"><img src="/images/Unisys_logo.gif" alt="Unisys"></a>
  <h1>Unisys Weather</h1>
</div>

<div class="dropfull">
<h2>Frequently Asked Questions</h2>
	<p><b>Q. What is the Unisys Weather Enthusiast application?</b></p>
		<p>A. Unisys Weather Enthusiast is an application designed to allow weather enthusiasts to quickly select and view their favorite weather imagery from their Apple iPhone or iPod Touch.  Users add frequently viewed images to their image list for quick access on the home screen.</p>
	<p><b>Q. How do I add images to my list?</b></p>
		<p>A. A user begins by selecting images based on their specifications from the &quotAdd&quot view.  Toggle between different types of imagery using the tab bar at the bottom, and fine tune your imagery by tapping the criteria types at the top.  When you have found an image you want to save as a favorite, press the &quotPlus&quot button in the top right of the screen.  This image is now added to your image list.</p>
	<p><b>Q. How do I view images saved in my list?</b></p>
		<p>A. Images saved in your list are viewable from the home screen of the application.  You can swipe left and right to move from image to image, as well as pinch to zoom in on an image currently in view.  Rotating the device to landscape mode will display the images full screen on the device.  Two arrows in the bottom left and right corners of the view allow the user to change the image currently being displayed.</p>
	<p><b>Q. How do I reorder my image list?</b></p>
		<p>A. Tapping the &quotThumbnail&quot button from the home screen allows you to click and drag your images around, reordering your list.</p>
	<p><b>Q. How do I remove an image from my list?</b></p>
		<p>A. Images can be removed from the home screen by tapping the trash can.  This will remove the image currently in view.  In addition, images can be removed from the &quotThumbnail&quot view by tapping the trash can, then tapping the images they wish to remove, and tapping again when done.</p>
	<p><b>Q. Why are some of the criteria in grayed out?</b></p>
		<p>A. Criteria that is grayed out is not applicable for the current selected image. To override the current image and start with new criteria check the button labeled "reset image."</p>



</div>
<p align="right">
<a href="/mobile/index.php"><b>Mobile App Home</b></a>
<br />
<a href="mailto:mobileappsupport@unisys.com"><b>Technical Support</b></a>
<br />
<a href="/mobile/terms.php"><b>Terms of Use</b></a>
</p>
<div class="clearboth">&nbsp;</div>

</div>

<div id="footer"> <span id="copyright"><small>Copyright &copy; Unisys 2012</small></span>
  <ul class="inline-navigation-list" id="bottom-navigation">
    <li><a href="http://www.unisys.com/unisys/privacy.html" target="_blank">Privacy Notice</a></li>
    <li><a href="http://www.unisys.com/unisys/terms-and-conditions.html" target="_blank">Terms of Use</a></li>
    <li><a href="/contactus.php">Contact Us</a></li>
    <li><a href="http://www.unisys.com/unisys/trademarks.html" target="_blank">Trademarks</a></li>
  </ul>
</div>
</div>
</body>
</html>
 
