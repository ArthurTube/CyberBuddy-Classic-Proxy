<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Unisys Weather
</title>
<meta name="description" content="The intent of this weather site is to provide a complete source of graphical weather 		information. This is intended to satisfy the needs of the weather professional, but can be a tool for the casual user as well. The graphics and data are displayed as a meteorologist would expect to see. For the novice user, there are detailed explanation pages to guide them through the various plots, charts and images. The data on this site are provided from the National Weather Service via the NOAAPORT satellite data service. All the images are generated using the Weather Processor (WXP) analysis package which is available from Unisys. "/>
<meta name="keywords" content="weather, unisys, unisys weather, weather maps, maps, nam, wrf, GFS, GFSx, hurricane, radar, satellite, surface, upper air">
</meta>
<meta name="copyright" content="Unisys Corp - 2010" />
<meta name="author" content="Unisys Corporation" />
<meta name="email" content="technical-support@weather.unisys.com" />
<meta name="Charset" content="UTF-8" />
<meta name="Distribution" content="Global" />
<meta name="Rating" content="General" />
<meta name="Robots" content="INDEX,FOLLOW" />
<meta name="Revisit-after" content="7 Days" />
<meta http-equiv="imagetoolbar" content="no" />
<link rel="stylesheet" type="text/css" href="/css/NOAA.css" />
</head>
<body>
<div id="wrap">
<div>
  <ul id="top-navigation" class="inline-navigation-list">
    <li><a href="http://www.unisys.com" title="Unisys Home Page">Unisys.com</a></li>
    <li><a href="/index.php" title="Unisys Weather">Weather Home</a></li>
    <li><a href="/analyses.php" title="Analyses">Analyses</a></li>
    <li><a href="/forehome.php" title="Forecast">Forecasts</a></li>
    <li><a href="/archives.php" title="Archives">Archives</a></li>
    <li><a href="/links.php" title="NOAA Links">NOAA Links</a></li>
    <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
  </ul>
</div>
<div id="header"> <a href="http://unisys.com"><img src="/images/Unisys_logo.gif" alt="Unisys"></a>
  <h1>Unisys Weather</h1>
</div>


<div class="dropfull">
<h2>Unisys Weather Content Terms of Use</h2><br/>
<p>
ATTENTION: PLEASE READ THESE TERMS OF USE ("TERMS") BEFORE USING THE UNISYS WEATHER FOR ENTHUSIASTS APPLICATION (&quotAPPLICATION&quot) TO ACCESS ANY CONTENT.
IF YOU DO NOT ACCEPT THESE TERMS, YOU ARE NOT AUTHORIZED TO USE THE APPLICATION OR THE CONTENT PRESENTED BY THE APPLICATION.
UNISYS CORPORATION ("UNISYS") RESERVES THE RIGHT TO CHANGE THESE TERMS AT ANY TIME, WITHOUT NOTICE TO YOU.  
ACCORDINGLY, YOU ARE ADVISED TO VISIT HTTP://WWW.WEATHER.UNISYS.COM/MOBILE/TERMS.PHP TO REVIEW THE MOST CURRENT VERSION.
</p>
<br>
<b>Use of Content -</b> 
<p>The Content presented by the Application is the property of Unisys or is licensed to Unisys by a third party.  
You may use the Application to display the Content, provided you do so only for personal, non-commercial purposes; that you do not modify the Content, and that you retain all copyright and other proprietary notices associated with the Content. 
Except as stated above, or unless otherwise expressly stated, no license is granted herein expressly, impliedly, by estoppel or otherwise under any patent, trade secret, trademark, copyright or other intellectual property of Unisys or any third party.
</p>
<b>Disclaimers -</b>
<p>THE CONTENT PUBLISHED OR PROVIDED BY THE APPLICATION IS FURNISHED TO YOU "AS IS" AND WITHOUT WARRANTIES OF ANY KIND, WHETHER EXPRESS OR IMPLIED.  TO THE FULLEST EXTENT PERMISSIBLE UNDER APPLICABLE LAW, UNISYS DISCLAIMS ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING, WITHOUT LIMITATION, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE, TITLE, OR NON-INFRINGEMENT.  UNISYS DOES NOT REPRESENT OR WARRANT THAT ACCESS TO THE CONTENT WILL BE UNINTERRUPTED OR ERROR-FREE, THAT DEFECTS WILL BE CORRECTED, OR THAT THE CONTENT OR THE SERVER(S) THAT SUPPLY THE CONTENT ARE FREE OF VIRUSES OR OTHER HARMFUL COMPONENTS.  UNISYS DOES NOT MAKE ANY WARRANTIES OR REPRESENTATIONS REGARDING THE USE OF THE CONTENT IN TERMS OF ITS COMPLETENESS, CORRECTNESS, ACCURACY, ADEQUACY, USEFULNESS, TIMELINESS, RELIABILITY OR OTHERWISE.
SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OF WARRANTIES, SO SOME OR ALL OF THE FOREGOING EXCLUSIONS MAY NOT BE APPLICABLE TO YOU.  IN THE EVENT A PARTICULAR EXCLUSION IS FOUND TO BE UNENFORCEABLE, BY ACCESSING THE CONTENT YOU AGREE THAT THE REMAINING EXCLUSIONS SHALL STILL APPLY.
Limitation of Liability - IN NO EVENT SHALL UNISYS OR ANY OTHER PARTY INVOLVED IN PRODUCING OR DELIVERING THE CONTENT BE LIABLE TO ANY PARTY FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, PUNITIVE, EXEMPLARY OR CONSEQUENTIAL DAMAGES OF ANY TYPE WHATSOEVER EVEN IF IT HAS, OR THEY HAVE, BEEN PREVIOUSLY ADVISED OF THE POSSIBILITY OF SUCH DAMAGES, WHETHER IN AN ACTION UNDER CONTRACT, TORT, NEGLIGENCE, OR ANY OTHER THEORY, RELATED TO OR ARISING FROM THE CONTENT OR FROM ANY USE OF THE CONTENT, OR FROM ANY CONTENT, SITE OR RESOURCES LINKED TO, REFERENCED BY, OR ACCESSED THROUGH THE CONTENT OR THE APPLICATION, INCLUDING, WITHOUT LIMITATION, ANY LOST PROFITS, BUSINESS INTERRUPTION, LOST SAVINGS OR LOSS OF PROGRAMS OR OTHER DATA, EVEN IF UNISYS IS EXPRESSLY ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.  
</p>
<b>Links to Third Party Content or Sites -</b>
<p>As a convenience, the Content may include links to third party content or sites.  Unisys does not review or control, and is thus not responsible for, these third party sites or the content.  Such links should not be assumed to constitute an endorsement or recommendation by Unisys.  By clicking on any of these links, you understand that you are accessing these other sites or the content, and agree that you are doing so at your own risk.
</p>
<b>Trademarks -</b> 
<p>Unisys and the Unisys logo are trademarks of Unisys Corporation.  A list of other Unisys marks is available at http://www.unisys.com/unisys/trademarks.html.  All other marks used in the Content are the property of their respective owners.
</p>
<b>User Feedback -</b> 
<p>Unless otherwise stated, any communication provided by you to Unisys in connection with the Content will be received only on a non-confidential basis.  There shall be no obligation on the part of Unisys with respect to use or disclosure of any information in such communication.  Unisys Corporation shall have the unrestricted right to copy, use and distribute any information you communicate to it, including but not limited to any ideas, concepts, know-how, techniques, software, documentation, diagrams, schematics or blueprints.  Additionally, all such information may be used by Unisys in any manner for any purpose including, but not limited to, developing and manufacturing products and providing services.
</p>
<b>Governing Law -</b> 
<p>These Terms shall be governed in all respects by the laws of the Commonwealth of Pennsylvania, without regard to its conflict of laws provisions.
</p>
<b>Import/Export -</b> 
<p>You may not access, download, use, or export any content in violation of any applicable laws or regulations including, without limitation, the International Traffic in Arms Regulations (ITAR) and Export Administration Regulations (EAR) and other U.S. export laws.
</p>
<b>Privacy -</b> 
<p>For information on how Unisys handles your personal information, see http://www.unisys.com/unisys/privacy-policy.html.
</p>
<b>Indemnification -</b> 
<p>You agree to indemnify, defend and hold harmless, Unisys, its subsidiaries, affiliates, joint venturers, business partners, licensors, employees, agents and third party information providers from and against all losses, expenses, damages and costs, including attorneys fees, resulting from any violation of these Terms (including negligent or wrongful conduct) by you or your use and access to this Site.
</p>
<b>No Waiver -</b> 
<p>The failure by Unisys to insist upon or enforce strict performance of any provision of these Terms shall not be construed as a waiver of any provision or right.
</p>
</div>
<p align="right">
<a href="/mobile/faq.php"><b>Fequently Asked Questions</b></a>
<br />
<a href="mailto:mobileappsupport@unisys.com"><b>Technical Support</b></a>
<br />
<a href="/mobile/index.php"><b>Mobile App Home</b></a>
</p>
<div class="clearboth">&nbsp;</div>

</div>

<div id="footer"> <span id="copyright"><small>Copyright &copy; Unisys 2012</small></span>
  <ul class="inline-navigation-list" id="bottom-navigation">
    <li><a href="http://www.unisys.com/unisys/privacy.html" target="_blank">Privacy Notice</a></li>
    <li><a href="http://www.unisys.com/unisys/terms-and-conditions.html" target="_blank">Terms of Use</a></li>
    <li><a href="/contactus.php">Contact Us</a></li>
    <li><a href="http://www.unisys.com/unisys/trademarks.html" target="_blank">Trademarks</a></li>
  </ul>
</div>
</div>
</body>
</html>
 
