<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Unisys Weather </title>
<meta name="description" content="The intent of this weather site is to provide a complete source of graphical weather 		information. This is intended to satisfy the needs of the weather professional, but can be a tool for the casual user as well. The graphics and data are displayed as a meteorologist would expect to see. For the novice user, there are detailed explanation pages to guide them through the various plots, charts and images. The data on this site are provided from the National Weather Service via the NOAAPORT satellite data service. All the images are generated using the Weather Processor (WXP) analysis package which is available from Unisys. "/>
<meta name="keywords" content="weather, unisys, unisys weather, weather maps, maps, nam, wrf, GFS, GFSx, hurricane, radar, satellite, surface, upper air" />
<meta name="copyright" content="Unisys Corp - 2011" />
<meta name="author" content="Unisys Corporation" />
<meta name="email" content="technical-support@weather.unisys.com" />
<meta name="Distribution" content="Global" />
<meta name="Rating" content="General" />
<meta name="Robots" content="INDEX,FOLLOW" />
<meta name="Revisit-after" content="7 Days" />
<meta http-equiv="Content-type" content="text/html;charset=UTF-8" />
<meta http-equiv="imagetoolbar" content="no" />
<meta http-equiv="Refresh" content="900" />
<meta http-equiv="X-UA-Compatible" content="IE=8"/>
<link rel="stylesheet" type="text/css" href="/css/WMAX.css" />
</head>
<body>
<div id="wrap">
  <div id="top-menu">
    <ul id="top-navigation" class="inline-navigation-list">
      <li><a href="http://www.unisys.com" title="Unisys Home Page">Unisys.com</a></li>
      <li><a href="/index.php" title="Unisys Weather">Weather Home</a></li>
      <li><a href="/analyses.php" title="Analyses">Analyses</a></li>
      <li><a href="/forehome.php" title="Forecast">Forecasts</a></li>
      <li><a href="/archives.php" title="Archives">Archives</a></li>
      <li><a href="/links.php" title="NOAA Links">NOAA Links</a></li>
      <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
    </ul>
  </div>

  <div id="header"> <a href="http://unisys.com"><img src="/images/Unisys_logo.gif" alt="Unisys" /></a>
    <h1>Unisys Weather</h1>
  </div>

<div id="leftside">
  <ul class="avmenu">
    <li><a href="/index.php" class="purple">Unisys Weather</a></li>
    <li><a href="/index.php"> Weather Home</a></li>
    <li><a href="/solutions/index.php">Weather Solutions</a></li>
    <li><a href="/mobile/index.php"><img id="mobile_icon" src="/mobile/Icon.png" width="24" height="24" alt="Download Unisys Weather Mobile App"/>iPhone App</a></li>
    <li><a href="/info/index.php">Information</a></li>
    <li><a href="/content.php">Contents</a></li>
    <li><a href="/analyses.php" class="purple">Analyses</a></li>
    <li><a href="/satellite/index.php">Satellite Images</a></li>
    <li><a href="/surface/index.php">Surface Data</a></li>
    <li><a href="/upper_air/index.php">Upper Air Data</a></li>
    <li><a href="/radar/index.php">Radar Data</a></li>
    <li><a href="/forehome.php" class="purple">Forecasts</a></li>
    <li><a href="/mos/index.php">Model Statistics</a></li>
    <li><a href="/nam/index.php">NAM/Wrf Model</a></li>
    <li><a href="/gfs/index.php?r=us">GFS/Avn Model</a></li>
    <li><a href="/gfsx/index.php?r=us">GFSx/MRF Model</a></li>
    <li><a href="/rap/index.php">RAP Model</a></li>
    <li><a href="/ecmwf/index.php">ECMWF Model</a></li>
    <li><a href="/archives.php" class="purple">Archive</a></li>
    <li><a href="/hurricane/index.php">Hurricane Data</a></li>
    <li><a href="/archive/index.php">Archive of Images</a></li>
    <li><a href="/usgs/index.php">USGS Maps</a></li>
  </ul>
</div>

<div id="extras">
  <ul class="avmenu">
    <li><a href="/foresetup.php" class="purple">Get a Forecast</a></li>
  </ul>

<script type="text/javascript">
function fsubmit()
{
     document.getElementById("Forecast").submit();
}
</script>

  <form method="get" id="Forecast" action="/forecast.php">
    <p class="center"> Enter a zip code or city name to get forecast:
      <input type="text" name="Name" id="Name" size="15" />
      <br />
      <button type="submit" style="border:none; background-color:transparent;">
         <img src="/images/GO.png" id="Go" alt="Get Forecast Data" style="height:30px;" />
      </button>
      <a href="/foresetup.php"><img src="/images/setup.png" alt="Setup Location" height="30" width="70" /></a> </p>
  </form>
  <script type="text/javascript">
                <!-- HIDE
                var index = document.cookie.indexOf("ZIP")
                var zipcode = 0
                var region = ""
                if( index != -1 ){
                   //zipcode = parseInt( document.cookie.substring(index+4,index+9),10)
                   zipcode = document.cookie.substring(index+4,index+9)
                   var validateZipCode = function() {
                     var zipcodeRegexp = /^\d{5}$/;
                     var zipTest = zipcodeRegexp.test(zipcode);
   
                     if (zipTest == false) {
                       return false;
                     }
                   }
                   validateZipCode();

                    if( ! isNaN(zipcode))

                    document.getElementById('Name').value = zipcode

                   if( zipcode >= 01000 && zipcode <= 19699 )
                      region = "ne"
                   else if( zipcode >= 19700 && zipcode <= 28999 )
                      region = "at"
                   else if( zipcode >= 43000 && zipcode <= 45999 )
                      region = "at"
                   else if( zipcode >= 29000 && zipcode <= 36999 )
                      region = "se"
                   else if( zipcode >= 38600 && zipcode <= 39999 )
                      region = "se"
                   else if( zipcode >= 46000 && zipcode <= 58999 )
                      region = "mw"
                   else if( zipcode >= 60000 && zipcode <= 62999 )
                      region = "mw"
                   else if( zipcode >= 68000 && zipcode <= 69999 )
                      region = "mw"
                   else if( zipcode >= 63000 && zipcode <= 67999 )
                      region = "cp"
                   else if( zipcode >= 71600 && zipcode <= 74999 )
                      region = "cp"
                   else if( zipcode >= 70000 && zipcode <= 71499 )
                      region = "sp"
                   else if( zipcode >= 75000 && zipcode <= 79999 )
                      region = "sp"
                   else if( zipcode >= 59000 && zipcode <= 59999 )
                      region = "nw"
                   else if( zipcode >= 82000 && zipcode <= 83999 )
                      region = "nw"
                   else if( zipcode >= 97000 && zipcode <= 99499 )
                      region = "nw"
                   else if( zipcode >= 80000 && zipcode <= 81999 )
                      region = "sw"
                   else if( zipcode >= 84000 && zipcode <= 96199 )
                      region = "sw"

                   if( region != "" ){
                      document.write( "<table border=\"0\" align=\"center\" class=\"grey\" width=\"100%\">" )
                      document.write( "<tr>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/surface/sfc_map.php?image=sfc&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Sfc" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=\"radar/rad" + region + ".php\">" )
                      document.write( "<a href=/radar/rcm_rad.php?image=rad&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Rad" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=vis&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Vis" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=enh&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>IR" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "</tr></table>" )
                      document.write( "</b>" )
                      }


                   
                   }
                // UNHIDE -->
                </script>
  <ul class="avmenu">
    <li><a href="/links.php" class="purple">NOAA Links</a></li>
    <li><a href="http://lwf.ncdc.noaa.gov/">National Climatic Data Center</a></li>
    <li><a href="http://www.cpc.noaa.gov/">Climate Prediction Center</a></li>
    <li><a href="http://oceanservice.noaa.gov/">National Ocean Service</a></li>
    <li><a href="http://www.lib.noaa.gov/">NOAA Library</a></li>
    <li><a href="http://www.oar.noaa.gov/">NOAA Office of Oceanic and Atmospheric Research</a></li>
    <li><a href="http://www.esrl.noaa.gov/">Earth Systems Research Laboratory</a></li>
    <li><a href="/overview.php" class="purple">About Us</a></li>
    <li><a href="/overview.php" title="Contact Us">Overview</a></li>
    <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
  </ul>
</div>
<div id="content">

<div class="drop">
<h2>MOS Data Details</h2>

<p>Forecast models postprocessors generate MOS (Model Output 
Statistics) which are statistically derived surface conditions for particular 
cities. Two types of plots include forecast surface conditions from the NAM 
model as well as maximum temperature predictions from the GFS out to 7 days. 
There are MOS based meteograms which give a graphical representation of the 
weather conditions for the next 60 hours for individual cities. The NAM plots 
are updated once every 12 hours at around 12:15 EST. The GFS plots are updated
once a day at around 8 AM EST. </p>

<hr />
<a name="forecast"></a><h3>NAM MOS Forecast</h3>
<p><img src="/mos/images/mos_sample.gif" alt="Sample NAM MOS plot" height="180" width="240" /><br /><i>Sample NAM MOS plot</i> </p><br /><br />

<p>This plot shows forecasted surface conditions at a 
particular forecast time for several major cities. The plot contains a 
contour analysis of 12 hour quantitative precipitation (colors) and plotted 
conditions for the forecast time. </p>

<h3>Quantitative precpitation field</h3>
<p>
The quantitative precpitation field shows estimated 12 hour precipitation 
(liquid equivalent) for the 12 hour period prior to the valid time. For 
example a 12 hour precipitation field valid 12Z THU 11 NOV 93 would show 12 
hour accumulated precipitation from 00Z THU to 12Z THU. The contours follow 
this scale:<br />
<img src="/mos/images/eta_sfc_lgnd.gif" alt="Eta_Sfc_Lgnd" height="23" width="311" /> </p>

<table border="1">
  <tr>
    <td>Black</td>
    <td>no measurable precip.</td>
  </tr>
  <tr>
    <td>Dark Magenta</td>
    <td>.01 to .05 inches</td>
  </tr>
  <tr>
    <td>Medium Magenta</td>
    <td>.05 to .10 inches</td>
  </tr>
  <tr>
    <td>Light Magenta</td>
    <td>.10 to .25 inches</td>
  </tr>
  <tr>
    <td>Blue-Magenta</td>
    <td>.25 to .50 inches</td>
  </tr>
  <tr>
    <td>Blue</td>
    <td>.50 to 1.0 inches</td>
  </tr>
  <tr>
    <td>Green</td>
    <td>1.0 to 2.0 inches</td>
  </tr>
  <tr>
    <td>Yellow</td>
    <td>2.0 to 4.0 inches</td>
  </tr>
  <tr>
    <td>Orange</td>
    <td>greater than 4.0 inches</td>
  </tr>
</table>

<p>In addition, the precipitation forecast can be used to 
estimate snow fall. A general 10 to 1 ratio can be used for snowfall based 
on the liquid equivalent shown in this chart. </p>

<a name="mos_plot"></a><h3>Forecasted surface data</h3>
<p>
The plotted information is a station model plot of surface conditions for the 
forecast time. The MOS station model plot contains the following information:
<br />
<img src="/mos/images/mos_plot_lgnd.gif" alt="MOS_Plot_Lgnd" height="88" width="358" /> </p>

<table border="1">
  <tr>
    <td ><b>Data</b></td>
    <td><b>Description</b></td>
  </tr>
  <tr>
    <td >temperature (F)</td>
    <td>upper left</td>
  </tr>
  <tr>
    <td >forecasted weather</td>
    <td>symbol center left</td>
  </tr>
  <tr>
    <td >dewpoint (F)</td>
    <td>lower left</td>
  </tr>
  <tr>
    <td >prob. of prec. (%)</td>
    <td>upper right</td>
  </tr>
  <tr>
    <td >cloud cover</td>
    <td>center circle (white fill indicates % cloud coverage)</td>
  </tr>
  <tr>
    <td >winds</td>
    <td>wind barb</td>
  </tr>
</table>
<a name="symbols"></a><h3>Weather Symbols</h3>
<p>
<img src="/mos/images/weather_lgnd.gif" alt="Weather_Lgnd" height="210" width="484" /><br />
<img src="/mos/images/cloud_lgnd.gif" alt="Cloud_Lgnd" height="248" width="123" />
<img src="/mos/images/winds_lgnd.gif" alt="Winds_Lgnd" height="255" width="148" /> </p>

<hr />
<a name="gfs"></a><h3>GFSX MOS Forecast</h3>

<p><img src="/mos/images/mos_mrf_sample.gif" alt="Sample MRF MOS plot" height="180" width="240" /><br /><i>Sample MRF MOS plot</i> </p>

<p>This plot shows forecasted information from the Glocal 
Forecast System (GFS) model extended MOS surface data. This data include 
the predicted maximum temperature (colors) and probability of precipitation 
(POP) for 1 through 7 days. </p>

<h3>Maximum temperature contour plot</h3>
<p>
<img src="/mos/images/mos_mrf_lgnd.gif" alt="MOS_Mrf_Lgnd" height="22" width="313" /><br />
The maximum temperatures are color contoured with a 5 degree contour interval.
</p>

<h3>Probability of precipitation plot</h3>
<p>
The POP data are contoured as well with the 10% line dashed, the areas from 
30% to 50% filled with diagonal black lines, and the areas greater than 50% 
hatched. Therefore, the likely areas of precipitation would show up hatched. 
</p>

</div>

<div class="clearboth">&nbsp;</div>

</div>

<div id="footer"> <span id="copyright"><small>Copyright &copy; Unisys 2012</small></span>
  <ul class="inline-navigation-list" id="bottom-navigation">
    <li><a href="http://www.unisys.com/unisys/privacy.html" target="_blank">Privacy Notice</a></li>
    <li><a href="http://www.unisys.com/unisys/terms-and-conditions.html" target="_blank">Terms of Use</a></li>
    <li><a href="/contactus.php">Contact Us</a></li>
    <li><a href="http://www.unisys.com/unisys/trademarks.html" target="_blank">Trademarks</a></li>
  </ul>
</div>
</div>
</body>
</html>
