<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Unisys Weather  - 2011 Hurricane/Tropical Data for Atlantic </title>
<meta name="description" content="The intent of this weather site is to provide a complete source of graphical weather 		information. This is intended to satisfy the needs of the weather professional, but can be a tool for the casual user as well. The graphics and data are displayed as a meteorologist would expect to see. For the novice user, there are detailed explanation pages to guide them through the various plots, charts and images. The data on this site are provided from the National Weather Service via the NOAAPORT satellite data service. All the images are generated using the Weather Processor (WXP) analysis package which is available from Unisys. "/>
<meta name="keywords" content="weather, unisys, unisys weather, weather maps, maps, nam, wrf, GFS, GFSx, hurricane, radar, satellite, surface, upper air" />
<meta name="copyright" content="Unisys Corp - 2011" />
<meta name="author" content="Unisys Corporation" />
<meta name="email" content="technical-support@weather.unisys.com" />
<meta name="Distribution" content="Global" />
<meta name="Rating" content="General" />
<meta name="Robots" content="INDEX,FOLLOW" />
<meta name="Revisit-after" content="7 Days" />
<meta http-equiv="Content-type" content="text/html;charset=UTF-8" />
<meta http-equiv="imagetoolbar" content="no" />
<meta http-equiv="Refresh" content="900" />
<meta http-equiv="X-UA-Compatible" content="IE=8"/>
<link rel="stylesheet" type="text/css" href="/css/WMAX.css" />
</head>
<body>
<div id="wrap">
  <div id="top-menu">
    <ul id="top-navigation" class="inline-navigation-list">
      <li><a href="http://www.unisys.com" title="Unisys Home Page">Unisys.com</a></li>
      <li><a href="/index.php" title="Unisys Weather">Weather Home</a></li>
      <li><a href="/analyses.php" title="Analyses">Analyses</a></li>
      <li><a href="/forehome.php" title="Forecast">Forecasts</a></li>
      <li><a href="/archives.php" title="Archives">Archives</a></li>
      <li><a href="/links.php" title="NOAA Links">NOAA Links</a></li>
      <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
    </ul>
  </div>

  <div id="header"> <a href="http://unisys.com"><img src="/images/Unisys_logo.gif" alt="Unisys" /></a>
    <h1>Unisys Weather</h1>
  </div>

<div id="leftside">
  <ul class="avmenu">
    <li><a href="/index.php" class="purple">Unisys Weather</a></li>
    <li><a href="/index.php"> Weather Home</a></li>
    <li><a href="/solutions/index.php">Weather Solutions</a></li>
    <li><a href="/mobile/index.php"><img id="mobile_icon" src="/mobile/Icon.png" width="24" height="24" alt="Download Unisys Weather Mobile App"/>iPhone App</a></li>
    <li><a href="/info/index.php">Information</a></li>
    <li><a href="/content.php">Contents</a></li>
    <li><a href="/analyses.php" class="purple">Analyses</a></li>
    <li><a href="/satellite/index.php">Satellite Images</a></li>
    <li><a href="/surface/index.php">Surface Data</a></li>
    <li><a href="/upper_air/index.php">Upper Air Data</a></li>
    <li><a href="/radar/index.php">Radar Data</a></li>
    <li><a href="/forehome.php" class="purple">Forecasts</a></li>
    <li><a href="/mos/index.php">Model Statistics</a></li>
    <li><a href="/nam/index.php">NAM/Wrf Model</a></li>
    <li><a href="/gfs/index.php?r=us">GFS/Avn Model</a></li>
    <li><a href="/gfsx/index.php?r=us">GFSx/MRF Model</a></li>
    <li><a href="/rap/index.php">RAP Model</a></li>
    <li><a href="/ecmwf/index.php">ECMWF Model</a></li>
    <li><a href="/archives.php" class="purple">Archive</a></li>
    <li><a href="/hurricane/index.php">Hurricane Data</a></li>
    <li><a href="/archive/index.php">Archive of Images</a></li>
    <li><a href="/usgs/index.php">USGS Maps</a></li>
  </ul>
</div>

<div id="extras">
  <ul class="avmenu">
    <li><a href="/foresetup.php" class="purple">Get a Forecast</a></li>
  </ul>

<script type="text/javascript">
function fsubmit()
{
     document.getElementById("Forecast").submit();
}
</script>

  <form method="get" id="Forecast" action="/forecast.php">
    <p class="center"> Enter a zip code or city name to get forecast:
      <input type="text" name="Name" id="Name" size="15" />
      <br />
      <button type="submit" style="border:none; background-color:transparent;">
         <img src="/images/GO.png" id="Go" alt="Get Forecast Data" style="height:30px;" />
      </button>
      <a href="/foresetup.php"><img src="/images/setup.png" alt="Setup Location" height="30" width="70" /></a> </p>
  </form>
  <script type="text/javascript">
                <!-- HIDE
                var index = document.cookie.indexOf("ZIP")
                var zipcode = 0
                var region = ""
                if( index != -1 ){
                   //zipcode = parseInt( document.cookie.substring(index+4,index+9),10)
                   zipcode = document.cookie.substring(index+4,index+9)
                   var validateZipCode = function() {
                     var zipcodeRegexp = /^\d{5}$/;
                     var zipTest = zipcodeRegexp.test(zipcode);
   
                     if (zipTest == false) {
                       return false;
                     }
                   }
                   validateZipCode();

                    if( ! isNaN(zipcode))

                    document.getElementById('Name').value = zipcode

                   if( zipcode >= 01000 && zipcode <= 19699 )
                      region = "ne"
                   else if( zipcode >= 19700 && zipcode <= 28999 )
                      region = "at"
                   else if( zipcode >= 43000 && zipcode <= 45999 )
                      region = "at"
                   else if( zipcode >= 29000 && zipcode <= 36999 )
                      region = "se"
                   else if( zipcode >= 38600 && zipcode <= 39999 )
                      region = "se"
                   else if( zipcode >= 46000 && zipcode <= 58999 )
                      region = "mw"
                   else if( zipcode >= 60000 && zipcode <= 62999 )
                      region = "mw"
                   else if( zipcode >= 68000 && zipcode <= 69999 )
                      region = "mw"
                   else if( zipcode >= 63000 && zipcode <= 67999 )
                      region = "cp"
                   else if( zipcode >= 71600 && zipcode <= 74999 )
                      region = "cp"
                   else if( zipcode >= 70000 && zipcode <= 71499 )
                      region = "sp"
                   else if( zipcode >= 75000 && zipcode <= 79999 )
                      region = "sp"
                   else if( zipcode >= 59000 && zipcode <= 59999 )
                      region = "nw"
                   else if( zipcode >= 82000 && zipcode <= 83999 )
                      region = "nw"
                   else if( zipcode >= 97000 && zipcode <= 99499 )
                      region = "nw"
                   else if( zipcode >= 80000 && zipcode <= 81999 )
                      region = "sw"
                   else if( zipcode >= 84000 && zipcode <= 96199 )
                      region = "sw"

                   if( region != "" ){
                      document.write( "<table border=\"0\" align=\"center\" class=\"grey\" width=\"100%\">" )
                      document.write( "<tr>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/surface/sfc_map.php?image=sfc&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Sfc" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=\"radar/rad" + region + ".php\">" )
                      document.write( "<a href=/radar/rcm_rad.php?image=rad&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Rad" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=vis&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Vis" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=enh&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>IR" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "</tr></table>" )
                      document.write( "</b>" )
                      }


                   
                   }
                // UNHIDE -->
                </script>
  <ul class="avmenu">
    <li><a href="/links.php" class="purple">NOAA Links</a></li>
    <li><a href="http://lwf.ncdc.noaa.gov/">National Climatic Data Center</a></li>
    <li><a href="http://www.cpc.noaa.gov/">Climate Prediction Center</a></li>
    <li><a href="http://oceanservice.noaa.gov/">National Ocean Service</a></li>
    <li><a href="http://www.lib.noaa.gov/">NOAA Library</a></li>
    <li><a href="http://www.oar.noaa.gov/">NOAA Office of Oceanic and Atmospheric Research</a></li>
    <li><a href="http://www.esrl.noaa.gov/">Earth Systems Research Laboratory</a></li>
    <li><a href="/overview.php" class="purple">About Us</a></li>
    <li><a href="/overview.php" title="Contact Us">Overview</a></li>
    <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
  </ul>
</div>
<div id="content">

<h2 style="font-family: helvetica,arial,sans-serif;">2005 Hurricane/Tropical Data for Atlantic</h2>
<a href="/hurricane/atlantic/2005H/track.gif">
  <img src="/hurricane/atlantic/2005H/track.gif" width="640" height="512" alt="Track Map"/></a>
<h3 style="font-family: helvetica,arial,sans-serif;">Individual Storm Summary</h3>
<p style="font-family: helvetica,arial,sans-serif;">Winds in knots, pressure in millibars,
category is based on Saffir-Simpson scale.</p>
<table border="0">
<tr style="font-size: 10pt; font-family: helvetica,arial,sans-serif; color: black;"><td width="20" align="right">#</td><td width="250">Name</td><td width="125" align="center">Date</td><td width="40" align="right">Wind</td><td width="40" align="right">Pres</td><td width="40" align="right">Cat</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">1</td><td width="250" style="color:black;">Tropical Storm ARLENE     </td><td width="125" align="right" style="color:black;">08-13 JUN     </td><td width="40" align="right" style="color:black;"> 60 </td><td width="40" align="right" style="color:black;">  30 </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">2</td><td width="250" style="color:black;">Tropical Storm BRET       </td><td width="125" align="right" style="color:black;">28-30 JUN     </td><td width="40" align="right" style="color:black;"> 35 </td><td width="40" align="right" style="color:black;">1002 </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">3</td><td width="250" style="color:black;">Hurricane CINDY           </td><td width="125" align="right" style="color:black;">03-07 JUL     </td><td width="40" align="right" style="color:black;"> 65 </td><td width="40" align="right" style="color:black;"> 992 </td><td width="40" align="right" style="color:black;">  1</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">4</td><td width="250" style="color:black;">Hurricane DENNIS          </td><td width="125" align="right" style="color:black;">05-13 JUL     </td><td width="40" align="right" style="color:black;">130 </td><td width="40" align="right" style="color:black;"> 930 </td><td width="40" align="right" style="color:black;">  4</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">5</td><td width="250" style="color:black;">Hurricane EMILY           </td><td width="125" align="right" style="color:black;">11-21 JUL     </td><td width="40" align="right" style="color:black;">135 </td><td width="40" align="right" style="color:black;"> 929 </td><td width="40" align="right" style="color:black;">  4</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">6</td><td width="250" style="color:black;">Tropical Storm FRANKLIN   </td><td width="125" align="right" style="color:black;">21-29 JUL     </td><td width="40" align="right" style="color:black;"> 60 </td><td width="40" align="right" style="color:black;"> 997 </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">7</td><td width="250" style="color:black;">Tropical Storm GERT       </td><td width="125" align="right" style="color:black;">23-25 JUL     </td><td width="40" align="right" style="color:black;"> 40 </td><td width="40" align="right" style="color:black;">1005 </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">8</td><td width="250" style="color:black;">Tropical Storm HARVEY     </td><td width="125" align="right" style="color:black;">02-08 AUG     </td><td width="40" align="right" style="color:black;"> 55 </td><td width="40" align="right" style="color:black;"> 994 </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">9</td><td width="250" style="color:black;">Hurricane IRENE           </td><td width="125" align="right" style="color:black;">04-18 AUG     </td><td width="40" align="right" style="color:black;"> 85 </td><td width="40" align="right" style="color:black;"> 975 </td><td width="40" align="right" style="color:black;">  2</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">10</td><td width="250" style="color:black;">Tropical Depression TEN   </td><td width="125" align="right" style="color:black;">13-14 AUG     </td><td width="40" align="right" style="color:black;"> 30 </td><td width="40" align="right" style="color:black;">1008 </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">11</td><td width="250" style="color:black;">Tropical Storm JOSE       </td><td width="125" align="right" style="color:black;">22-23 AUG     </td><td width="40" align="right" style="color:black;"> 45 </td><td width="40" align="right" style="color:black;">1001 </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">12</td><td width="250" style="color:black;">Hurricane KATRINA         </td><td width="125" align="right" style="color:black;">23-31 AUG     </td><td width="40" align="right" style="color:black;">150 </td><td width="40" align="right" style="color:black;"> 902 </td><td width="40" align="right" style="color:black;">  5</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">13</td><td width="250" style="color:black;">Tropical Storm LEE        </td><td width="125" align="right" style="color:black;">28 AUG-02 SEP </td><td width="40" align="right" style="color:black;"> 35 </td><td width="40" align="right" style="color:black;">1007 </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">14</td><td width="250" style="color:black;">Hurricane MARIA           </td><td width="125" align="right" style="color:black;">01-10 SEP     </td><td width="40" align="right" style="color:black;">100 </td><td width="40" align="right" style="color:black;"> 960 </td><td width="40" align="right" style="color:black;">  3</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">15</td><td width="250" style="color:black;">Hurricane NATE            </td><td width="125" align="right" style="color:black;">05-10 SEP     </td><td width="40" align="right" style="color:black;"> 80 </td><td width="40" align="right" style="color:black;"> 979 </td><td width="40" align="right" style="color:black;">  1</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">16</td><td width="250" style="color:black;">Hurricane OPHELIA         </td><td width="125" align="right" style="color:black;">06-18 SEP     </td><td width="40" align="right" style="color:black;"> 80 </td><td width="40" align="right" style="color:black;"> 976 </td><td width="40" align="right" style="color:black;">  1</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">17</td><td width="250" style="color:black;">Hurricane PHILIPPE        </td><td width="125" align="right" style="color:black;">17-24 SEP     </td><td width="40" align="right" style="color:black;"> 70 </td><td width="40" align="right" style="color:black;"> 985 </td><td width="40" align="right" style="color:black;">  1</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">18</td><td width="250" style="color:black;">Hurricane RITA            </td><td width="125" align="right" style="color:black;">18-26 SEP     </td><td width="40" align="right" style="color:black;">150 </td><td width="40" align="right" style="color:black;"> 897 </td><td width="40" align="right" style="color:black;">  5</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">19</td><td width="250" style="color:black;">Tropical Depression NINETE</td><td width="125" align="right" style="color:black;">30 SEP-02 OCT </td><td width="40" align="right" style="color:black;"> 30 </td><td width="40" align="right" style="color:black;">1006 </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">20</td><td width="250" style="color:black;">Hurricane STAN            </td><td width="125" align="right" style="color:black;">01-05 OCT     </td><td width="40" align="right" style="color:black;"> 70 </td><td width="40" align="right" style="color:black;"> 979 </td><td width="40" align="right" style="color:black;">  1</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">21</td><td width="250" style="color:black;">Tropical Storm TAMMY      </td><td width="125" align="right" style="color:black;">05-06 OCT     </td><td width="40" align="right" style="color:black;"> 45 </td><td width="40" align="right" style="color:black;">  30 </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">22</td><td width="250" style="color:black;">Tropical Depression TWENTY</td><td width="125" align="right" style="color:black;">08-09 OCT     </td><td width="40" align="right" style="color:black;"> 30 </td><td width="40" align="right" style="color:black;">1009 </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">23</td><td width="250" style="color:black;">Hurricane VINCE           </td><td width="125" align="right" style="color:black;">09-11 OCT     </td><td width="40" align="right" style="color:black;"> 65 </td><td width="40" align="right" style="color:black;"> 987 </td><td width="40" align="right" style="color:black;">  1</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">24</td><td width="250" style="color:black;">Hurricane WILMA           </td><td width="125" align="right" style="color:black;">15-25 OCT     </td><td width="40" align="right" style="color:black;">150 </td><td width="40" align="right" style="color:black;"> 882 </td><td width="40" align="right" style="color:black;">  5</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">25</td><td width="250" style="color:black;">Tropical Storm ALPHA      </td><td width="125" align="right" style="color:black;">22-24 OCT     </td><td width="40" align="right" style="color:black;"> 45 </td><td width="40" align="right" style="color:black;"> 998 </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">26</td><td width="250" style="color:black;">Hurricane BETA            </td><td width="125" align="right" style="color:black;">27-31 OCT     </td><td width="40" align="right" style="color:black;">100 </td><td width="40" align="right" style="color:black;"> 960 </td><td width="40" align="right" style="color:black;">  3</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">27</td><td width="250" style="color:black;">Tropical Depression TWENTY</td><td width="125" align="right" style="color:black;">14-16 NOV     </td><td width="40" align="right" style="color:black;"> 30 </td><td width="40" align="right" style="color:black;">1004 </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">28</td><td width="250" style="color:black;">Tropical Storm GAMMA      </td><td width="125" align="right" style="color:black;">18-21 NOV     </td><td width="40" align="right" style="color:black;"> 40 </td><td width="40" align="right" style="color:black;">1004 </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">29</td><td width="250" style="color:black;">Tropical Storm DELTA      </td><td width="125" align="right" style="color:black;">23-28 NOV     </td><td width="40" align="right" style="color:black;"> 60 </td><td width="40" align="right" style="color:black;"> 980 </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">30</td><td width="250" style="color:black;">Hurricane EPSILON         </td><td width="125" align="right" style="color:black;">29 NOV-08 DEC </td><td width="40" align="right" style="color:black;"> 75 </td><td width="40" align="right" style="color:black;"> 979 </td><td width="40" align="right" style="color:black;">  1</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">31</td><td width="250" style="color:black;">Tropical Storm ZETA       </td><td width="125" align="right" style="color:black;">30 DEC-06 JAN </td><td width="40" align="right" style="color:black;"> 55 </td><td width="40" align="right" style="color:black;"> 994 </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
</table><br/>
<big style="font-weight: bold;"><span
 style="font-family: helvetica,arial,sans-serif;"> Saffir-Simpson Scale</span></big>
      <p style="font-family: helvetica,arial,sans-serif;">The chart
color codes intensity (category based on Saffir-Simpson scale): </p>
      <table border="0" style="font-family: helvetica,arial,sans-serif;">
        <tbody>
          <tr>
            <td valign="top" bgcolor="#000099"
 style="color: rgb(255, 255, 255); font-weight: bold;"><small>Type</small></td>
            <td align="center" valign="top" bgcolor="#000099"
 style="color: rgb(255, 255, 255); font-weight: bold;"><small>Category</small></td>
            <td align="center" valign="top" bgcolor="#000099"
 style="color: rgb(255, 255, 255); font-weight: bold;"><small>Pressure
(mb)</small></td>
            <td align="center" valign="top" bgcolor="#000099"
 style="color: rgb(255, 255, 255); font-weight: bold;"><small>Winds<br/>
(knots)</small></td>
            <td align="center" valign="top" bgcolor="#000099"
 style="color: rgb(255, 255, 255); font-weight: bold;"><small>Winds<br/>
(mph)</small></td>
            <td align="center" valign="top" bgcolor="#000099"
 style="color: rgb(255, 255, 255); font-weight: bold;"><small>Line Color</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Depression</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>td</small></td>
            <td
 style="text-align: center; vertical-align: top; background-color: rgb(160, 224, 255); font-weight: bold;"><small>-----</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>&lt; 34</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>&lt; 39</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Green</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Tropical Storm</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>TS</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>-----</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>34-63</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>39-73</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Yellow</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Hurricane</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>1</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>&gt; 980</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>64-82</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>74-95</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Red</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Hurricane</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>2</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>965-980</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>83-95</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>96-110</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Light Red</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Hurricane</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>3</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>945-965</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>96-112</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>111-130</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Magenta</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Hurricane</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>4</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>920-945</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>113-135</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>131-155</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Light Magenta</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Hurricane</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>5</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>&lt; 920</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>&gt;135</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>&gt;155</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>White</small></td>
          </tr>
        </tbody>
      </table>
      <p style="font-family: helvetica,arial,sans-serif;"><small><b>NOTE:</b>
Pressures are in millibars and winds are in <b>knots</b> where one knot
is equal to 1.15 mph</small></p><hr/>
<h3 style="font-family: helvetica,arial,sans-serif;">Individual Storm Details</h3>
<table border="1" style="font-family: helvetica,arial,sans-serif;">

<TR><TD VALIGN=TOP>
<A HREF=ZETA/track.gif>
  <IMG SRC=ZETA/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Tropical Storm ZETA</b> (30 DEC-06 JAN)<br>
Storm - Max Winds: 55 Min Pres: 994 Category: TS<P>
<A HREF=ZETA/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=EPSILON/track.gif>
  <IMG SRC=EPSILON/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Hurricane EPSILON</b> (29 NOV-08 DEC)<br>
Storm - Max Winds: 75 Min Pres: 979 Category: 1<P>
<A HREF=EPSILON/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=DELTA/track.gif>
  <IMG SRC=DELTA/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Tropical Storm DELTA</b> (23-28 NOV)<br>
Storm - Max Winds: 60 Min Pres: 980 Category: TS<P>
<A HREF=DELTA/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=GAMMA/track.gif>
  <IMG SRC=GAMMA/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Tropical Storm GAMMA</b> (18-21 NOV)<br>
Storm - Max Winds: 40 Min Pres: 1004 Category: TS<P>
<A HREF=GAMMA/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=TWENTY_SEVEN/track.gif>
  <IMG SRC=TWENTY_SEVEN/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Tropical Depression TWENTY_SEVEN</b> (14-16 NOV)<br>
Storm - Max Winds: 30 Min Pres: 1004 Category: TD<P>
<A HREF=TWENTY_SEVEN/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=BETA/track.gif>
  <IMG SRC=BETA/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Hurricane BETA</b> (27-31 OCT)<br>
Storm - Max Winds: 100 Min Pres: 960 Category: 3<P>
<A HREF=BETA/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=ALPHA/track.gif>
  <IMG SRC=ALPHA/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Tropical Storm ALPHA</b> (22-24 OCT)<br>
Storm - Max Winds: 45 Min Pres: 998 Category: TS<P>
<A HREF=ALPHA/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=WILMA/track.gif>
  <IMG SRC=WILMA/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Hurricane WILMA</b> (15-25 OCT)<br>
Storm - Max Winds: 150 Min Pres: 882 Category: 5<P>
<A HREF=WILMA/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=VINCE/track.gif>
  <IMG SRC=VINCE/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Hurricane VINCE</b> (09-11 OCT)<br>
Storm - Max Winds: 65 Min Pres: 987 Category: 1<P>
<A HREF=VINCE/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=TWENTY_TWO/track.gif>
  <IMG SRC=TWENTY_TWO/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Tropical Depression TWENTY_TWO</b> (08-09 OCT)<br>
Storm - Max Winds: 30 Min Pres: 1009 Category: TD<P>
<A HREF=TWENTY_TWO/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=TAMMY/track.gif>
  <IMG SRC=TAMMY/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Tropical Storm TAMMY</b> (05-06 OCT)<br>
Storm - Max Winds: 45 Min Pres: 30 Category: TS<P>
<A HREF=TAMMY/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=STAN/track.gif>
  <IMG SRC=STAN/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Hurricane STAN</b> (01-05 OCT)<br>
Storm - Max Winds: 70 Min Pres: 979 Category: 1<P>
<A HREF=STAN/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=NINETEEN/track.gif>
  <IMG SRC=NINETEEN/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Tropical Depression NINETEEN</b> (30 SEP-02 OCT)<br>
Storm - Max Winds: 30 Min Pres: 1006 Category: TD<P>
<A HREF=NINETEEN/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=RITA/track.gif>
  <IMG SRC=RITA/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Hurricane RITA</b> (18-26 SEP)<br>
Storm - Max Winds: 150 Min Pres: 897 Category: 5<P>
<A HREF=RITA/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=PHILIPPE/track.gif>
  <IMG SRC=PHILIPPE/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Hurricane PHILIPPE</b> (17-24 SEP)<br>
Storm - Max Winds: 70 Min Pres: 985 Category: 1<P>
<A HREF=PHILIPPE/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=OPHELIA/track.gif>
  <IMG SRC=OPHELIA/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Hurricane OPHELIA</b> (06-18 SEP)<br>
Storm - Max Winds: 80 Min Pres: 976 Category: 1<P>
<A HREF=OPHELIA/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=NATE/track.gif>
  <IMG SRC=NATE/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Hurricane NATE</b> (05-10 SEP)<br>
Storm - Max Winds: 80 Min Pres: 979 Category: 1<P>
<A HREF=NATE/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=MARIA/track.gif>
  <IMG SRC=MARIA/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Hurricane MARIA</b> (01-10 SEP)<br>
Storm - Max Winds: 100 Min Pres: 960 Category: 3<P>
<A HREF=MARIA/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=LEE/track.gif>
  <IMG SRC=LEE/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Tropical Storm LEE</b> (28 AUG-02 SEP)<br>
Storm - Max Winds: 35 Min Pres: 1007 Category: TS<P>
<A HREF=LEE/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=KATRINA/track.gif>
  <IMG SRC=KATRINA/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Hurricane KATRINA</b> (23-31 AUG)<br>
Storm - Max Winds: 150 Min Pres: 902 Category: 5<P>
<A HREF=KATRINA/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=JOSE/track.gif>
  <IMG SRC=JOSE/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Tropical Storm JOSE</b> (22-23 AUG)<br>
Storm - Max Winds: 45 Min Pres: 1001 Category: TS<P>
<A HREF=JOSE/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=TEN/track.gif>
  <IMG SRC=TEN/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Tropical Depression TEN</b> (13-14 AUG)<br>
Storm - Max Winds: 30 Min Pres: 1008 Category: TD<P>
<A HREF=TEN/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=IRENE/track.gif>
  <IMG SRC=IRENE/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Hurricane IRENE</b> (04-18 AUG)<br>
Storm - Max Winds: 85 Min Pres: 975 Category: 2<P>
<A HREF=IRENE/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=HARVEY/track.gif>
  <IMG SRC=HARVEY/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Tropical Storm HARVEY</b> (02-08 AUG)<br>
Storm - Max Winds: 55 Min Pres: 994 Category: TS<P>
<A HREF=HARVEY/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=GERT/track.gif>
  <IMG SRC=GERT/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Tropical Storm GERT</b> (23-25 JUL)<br>
Storm - Max Winds: 40 Min Pres: 1005 Category: TS<P>
<A HREF=GERT/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=FRANKLIN/track.gif>
  <IMG SRC=FRANKLIN/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Tropical Storm FRANKLIN</b> (21-29 JUL)<br>
Storm - Max Winds: 60 Min Pres: 997 Category: TS<P>
<A HREF=FRANKLIN/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=EMILY/track.gif>
  <IMG SRC=EMILY/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Hurricane EMILY</b> (11-21 JUL)<br>
Storm - Max Winds: 135 Min Pres: 929 Category: 4<P>
<A HREF=EMILY/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=DENNIS/track.gif>
  <IMG SRC=DENNIS/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Hurricane DENNIS</b> (05-13 JUL)<br>
Storm - Max Winds: 130 Category: 4<P>
<A HREF=DENNIS/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=CINDY/track.gif>
  <IMG SRC=CINDY/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Hurricane CINDY</b> (03-07 JUL)<br>
Storm - Max Winds: 65 Category: 1<P>
<A HREF=CINDY/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=BRET/track.gif>
  <IMG SRC=BRET/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Tropical Storm BRET</b> (28-30 JUN)<br>
Storm - Max Winds: 35 Min Pres: 1002 Category: TS<P>
<A HREF=BRET/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=ARLENE/track.gif>
  <IMG SRC=ARLENE/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Tropical Storm ARLENE</b> (08-13 JUN)<br>
Storm - Max Winds: 60 Min Pres: 30 Category: TS<P>
<A HREF=ARLENE/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

</table>
<div class="clearboth">&nbsp;</div>

</div>

<div id="footer"> <span id="copyright"><small>Copyright &copy; Unisys 2012</small></span>
  <ul class="inline-navigation-list" id="bottom-navigation">
    <li><a href="http://www.unisys.com/unisys/privacy.html" target="_blank">Privacy Notice</a></li>
    <li><a href="http://www.unisys.com/unisys/terms-and-conditions.html" target="_blank">Terms of Use</a></li>
    <li><a href="/contactus.php">Contact Us</a></li>
    <li><a href="http://www.unisys.com/unisys/trademarks.html" target="_blank">Trademarks</a></li>
  </ul>
</div>
</div>
</body>
</html>
