<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Unisys Weather  - The Six-Year List of Names for Atlantic Storms</title>
<meta name="description" content="The intent of this weather site is to provide a complete source of graphical weather 		information. This is intended to satisfy the needs of the weather professional, but can be a tool for the casual user as well. The graphics and data are displayed as a meteorologist would expect to see. For the novice user, there are detailed explanation pages to guide them through the various plots, charts and images. The data on this site are provided from the National Weather Service via the NOAAPORT satellite data service. All the images are generated using the Weather Processor (WXP) analysis package which is available from Unisys. "/>
<meta name="keywords" content="weather, unisys, unisys weather, weather maps, maps, nam, wrf, GFS, GFSx, hurricane, radar, satellite, surface, upper air" />
<meta name="copyright" content="Unisys Corp - 2011" />
<meta name="author" content="Unisys Corporation" />
<meta name="email" content="technical-support@weather.unisys.com" />
<meta name="Distribution" content="Global" />
<meta name="Rating" content="General" />
<meta name="Robots" content="INDEX,FOLLOW" />
<meta name="Revisit-after" content="7 Days" />
<meta http-equiv="Content-type" content="text/html;charset=UTF-8" />
<meta http-equiv="imagetoolbar" content="no" />
<meta http-equiv="Refresh" content="900" />
<meta http-equiv="X-UA-Compatible" content="IE=8"/>
<link rel="stylesheet" type="text/css" href="/css/WMAX.css" />
</head>
<body>
<div id="wrap">
  <div id="top-menu">
    <ul id="top-navigation" class="inline-navigation-list">
      <li><a href="http://www.unisys.com" title="Unisys Home Page">Unisys.com</a></li>
      <li><a href="/index.php" title="Unisys Weather">Weather Home</a></li>
      <li><a href="/analyses.php" title="Analyses">Analyses</a></li>
      <li><a href="/forehome.php" title="Forecast">Forecasts</a></li>
      <li><a href="/archives.php" title="Archives">Archives</a></li>
      <li><a href="/links.php" title="NOAA Links">NOAA Links</a></li>
      <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
    </ul>
  </div>

  <div id="header"> <a href="http://unisys.com"><img src="/images/Unisys_logo.gif" alt="Unisys" /></a>
    <h1>Unisys Weather</h1>
  </div>

<div id="leftside">
  <ul class="avmenu">
    <li><a href="/index.php" class="purple">Unisys Weather</a></li>
    <li><a href="/index.php"> Weather Home</a></li>
    <li><a href="/solutions/index.php">Weather Solutions</a></li>
    <li><a href="/mobile/index.php"><img id="mobile_icon" src="/mobile/Icon.png" width="24" height="24" alt="Download Unisys Weather Mobile App"/>iPhone App</a></li>
    <li><a href="/info/index.php">Information</a></li>
    <li><a href="/content.php">Contents</a></li>
    <li><a href="/analyses.php" class="purple">Analyses</a></li>
    <li><a href="/satellite/index.php">Satellite Images</a></li>
    <li><a href="/surface/index.php">Surface Data</a></li>
    <li><a href="/upper_air/index.php">Upper Air Data</a></li>
    <li><a href="/radar/index.php">Radar Data</a></li>
    <li><a href="/forehome.php" class="purple">Forecasts</a></li>
    <li><a href="/mos/index.php">Model Statistics</a></li>
    <li><a href="/nam/index.php">NAM/Wrf Model</a></li>
    <li><a href="/gfs/index.php?r=us">GFS/Avn Model</a></li>
    <li><a href="/gfsx/index.php?r=us">GFSx/MRF Model</a></li>
    <li><a href="/rap/index.php">RAP Model</a></li>
    <li><a href="/ecmwf/index.php">ECMWF Model</a></li>
    <li><a href="/archives.php" class="purple">Archive</a></li>
    <li><a href="/hurricane/index.php">Hurricane Data</a></li>
    <li><a href="/archive/index.php">Archive of Images</a></li>
    <li><a href="/usgs/index.php">USGS Maps</a></li>
  </ul>
</div>

<div id="extras">
  <ul class="avmenu">
    <li><a href="/foresetup.php" class="purple">Get a Forecast</a></li>
  </ul>

<script type="text/javascript">
function fsubmit()
{
     document.getElementById("Forecast").submit();
}
</script>

  <form method="get" id="Forecast" action="/forecast.php">
    <p class="center"> Enter a zip code or city name to get forecast:
      <input type="text" name="Name" id="Name" size="15" />
      <br />
      <button type="submit" style="border:none; background-color:transparent;">
         <img src="/images/GO.png" id="Go" alt="Get Forecast Data" style="height:30px;" />
      </button>
      <a href="/foresetup.php"><img src="/images/setup.png" alt="Setup Location" height="30" width="70" /></a> </p>
  </form>
  <script type="text/javascript">
                <!-- HIDE
                var index = document.cookie.indexOf("ZIP")
                var zipcode = 0
                var region = ""
                if( index != -1 ){
                   //zipcode = parseInt( document.cookie.substring(index+4,index+9),10)
                   zipcode = document.cookie.substring(index+4,index+9)
                   var validateZipCode = function() {
                     var zipcodeRegexp = /^\d{5}$/;
                     var zipTest = zipcodeRegexp.test(zipcode);
   
                     if (zipTest == false) {
                       return false;
                     }
                   }
                   validateZipCode();

                    if( ! isNaN(zipcode))

                    document.getElementById('Name').value = zipcode

                   if( zipcode >= 01000 && zipcode <= 19699 )
                      region = "ne"
                   else if( zipcode >= 19700 && zipcode <= 28999 )
                      region = "at"
                   else if( zipcode >= 43000 && zipcode <= 45999 )
                      region = "at"
                   else if( zipcode >= 29000 && zipcode <= 36999 )
                      region = "se"
                   else if( zipcode >= 38600 && zipcode <= 39999 )
                      region = "se"
                   else if( zipcode >= 46000 && zipcode <= 58999 )
                      region = "mw"
                   else if( zipcode >= 60000 && zipcode <= 62999 )
                      region = "mw"
                   else if( zipcode >= 68000 && zipcode <= 69999 )
                      region = "mw"
                   else if( zipcode >= 63000 && zipcode <= 67999 )
                      region = "cp"
                   else if( zipcode >= 71600 && zipcode <= 74999 )
                      region = "cp"
                   else if( zipcode >= 70000 && zipcode <= 71499 )
                      region = "sp"
                   else if( zipcode >= 75000 && zipcode <= 79999 )
                      region = "sp"
                   else if( zipcode >= 59000 && zipcode <= 59999 )
                      region = "nw"
                   else if( zipcode >= 82000 && zipcode <= 83999 )
                      region = "nw"
                   else if( zipcode >= 97000 && zipcode <= 99499 )
                      region = "nw"
                   else if( zipcode >= 80000 && zipcode <= 81999 )
                      region = "sw"
                   else if( zipcode >= 84000 && zipcode <= 96199 )
                      region = "sw"

                   if( region != "" ){
                      document.write( "<table border=\"0\" align=\"center\" class=\"grey\" width=\"100%\">" )
                      document.write( "<tr>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/surface/sfc_map.php?image=sfc&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Sfc" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=\"radar/rad" + region + ".php\">" )
                      document.write( "<a href=/radar/rcm_rad.php?image=rad&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Rad" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=vis&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Vis" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=enh&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>IR" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "</tr></table>" )
                      document.write( "</b>" )
                      }


                   
                   }
                // UNHIDE -->
                </script>
  <ul class="avmenu">
    <li><a href="/links.php" class="purple">NOAA Links</a></li>
    <li><a href="http://lwf.ncdc.noaa.gov/">National Climatic Data Center</a></li>
    <li><a href="http://www.cpc.noaa.gov/">Climate Prediction Center</a></li>
    <li><a href="http://oceanservice.noaa.gov/">National Ocean Service</a></li>
    <li><a href="http://www.lib.noaa.gov/">NOAA Library</a></li>
    <li><a href="http://www.oar.noaa.gov/">NOAA Office of Oceanic and Atmospheric Research</a></li>
    <li><a href="http://www.esrl.noaa.gov/">Earth Systems Research Laboratory</a></li>
    <li><a href="/overview.php" class="purple">About Us</a></li>
    <li><a href="/overview.php" title="Contact Us">Overview</a></li>
    <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
  </ul>
</div>
<div id="content">

<h1>Names for Atlantic Storms</h1>

<table border="0" cellpadding="2">
  <tr>
    <th width="61">2007</th>
    <th width="61">2008</th>
    <th width="61">2009</th>
    <th width="61">2010</th>
    <th width="61">2011</th>
    <th width="61">2012</th>
  </tr>
  <tr>
    <td width="61">Andrea</td>
    <td width="61">Arthur</td>
    <td width="61">Ana</td>
    <td width="61">Alex</td>
    <td width="61">Arlene</td>
    <td width="61">Alberto</td>
  </tr>
  <tr>
    <td width="61">Barry</td>
    <td width="61">Bertha</td>
    <td width="61">Bill</td>
    <td width="61">Bonnie</td>
    <td width="61">Bret</td>
    <td width="61">Beryl</td>
  </tr>
  <tr>
    <td width="61">Chantal</td>
    <td width="61">Cristobal</td>
    <td width="61">Claudette</td>
    <td width="61">Colin</td>
    <td width="61">Cindy</td>
    <td width="61">Chris</td>
  </tr>
  <tr>
    <td width="61">Dean</td>
    <td width="61">Dolly</td>
    <td width="61">Danny</td>
    <td width="61">Danielle</td>
    <td width="61">Don</td>
    <td width="61">Debby</td>
  </tr>
  <tr>
    <td width="61">Erin</td>
    <td width="61">Edouard</td>
    <td width="61">Erika</td>
    <td width="61">Earl</td>
    <td width="61">Emily</td>
    <td width="61">Ernesto</td>
  </tr>
  <tr>
    <td width="61">Felix</td>
    <td width="61">Fay</td>
    <td width="61">Fred</td>
    <td width="61">Fiona</td>
    <td width="61">Franklin</td>
    <td width="61">Florence</td>
  </tr>
  <tr>
    <td width="61">Gabielle</td>
    <td width="61">Gustav</td>
    <td width="61">Grace</td>
    <td width="61">Gaston</td>
    <td width="61">Gert</td>
    <td width="61">Gordon</td>
  </tr>
  <tr>
    <td width="61">Humberto</td>
    <td width="61">Hanna</td>
    <td width="61">Henri</td>
    <td width="61">Hermine</td>
    <td width="61">Harvey</td>
    <td width="61">Helene</td>
  </tr>
  <tr>
    <td width="61">Ingrid</td>
    <td width="61">Ike</td>
    <td width="61">Ida</td>
    <td width="61">Igor</td>
    <td width="61">Irene</td>
    <td width="61">Isaac</td>
  </tr>
  <tr>
    <td width="61">Jerry</td>
    <td width="61">Josephine</td>
    <td width="61">Joaquin</td>
    <td width="61">Julia</td>
    <td width="61">Jose</td>
    <td width="61">Joyce</td>
  </tr>
  <tr>
    <td width="61">Karen</td>
    <td width="61">Kyle</td>
    <td width="61">Kate</td>
    <td width="61">Karl</td>
    <td width="61">Katia</td>
    <td width="61">Kirk</td>
  </tr>
  <tr>
    <td width="61">Lorenzo</td>
    <td width="61">Laura</td>
    <td width="61">Larry</td>
    <td width="61">Lisa</td>
    <td width="61">Lee</td>
    <td width="61">Leslie</td>
  </tr>
  <tr>
    <td width="61">Melissa</td>
    <td width="61">Marco</td>
    <td width="61">Mindy</td>
    <td width="61">Matthew</td>
    <td width="61">Maria</td>
    <td width="61">Michael</td>
  </tr>
  <tr>
    <td width="61">Noel</td>
    <td width="61">Nana</td>
    <td width="61">Nicholas</td>
    <td width="61">Nicole</td>
    <td width="61">Nate</td>
    <td width="61">Nadine</td>
  </tr>
  <tr>
    <td width="61">Olga</td>
    <td width="61">Omar</td>
    <td width="61">Odette</td>
    <td width="61">Otto</td>
    <td width="61">Ophelia</td>
    <td width="61">Oscar</td>
  </tr>
  <tr>
    <td width="61">Pablo</td>
    <td width="61">Paloma</td>
    <td width="61">Peter</td>
    <td width="61">Paula</td>
    <td width="61">Philippe</td>
    <td width="61">Patty</td>
  </tr>
  <tr>
    <td width="61">Rebekah</td>
    <td width="61">Rene</td>
    <td width="61">Rose</td>
    <td width="61">Richard</td>
    <td width="61">Rina</td>
    <td width="61">Rafael</td>
  </tr>
  <tr>
    <td width="61">Sebastien</td>
    <td width="61">Sally</td>
    <td width="61">Sam</td>
    <td width="61">Shary</td>
    <td width="61">Sean</td>
    <td width="61">Sandy</td>
  </tr>
  <tr>
    <td width="61">Tanya</td>
    <td width="61">Teddy</td>
    <td width="61">Teresa</td>
    <td width="61">Tomas</td>
    <td width="61">Tammy</td>
    <td width="61">Tony</td>
  </tr>
  <tr>
    <td width="61">Van</td>
    <td width="61">Vicky</td>
    <td width="61">Victor</td>
    <td width="61">Virginie</td>
    <td width="61">Vince</td>
    <td width="61">Valerie</td>
  </tr>
  <tr>
    <td width="61">Wendy</td>
    <td width="61">Wilfred</td>
    <td width="61">Wanda</td>
    <td width="61">Walter</td>
    <td width="61">Whitney</td>
    <td width="61">William</td>
  </tr>
</table>

<p>Names are recycled every 6 years. Influential hurricanes have their names retired.</p>
<br/>
<h2>Retired Atlantic hurricane names:</h2>

<table style="width:100%; border:0;">
  <tr>
    <td style="width:50%; vertical-align:top;">
    <ul>
      <li>Agnes - 1972</li>
      <li>Alicia - 1983</li>
      <li>Allen - 1980</li>
      <li>Allison - 2001</li>
      <li>Andrew - 1992</li>
      <li>Anita - 1977</li>
      <li>Audrey - 1957</li>
      <li>Betsy - 1965</li>
      <li>Beulah - 1967</li>
      <li>Bob - 1991</li>
      <li>Camille - 1969</li>
      <li>Carla - 1961</li>
      <li>Carmen - 1974</li>
      <li>Carol - 1954</li>
      <li>Celia - 1970</li>
      <li>Cesar - 1996</li>
      <li>Charley - 2004</li>
      <li>Cleo - 1964</li>
      <li>Connie - 1955</li>
      <li>David - 1979</li>
      <li>Dennis - 2005</li>
      <li>Diana - 1990</li>
      <li>Diane - 1955</li>
      <li>Donna - 1960</li>
      <li>Dora - 1964</li>
      <li>Edna - 1968</li>
      <li>Elena - 1985</li>
      <li>Eloise - 1975</li>
      <li>Fabian - 2003</li>
      <li>Fifi - 1974</li>
      <li>Flora - 1963</li>
      <li>Floyd - 1999</li>
      <li>Fran - 1996</li>
      <li>Frances - 2004</li>
    </ul>
    </td>
    <td style="width:50%; vertical-align:top;">
    <ul>
      <li>Frederic - 1979</li>
      <li>Georges - 1998</li>
      <li>Gilbert - 1988</li>
      <li>Gloria - 1985</li>
      <li>Hattie - 1961</li>
      <li>Hazel - 1954</li>
      <li>Hilda - 1964</li>
      <li>Hortense - 1996</li>
      <li>Hugo - 1989</li>
      <li>Inez - 1966</li>
      <li>Ione - 1955</li>
      <li>Iris - 2001</li>
      <li>Isabel - 2003</li>
      <li>Isidore - 2002</li>
      <li>Ivan - 2004</li>
      <li>Janet - 1955</li>
      <li>Jeanne - 2004</li>
      <li>Joan - 1988</li>
      <li>Juan - 2003</li>
      <li>Katrina - 2005</li>
      <li>Keith - 2000</li>
      <li>Klaus - 1990</li>
      <li>Lenny - 1999</li>
      <li>Lili - 2002</li>
      <li>Luis - 1995</li>
      <li>Marilyn - 1995</li>
      <li>Michelle - 2001</li>
      <li>Mitch - 1998</li>
      <li>Opal - 1995</li>
      <li>Rita - 2005</li>
      <li>Roxanne - 1995</li>
      <li>Stan - 2005</li>
      <li>Wilma - 2005</li>
    </ul>
    </td>
  </tr>
</table>

<div class="clearboth">&nbsp;</div>

</div>

<div id="footer"> <span id="copyright"><small>Copyright &copy; Unisys 2012</small></span>
  <ul class="inline-navigation-list" id="bottom-navigation">
    <li><a href="http://www.unisys.com/unisys/privacy.html" target="_blank">Privacy Notice</a></li>
    <li><a href="http://www.unisys.com/unisys/terms-and-conditions.html" target="_blank">Terms of Use</a></li>
    <li><a href="/contactus.php">Contact Us</a></li>
    <li><a href="http://www.unisys.com/unisys/trademarks.html" target="_blank">Trademarks</a></li>
  </ul>
</div>
</div>
</body>
</html>
