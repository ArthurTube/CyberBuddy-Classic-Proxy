<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Unisys Weather  - Classic Hurricanes</title>
<meta name="description" content="The intent of this weather site is to provide a complete source of graphical weather 		information. This is intended to satisfy the needs of the weather professional, but can be a tool for the casual user as well. The graphics and data are displayed as a meteorologist would expect to see. For the novice user, there are detailed explanation pages to guide them through the various plots, charts and images. The data on this site are provided from the National Weather Service via the NOAAPORT satellite data service. All the images are generated using the Weather Processor (WXP) analysis package which is available from Unisys. "/>
<meta name="keywords" content="weather, unisys, unisys weather, weather maps, maps, nam, wrf, GFS, GFSx, hurricane, radar, satellite, surface, upper air" />
<meta name="copyright" content="Unisys Corp - 2011" />
<meta name="author" content="Unisys Corporation" />
<meta name="email" content="technical-support@weather.unisys.com" />
<meta name="Distribution" content="Global" />
<meta name="Rating" content="General" />
<meta name="Robots" content="INDEX,FOLLOW" />
<meta name="Revisit-after" content="7 Days" />
<meta http-equiv="Content-type" content="text/html;charset=UTF-8" />
<meta http-equiv="imagetoolbar" content="no" />
<meta http-equiv="Refresh" content="900" />
<meta http-equiv="X-UA-Compatible" content="IE=8"/>
<link rel="stylesheet" type="text/css" href="/css/WMAX.css" />
</head>
<body>
<div id="wrap">
  <div id="top-menu">
    <ul id="top-navigation" class="inline-navigation-list">
      <li><a href="http://www.unisys.com" title="Unisys Home Page">Unisys.com</a></li>
      <li><a href="/index.php" title="Unisys Weather">Weather Home</a></li>
      <li><a href="/analyses.php" title="Analyses">Analyses</a></li>
      <li><a href="/forehome.php" title="Forecast">Forecasts</a></li>
      <li><a href="/archives.php" title="Archives">Archives</a></li>
      <li><a href="/links.php" title="NOAA Links">NOAA Links</a></li>
      <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
    </ul>
  </div>

  <div id="header"> <a href="http://unisys.com"><img src="/images/Unisys_logo.gif" alt="Unisys" /></a>
    <h1>Unisys Weather</h1>
  </div>

<div id="leftside">
  <ul class="avmenu">
    <li><a href="/index.php" class="purple">Unisys Weather</a></li>
    <li><a href="/index.php"> Weather Home</a></li>
    <li><a href="/solutions/index.php">Weather Solutions</a></li>
    <li><a href="/mobile/index.php"><img id="mobile_icon" src="/mobile/Icon.png" width="24" height="24" alt="Download Unisys Weather Mobile App"/>iPhone App</a></li>
    <li><a href="/info/index.php">Information</a></li>
    <li><a href="/content.php">Contents</a></li>
    <li><a href="/analyses.php" class="purple">Analyses</a></li>
    <li><a href="/satellite/index.php">Satellite Images</a></li>
    <li><a href="/surface/index.php">Surface Data</a></li>
    <li><a href="/upper_air/index.php">Upper Air Data</a></li>
    <li><a href="/radar/index.php">Radar Data</a></li>
    <li><a href="/forehome.php" class="purple">Forecasts</a></li>
    <li><a href="/mos/index.php">Model Statistics</a></li>
    <li><a href="/nam/index.php">NAM/Wrf Model</a></li>
    <li><a href="/gfs/index.php?r=us">GFS/Avn Model</a></li>
    <li><a href="/gfsx/index.php?r=us">GFSx/MRF Model</a></li>
    <li><a href="/rap/index.php">RAP Model</a></li>
    <li><a href="/ecmwf/index.php">ECMWF Model</a></li>
    <li><a href="/archives.php" class="purple">Archive</a></li>
    <li><a href="/hurricane/index.php">Hurricane Data</a></li>
    <li><a href="/archive/index.php">Archive of Images</a></li>
    <li><a href="/usgs/index.php">USGS Maps</a></li>
  </ul>
</div>

<div id="extras">
  <ul class="avmenu">
    <li><a href="/foresetup.php" class="purple">Get a Forecast</a></li>
  </ul>

<script type="text/javascript">
function fsubmit()
{
     document.getElementById("Forecast").submit();
}
</script>

  <form method="get" id="Forecast" action="/forecast.php">
    <p class="center"> Enter a zip code or city name to get forecast:
      <input type="text" name="Name" id="Name" size="15" />
      <br />
      <button type="submit" style="border:none; background-color:transparent;">
         <img src="/images/GO.png" id="Go" alt="Get Forecast Data" style="height:30px;" />
      </button>
      <a href="/foresetup.php"><img src="/images/setup.png" alt="Setup Location" height="30" width="70" /></a> </p>
  </form>
  <script type="text/javascript">
                <!-- HIDE
                var index = document.cookie.indexOf("ZIP")
                var zipcode = 0
                var region = ""
                if( index != -1 ){
                   //zipcode = parseInt( document.cookie.substring(index+4,index+9),10)
                   zipcode = document.cookie.substring(index+4,index+9)
                   var validateZipCode = function() {
                     var zipcodeRegexp = /^\d{5}$/;
                     var zipTest = zipcodeRegexp.test(zipcode);
   
                     if (zipTest == false) {
                       return false;
                     }
                   }
                   validateZipCode();

                    if( ! isNaN(zipcode))

                    document.getElementById('Name').value = zipcode

                   if( zipcode >= 01000 && zipcode <= 19699 )
                      region = "ne"
                   else if( zipcode >= 19700 && zipcode <= 28999 )
                      region = "at"
                   else if( zipcode >= 43000 && zipcode <= 45999 )
                      region = "at"
                   else if( zipcode >= 29000 && zipcode <= 36999 )
                      region = "se"
                   else if( zipcode >= 38600 && zipcode <= 39999 )
                      region = "se"
                   else if( zipcode >= 46000 && zipcode <= 58999 )
                      region = "mw"
                   else if( zipcode >= 60000 && zipcode <= 62999 )
                      region = "mw"
                   else if( zipcode >= 68000 && zipcode <= 69999 )
                      region = "mw"
                   else if( zipcode >= 63000 && zipcode <= 67999 )
                      region = "cp"
                   else if( zipcode >= 71600 && zipcode <= 74999 )
                      region = "cp"
                   else if( zipcode >= 70000 && zipcode <= 71499 )
                      region = "sp"
                   else if( zipcode >= 75000 && zipcode <= 79999 )
                      region = "sp"
                   else if( zipcode >= 59000 && zipcode <= 59999 )
                      region = "nw"
                   else if( zipcode >= 82000 && zipcode <= 83999 )
                      region = "nw"
                   else if( zipcode >= 97000 && zipcode <= 99499 )
                      region = "nw"
                   else if( zipcode >= 80000 && zipcode <= 81999 )
                      region = "sw"
                   else if( zipcode >= 84000 && zipcode <= 96199 )
                      region = "sw"

                   if( region != "" ){
                      document.write( "<table border=\"0\" align=\"center\" class=\"grey\" width=\"100%\">" )
                      document.write( "<tr>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/surface/sfc_map.php?image=sfc&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Sfc" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=\"radar/rad" + region + ".php\">" )
                      document.write( "<a href=/radar/rcm_rad.php?image=rad&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Rad" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=vis&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Vis" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=enh&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>IR" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "</tr></table>" )
                      document.write( "</b>" )
                      }


                   
                   }
                // UNHIDE -->
                </script>
  <ul class="avmenu">
    <li><a href="/links.php" class="purple">NOAA Links</a></li>
    <li><a href="http://lwf.ncdc.noaa.gov/">National Climatic Data Center</a></li>
    <li><a href="http://www.cpc.noaa.gov/">Climate Prediction Center</a></li>
    <li><a href="http://oceanservice.noaa.gov/">National Ocean Service</a></li>
    <li><a href="http://www.lib.noaa.gov/">NOAA Library</a></li>
    <li><a href="http://www.oar.noaa.gov/">NOAA Office of Oceanic and Atmospheric Research</a></li>
    <li><a href="http://www.esrl.noaa.gov/">Earth Systems Research Laboratory</a></li>
    <li><a href="/overview.php" class="purple">About Us</a></li>
    <li><a href="/overview.php" title="Contact Us">Overview</a></li>
    <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
  </ul>
</div>
<div id="content">

<h1>Classic Hurricanes</h1>
<table border="0" cellpadding="2">
  <tr>
    <td valign="top">
	<h2>Hurricane ANDREW (16-28 AUG 1992)</h2>
        <p><a href="/hurricane/atlantic/1992/ANDREW/track.gif"><img src="/hurricane/atlantic/1992/ANDREW/track_s.gif" alt="Image Track" border="0" width="240" height="160" style="float:left; margin:0 5px 0 0;"/></a>
	<b>Max Winds: 135 Min Pres: 922 Category: 5</b><br/>
	This was the the most detructive hurricane to hit the US mainland. Andrew took a beeline direction for the south Florida coast wiping out most of south Dade county including the city of Homestead. The total damage exceded $25 billion. Andrew weakened somewhat moving over Florida and continued into the Gulf heading towards Louisiana where it made final landfall west of New Orleans.</p><br/>
	<a href="/hurricane/atlantic/1992/ANDREW/track.dat"><img src="/images/DETAILS.gif" border="0" width="49" height="13"/>Tracking information</a><br/>
	<a href="/hurricane/atlantic/1992H/Andrew/sat_2318.gif"><img src="/images/GIF.gif" border="0" width="31" height="13"/>Image of Andrew over Bahamas (1831Z 23 AUG 92)</a><br/>
	<a href="/hurricane/atlantic/1992H/Andrew/sat_2409.gif"><img src="/images/GIF.gif" border="0" width="31" height="13"/>Image of Andrew making landfall (0931Z 24 AUG 92)</a><br/>
	<a href="/hurricane/atlantic/1992H/Andrew/sat_2520.gif"><img src="/hurricane/images/GIF.gif" border="0" width="31" height="13"/>Image of Andrew off Louisiana (2031Z 25 AUG 92)</a><br/>
	<a href="/hurricane/atlantic/1992H/Andrew/sat.mpg"><img src="/images/MPG.gif" border="0" width="38" height="13"/>Movie of Andrew (07Z 23 - 19Z 27 SEP 92)</a><br/>
    <br/>
    </td>
  </tr>
  <tr>
    <td valign="top">
    <h2>Hurricane HUGO (10-25 SEP 1989)</h2>
    <p><a href="/hurricane/atlantic/1989/HUGO/track.gif"><img src="/hurricane/atlantic/1989/HUGO/track_s.gif" border="0" alt="Image track" width="240" height="160" style="float:left; margin:0 5px 0 0;"/></a>
    <b>Max Winds: 140 Min Pres: 918 Category: 5</b><br/>
    This was a powerful category 5 hurricane that formed well out into the Atlantic and lasted almost 2 weeks. The storm hit the Virgin Islands and Puerto Rico causing tremendous damage. It then moved out over the western Atlantic, reintensifying and hitting South Carolina causing near $7 billion in damage.</p><br/><br/><br/>
    <a href="/hurricane/atlantic/1989/HUGO/track.dat"><img src="/images/DETAILS.gif" border="0" width="49" height="13"/>Tracking information</a><br/>
    <a href="/hurricane/atlantic/1989H/Hugo/hugo-5.gif"><img src="/images/GIF.gif" border="0" width="31" height="13"/>Image of Hugo east of Caribbean when category 5 (2001Z 15 SEP 89)</a><br/>
    <a href="/hurricane/atlantic/1989H/Hugo/hugo-7.gif"><img src="/images/GIF.gif" border="0" width="31" height="13"/>Image of Hugo over windward islands of Caribbean (1331Z 17 SEP 89)</a><br/>
    <a href="/hurricane/atlantic/1989H/Hugo/hugo-6.gif"><img src="/images/GIF.gif" border="0" width="31" height="13"/>Image of Hugo in Atlantic trying to regroup (1701Z 20 SEP 89)</a><br/>
    <a href="/hurricane/atlantic/1989H/Hugo/hugo-2.gif"><img src="/images/GIF.gif" border="0" width="31" height="13"/>Image of Hugo off South Carolina (2031Z 21 SEP 89)</a><br/>
    <a href="/hurricane/atlantic/1989H/Hugo/hugo-3.gif"><img src="/images/GIF.gif" border="0" width="31" height="13"/>Enh. IR Image of Hugo off South Carolina (0001Z 22 SEP 89)</a><br/>
    <a href="/hurricane/atlantic/1989H/Hugo/hugo-4.gif"><img src="/images/GIF.gif" border="0" width="31" height="13"/>Enh. IR Image of Hugo onshore and weakening (0731Z 22 SEP 89)</a><br/>
    <br/>
    </td>
  </tr>
  <tr>
    <td valign="top">
    <h2>Hurricane GILBERT ( 8-20 SEP 1988)</h2>
    <p><a href="/hurricane/atlantic/1988/GILBERT/track.gif"><img src="/hurricane/atlantic/1988/GILBERT/track_s.gif" border="0" alt="Image track" width="240" height="160" style="float:left; margin:0 5px 0 0;"/></a>
    <b>Max Winds: 160 Min Pres: 888 Category: 5</b><br/>
    This was probably one of the strongest hurricanes ever in the Atlantic, Caribbean and Gulf of Mexico. Gilbert reached a central pressure of 888 mb at 00Z on the 14th making it the lowest pressure ever recorded for an Atlantic hurricane at the time. Gilbert wreaked havok on Jamaica as it went down the entire length of the island. It then hit the Yucatan pennisula shortly after recording the lowest pressure reading. The Yucatan was spared as the eye wall weakened shortly before landfall. After moving over the Yucatan, the strength of the hurricane deminished from a category 5 to a category 3. It never did reintensify before making landfall again in northern Mexico. It did cause serious flooding in the Monterrey region of Mexico.</p><br/>
    <a href="/hurricane/atlantic/1988/GILBERT/track.dat"><img src="/images/DETAILS.gif" border="0" width="49" height="13"/> Tracking information</a><br/>
    <a href="/hurricane/atlantic/1988H/Gilbert/gilbert-1.gif"><img src="/images/GIF.gif" border="0" width="31" height="13"/> Image of Gilbert off Jamaica (2331Z 12 SEP 88)</a><br/>
    <a href="/hurricane/atlantic/1988H/Gilbert/gilbert-2.gif"><img src="/images/GIF.gif" border="0" width="31" height="13"/> Image of Gilbert at peak intensity (1831Z 13 SEP 88)</a><br/>
    <a href="/hurricane/atlantic/1988H/Gilbert/gilbert-3.gif"><img src="/images/GIF.gif" border="0" width="31" height="13"/> Image of Gilbert nearing Mexico coast (1931Z 16 SEP 88)</a><br/>
    <br/>
    </td>
  </tr>
</table>

<p><a href="/hurricane/index.php"><strong><img src="/images/rback.gif" alt="Go back" border="0" width="13" height="13"/> Back to Hurricane Index</strong></a></p>

<div class="clearboth">&nbsp;</div>

</div>

<div id="footer"> <span id="copyright"><small>Copyright &copy; Unisys 2012</small></span>
  <ul class="inline-navigation-list" id="bottom-navigation">
    <li><a href="http://www.unisys.com/unisys/privacy.html" target="_blank">Privacy Notice</a></li>
    <li><a href="http://www.unisys.com/unisys/terms-and-conditions.html" target="_blank">Terms of Use</a></li>
    <li><a href="/contactus.php">Contact Us</a></li>
    <li><a href="http://www.unisys.com/unisys/trademarks.html" target="_blank">Trademarks</a></li>
  </ul>
</div>
</div>
</body>
</html>

