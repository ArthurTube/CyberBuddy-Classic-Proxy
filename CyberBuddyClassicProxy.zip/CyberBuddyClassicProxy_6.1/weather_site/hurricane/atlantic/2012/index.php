<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Unisys Weather  - 2011 Hurricane/Tropical Data for Atlantic </title>
<meta name="description" content="The intent of this weather site is to provide a complete source of graphical weather 		information. This is intended to satisfy the needs of the weather professional, but can be a tool for the casual user as well. The graphics and data are displayed as a meteorologist would expect to see. For the novice user, there are detailed explanation pages to guide them through the various plots, charts and images. The data on this site are provided from the National Weather Service via the NOAAPORT satellite data service. All the images are generated using the Weather Processor (WXP) analysis package which is available from Unisys. "/>
<meta name="keywords" content="weather, unisys, unisys weather, weather maps, maps, nam, wrf, GFS, GFSx, hurricane, radar, satellite, surface, upper air" />
<meta name="copyright" content="Unisys Corp - 2011" />
<meta name="author" content="Unisys Corporation" />
<meta name="email" content="technical-support@weather.unisys.com" />
<meta name="Distribution" content="Global" />
<meta name="Rating" content="General" />
<meta name="Robots" content="INDEX,FOLLOW" />
<meta name="Revisit-after" content="7 Days" />
<meta http-equiv="Content-type" content="text/html;charset=UTF-8" />
<meta http-equiv="imagetoolbar" content="no" />
<meta http-equiv="Refresh" content="900" />
<meta http-equiv="X-UA-Compatible" content="IE=8"/>
<link rel="stylesheet" type="text/css" href="/css/WMAX.css" />
</head>
<body>
<div id="wrap">
  <div id="top-menu">
    <ul id="top-navigation" class="inline-navigation-list">
      <li><a href="http://www.unisys.com" title="Unisys Home Page">Unisys.com</a></li>
      <li><a href="/index.php" title="Unisys Weather">Weather Home</a></li>
      <li><a href="/analyses.php" title="Analyses">Analyses</a></li>
      <li><a href="/forehome.php" title="Forecast">Forecasts</a></li>
      <li><a href="/archives.php" title="Archives">Archives</a></li>
      <li><a href="/links.php" title="NOAA Links">NOAA Links</a></li>
      <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
    </ul>
  </div>

  <div id="header"> <a href="http://unisys.com"><img src="/images/Unisys_logo.gif" alt="Unisys" /></a>
    <h1>Unisys Weather</h1>
  </div>

<div id="leftside">
  <ul class="avmenu">
    <li><a href="/index.php" class="purple">Unisys Weather</a></li>
    <li><a href="/index.php"> Weather Home</a></li>
    <li><a href="/solutions/index.php">Weather Solutions</a></li>
    <li><a href="/mobile/index.php"><img id="mobile_icon" src="/mobile/Icon.png" width="24" height="24" alt="Download Unisys Weather Mobile App"/>iPhone App</a></li>
    <li><a href="/info/index.php">Information</a></li>
    <li><a href="/content.php">Contents</a></li>
    <li><a href="/analyses.php" class="purple">Analyses</a></li>
    <li><a href="/satellite/index.php">Satellite Images</a></li>
    <li><a href="/surface/index.php">Surface Data</a></li>
    <li><a href="/upper_air/index.php">Upper Air Data</a></li>
    <li><a href="/radar/index.php">Radar Data</a></li>
    <li><a href="/forehome.php" class="purple">Forecasts</a></li>
    <li><a href="/mos/index.php">Model Statistics</a></li>
    <li><a href="/nam/index.php">NAM/Wrf Model</a></li>
    <li><a href="/gfs/index.php?r=us">GFS/Avn Model</a></li>
    <li><a href="/gfsx/index.php?r=us">GFSx/MRF Model</a></li>
    <li><a href="/rap/index.php">RAP Model</a></li>
    <li><a href="/ecmwf/index.php">ECMWF Model</a></li>
    <li><a href="/archives.php" class="purple">Archive</a></li>
    <li><a href="/hurricane/index.php">Hurricane Data</a></li>
    <li><a href="/archive/index.php">Archive of Images</a></li>
    <li><a href="/usgs/index.php">USGS Maps</a></li>
  </ul>
</div>

<div id="extras">
  <ul class="avmenu">
    <li><a href="/foresetup.php" class="purple">Get a Forecast</a></li>
  </ul>

<script type="text/javascript">
function fsubmit()
{
     document.getElementById("Forecast").submit();
}
</script>

  <form method="get" id="Forecast" action="/forecast.php">
    <p class="center"> Enter a zip code or city name to get forecast:
      <input type="text" name="Name" id="Name" size="15" />
      <br />
      <button type="submit" style="border:none; background-color:transparent;">
         <img src="/images/GO.png" id="Go" alt="Get Forecast Data" style="height:30px;" />
      </button>
      <a href="/foresetup.php"><img src="/images/setup.png" alt="Setup Location" height="30" width="70" /></a> </p>
  </form>
  <script type="text/javascript">
                <!-- HIDE
                var index = document.cookie.indexOf("ZIP")
                var zipcode = 0
                var region = ""
                if( index != -1 ){
                   //zipcode = parseInt( document.cookie.substring(index+4,index+9),10)
                   zipcode = document.cookie.substring(index+4,index+9)
                   var validateZipCode = function() {
                     var zipcodeRegexp = /^\d{5}$/;
                     var zipTest = zipcodeRegexp.test(zipcode);
   
                     if (zipTest == false) {
                       return false;
                     }
                   }
                   validateZipCode();

                    if( ! isNaN(zipcode))

                    document.getElementById('Name').value = zipcode

                   if( zipcode >= 01000 && zipcode <= 19699 )
                      region = "ne"
                   else if( zipcode >= 19700 && zipcode <= 28999 )
                      region = "at"
                   else if( zipcode >= 43000 && zipcode <= 45999 )
                      region = "at"
                   else if( zipcode >= 29000 && zipcode <= 36999 )
                      region = "se"
                   else if( zipcode >= 38600 && zipcode <= 39999 )
                      region = "se"
                   else if( zipcode >= 46000 && zipcode <= 58999 )
                      region = "mw"
                   else if( zipcode >= 60000 && zipcode <= 62999 )
                      region = "mw"
                   else if( zipcode >= 68000 && zipcode <= 69999 )
                      region = "mw"
                   else if( zipcode >= 63000 && zipcode <= 67999 )
                      region = "cp"
                   else if( zipcode >= 71600 && zipcode <= 74999 )
                      region = "cp"
                   else if( zipcode >= 70000 && zipcode <= 71499 )
                      region = "sp"
                   else if( zipcode >= 75000 && zipcode <= 79999 )
                      region = "sp"
                   else if( zipcode >= 59000 && zipcode <= 59999 )
                      region = "nw"
                   else if( zipcode >= 82000 && zipcode <= 83999 )
                      region = "nw"
                   else if( zipcode >= 97000 && zipcode <= 99499 )
                      region = "nw"
                   else if( zipcode >= 80000 && zipcode <= 81999 )
                      region = "sw"
                   else if( zipcode >= 84000 && zipcode <= 96199 )
                      region = "sw"

                   if( region != "" ){
                      document.write( "<table border=\"0\" align=\"center\" class=\"grey\" width=\"100%\">" )
                      document.write( "<tr>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/surface/sfc_map.php?image=sfc&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Sfc" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=\"radar/rad" + region + ".php\">" )
                      document.write( "<a href=/radar/rcm_rad.php?image=rad&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Rad" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=vis&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Vis" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=enh&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>IR" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "</tr></table>" )
                      document.write( "</b>" )
                      }


                   
                   }
                // UNHIDE -->
                </script>
  <ul class="avmenu">
    <li><a href="/links.php" class="purple">NOAA Links</a></li>
    <li><a href="http://lwf.ncdc.noaa.gov/">National Climatic Data Center</a></li>
    <li><a href="http://www.cpc.noaa.gov/">Climate Prediction Center</a></li>
    <li><a href="http://oceanservice.noaa.gov/">National Ocean Service</a></li>
    <li><a href="http://www.lib.noaa.gov/">NOAA Library</a></li>
    <li><a href="http://www.oar.noaa.gov/">NOAA Office of Oceanic and Atmospheric Research</a></li>
    <li><a href="http://www.esrl.noaa.gov/">Earth Systems Research Laboratory</a></li>
    <li><a href="/overview.php" class="purple">About Us</a></li>
    <li><a href="/overview.php" title="Contact Us">Overview</a></li>
    <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
  </ul>
</div>
<div id="content">

<h2 style="font-family: helvetica,arial,sans-serif;">2012 Hurricane/Tropical Data for Atlantic</h2>
<a href="/hurricane/atlantic/2012/track.gif">
  <img src="/hurricane/atlantic/2012/track.gif" width="640" height="512" alt="Track Map"/></a>
<h3 style="font-family: helvetica,arial,sans-serif;">Individual Storm Summary</h3>
<p style="font-family: helvetica,arial,sans-serif;">Winds in knots, pressure in millibars,
category is based on Saffir-Simpson scale.</p>
<table border="0">
<tr style="font-size: 10pt; font-family: helvetica,arial,sans-serif; color: black;"><td width="20" align="right">#</td><td width="250">Name</td><td width="125" align="center">Date</td><td width="40" align="right">Wind</td><td width="40" align="right">Pres</td><td width="40" align="right">Cat</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">1</td><td width="250" style="color:black;">Tropical Storm ALBERTO    </td><td width="125" align="right" style="color:black;">19-22 MAY     </td><td width="40" align="right" style="color:black;"> 45 </td><td width="40" align="right" style="color:black;"> 998 </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">2</td><td width="250" style="color:black;">Tropical Storm BERYL      </td><td width="125" align="right" style="color:black;">26-30 MAY     </td><td width="40" align="right" style="color:black;"> 60 </td><td width="40" align="right" style="color:black;"> 992 </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">3</td><td width="250" style="color:black;">Hurricane-1 CHRIS         </td><td width="125" align="right" style="color:black;">19-22 JUN     </td><td width="40" align="right" style="color:black;"> 65 </td><td width="40" align="right" style="color:black;"> 987 </td><td width="40" align="right" style="color:black;">  1</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">4</td><td width="250" style="color:black;">Tropical Storm DEBBY      </td><td width="125" align="right" style="color:black;">23-27 JUN     </td><td width="40" align="right" style="color:black;"> 50 </td><td width="40" align="right" style="color:black;"> 990 </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">5</td><td width="250" style="color:black;">Hurricane-1 ERNESTO       </td><td width="125" align="right" style="color:black;">01-10 AUG     </td><td width="40" align="right" style="color:black;"> 75 </td><td width="40" align="right" style="color:black;"> 980 </td><td width="40" align="right" style="color:black;">  1</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">6</td><td width="250" style="color:black;">Tropical Storm FLORENCE   </td><td width="125" align="right" style="color:black;">04-06 AUG     </td><td width="40" align="right" style="color:black;"> 50 </td><td width="40" align="right" style="color:black;">1000 </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">7</td><td width="250" style="color:black;">Hurricane-2 GORDON        </td><td width="125" align="right" style="color:black;">15-20 AUG     </td><td width="40" align="right" style="color:black;"> 95 </td><td width="40" align="right" style="color:black;"> 965 </td><td width="40" align="right" style="color:black;">  2</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">8</td><td width="250" style="color:black;">Tropical Storm HELENE     </td><td width="125" align="right" style="color:black;">09-18 AUG     </td><td width="40" align="right" style="color:black;"> 40 </td><td width="40" align="right" style="color:black;">1004 </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">9</td><td width="250" style="color:black;">Hurricane-1 ISAAC         </td><td width="125" align="right" style="color:black;">21 AUG-01 SEP </td><td width="40" align="right" style="color:black;"> 70 </td><td width="40" align="right" style="color:black;"> 968 </td><td width="40" align="right" style="color:black;">  1</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">10</td><td width="250" style="color:black;">Tropical Storm JOYCE      </td><td width="125" align="right" style="color:black;">22-24 AUG     </td><td width="40" align="right" style="color:black;"> 35 </td><td width="40" align="right" style="color:black;">1006 </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">11</td><td width="250" style="color:black;">Hurricane-2 KIRK          </td><td width="125" align="right" style="color:black;">28 AUG-02 SEP </td><td width="40" align="right" style="color:black;"> 90 </td><td width="40" align="right" style="color:black;"> 970 </td><td width="40" align="right" style="color:black;">  2</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">12</td><td width="250" style="color:black;">Hurricane-1 LESLIE        </td><td width="125" align="right" style="color:black;">30 AUG-11 SEP </td><td width="40" align="right" style="color:black;"> 65 </td><td width="40" align="right" style="color:black;">968  </td><td width="40" align="right" style="color:black;"> 1 </td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">13</td><td width="250" style="color:black;">Hurricane-3 MICHAEL       </td><td width="125" align="right" style="color:black;">03-11 SEP     </td><td width="40" align="right" style="color:black;">100 </td><td width="40" align="right" style="color:black;"> 964 </td><td width="40" align="right" style="color:black;">  3</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">14</td><td width="250" style="color:black;">Hurricane-1 NADINE        </td><td width="125" align="right" style="color:black;">11 SEP-04 OCT </td><td width="40" align="right" style="color:black;"> 80 </td><td width="40" align="right" style="color:black;"> 978 </td><td width="40" align="right" style="color:black;">  1</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">15</td><td width="250" style="color:black;">Tropical Storm OSCAR      </td><td width="125" align="right" style="color:black;">03-05 OCT     </td><td width="40" align="right" style="color:black;"> 45 </td><td width="40" align="right" style="color:black;"> 997 </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">16</td><td width="250" style="color:black;">Tropical Storm PATTY      </td><td width="125" align="right" style="color:black;">11-13 OCT     </td><td width="40" align="right" style="color:black;"> 40 </td><td width="40" align="right" style="color:black;">1005 </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">17</td><td width="250" style="color:black;">Hurricane-1 RAFAEL        </td><td width="125" align="right" style="color:black;">12-17 OCT     </td><td width="40" align="right" style="color:black;"> 80 </td><td width="40" align="right" style="color:black;"> 969 </td><td width="40" align="right" style="color:black;">  1</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">18</td><td width="250" style="color:black;">Hurricane-2 SANDY         </td><td width="125" align="right" style="color:black;">22-29 OCT     </td><td width="40" align="right" style="color:black;"> 95 </td><td width="40" align="right" style="color:black;"> 940 </td><td width="40" align="right" style="color:black;">  2</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">19</td><td width="250" style="color:black;">Tropical Storm TONY       </td><td width="125" align="right" style="color:black;">22-25 OCT     </td><td width="40" align="right" style="color:black;"> 45 </td><td width="40" align="right" style="color:black;">1000 </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
</table><br/>
<big style="font-weight: bold;"><span
 style="font-family: helvetica,arial,sans-serif;"> Saffir-Simpson Scale</span></big>
      <p style="font-family: helvetica,arial,sans-serif;">The chart
color codes intensity (category based on Saffir-Simpson scale): </p>
      <table border="0" style="font-family: helvetica,arial,sans-serif;">
        <tbody>
          <tr>
            <td valign="top" bgcolor="#000099"
 style="color: rgb(255, 255, 255); font-weight: bold;"><small>Type</small></td>
            <td align="center" valign="top" bgcolor="#000099"
 style="color: rgb(255, 255, 255); font-weight: bold;"><small>Category</small></td>
            <td align="center" valign="top" bgcolor="#000099"
 style="color: rgb(255, 255, 255); font-weight: bold;"><small>Pressure
(mb)</small></td>
            <td align="center" valign="top" bgcolor="#000099"
 style="color: rgb(255, 255, 255); font-weight: bold;"><small>Winds<br/>
(knots)</small></td>
            <td align="center" valign="top" bgcolor="#000099"
 style="color: rgb(255, 255, 255); font-weight: bold;"><small>Winds<br/>
(mph)</small></td>
            <td align="center" valign="top" bgcolor="#000099"
 style="color: rgb(255, 255, 255); font-weight: bold;"><small>Line Color</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Depression</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>td</small></td>
            <td
 style="text-align: center; vertical-align: top; background-color: rgb(160, 224, 255); font-weight: bold;"><small>-----</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>&lt; 34</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>&lt; 39</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Green</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Tropical Storm</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>TS</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>-----</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>34-63</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>39-73</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Yellow</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Hurricane</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>1</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>&gt; 980</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>64-82</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>74-95</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Red</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Hurricane</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>2</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>965-980</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>83-95</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>96-110</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Light Red</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Hurricane</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>3</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>945-965</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>96-112</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>111-130</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Magenta</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Hurricane</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>4</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>920-945</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>113-135</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>131-155</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Light Magenta</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Hurricane</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>5</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>&lt; 920</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>&gt;135</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>&gt;155</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>White</small></td>
          </tr>
        </tbody>
      </table>
      <p style="font-family: helvetica,arial,sans-serif;"><small><b>NOTE:</b>
Pressures are in millibars and winds are in <b>knots</b> where one knot
is equal to 1.15 mph</small></p><hr/>
<h3 style="font-family: helvetica,arial,sans-serif;">Individual Storm Details</h3>
<table border="1" style="font-family: helvetica,arial,sans-serif;">

<tr><td valign="top">
<a href="/hurricane/atlantic/2012/TONY/track.gif">
  <img src="/hurricane/atlantic/2012/TONY/track_s.gif" border="0" alt="Track"/></a><br/>
<a href="/hurricane/atlantic/2012/TONY/sat_ir.gif">
  <img src="/hurricane/atlantic/2012/TONY/sat_ir_s.gif" border="0" alt="Sat IR"/></a><br/>
  <b>Current: <a href="/hurricane/atlantic/2012/TONY/track.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Track"/>Track</a> 
  <a href="/hurricane/atlantic/2012/TONY/sat_ir.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Sat IR"/>IR</a>
  <a href="/hurricane/atlantic/2012/TONY/sat_vis.gif">
     <img src="/hurricane/images/GIF.gif" border="0" alt="Sat Vis"/>Vis</a>
</b><br/>
</td><td>
<ul><li><b>Tropical Storm TONY</b> (22-25 OCT)<br/>
Storm - Max Winds: 45 Min Pres: 1000 Category: TS<br/>
Current - Max Winds: 35 Min Pres: 1000 Category: TS<br/>
</li></ul>
<pre><span style="font-size:x-small;">
TROPICAL STORM TONY FORECAST/ADVISORY NUMBER  12
NWS NATIONAL HURRICANE CENTER MIAMI FL       AL192012
1500 UTC THU OCT 25 2012
 
THERE ARE NO COASTAL WATCHES OR WARNINGS IN EFFECT.
 
TROPICAL STORM CENTER LOCATED NEAR 31.0N  36.3W AT 25/1500Z
POSITION ACCURATE WITHIN  25 NM
 
PRESENT MOVEMENT TOWARD THE EAST-NORTHEAST OR  70 DEGREES AT  18 KT
 
ESTIMATED MINIMUM CENTRAL PRESSURE 1000 MB
MAX SUSTAINED WINDS  35 KT WITH GUSTS TO  45 KT.
34 KT....... 90NE  70SE  40SW  30NW.
12 FT SEAS.. 60NE  30SE   0SW   0NW.
WINDS AND SEAS VARY GREATLY IN EACH QUADRANT.  RADII IN NAUTICAL
MILES ARE THE LARGEST RADII EXPECTED ANYWHERE IN THAT QUADRANT.

FORECAST POSITIONS AND MAX WINDS
 
INIT  25/1500Z 31.0N  36.3W   35 KT  40 MPH
 12H  26/0000Z 31.6N  33.4W   35 KT  40 MPH...POST-TROP/EXTRATROP
 24H  26/1200Z 32.5N  30.0W   35 KT  40 MPH...POST-TROP/EXTRATROP
 36H  27/0000Z 33.2N  27.8W   30 KT  35 MPH...POST-TROP/EXTRATROP
 48H  27/1200Z...DISSIPATED
</span></pre>
<ul><li class="nobullet">
<a href="/hurricane/atlantic/2012/TONY/track.dat">
<img src="/hurricane/images/DETAILS.gif" border="0" alt="Details"/>Tracking information</a><br/></li></ul>
</td></tr>

<tr><td valign="top">
<a href="/hurricane/atlantic/2012/SANDY/track.gif">
  <img src="/hurricane/atlantic/2012/SANDY/track_s.gif" border="0" alt="Track"/></a><br/>
<a href="/hurricane/atlantic/2012/SANDY/sat_ir.gif">
  <img src="/hurricane/atlantic/2012/SANDY/sat_ir_s.gif" border="0" alt="Sat IR"/></a><br/>
  <b>Current: <a href="/hurricane/atlantic/2012/SANDY/track.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Track"/>Track</a> 
  <a href="/hurricane/atlantic/2012/SANDY/sat_ir.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Sat IR"/>IR</a>
  <a href="/hurricane/atlantic/2012/SANDY/sat_vis.gif">
     <img src="/hurricane/images/GIF.gif" border="0" alt="Sat Vis"/>Vis</a>
</b><br/>
</td><td>
<ul><li><b>Hurricane-2 SANDY</b> (22-29 OCT)<br/>
Storm - Max Winds: 95 Min Pres: 940 Category: 2<br/>
Current - Max Winds: 80 Min Pres: 940 Category: 1<br/>
</li></ul>
<pre><span style="font-size:x-small;">
HURRICANE SANDY FORECAST/ADVISORY NUMBER  30
NWS NATIONAL HURRICANE CENTER MIAMI FL       AL182012
2100 UTC MON OCT 29 2012
 
CHANGES IN WATCHES AND WARNINGS WITH THIS ADVISORY...
 
ALL TROPICAL STORM WARNINGS FOR EASTERN NORTH CAROLINA HAVE BEEN
DISCONTINUED.
 
SUMMARY OF WATCHES AND WARNINGS IN EFFECT...
 
THERE ARE NO COASTAL TROPICAL CYCLONE WARNINGS IN EFFECT.
 
HOWEVER...THERE ARE NON-TROPICAL HIGH-WIND WARNINGS IN EFFECT FOR
PORTIONS OF THE MID-ATLANTIC AND NEW ENGLAND STATES. PLEASE SEE
STATEMENTS FROM LOCAL NATIONAL WEATHER SERVICE FORECAST OFFICES.
 
HURRICANE-FORCE WINDS ARE EXPECTED ALONG PORTIONS OF THE COAST
BETWEEN CHINCOTEAGUE VIRGINIA AND CHATHAM MASSACHUSETTS. THIS
INCLUDES THE TIDAL POTOMAC FROM COBB ISLAND TO SMITH POINT... THE
MIDDLE AND UPPER CHESAPEAKE BAY...DELAWARE BAY...AND THE COASTS OF
THE NORTHERN DELMARVA PENINSULA...NEW JERSEY...THE NEW YORK CITY
AREA...LONG ISLAND...CONNECTICUT...AND RHODE ISLAND.
 
TROPICAL-STORM-FORCE WINDS ARE EXPECTED NORTH OF CHATHAM TO
MERRIMACK RIVER MASSACHUSETTS...THE LOWER CHESAPEAKE BAY...AND
SOUTH OF CHINCOTEAGUE TO EXTREME NORTHEASTERN NORTH CAROLINA.
 
HURRICANE CENTER LOCATED NEAR 38.8N  74.4W AT 29/2100Z
POSITION ACCURATE WITHIN  20 NM
 
PRESENT MOVEMENT TOWARD THE WEST-NORTHWEST OR 300 DEGREES AT  24 KT
 
ESTIMATED MINIMUM CENTRAL PRESSURE  940 MB
MAX SUSTAINED WINDS  80 KT WITH GUSTS TO 100 KT.
64 KT.......  0NE  80SE 150SW   0NW.
50 KT.......170NE 150SE 200SW 150NW.
34 KT.......420NE 370SE 400SW 200NW.
12 FT SEAS..660NE 995SE 660SW 180NW.
WINDS AND SEAS VARY GREATLY IN EACH QUADRANT.  RADII IN NAUTICAL
MILES ARE THE LARGEST RADII EXPECTED ANYWHERE IN THAT QUADRANT.

FORECAST POSITIONS AND MAX WINDS
 
INIT  29/2100Z 38.8N  74.4W   80 KT  90 MPH
 12H  30/0600Z 39.8N  76.6W   65 KT  75 MPH...POST-TROP/EXTRATROP
 24H  30/1800Z 40.4N  78.3W   50 KT  60 MPH...POST-TROP/EXTRATROP
 36H  31/0600Z 41.3N  78.2W   40 KT  45 MPH...POST-TROP/EXTRATROP
 48H  31/1800Z 42.8N  77.5W   30 KT  35 MPH...POST-TROP/EXTRATROP
 72H  01/1800Z 45.1N  75.5W   30 KT  35 MPH...POST-TROP/EXTRATROP
 96H  02/1800Z 46.3N  72.2W   25 KT  30 MPH...POST-TROP/EXTRATROP
120H  03/1800Z 47.5N  65.5W   20 KT  25 MPH...POST-TROP/EXTRATROP
</span></pre>
<ul><li class="nobullet">
<a href="/hurricane/atlantic/2012/SANDY/track.dat">
<img src="/hurricane/images/DETAILS.gif" border="0" alt="Details"/>Tracking information</a><br/></li></ul>
</td></tr>

<tr><td valign="top">
<a href="/hurricane/atlantic/2012/RAFAEL/track.gif">
  <img src="/hurricane/atlantic/2012/RAFAEL/track_s.gif" border="0" alt="Track"/></a><br/>
<a href="/hurricane/atlantic/2012/RAFAEL/sat_ir.gif">
  <img src="/hurricane/atlantic/2012/RAFAEL/sat_ir_s.gif" border="0" alt="Sat IR"/></a><br/>
  <b>Current: <a href="/hurricane/atlantic/2012/RAFAEL/track.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Track"/>Track</a> 
  <a href="/hurricane/atlantic/2012/RAFAEL/sat_ir.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Sat IR"/>IR</a>
  <a href="/hurricane/atlantic/2012/RAFAEL/sat_vis.gif">
     <img src="/hurricane/images/GIF.gif" border="0" alt="Sat Vis"/>Vis</a>
</b><br/>
</td><td>
<ul><li><b>Hurricane-1 RAFAEL</b> (12-17 OCT)<br/>
Storm - Max Winds: 80 Min Pres: 969 Category: 1<br/>
Current - Max Winds: 65 Min Pres: 975 Category: 1<br/>
</li></ul>
<pre><span style="font-size:x-small;">
HURRICANE RAFAEL FORECAST/ADVISORY NUMBER  20
NWS NATIONAL HURRICANE CENTER MIAMI FL       AL172012
1500 UTC WED OCT 17 2012
 
THERE ARE NO COASTAL WATCHES OR WARNINGS IN EFFECT.
 
HURRICANE CENTER LOCATED NEAR 37.5N  59.1W AT 17/1500Z
POSITION ACCURATE WITHIN  25 NM
 
PRESENT MOVEMENT TOWARD THE NORTH-NORTHEAST OR  30 DEGREES AT  30 KT
 
ESTIMATED MINIMUM CENTRAL PRESSURE  975 MB
MAX SUSTAINED WINDS  65 KT WITH GUSTS TO  80 KT.
64 KT....... 50NE  60SE   0SW  30NW.
50 KT.......100NE 120SE  60SW  80NW.
34 KT.......240NE 270SE 150SW 150NW.
12 FT SEAS..360NE 420SE 300SW 150NW.
WINDS AND SEAS VARY GREATLY IN EACH QUADRANT.  RADII IN NAUTICAL
MILES ARE THE LARGEST RADII EXPECTED ANYWHERE IN THAT QUADRANT.

FORECAST POSITIONS AND MAX WINDS
 
INIT  17/1500Z 37.5N  59.1W   65 KT  75 MPH
 12H  18/0000Z 41.0N  54.5W   60 KT  70 MPH...POST-TROP/EXTRATROP
 24H  18/1200Z 44.8N  45.8W   60 KT  70 MPH...POST-TROP/EXTRATROP
 36H  19/0000Z 48.0N  36.5W   55 KT  65 MPH...POST-TROP/EXTRATROP
 48H  19/1200Z 51.0N  30.0W   50 KT  60 MPH...POST-TROP/EXTRATROP
 72H  20/1200Z 54.0N  33.0W   50 KT  60 MPH...POST-TROP/EXTRATROP
 96H  21/1200Z 47.5N  34.0W   40 KT  45 MPH...POST-TROP/EXTRATROP
120H  22/1200Z 43.5N  29.0W   35 KT  40 MPH...POST-TROP/EXTRATROP
</span></pre>
<ul><li class="nobullet">
<a href="/hurricane/atlantic/2012/RAFAEL/track.dat">
<img src="/hurricane/images/DETAILS.gif" border="0" alt="Details"/>Tracking information</a><br/></li></ul>
</td></tr>

<tr><td valign="top">
<a href="/hurricane/atlantic/2012/PATTY/track.gif">
  <img src="/hurricane/atlantic/2012/PATTY/track_s.gif" border="0" alt="Track"/></a><br/>
<a href="/hurricane/atlantic/2012/PATTY/sat_ir.gif">
  <img src="/hurricane/atlantic/2012/PATTY/sat_ir_s.gif" border="0" alt="Sat IR"/></a><br/>
  <b>Current: <a href="/hurricane/atlantic/2012/PATTY/track.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Track"/>Track</a> 
  <a href="/hurricane/atlantic/2012/PATTY/sat_ir.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Sat IR"/>IR</a>
  <a href="/hurricane/atlantic/2012/PATTY/sat_vis.gif">
     <img src="/hurricane/images/GIF.gif" border="0" alt="Sat Vis"/>Vis</a>
</b><br/>
</td><td>
<ul><li><b>Tropical Storm PATTY</b> (11-13 OCT)<br/>
Storm - Max Winds: 40 Min Pres: 1005 Category: TS<br/>
Current - Max Winds: 30 Min Pres: 1008 Category: TD<br/>
</li></ul>
<pre><span style="font-size:x-small;">
TROPICAL DEPRESSION PATTY FORECAST/ADVISORY NUMBER   8
NWS NATIONAL HURRICANE CENTER MIAMI FL       AL162012
0900 UTC SAT OCT 13 2012
 
THERE ARE NO COASTAL WATCHES OR WARNINGS IN EFFECT.
 
TROPICAL DEPRESSION CENTER LOCATED NEAR 25.5N  71.9W AT 13/0900Z
POSITION ACCURATE WITHIN  20 NM
 
PRESENT MOVEMENT IS STATIONARY
 
ESTIMATED MINIMUM CENTRAL PRESSURE 1008 MB
MAX SUSTAINED WINDS  30 KT WITH GUSTS TO  40 KT.
WINDS AND SEAS VARY GREATLY IN EACH QUADRANT.  RADII IN NAUTICAL
MILES ARE THE LARGEST RADII EXPECTED ANYWHERE IN THAT QUADRANT.

FORECAST POSITIONS AND MAX WINDS
 
INIT  13/0900Z 25.5N  71.9W   30 KT  35 MPH
 12H  13/1800Z 25.4N  72.0W   25 KT  30 MPH...POST-TROP/REMNT LOW
 24H  14/0600Z 24.0N  74.5W   25 KT  30 MPH...POST-TROP/REMNT LOW
 36H  14/1800Z...DISSIPATED
</span></pre>
<ul><li class="nobullet">
<a href="/hurricane/atlantic/2012/PATTY/track.dat">
<img src="/hurricane/images/DETAILS.gif" border="0" alt="Details"/>Tracking information</a><br/></li></ul>
</td></tr>

<tr><td valign="top">
<a href="/hurricane/atlantic/2012/OSCAR/track.gif">
  <img src="/hurricane/atlantic/2012/OSCAR/track_s.gif" border="0" alt="Track"/></a><br/>
<a href="/hurricane/atlantic/2012/OSCAR/sat_ir.gif">
  <img src="/hurricane/atlantic/2012/OSCAR/sat_ir_s.gif" border="0" alt="Sat IR"/></a><br/>
  <b>Current: <a href="/hurricane/atlantic/2012/OSCAR/track.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Track"/>Track</a> 
  <a href="/hurricane/atlantic/2012/OSCAR/sat_ir.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Sat IR"/>IR</a>
  <a href="/hurricane/atlantic/2012/OSCAR/sat_vis.gif">
     <img src="/hurricane/images/GIF.gif" border="0" alt="Sat Vis"/>Vis</a>
</b><br/>
</td><td>
<ul><li><b>Tropical Storm OSCAR</b> (03-05 OCT)<br/>
Storm - Max Winds: 45 Min Pres: 997 Category: TS<br/>
Current - Max Winds: 45 Min Pres: 997 Category: TS<br/>
</li></ul>
<pre><span style="font-size:x-small;">
TROPICAL STORM OSCAR FORECAST/ADVISORY NUMBER   8
NWS NATIONAL HURRICANE CENTER MIAMI FL       AL152012
0900 UTC FRI OCT 05 2012
 
THERE ARE NO COASTAL WATCHES OR WARNINGS IN EFFECT.
 
TROPICAL STORM CENTER LOCATED NEAR 23.0N  38.9W AT 05/0900Z
POSITION ACCURATE WITHIN  30 NM
 
PRESENT MOVEMENT TOWARD THE NORTHEAST OR  50 DEGREES AT  13 KT
 
ESTIMATED MINIMUM CENTRAL PRESSURE  997 MB
MAX SUSTAINED WINDS  45 KT WITH GUSTS TO  55 KT.
34 KT.......180NE 140SE   0SW   0NW.
12 FT SEAS..180NE 150SE   0SW   0NW.
WINDS AND SEAS VARY GREATLY IN EACH QUADRANT.  RADII IN NAUTICAL
MILES ARE THE LARGEST RADII EXPECTED ANYWHERE IN THAT QUADRANT.

FORECAST POSITIONS AND MAX WINDS
 
INIT  05/0900Z 23.0N  38.9W   45 KT  50 MPH
 12H  05/1800Z 25.5N  35.6W   45 KT  50 MPH
 24H  06/0600Z...DISSIPATED
</span></pre>
<ul><li class="nobullet">
<a href="/hurricane/atlantic/2012/OSCAR/track.dat">
<img src="/hurricane/images/DETAILS.gif" border="0" alt="Details"/>Tracking information</a><br/></li></ul>
</td></tr>

<tr><td valign="top">
<a href="/hurricane/atlantic/2012/NADINE/track.gif">
  <img src="/hurricane/atlantic/2012/NADINE/track_s.gif" border="0" alt="Track"/></a><br/>
<a href="/hurricane/atlantic/2012/NADINE/sat_ir.gif">
  <img src="/hurricane/atlantic/2012/NADINE/sat_ir_s.gif" border="0" alt="Sat IR"/></a><br/>
  <b>Current: <a href="/hurricane/atlantic/2012/NADINE/track.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Track"/>Track</a> 
  <a href="/hurricane/atlantic/2012/NADINE/sat_ir.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Sat IR"/>IR</a>
  <a href="/hurricane/atlantic/2012/NADINE/sat_vis.gif">
     <img src="/hurricane/images/GIF.gif" border="0" alt="Sat Vis"/>Vis</a>
</b><br/>
</td><td>
<ul><li><b>Hurricane-1 NADINE</b> (11 SEP-04 OCT)<br/>
Storm - Max Winds: 80 Min Pres: 978 Category: 1<br/>
Current - Max Winds: 40 Min Pres: 992 Category: TS<br/>
</li></ul>
<pre><span style="font-size:x-small;">
TROPICAL STORM NADINE FORECAST/ADVISORY NUMBER  87
NWS NATIONAL HURRICANE CENTER MIAMI FL       AL142012
0900 UTC THU OCT 04 2012
 
CHANGES IN WATCHES AND WARNINGS WITH THIS ADVISORY...
 
NONE.
 
SUMMARY OF WATCHES AND WARNINGS IN EFFECT...
 
A TROPICAL STORM WARNING IS IN EFFECT FOR...
* THE AZORES
 
A TROPICAL STORM WARNING MEANS THAT TROPICAL STORM CONDITIONS ARE
EXPECTED SOMEWHERE WITHIN THE WARNING AREA...IN THIS CASE WITHIN
THE NEXT 12 HOURS.
 
TROPICAL STORM CENTER LOCATED NEAR 38.4N  28.4W AT 04/0900Z
POSITION ACCURATE WITHIN  35 NM
 
PRESENT MOVEMENT TOWARD THE NORTHEAST OR  40 DEGREES AT  20 KT
 
ESTIMATED MINIMUM CENTRAL PRESSURE  996 MB
MAX SUSTAINED WINDS  40 KT WITH GUSTS TO  50 KT.
34 KT.......100NE 120SE  90SW  60NW.
12 FT SEAS..120NE 180SE 150SW 120NW.
WINDS AND SEAS VARY GREATLY IN EACH QUADRANT.  RADII IN NAUTICAL
MILES ARE THE LARGEST RADII EXPECTED ANYWHERE IN THAT QUADRANT.

FORECAST POSITIONS AND MAX WINDS
 
INIT  04/0900Z 38.4N  28.4W   40 KT  45 MPH
 12H  04/1800Z 41.9N  26.6W   40 KT  45 MPH...POST-TROPICAL
 24H  05/0600Z 45.2N  26.0W   40 KT  45 MPH...POST-TROP/EXTRATROP
 36H  05/1800Z 47.0N  26.0W   40 KT  45 MPH...POST-TROP/EXTRATROP
 48H  06/0600Z 48.5N  27.5W   35 KT  40 MPH...POST-TROP/EXTRATROP
 72H  07/0600Z...ABSORBED BY EXTRATROPICAL LOW
</span></pre>
<ul><li class="nobullet">
<a href="/hurricane/atlantic/2012/NADINE/track.dat">
<img src="/hurricane/images/DETAILS.gif" border="0" alt="Details"/>Tracking information</a><br/></li></ul>
</td></tr>

<tr><td valign="top">
<a href="/hurricane/atlantic/2012/MICHAEL/track.gif">
  <img src="/hurricane/atlantic/2012/MICHAEL/track_s.gif" border="0" alt="Track"/></a><br/>
<a href="/hurricane/atlantic/2012/MICHAEL/sat_ir.gif">
  <img src="/hurricane/atlantic/2012/MICHAEL/sat_ir_s.gif" border="0" alt="Sat IR"/></a><br/>
  <b>Current: <a href="/hurricane/atlantic/2012/MICHAEL/track.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Track"/>Track</a> 
  <a href="/hurricane/atlantic/2012/MICHAEL/sat_ir.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Sat IR"/>IR</a>
  <a href="/hurricane/atlantic/2012/MICHAEL/sat_vis.gif">
     <img src="/hurricane/images/GIF.gif" border="0" alt="Sat Vis"/>Vis</a>
</b><br/>
</td><td>
<ul><li><b>Hurricane-3 MICHAEL</b> (03-11 SEP)<br/>
Storm - Max Winds: 100 Min Pres: 964 Category: 3<br/>
Current - Max Winds: 40 Min Pres: 1000 Category: TS<br/>
</li></ul>
<pre><span style="font-size:x-small;">
TROPICAL STORM MICHAEL FORECAST/ADVISORY NUMBER  34
NWS NATIONAL HURRICANE CENTER MIAMI FL       AL132012
1500 UTC TUE SEP 11 2012
 
THERE ARE NO COASTAL WATCHES OR WARNINGS IN EFFECT.
 
TROPICAL STORM CENTER LOCATED NEAR 39.2N  47.2W AT 11/1500Z
POSITION ACCURATE WITHIN  30 NM
 
PRESENT MOVEMENT TOWARD THE NORTH-NORTHEAST OR  20 DEGREES AT  20 KT
 
ESTIMATED MINIMUM CENTRAL PRESSURE 1000 MB
MAX SUSTAINED WINDS  40 KT WITH GUSTS TO  50 KT.
34 KT....... 70NE  70SE   0SW   0NW.
12 FT SEAS..120NE 120SE  90SW  90NW.
WINDS AND SEAS VARY GREATLY IN EACH QUADRANT.  RADII IN NAUTICAL
MILES ARE THE LARGEST RADII EXPECTED ANYWHERE IN THAT QUADRANT.

FORECAST POSITIONS AND MAX WINDS
 
INIT  11/1500Z 39.2N  47.2W   40 KT  45 MPH
 12H  12/0000Z 43.0N  46.0W   35 KT  40 MPH...POST-TROP/REMNT LOW
 24H  12/1200Z 48.0N  40.0W   30 KT  35 MPH...POST-TROP/EXTRATROP
 36H  13/0000Z...ABSORBED BY A FRONT
</span></pre>
<ul><li class="nobullet">
<a href="/hurricane/atlantic/2012/MICHAEL/track.dat">
<img src="/hurricane/images/DETAILS.gif" border="0" alt="Details"/>Tracking information</a><br/></li></ul>
</td></tr>

<tr><td valign="top">
<a href="/hurricane/atlantic/2012/LESLIE/track.gif">
  <img src="/hurricane/atlantic/2012/LESLIE/track_s.gif" border="0" alt="Track"/></a><br/>
<a href="/hurricane/atlantic/2012/LESLIE/sat_ir.gif">
  <img src="/hurricane/atlantic/2012/LESLIE/sat_ir_s.gif" border="0" alt="Sat IR"/></a><br/>
  <b>Current: <a href="/hurricane/atlantic/2012/LESLIE/track.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Track"/>Track</a> 
  <a href="/hurricane/atlantic/2012/LESLIE/sat_ir.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Sat IR"/>IR</a>
  <a href="/hurricane/atlantic/2012/LESLIE/sat_vis.gif">
     <img src="/hurricane/images/GIF.gif" border="0" alt="Sat Vis"/>Vis</a>
</b><br/>
</td><td>
<ul><li><b>Hurricane-1 LESLIE</b> (30 AUG-11 SEP)<br/>
Storm - Max Winds: 65 Min Pres: 968 Category: 1<br/>
Current - Max Winds: 60 Min Pres: 968 Category: TS<br/>
</li></ul>
<pre><span style="font-size:x-small;">
TROPICAL STORM LESLIE FORECAST/ADVISORY NUMBER  48
NWS NATIONAL HURRICANE CENTER MIAMI FL       AL122012
0900 UTC TUE SEP 11 2012
 
CHANGES IN WATCHES AND WARNINGS WITH THIS ADVISORY...
 
NONE.
 
SUMMARY OF WATCHES AND WARNINGS IN EFFECT...
 
A HURRICANE WATCH IS IN EFFECT FOR...
* NEWFOUNDLAND FROM STONES COVE TO CHARLOTTETOWN
 
A TROPICAL STORM WARNING IS IN EFFECT FOR...
* NEWFOUNDLAND FROM INDIAN HARBOUR...TO TRITON
 
TROPICAL STORM CENTER LOCATED NEAR 45.7N  56.4W AT 11/0900Z
POSITION ACCURATE WITHIN  40 NM
 
PRESENT MOVEMENT TOWARD THE NORTH-NORTHEAST OR  20 DEGREES AT  35 KT
 
ESTIMATED MINIMUM CENTRAL PRESSURE  968 MB
MAX SUSTAINED WINDS  60 KT WITH GUSTS TO  75 KT.
50 KT.......120NE 150SE  60SW  60NW.
34 KT.......270NE 270SE 180SW 150NW.
12 FT SEAS..300NE 320SE 380SW 360NW.
WINDS AND SEAS VARY GREATLY IN EACH QUADRANT.  RADII IN NAUTICAL
MILES ARE THE LARGEST RADII EXPECTED ANYWHERE IN THAT QUADRANT.

FORECAST POSITIONS AND MAX WINDS
 
INIT  11/0900Z 45.7N  56.4W   60 KT  70 MPH
 12H  11/1800Z 51.0N  52.0W   60 KT  70 MPH...POST-TROP/EXTRATROP
 24H  12/0600Z 57.5N  43.5W   60 KT  70 MPH...POST-TROP/EXTRATROP
 36H  12/1800Z 61.5N  33.0W   60 KT  70 MPH...POST-TROP/EXTRATROP
 48H  13/0600Z 63.5N  25.0W   55 KT  65 MPH...POST-TROP/EXTRATROP
 72H  14/0600Z 61.5N   9.0W   45 KT  50 MPH...POST-TROP/EXTRATROP
 96H  15/0600Z...ABSORBED
</span></pre>
<ul><li class="nobullet">
<a href="/hurricane/atlantic/2012/LESLIE/track.dat">
<img src="/hurricane/images/DETAILS.gif" border="0" alt="Details"/>Tracking information</a><br/></li></ul>
</td></tr>

<tr><td valign="top">
<a href="/hurricane/atlantic/2012/KIRK/track.gif">
  <img src="/hurricane/atlantic/2012/KIRK/track_s.gif" border="0" alt="Track"/></a><br/>
<a href="/hurricane/atlantic/2012/KIRK/sat_ir.gif">
  <img src="/hurricane/atlantic/2012/KIRK/sat_ir_s.gif" border="0" alt="Sat IR"/></a><br/>
  <b>Current: <a href="/hurricane/atlantic/2012/KIRK/track.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Track"/>Track</a> 
  <a href="/hurricane/atlantic/2012/KIRK/sat_ir.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Sat IR"/>IR</a>
  <a href="/hurricane/atlantic/2012/KIRK/sat_vis.gif">
     <img src="/hurricane/images/GIF.gif" border="0" alt="Sat Vis"/>Vis</a>
</b><br/>
</td><td>
<ul><li><b>Hurricane-2 KIRK</b> (28 AUG-02 SEP)<br/>
Storm - Max Winds: 90 Min Pres: 970 Category: 2<br/>
Current - Max Winds: 45 Min Pres: 1002 Category: TS<br/>
</li></ul>
<pre><span style="font-size:x-small;">
TROPICAL STORM KIRK FORECAST/ADVISORY NUMBER  20
NWS NATIONAL HURRICANE CENTER MIAMI FL       AL112012
1500 UTC SUN SEP 02 2012
 
THERE ARE NO COASTAL WATCHES OR WARNINGS IN EFFECT.
 
TROPICAL STORM CENTER LOCATED NEAR 46.2N  36.5W AT 02/1500Z
POSITION ACCURATE WITHIN  40 NM
 
PRESENT MOVEMENT TOWARD THE NORTHEAST OR  35 DEGREES AT  32 KT
 
ESTIMATED MINIMUM CENTRAL PRESSURE 1002 MB
MAX SUSTAINED WINDS  45 KT WITH GUSTS TO  55 KT.
34 KT....... 60NE 100SE   0SW   0NW.
12 FT SEAS.. 60NE 150SE 200SW  60NW.
WINDS AND SEAS VARY GREATLY IN EACH QUADRANT.  RADII IN NAUTICAL
MILES ARE THE LARGEST RADII EXPECTED ANYWHERE IN THAT QUADRANT.

FORECAST POSITIONS AND MAX WINDS
 
INIT  02/1500Z 46.2N  36.5W   45 KT  50 MPH
 12H  03/0000Z 51.1N  30.1W   45 KT  50 MPH...POST-TROPICAL
 24H  03/1200Z...DISSIPATED
</span></pre>
<ul><li class="nobullet">
<a href="/hurricane/atlantic/2012/KIRK/track.dat">
<img src="/hurricane/images/DETAILS.gif" border="0" alt="Details"/>Tracking information</a><br/></li></ul>
</td></tr>

<tr><td valign="top">
<a href="/hurricane/atlantic/2012/JOYCE/track.gif">
  <img src="/hurricane/atlantic/2012/JOYCE/track_s.gif" border="0" alt="Track"/></a><br/>
<a href="/hurricane/atlantic/2012/JOYCE/sat_ir.gif">
  <img src="/hurricane/atlantic/2012/JOYCE/sat_ir_s.gif" border="0" alt="Sat IR"/></a><br/>
  <b>Current: <a href="/hurricane/atlantic/2012/JOYCE/track.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Track"/>Track</a> 
  <a href="/hurricane/atlantic/2012/JOYCE/sat_ir.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Sat IR"/>IR</a>
  <a href="/hurricane/atlantic/2012/JOYCE/sat_vis.gif">
     <img src="/hurricane/images/GIF.gif" border="0" alt="Sat Vis"/>Vis</a>
</b><br/>
</td><td>
<ul><li><b>Tropical Storm JOYCE</b> (22-24 AUG)<br/>
Storm - Max Winds: 35 Min Pres: 1006 Category: TS<br/>
Current - Max Winds: 30 Min Pres: 1008 Category: TD<br/>
</li></ul>
<pre><span style="font-size:x-small;">
TROPICAL DEPRESSION JOYCE FORECAST/ADVISORY NUMBER   8
NWS NATIONAL HURRICANE CENTER MIAMI FL       AL102012
0900 UTC FRI AUG 24 2012
 
THERE ARE NO COASTAL WATCHES OR WARNINGS IN EFFECT.
 
TROPICAL DEPRESSION CENTER LOCATED NEAR 16.9N  45.0W AT 24/0900Z
POSITION ACCURATE WITHIN  15 NM
 
PRESENT MOVEMENT TOWARD THE NORTHWEST OR 305 DEGREES AT  12 KT
 
ESTIMATED MINIMUM CENTRAL PRESSURE 1008 MB
MAX SUSTAINED WINDS  30 KT WITH GUSTS TO  40 KT.
WINDS AND SEAS VARY GREATLY IN EACH QUADRANT.  RADII IN NAUTICAL
MILES ARE THE LARGEST RADII EXPECTED ANYWHERE IN THAT QUADRANT.

FORECAST POSITIONS AND MAX WINDS
 
INIT  24/0900Z 16.9N  45.0W   30 KT  35 MPH
 12H  24/1800Z 17.8N  47.0W   30 KT  35 MPH
 24H  25/0600Z 19.2N  50.6W   30 KT  35 MPH
 36H  25/1800Z 21.0N  54.0W   30 KT  35 MPH
 48H  26/0600Z 22.8N  57.5W   30 KT  35 MPH
 72H  27/0600Z 27.0N  63.0W   30 KT  35 MPH
 96H  28/0600Z 31.5N  64.0W   30 KT  35 MPH
120H  29/0600Z 36.5N  56.0W   30 KT  35 MPH
</span></pre>
<ul><li class="nobullet">
<a href="/hurricane/atlantic/2012/JOYCE/track.dat">
<img src="/hurricane/images/DETAILS.gif" border="0" alt="Details"/>Tracking information</a><br/></li></ul>
</td></tr>

<tr><td valign="top">
<a href="/hurricane/atlantic/2012/ISAAC/track.gif">
  <img src="/hurricane/atlantic/2012/ISAAC/track_s.gif" border="0" alt="Track"/></a><br/>
<a href="/hurricane/atlantic/2012/ISAAC/sat_ir.gif">
  <img src="/hurricane/atlantic/2012/ISAAC/sat_ir_s.gif" border="0" alt="Sat IR"/></a><br/>
  <b>Current: <a href="/hurricane/atlantic/2012/ISAAC/track.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Track"/>Track</a> 
  <a href="/hurricane/atlantic/2012/ISAAC/sat_ir.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Sat IR"/>IR</a>
  <a href="/hurricane/atlantic/2012/ISAAC/sat_vis.gif">
     <img src="/hurricane/images/GIF.gif" border="0" alt="Sat Vis"/>Vis</a>
</b><br/>
</td><td>
<ul><li><b>Hurricane-1 ISAAC</b> (21 AUG-01 SEP)<br/>
Storm - Max Winds: 70 Min Pres: 968 Category: 1<br/>
Current - Max Winds: 20 Min Pres: 1004 Category: TD<br/>
</li></ul>
<pre><span style="font-size:x-small;">
</span></pre>
<ul><li class="nobullet">
<a href="/hurricane/atlantic/2012/ISAAC/track.dat">
<img src="/hurricane/images/DETAILS.gif" border="0" alt="Details"/>Tracking information</a><br/></li></ul>
</td></tr>

<tr><td valign="top">
<a href="/hurricane/atlantic/2012/HELENE/track.gif">
  <img src="/hurricane/atlantic/2012/HELENE/track_s.gif" border="0" alt="Track"/></a><br/>
<a href="/hurricane/atlantic/2012/HELENE/sat_ir.gif">
  <img src="/hurricane/atlantic/2012/HELENE/sat_ir_s.gif" border="0" alt="Sat IR"/></a><br/>
  <b>Current: <a href="/hurricane/atlantic/2012/HELENE/track.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Track"/>Track</a> 
  <a href="/hurricane/atlantic/2012/HELENE/sat_ir.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Sat IR"/>IR</a>
  <a href="/hurricane/atlantic/2012/HELENE/sat_vis.gif">
     <img src="/hurricane/images/GIF.gif" border="0" alt="Sat Vis"/>Vis</a>
</b><br/>
</td><td>
<ul><li><b>Tropical Storm HELENE</b> (09-18 AUG)<br/>
Storm - Max Winds: 40 Min Pres: 1004 Category: TS<br/>
Current - Max Winds: 25 Min Pres: 1010 Category: TD<br/>
</li></ul>
<pre><span style="font-size:x-small;">
TROPICAL DEPRESSION HELENE FORECAST/ADVISORY NUMBER  13
NWS NATIONAL HURRICANE CENTER MIAMI FL       AL072012
2100 UTC SAT AUG 18 2012
 
THERE ARE NO COASTAL WATCHES AND WARNINGS IN EFFECT.
 
TROPICAL DEPRESSION CENTER LOCATED NEAR 22.6N  98.8W AT 18/2100Z
POSITION ACCURATE WITHIN  30 NM
 
PRESENT MOVEMENT TOWARD THE WEST-NORTHWEST OR 295 DEGREES AT   4 KT
 
ESTIMATED MINIMUM CENTRAL PRESSURE 1010 MB
MAX SUSTAINED WINDS  25 KT WITH GUSTS TO  35 KT.
WINDS AND SEAS VARY GREATLY IN EACH QUADRANT.  RADII IN NAUTICAL
MILES ARE THE LARGEST RADII EXPECTED ANYWHERE IN THAT QUADRANT.

FORECAST POSITIONS AND MAX WINDS
 
INIT  18/2100Z 22.6N  98.8W   25 KT  30 MPH...INLAND
 12H  19/0600Z 22.9N  99.2W   20 KT  25 MPH...POST-TROP/REMNT LOW
 24H  19/1800Z...DISSIPATED
</span></pre>
<ul><li class="nobullet">
<a href="/hurricane/atlantic/2012/HELENE/track.dat">
<img src="/hurricane/images/DETAILS.gif" border="0" alt="Details"/>Tracking information</a><br/></li></ul>
</td></tr>

<tr><td valign="top">
<a href="/hurricane/atlantic/2012/GORDON/track.gif">
  <img src="/hurricane/atlantic/2012/GORDON/track_s.gif" border="0" alt="Track"/></a><br/>
<a href="/hurricane/atlantic/2012/GORDON/sat_ir.gif">
  <img src="/hurricane/atlantic/2012/GORDON/sat_ir_s.gif" border="0" alt="Sat IR"/></a><br/>
  <b>Current: <a href="/hurricane/atlantic/2012/GORDON/track.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Track"/>Track</a> 
  <a href="/hurricane/atlantic/2012/GORDON/sat_ir.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Sat IR"/>IR</a>
  <a href="/hurricane/atlantic/2012/GORDON/sat_vis.gif">
     <img src="/hurricane/images/GIF.gif" border="0" alt="Sat Vis"/>Vis</a>
</b><br/>
</td><td>
<ul><li><b>Hurricane-2 GORDON</b> (15-20 AUG)<br/>
Storm - Max Winds: 95 Min Pres: 965 Category: 2<br/>
Current - Max Winds: 55 Min Pres: 990 Category: TS<br/>
</li></ul>
<pre><span style="font-size:x-small;">
TROPICAL STORM GORDON FORECAST/ADVISORY NUMBER  20
NWS NATIONAL HURRICANE CENTER MIAMI FL       AL082012
1500 UTC MON AUG 20 2012
 
THERE ARE NO COASTAL WATCHES OR WARNINGS IN EFFECT.
 
TROPICAL STORM CENTER LOCATED NEAR 38.3N  22.3W AT 20/1500Z
POSITION ACCURATE WITHIN  25 NM
 
PRESENT MOVEMENT TOWARD THE EAST-NORTHEAST OR  60 DEGREES AT  14 KT
 
ESTIMATED MINIMUM CENTRAL PRESSURE  990 MB
MAX SUSTAINED WINDS  55 KT WITH GUSTS TO  65 KT.
50 KT....... 40NE  50SE  30SW  40NW.
34 KT.......100NE 100SE  60SW  70NW.
12 FT SEAS..120NE 200SE 240SW  60NW.
WINDS AND SEAS VARY GREATLY IN EACH QUADRANT.  RADII IN NAUTICAL
MILES ARE THE LARGEST RADII EXPECTED ANYWHERE IN THAT QUADRANT.

FORECAST POSITIONS AND MAX WINDS
 
INIT  20/1500Z 38.3N  22.3W   55 KT  65 MPH
 12H  21/0000Z 39.0N  20.3W   40 KT  45 MPH...POST-TROPICAL
 24H  21/1200Z 39.2N  18.5W   30 KT  35 MPH...POST-TROP/REMNT LOW
 36H  22/0000Z 39.2N  17.6W   25 KT  30 MPH...POST-TROP/REMNT LOW
 48H  22/1200Z 39.0N  16.7W   20 KT  25 MPH...POST-TROP/REMNT LOW
 72H  23/1200Z...DISSIPATED
</span></pre>
<ul><li class="nobullet">
<a href="/hurricane/atlantic/2012/GORDON/track.dat">
<img src="/hurricane/images/DETAILS.gif" border="0" alt="Details"/>Tracking information</a><br/></li></ul>
</td></tr>

<tr><td valign="top">
<a href="/hurricane/atlantic/2012/FLORENCE/track.gif">
  <img src="/hurricane/atlantic/2012/FLORENCE/track_s.gif" border="0" alt="Track"/></a><br/>
<a href="/hurricane/atlantic/2012/FLORENCE/sat_ir.gif">
  <img src="/hurricane/atlantic/2012/FLORENCE/sat_ir_s.gif" border="0" alt="Sat IR"/></a><br/>
  <b>Current: <a href="/hurricane/atlantic/2012/FLORENCE/track.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Track"/>Track</a> 
  <a href="/hurricane/atlantic/2012/FLORENCE/sat_ir.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Sat IR"/>IR</a>
  <a href="/hurricane/atlantic/2012/FLORENCE/sat_vis.gif">
     <img src="/hurricane/images/GIF.gif" border="0" alt="Sat Vis"/>Vis</a>
</b><br/>
</td><td>
<ul><li><b>Tropical Storm FLORENCE</b> (04-06 AUG)<br/>
Storm - Max Winds: 50 Min Pres: 1000 Category: TS<br/>
Current - Max Winds: 30 Min Pres: 1009 Category: TD<br/>
</li></ul>
<pre><span style="font-size:x-small;">
TROPICAL DEPRESSION FLORENCE FORECAST/ADVISORY NUMBER  10
NWS NATIONAL HURRICANE CENTER MIAMI FL       AL062012
0900 UTC MON AUG 06 2012
 
THERE ARE NO COASTAL WATCHES OR WARNINGS IN EFFECT.
 
TROPICAL DEPRESSION CENTER LOCATED NEAR 16.2N  38.8W AT 06/0900Z
POSITION ACCURATE WITHIN  20 NM
 
PRESENT MOVEMENT TOWARD THE WEST OR 270 DEGREES AT  10 KT
 
ESTIMATED MINIMUM CENTRAL PRESSURE 1009 MB
MAX SUSTAINED WINDS  30 KT WITH GUSTS TO  40 KT.
WINDS AND SEAS VARY GREATLY IN EACH QUADRANT.  RADII IN NAUTICAL
MILES ARE THE LARGEST RADII EXPECTED ANYWHERE IN THAT QUADRANT.

FORECAST POSITIONS AND MAX WINDS
 
INIT  06/0900Z 16.2N  38.8W   30 KT  35 MPH
 12H  06/1800Z 16.3N  41.0W   30 KT  35 MPH
 24H  07/0600Z 16.6N  44.2W   25 KT  30 MPH
 36H  07/1800Z 17.2N  47.9W   25 KT  30 MPH...POST-TROP/REMNT LOW
 48H  08/0600Z 18.1N  51.8W   25 KT  30 MPH...POST-TROP/REMNT LOW
 72H  09/0600Z 20.4N  58.9W   25 KT  30 MPH...POST-TROP/REMNT LOW
 96H  10/0600Z 23.5N  64.5W   25 KT  30 MPH...POST-TROP/REMNT LOW
120H  11/0600Z...DISSIPATED
</span></pre>
<ul><li class="nobullet">
<a href="/hurricane/atlantic/2012/FLORENCE/track.dat">
<img src="/hurricane/images/DETAILS.gif" border="0" alt="Details"/>Tracking information</a><br/></li></ul>
</td></tr>

<tr><td valign="top">
<a href="/hurricane/atlantic/2012/ERNESTO/track.gif">
  <img src="/hurricane/atlantic/2012/ERNESTO/track_s.gif" border="0" alt="Track"/></a><br/>
<a href="/hurricane/atlantic/2012/ERNESTO/sat_ir.gif">
  <img src="/hurricane/atlantic/2012/ERNESTO/sat_ir_s.gif" border="0" alt="Sat IR"/></a><br/>
  <b>Current: <a href="/hurricane/atlantic/2012/ERNESTO/track.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Track"/>Track</a> 
  <a href="/hurricane/atlantic/2012/ERNESTO/sat_ir.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Sat IR"/>IR</a>
  <a href="/hurricane/atlantic/2012/ERNESTO/sat_vis.gif">
     <img src="/hurricane/images/GIF.gif" border="0" alt="Sat Vis"/>Vis</a>
</b><br/>
</td><td>
<ul><li><b>Hurricane-1 ERNESTO</b> (01-10 AUG)<br/>
Storm - Max Winds: 75 Min Pres: 980 Category: 1<br/>
Current - Max Winds: 30 Min Pres: 1004 Category: TD<br/>
</li></ul>
<pre><span style="font-size:x-small;">
TROPICAL DEPRESSION ERNESTO FORECAST/ADVISORY NUMBER  36
NWS NATIONAL HURRICANE CENTER MIAMI FL       AL052012
0900 UTC FRI AUG 10 2012
 
THERE ARE NO COASTAL WATCHES OR WARNINGS IN EFFECT.
 
TROPICAL DEPRESSION CENTER LOCATED NEAR 18.0N  97.8W AT 10/0900Z
POSITION ACCURATE WITHIN  35 NM
 
PRESENT MOVEMENT TOWARD THE WEST OR 265 DEGREES AT  11 KT
 
ESTIMATED MINIMUM CENTRAL PRESSURE 1004 MB
MAX SUSTAINED WINDS  30 KT WITH GUSTS TO  40 KT.
12 FT SEAS.. 90NE   0SE   0SW   0NW.
WINDS AND SEAS VARY GREATLY IN EACH QUADRANT.  RADII IN NAUTICAL
MILES ARE THE LARGEST RADII EXPECTED ANYWHERE IN THAT QUADRANT.

FORECAST POSITIONS AND MAX WINDS
 
INIT  10/0900Z 18.0N  97.8W   30 KT  35 MPH...INLAND
 12H  10/1800Z 17.9N  99.4W   25 KT  30 MPH...INLAND REMNANT LOW
 24H  11/0600Z...DISSIPATED
</span></pre>
<ul><li class="nobullet">
<a href="/hurricane/atlantic/2012/ERNESTO/track.dat">
<img src="/hurricane/images/DETAILS.gif" border="0" alt="Details"/>Tracking information</a><br/></li></ul>
</td></tr>

<tr><td valign="top">
<a href="/hurricane/atlantic/2012/DEBBY/track.gif">
  <img src="/hurricane/atlantic/2012/DEBBY/track_s.gif" border="0" alt="Track"/></a><br/>
<a href="/hurricane/atlantic/2012/DEBBY/sat_ir.gif">
  <img src="/hurricane/atlantic/2012/DEBBY/sat_ir_s.gif" border="0" alt="Sat IR"/></a><br/>
  <b>Current: <a href="/hurricane/atlantic/2012/DEBBY/track.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Track"/>Track</a> 
  <a href="/hurricane/atlantic/2012/DEBBY/sat_ir.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Sat IR"/>IR</a>
  <a href="/hurricane/atlantic/2012/DEBBY/sat_vis.gif">
     <img src="/hurricane/images/GIF.gif" border="0" alt="Sat Vis"/>Vis</a>
</b><br/>
</td><td>
<ul><li><b>Tropical Storm DEBBY</b> (23-27 JUN)<br/>
Storm - Max Winds: 50 Min Pres: 990 Category: TS<br/>
Current - Max Winds: 30 Min Pres: 1001 Category: TD<br/>
</li></ul>
<pre><span style="font-size:x-small;">
TROPICAL DEPRESSION DEBBY FORECAST/ADVISORY NUMBER  17
NWS NATIONAL HURRICANE CENTER MIAMI FL       AL042012
1500 UTC WED JUN 27 2012
 
THERE ARE NO COASTAL WATCHES OR WARNINGS IN EFFECT.
 
TROPICAL DEPRESSION CENTER LOCATED NEAR 29.7N  79.8W AT 27/1500Z
POSITION ACCURATE WITHIN  20 NM
 
PRESENT MOVEMENT TOWARD THE EAST OR  85 DEGREES AT   9 KT
 
ESTIMATED MINIMUM CENTRAL PRESSURE 1001 MB
MAX SUSTAINED WINDS  30 KT WITH GUSTS TO  40 KT.
WINDS AND SEAS VARY GREATLY IN EACH QUADRANT.  RADII IN NAUTICAL
MILES ARE THE LARGEST RADII EXPECTED ANYWHERE IN THAT QUADRANT.

FORECAST POSITIONS AND MAX WINDS
 
INIT  27/1500Z 29.7N  79.8W   30 KT  35 MPH
 12H  28/0000Z 30.1N  77.5W   30 KT  35 MPH
 24H  28/1200Z 30.5N  74.8W   30 KT  35 MPH
 36H  29/0000Z 31.3N  71.8W   30 KT  35 MPH
 48H  29/1200Z 32.3N  69.5W   30 KT  35 MPH
 72H  30/1200Z 35.5N  65.3W   30 KT  35 MPH
 96H  01/1200Z 40.0N  60.0W   35 KT  40 MPH
120H  02/1200Z 46.0N  48.0W   35 KT  40 MPH
</span></pre>
<ul><li class="nobullet">
<a href="/hurricane/atlantic/2012/DEBBY/track.dat">
<img src="/hurricane/images/DETAILS.gif" border="0" alt="Details"/>Tracking information</a><br/></li></ul>
</td></tr>

<tr><td valign="top">
<a href="/hurricane/atlantic/2012/CHRIS/track.gif">
  <img src="/hurricane/atlantic/2012/CHRIS/track_s.gif" border="0" alt="Track"/></a><br/>
<a href="/hurricane/atlantic/2012/CHRIS/sat_ir.gif">
  <img src="/hurricane/atlantic/2012/CHRIS/sat_ir_s.gif" border="0" alt="Sat IR"/></a><br/>
  <b>Current: <a href="/hurricane/atlantic/2012/CHRIS/track.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Track"/>Track</a> 
  <a href="/hurricane/atlantic/2012/CHRIS/sat_ir.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Sat IR"/>IR</a>
  <a href="/hurricane/atlantic/2012/CHRIS/sat_vis.gif">
     <img src="/hurricane/images/GIF.gif" border="0" alt="Sat Vis"/>Vis</a>
</b><br/>
</td><td>
<ul><li><b>Hurricane-1 CHRIS</b> (19-22 JUN)<br/>
Storm - Max Winds: 65 Min Pres: 987 Category: 1<br/>
Current - Max Winds: 45 Min Pres: 989 Category: TS<br/>
</li></ul>
<pre><span style="font-size:x-small;">
TROPICAL STORM CHRIS FORECAST/ADVISORY NUMBER  11
NWS NATIONAL HURRICANE CENTER MIAMI FL       AL032012
0900 UTC FRI JUN 22 2012
 
THERE ARE NO COASTAL WATCHES OR WARNINGS IN EFFECT.
 
TROPICAL STORM CENTER LOCATED NEAR 44.8N  44.5W AT 22/0900Z
POSITION ACCURATE WITHIN  30 NM
 
PRESENT MOVEMENT TOWARD THE NORTHWEST OR 315 DEGREES AT  12 KT
 
ESTIMATED MINIMUM CENTRAL PRESSURE  989 MB
MAX SUSTAINED WINDS  45 KT WITH GUSTS TO  55 KT.
34 KT.......150NE  90SE   0SW 150NW.
12 FT SEAS..160NE 300SE 100SW  60NW.
WINDS AND SEAS VARY GREATLY IN EACH QUADRANT.  RADII IN NAUTICAL
MILES ARE THE LARGEST RADII EXPECTED ANYWHERE IN THAT QUADRANT.

FORECAST POSITIONS AND MAX WINDS
 
INIT  22/0900Z 44.8N  44.5W   45 KT  50 MPH
 12H  22/1800Z 44.3N  45.7W   40 KT  45 MPH...POST-TROPICAL
 24H  23/0600Z 43.2N  45.5W   35 KT  40 MPH...POST-TROP/EXTRATROP
 36H  23/1800Z...DISSIPATED
</span></pre>
<ul><li class="nobullet">
<a href="/hurricane/atlantic/2012/CHRIS/track.dat">
<img src="/hurricane/images/DETAILS.gif" border="0" alt="Details"/>Tracking information</a><br/></li></ul>
</td></tr>

<tr><td valign="top">
<a href="/hurricane/atlantic/2012/BERYL/track.gif">
  <img src="/hurricane/atlantic/2012/BERYL/track_s.gif" border="0" alt="Track"/></a><br/>
<a href="/hurricane/atlantic/2012/BERYL/sat_ir.gif">
  <img src="/hurricane/atlantic/2012/BERYL/sat_ir_s.gif" border="0" alt="Sat IR"/></a><br/>
  <b>Current: <a href="/hurricane/atlantic/2012/BERYL/track.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Track"/>Track</a> 
  <a href="/hurricane/atlantic/2012/BERYL/sat_ir.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Sat IR"/>IR</a>
  <a href="/hurricane/atlantic/2012/BERYL/sat_vis.gif">
     <img src="/hurricane/images/GIF.gif" border="0" alt="Sat Vis"/>Vis</a>
</b><br/>
</td><td>
<ul><li><b>Tropical Storm BERYL</b> (26-30 MAY)<br/>
Storm - Max Winds: 60 Min Pres: 992 Category: TS<br/>
Current - Max Winds: 30 Min Pres: 1000 Category: TD<br/>
</li></ul>
<pre><span style="font-size:x-small;">
TROPICAL DEPRESSION BERYL FORECAST/ADVISORY NUMBER  19
NWS NATIONAL HURRICANE CENTER MIAMI FL       AL022012
1500 UTC WED MAY 30 2012
 
THERE ARE NO COASTAL WATCHES OR WARNINGS IN EFFECT.
 
TROPICAL DEPRESSION CENTER LOCATED NEAR 34.2N  78.0W AT 30/1500Z
POSITION ACCURATE WITHIN  20 NM
 
PRESENT MOVEMENT TOWARD THE NORTHEAST OR  55 DEGREES AT  17 KT
 
ESTIMATED MINIMUM CENTRAL PRESSURE 1000 MB
MAX SUSTAINED WINDS  30 KT WITH GUSTS TO  40 KT.
12 FT SEAS..  0NE  60SE   0SW   0NW.
WINDS AND SEAS VARY GREATLY IN EACH QUADRANT.  RADII IN NAUTICAL
MILES ARE THE LARGEST RADII EXPECTED ANYWHERE IN THAT QUADRANT.

FORECAST POSITIONS AND MAX WINDS
 
INIT  30/1500Z 34.2N  78.0W   30 KT  35 MPH
 12H  31/0000Z 35.5N  75.5W   35 KT  40 MPH...POST-TROPICAL
 24H  31/1200Z 37.0N  71.0W   35 KT  40 MPH...POST-TROPICAL
 36H  01/0000Z 38.5N  66.0W   40 KT  45 MPH...POST-TROP/EXTRATROP
 48H  01/1200Z 39.0N  60.0W   40 KT  45 MPH...POST-TROP/EXTRATROP
 72H  02/1200Z 38.0N  49.0W   45 KT  50 MPH...POST-TROP/EXTRATROP
 96H  03/1200Z...DISSIPATED
</span></pre>
<ul><li class="nobullet">
<a href="/hurricane/atlantic/2012/BERYL/track.dat">
<img src="/hurricane/images/DETAILS.gif" border="0" alt="Details"/>Tracking information</a><br/></li></ul>
</td></tr>

<tr><td valign="top">
<a href="/hurricane/atlantic/2012/ALBERTO/track.gif">
  <img src="/hurricane/atlantic/2012/ALBERTO/track_s.gif" border="0" alt="Track"/></a><br/>
<a href="/hurricane/atlantic/2012/ALBERTO/sat_ir.gif">
  <img src="/hurricane/atlantic/2012/ALBERTO/sat_ir_s.gif" border="0" alt="Sat IR"/></a><br/>
  <b>Current: <a href="/hurricane/atlantic/2012/ALBERTO/track.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Track"/>Track</a> 
  <a href="/hurricane/atlantic/2012/ALBERTO/sat_ir.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Sat IR"/>IR</a>
  <a href="/hurricane/atlantic/2012/ALBERTO/sat_vis.gif">
     <img src="/hurricane/images/GIF.gif" border="0" alt="Sat Vis"/>Vis</a>
</b><br/>
</td><td>
<ul><li><b>Tropical Storm ALBERTO</b> (19-22 MAY)<br/>
Storm - Max Winds: 45 Min Pres: 998 Category: TS<br/>
Current - Max Winds: 30 Min Pres: 1008 Category: TD<br/>
</li></ul>
<pre><span style="font-size:x-small;">
TROPICAL DEPRESSION ALBERTO FORECAST/ADVISORY NUMBER  11
NWS NATIONAL HURRICANE CENTER MIAMI FL       AL012012
0900 UTC TUE MAY 22 2012
 
THERE ARE NO COASTAL WATCHES OR WARNINGS IN EFFECT.
 
TROPICAL DEPRESSION CENTER LOCATED NEAR 32.0N  75.5W AT 22/0900Z
POSITION ACCURATE WITHIN  20 NM
 
PRESENT MOVEMENT TOWARD THE NORTHEAST OR  45 DEGREES AT  13 KT
 
ESTIMATED MINIMUM CENTRAL PRESSURE 1008 MB
MAX SUSTAINED WINDS  30 KT WITH GUSTS TO  40 KT.
WINDS AND SEAS VARY GREATLY IN EACH QUADRANT.  RADII IN NAUTICAL
MILES ARE THE LARGEST RADII EXPECTED ANYWHERE IN THAT QUADRANT.

FORECAST POSITIONS AND MAX WINDS
 
INIT  22/0900Z 32.0N  75.5W   30 KT  35 MPH
 12H  22/1800Z 33.4N  73.8W   30 KT  35 MPH
 24H  23/0600Z 35.5N  71.1W   30 KT  35 MPH...POST-TROP/REMNT LOW
 36H  23/1800Z 37.5N  68.0W   25 KT  30 MPH...POST-TROP/REMNT LOW
 48H  24/0600Z...DISSIPATED
</span></pre>
<ul><li class="nobullet">
<a href="/hurricane/atlantic/2012/ALBERTO/track.dat">
<img src="/hurricane/images/DETAILS.gif" border="0" alt="Details"/>Tracking information</a><br/></li></ul>
</td></tr>

</table>
<div class="clearboth">&nbsp;</div>

</div>

<div id="footer"> <span id="copyright"><small>Copyright &copy; Unisys 2012</small></span>
  <ul class="inline-navigation-list" id="bottom-navigation">
    <li><a href="http://www.unisys.com/unisys/privacy.html" target="_blank">Privacy Notice</a></li>
    <li><a href="http://www.unisys.com/unisys/terms-and-conditions.html" target="_blank">Terms of Use</a></li>
    <li><a href="/contactus.php">Contact Us</a></li>
    <li><a href="http://www.unisys.com/unisys/trademarks.html" target="_blank">Trademarks</a></li>
  </ul>
</div>
</div>
</body>
</html>
