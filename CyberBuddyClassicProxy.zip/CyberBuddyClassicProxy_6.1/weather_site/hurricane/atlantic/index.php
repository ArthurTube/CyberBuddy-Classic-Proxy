<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Unisys Weather  - Atlantic Tropical Storm Tracking by Year</title>
<meta name="description" content="The intent of this weather site is to provide a complete source of graphical weather 		information. This is intended to satisfy the needs of the weather professional, but can be a tool for the casual user as well. The graphics and data are displayed as a meteorologist would expect to see. For the novice user, there are detailed explanation pages to guide them through the various plots, charts and images. The data on this site are provided from the National Weather Service via the NOAAPORT satellite data service. All the images are generated using the Weather Processor (WXP) analysis package which is available from Unisys. "/>
<meta name="keywords" content="weather, unisys, unisys weather, weather maps, maps, nam, wrf, GFS, GFSx, hurricane, radar, satellite, surface, upper air" />
<meta name="copyright" content="Unisys Corp - 2011" />
<meta name="author" content="Unisys Corporation" />
<meta name="email" content="technical-support@weather.unisys.com" />
<meta name="Distribution" content="Global" />
<meta name="Rating" content="General" />
<meta name="Robots" content="INDEX,FOLLOW" />
<meta name="Revisit-after" content="7 Days" />
<meta http-equiv="Content-type" content="text/html;charset=UTF-8" />
<meta http-equiv="imagetoolbar" content="no" />
<meta http-equiv="Refresh" content="900" />
<meta http-equiv="X-UA-Compatible" content="IE=8"/>
<link rel="stylesheet" type="text/css" href="/css/WMAX.css" />
</head>
<body>
<div id="wrap">
  <div id="top-menu">
    <ul id="top-navigation" class="inline-navigation-list">
      <li><a href="http://www.unisys.com" title="Unisys Home Page">Unisys.com</a></li>
      <li><a href="/index.php" title="Unisys Weather">Weather Home</a></li>
      <li><a href="/analyses.php" title="Analyses">Analyses</a></li>
      <li><a href="/forehome.php" title="Forecast">Forecasts</a></li>
      <li><a href="/archives.php" title="Archives">Archives</a></li>
      <li><a href="/links.php" title="NOAA Links">NOAA Links</a></li>
      <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
    </ul>
  </div>

  <div id="header"> <a href="http://unisys.com"><img src="/images/Unisys_logo.gif" alt="Unisys" /></a>
    <h1>Unisys Weather</h1>
  </div>

<div id="leftside">
  <ul class="avmenu">
    <li><a href="/index.php" class="purple">Unisys Weather</a></li>
    <li><a href="/index.php"> Weather Home</a></li>
    <li><a href="/solutions/index.php">Weather Solutions</a></li>
    <li><a href="/mobile/index.php"><img id="mobile_icon" src="/mobile/Icon.png" width="24" height="24" alt="Download Unisys Weather Mobile App"/>iPhone App</a></li>
    <li><a href="/info/index.php">Information</a></li>
    <li><a href="/content.php">Contents</a></li>
    <li><a href="/analyses.php" class="purple">Analyses</a></li>
    <li><a href="/satellite/index.php">Satellite Images</a></li>
    <li><a href="/surface/index.php">Surface Data</a></li>
    <li><a href="/upper_air/index.php">Upper Air Data</a></li>
    <li><a href="/radar/index.php">Radar Data</a></li>
    <li><a href="/forehome.php" class="purple">Forecasts</a></li>
    <li><a href="/mos/index.php">Model Statistics</a></li>
    <li><a href="/nam/index.php">NAM/Wrf Model</a></li>
    <li><a href="/gfs/index.php?r=us">GFS/Avn Model</a></li>
    <li><a href="/gfsx/index.php?r=us">GFSx/MRF Model</a></li>
    <li><a href="/rap/index.php">RAP Model</a></li>
    <li><a href="/ecmwf/index.php">ECMWF Model</a></li>
    <li><a href="/archives.php" class="purple">Archive</a></li>
    <li><a href="/hurricane/index.php">Hurricane Data</a></li>
    <li><a href="/archive/index.php">Archive of Images</a></li>
    <li><a href="/usgs/index.php">USGS Maps</a></li>
  </ul>
</div>

<div id="extras">
  <ul class="avmenu">
    <li><a href="/foresetup.php" class="purple">Get a Forecast</a></li>
  </ul>

<script type="text/javascript">
function fsubmit()
{
     document.getElementById("Forecast").submit();
}
</script>

  <form method="get" id="Forecast" action="/forecast.php">
    <p class="center"> Enter a zip code or city name to get forecast:
      <input type="text" name="Name" id="Name" size="15" />
      <br />
      <button type="submit" style="border:none; background-color:transparent;">
         <img src="/images/GO.png" id="Go" alt="Get Forecast Data" style="height:30px;" />
      </button>
      <a href="/foresetup.php"><img src="/images/setup.png" alt="Setup Location" height="30" width="70" /></a> </p>
  </form>
  <script type="text/javascript">
                <!-- HIDE
                var index = document.cookie.indexOf("ZIP")
                var zipcode = 0
                var region = ""
                if( index != -1 ){
                   //zipcode = parseInt( document.cookie.substring(index+4,index+9),10)
                   zipcode = document.cookie.substring(index+4,index+9)
                   var validateZipCode = function() {
                     var zipcodeRegexp = /^\d{5}$/;
                     var zipTest = zipcodeRegexp.test(zipcode);
   
                     if (zipTest == false) {
                       return false;
                     }
                   }
                   validateZipCode();

                    if( ! isNaN(zipcode))

                    document.getElementById('Name').value = zipcode

                   if( zipcode >= 01000 && zipcode <= 19699 )
                      region = "ne"
                   else if( zipcode >= 19700 && zipcode <= 28999 )
                      region = "at"
                   else if( zipcode >= 43000 && zipcode <= 45999 )
                      region = "at"
                   else if( zipcode >= 29000 && zipcode <= 36999 )
                      region = "se"
                   else if( zipcode >= 38600 && zipcode <= 39999 )
                      region = "se"
                   else if( zipcode >= 46000 && zipcode <= 58999 )
                      region = "mw"
                   else if( zipcode >= 60000 && zipcode <= 62999 )
                      region = "mw"
                   else if( zipcode >= 68000 && zipcode <= 69999 )
                      region = "mw"
                   else if( zipcode >= 63000 && zipcode <= 67999 )
                      region = "cp"
                   else if( zipcode >= 71600 && zipcode <= 74999 )
                      region = "cp"
                   else if( zipcode >= 70000 && zipcode <= 71499 )
                      region = "sp"
                   else if( zipcode >= 75000 && zipcode <= 79999 )
                      region = "sp"
                   else if( zipcode >= 59000 && zipcode <= 59999 )
                      region = "nw"
                   else if( zipcode >= 82000 && zipcode <= 83999 )
                      region = "nw"
                   else if( zipcode >= 97000 && zipcode <= 99499 )
                      region = "nw"
                   else if( zipcode >= 80000 && zipcode <= 81999 )
                      region = "sw"
                   else if( zipcode >= 84000 && zipcode <= 96199 )
                      region = "sw"

                   if( region != "" ){
                      document.write( "<table border=\"0\" align=\"center\" class=\"grey\" width=\"100%\">" )
                      document.write( "<tr>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/surface/sfc_map.php?image=sfc&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Sfc" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=\"radar/rad" + region + ".php\">" )
                      document.write( "<a href=/radar/rcm_rad.php?image=rad&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Rad" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=vis&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Vis" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=enh&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>IR" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "</tr></table>" )
                      document.write( "</b>" )
                      }


                   
                   }
                // UNHIDE -->
                </script>
  <ul class="avmenu">
    <li><a href="/links.php" class="purple">NOAA Links</a></li>
    <li><a href="http://lwf.ncdc.noaa.gov/">National Climatic Data Center</a></li>
    <li><a href="http://www.cpc.noaa.gov/">Climate Prediction Center</a></li>
    <li><a href="http://oceanservice.noaa.gov/">National Ocean Service</a></li>
    <li><a href="http://www.lib.noaa.gov/">NOAA Library</a></li>
    <li><a href="http://www.oar.noaa.gov/">NOAA Office of Oceanic and Atmospheric Research</a></li>
    <li><a href="http://www.esrl.noaa.gov/">Earth Systems Research Laboratory</a></li>
    <li><a href="/overview.php" class="purple">About Us</a></li>
    <li><a href="/overview.php" title="Contact Us">Overview</a></li>
    <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
  </ul>
</div>
<div id="content">
<table cellpadding="0" cellspacing="0" border="0" style="text-align: left; width: 640px;">
  <tr>
    <td style="vertical-align: top;">
      <big style="font-weight: bold;"><span style="font-family: helvetica,arial,sans-serif;"><big>Atlantic Tropical Storm Tracking by Year</big><br/></span></big><br/><span style="font-family: helvetica,arial,sans-serif;"><span style="font-weight: bold;">from Tropical Prediction Center Best Track Reanalysis</span><br/></span><br/>
      <small><span style="font-family: helvetica,arial,sans-serif;">This is a list of Atlantic hurricanes since 1851. Provided are charts on the track of the storm plus a text based table of tracking information. The table includes position in latitude and longitude, maximum sustained winds in knots, and central pressure in millibars.&nbsp; </span><b>NOTE:</b></small><span style="font-family: helvetica,arial,sans-serif;"><small> Data courtesy of Tropical Prediction Center (see note below).<br/>
      <b>Updated:</b> May 23, 2012<br/></small><br/></span>
    
      <table border="0" cellpadding="0">
        <tr>
          <td style="font-family: helvetica,arial,sans-serif;" bgcolor="#a0e0ff">
            <br/>
          </td>
          <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;">
            <strong><a href="/hurricane/atlantic/1851/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1851</a></strong>
          </td>
          <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;">
            <strong><a href="/hurricane/atlantic/1852/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1852</a></strong>
          </td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1853/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1853</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1854/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1854</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1855/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1855</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1856/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1856</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1857/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1857</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1858/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1858</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1859/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1859</a></strong></td>
      </tr>
      <tr>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1860/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1860</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1861/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1861</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1862/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1862</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1863/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1863</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1864/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1864</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1865/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1865</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1866/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1866</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1867/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1867</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1868/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1868</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1869/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1869</a></strong></td>
      </tr>
      <tr>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1870/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1870</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1871/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1871</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1872/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1872</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1873/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1873</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1874/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1874</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1875/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1875</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1876/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1876</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1877/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1877</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1878/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1878</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1879/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1879</a></strong></td>
      </tr>
      <tr>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1880/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1880</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1881/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1881</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1882/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1882</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1883/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1883</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1884/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1884</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1885/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1885</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1886/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1886</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1887/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1887</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1888/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1888</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1889/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1889</a></strong></td>
      </tr>
      <tr>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1890/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1890</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1891/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1891</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1892/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1892</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1893/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1893</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1894/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1894</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1895/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1895</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1896/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1896</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1897/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1897</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1898/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1898</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1899/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1899</a></strong></td>
      </tr>
      <tr>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1900/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1900</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1901/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1901</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1902/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1902</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1903/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1903</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1904/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1904</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1905/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1905</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1906/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1906</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1907/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1907</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1908/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1908</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1909/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1909</a></strong></td>
      </tr>
      <tr>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1910/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1910</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1911/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1911</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1912/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1912</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1913/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1913</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1914/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1914</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1915/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1915</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1916/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1916</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1917/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1917</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1918/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1918</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1919/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1919</a></strong></td>
      </tr>
      <tr>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1920/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1920</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1921/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1921</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1922/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1922</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1923/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1923</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1924/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1924</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1925/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1925</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1926/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1926</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1927/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1927</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1928/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1928</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1929/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1929</a></strong></td>
      </tr>
      <tr>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1930/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1930</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1931/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1931</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1932/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1932</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1933/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1933</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1934/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1934</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1935/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1935</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1936/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1936</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1937/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1937</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1938/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1938</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1939/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1939</a></strong></td>
      </tr>
      <tr>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1940/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1940</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1941/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1941</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1942/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1942</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1943/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1943</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1944/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1944</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1945/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1945</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1946/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1946</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1947/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1947</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1948/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1948</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1949/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1949</a></strong></td>
      </tr>
      <tr>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1950/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1950</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1951/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1951</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1952/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1952</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1953/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1953</a> </strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1954/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1954</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1955/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1955</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1956/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1956</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1957/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1957</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1958/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1958</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1959/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1959</a></strong></td>
      </tr>
      <tr>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1960/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1960</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1961/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1961</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1962/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1962</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1963/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1963</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1964/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1964</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1965/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1965</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1966/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1966</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1967/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1967</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1968/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1968</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1969/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1969</a></strong></td>
      </tr>
      <tr>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1970/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1970</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1971/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1971</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1972/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1972</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1973/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1973</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1974/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1974</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1975/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1975</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1976/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1976</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1977/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1977</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1978/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1978</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1979/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1979</a></strong></td>
      </tr>
      <tr>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1980/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1980</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1981/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1981</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1982/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1982</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1983/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1983</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1984/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1984</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1985/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1985</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1986/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1986</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1987/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1987</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1988/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1988</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1989/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1989</a></strong></td>
      </tr>
      <tr>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1990/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1990</a> </strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1991/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1991</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1992/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1992</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1993/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1993</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1994/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1994</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1995/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1995</a></strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1996/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1996</a> </strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1997/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1997</a> </strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1998/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1998</a> </strong></td>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/1999/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1999</a> </strong></td>
      </tr>
      <tr>
        <td bgcolor="#a0e0ff" style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/2000/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />2000</a></strong></td>
        <td style="font-family: helvetica,arial,sans-serif;" bgcolor="#a0e0ff"><strong><a href="/hurricane/atlantic/2001/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />2001</a></strong></td>
        <td style="font-family: helvetica,arial,sans-serif;" bgcolor="#a0e0ff"><strong><a href="/hurricane/atlantic/2002/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />2002</a></strong></td>
        <td style="font-family: helvetica,arial,sans-serif;" bgcolor="#a0e0ff"><strong><a href="/hurricane/atlantic/2003/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />2003</a></strong></td>
        <td style="font-family: helvetica,arial,sans-serif;" bgcolor="#a0e0ff"><strong><a href="/hurricane/atlantic/2004/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />2004</a></strong></td>
        <td style="font-family: helvetica,arial,sans-serif;" bgcolor="#a0e0ff"><strong><a href="/hurricane/atlantic/2005/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />2005</a></strong></td>
        <td style="font-family: helvetica,arial,sans-serif;" bgcolor="#a0e0ff"><strong><a href="/hurricane/atlantic/2006/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />2006</a></strong></td>
        <td style="font-family: helvetica,arial,sans-serif;" bgcolor="#a0e0ff"><strong><a href="/hurricane/atlantic/2007/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />2007</a></strong></td>
        <td style="font-family: helvetica,arial,sans-serif;" bgcolor="#a0e0ff"><strong><a href="/hurricane/atlantic/2008/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />2008</a></strong></td>
        <td style="font-family: helvetica,arial,sans-serif;" bgcolor="#a0e0ff"><strong><a href="/hurricane/atlantic/2009/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />2009</a></strong></td>
      </tr>
      <tr>
        <td style="font-family: helvetica,arial,sans-serif;" bgcolor="#a0e0ff"><strong><a href="/hurricane/atlantic/2010/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />2010</a></strong></td>
        <td style="font-family: helvetica,arial,sans-serif;" bgcolor="#a0e0ff"><strong><a href="/hurricane/atlantic/2011/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />2011</a></strong></td>
        <td style="font-family: helvetica,arial,sans-serif;" bgcolor="#a0e0ff"><br/></td>
        <td style="font-family: helvetica,arial,sans-serif;" bgcolor="#a0e0ff"><br/></td>
        <td style="font-family: helvetica,arial,sans-serif;" bgcolor="#a0e0ff"><br/></td>
        <td style="font-family: helvetica,arial,sans-serif;" bgcolor="#a0e0ff"><br/></td>
        <td style="font-family: helvetica,arial,sans-serif;" bgcolor="#a0e0ff"><br/></td>
        <td style="font-family: helvetica,arial,sans-serif;" bgcolor="#a0e0ff"><br/></td>
        <td style="font-family: helvetica,arial,sans-serif;" bgcolor="#a0e0ff"><br/></td>
        <td style="font-family: helvetica,arial,sans-serif;" bgcolor="#a0e0ff"><br/></td>
      </tr>
    </table>

    <big style="font-weight: bold;"><span style="font-family: helvetica,arial,sans-serif;"><br/>Saffir-Simpson Scale</span></big>
    <p style="font-family: helvetica,arial,sans-serif;">The chart color codes intensity (category based on Saffir-Simpson scale): </p>

    <table border="0" style="font-family: helvetica,arial,sans-serif;">
      <tr>
        <td valign="top" bgcolor="#000099"  style="color: rgb(255, 255, 255); font-weight: bold;"><small>Type</small></td>
        <td align="center" valign="top" bgcolor="#000099" style="color: rgb(255, 255, 255); font-weight: bold;"><small>Category</small></td>
        <td align="center" valign="top" bgcolor="#000099" style="color: rgb(255, 255, 255); font-weight: bold;"><small>Pressure(mb)</small></td>
        <td align="center" valign="top" bgcolor="#000099" style="color: rgb(255, 255, 255); font-weight: bold;"><small>Winds<br/>(knots)</small></td>
        <td align="center" valign="top" bgcolor="#000099" style="color: rgb(255, 255, 255); font-weight: bold;"><small>Winds<br/>(mph)</small></td>
        <td align="center" valign="top" bgcolor="#000099" style="color: rgb(255, 255, 255); font-weight: bold;"><small>Line Color</small></td>
      </tr>
      <tr>
        <td valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>Depression</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>TD</small></td>
        <td style="text-align: center; vertical-align: top; background-color: rgb(160, 224, 255); font-weight: bold;"><small>-----</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>&lt; 34</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>&lt; 39</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>Green</small></td>
      </tr>
      <tr>
        <td valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>Tropical Storm</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>TS</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>-----</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>34-63</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>39-73</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>Yellow</small></td>
      </tr>
      <tr>
        <td valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>Hurricane</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>1</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>&gt; 980</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>64-82</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>74-95</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>Red</small></td>
      </tr>
      <tr>
        <td valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>Hurricane</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>2</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>965-980</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>83-95</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>96-110</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>Light Red</small></td>
      </tr>
      <tr>
        <td valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>Hurricane</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>3</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>945-965</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>96-112</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>111-130</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>Magenta</small></td>
      </tr>
      <tr>
        <td valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>Hurricane</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>4</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>920-945</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>113-135</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>131-155</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>Light Magenta</small></td>
      </tr>
      <tr>
        <td valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>Hurricane</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>5</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>&lt; 920</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>&gt;135</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>&gt;155</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>White</small></td>
      </tr>
    </table>

    <p style="font-family: helvetica,arial,sans-serif;"><small><b>NOTE:</b> Pressures are in millibars and winds are in <b>knots</b> where one knot is equal to 1.15 mph</small></p>
    <p class="reg" style="font-family: helvetica,arial,sans-serif;"><small><b>NOTE:</b>The Atlantic Tracks File is an ASCII (text) file containing the 6-hourly (0000, 0600, 1200, 1800 UTC) center locations (latitude and longitude in tenths of degrees) and intensities (maximum 1-minute surface wind speeds in knots and minimum central pressures in millibars) for all Tropical Storms and Hurricanes from 1851 through 2002. More information on this file is found in NOAA Technical Memorandum NWS NHC 22 "A Tropical Cyclone Data Tape for the North Atlantic Basin, 1886-1983: Contents, Limitations, and Uses" by Brian R. Jarvinen, Charles J. Neumann, and Mary A. S. Davis.</small></p>
    <p class="reg" style="font-family: helvetica,arial,sans-serif;"><small> For detailed information regarding the re-analysis of the Atlantic hurricane database see <a  href="http://www.aoml.noaa.gov/hrd/data_sub/re_anal.html">here</a>.</small></p>

      <span style="font-family: helvetica,arial,sans-serif; font-weight: bold;">Hurricane Database Raw Data</span>
      <p style="font-family: helvetica,arial,sans-serif;"><strong><a href="/hurricane/atlantic/tracks.atl"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />Download Hurricane Database</a><br/><a href="/hurricane/atlantic/tracks_atl_readme.txt"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />Hurricane Database README</a></strong></p>

      <p style="font-family: helvetica,arial,sans-serif;"><b>Hurricane Database reformatted by decade</b><br/>
      <strong><a href="/hurricane/atlantic/1850.data"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1850</a> 
              <a href="/hurricane/atlantic/1860.data"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1860</a> 
              <a href="/hurricane/atlantic/1870.data"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1870</a> 
              <a href="/hurricane/atlantic/1880.data"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1880</a> 
              <a href="/hurricane/atlantic/1890.data"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1890</a><br/> 
              <a href="/hurricane/atlantic/1900.data"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1900</a> 
              <a href="/hurricane/atlantic/1910.data"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1910</a> 
              <a href="/hurricane/atlantic/1920.data"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1920</a> 
              <a href="/hurricane/atlantic/1930.data"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1930</a> 
              <a href="/hurricane/atlantic/1940.data"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1940</a><br/> 
              <a href="/hurricane/atlantic/1950.data"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1950</a> 
              <a href="/hurricane/atlantic/1960.data"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1960</a> 
              <a href="/hurricane/atlantic/1970.data"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1970</a> 
              <a href="/hurricane/atlantic/1980.data"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1980</a> 
              <a href="/hurricane/atlantic/1990.data"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1990</a><br/> 
              <a href="/hurricane/atlantic/2000.data"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />2000</a> 
              <a href="/hurricane/atlantic/2010.data"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />2010</a> 
              </strong></p>

      <hr/>
      </td>
    </tr>
  </table>

<div class="clearboth">&nbsp;</div>

</div>

<div id="footer"> <span id="copyright"><small>Copyright &copy; Unisys 2012</small></span>
  <ul class="inline-navigation-list" id="bottom-navigation">
    <li><a href="http://www.unisys.com/unisys/privacy.html" target="_blank">Privacy Notice</a></li>
    <li><a href="http://www.unisys.com/unisys/terms-and-conditions.html" target="_blank">Terms of Use</a></li>
    <li><a href="/contactus.php">Contact Us</a></li>
    <li><a href="http://www.unisys.com/unisys/trademarks.html" target="_blank">Trademarks</a></li>
  </ul>
</div>
</div>
</body>
</html>
