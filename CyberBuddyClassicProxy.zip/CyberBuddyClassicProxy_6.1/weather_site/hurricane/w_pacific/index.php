<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Unisys Weather  - West Pacific Tropical Storm Tracking by Year</title>
<meta name="description" content="The intent of this weather site is to provide a complete source of graphical weather 		information. This is intended to satisfy the needs of the weather professional, but can be a tool for the casual user as well. The graphics and data are displayed as a meteorologist would expect to see. For the novice user, there are detailed explanation pages to guide them through the various plots, charts and images. The data on this site are provided from the National Weather Service via the NOAAPORT satellite data service. All the images are generated using the Weather Processor (WXP) analysis package which is available from Unisys. "/>
<meta name="keywords" content="weather, unisys, unisys weather, weather maps, maps, nam, wrf, GFS, GFSx, hurricane, radar, satellite, surface, upper air" />
<meta name="copyright" content="Unisys Corp - 2011" />
<meta name="author" content="Unisys Corporation" />
<meta name="email" content="technical-support@weather.unisys.com" />
<meta name="Distribution" content="Global" />
<meta name="Rating" content="General" />
<meta name="Robots" content="INDEX,FOLLOW" />
<meta name="Revisit-after" content="7 Days" />
<meta http-equiv="Content-type" content="text/html;charset=UTF-8" />
<meta http-equiv="imagetoolbar" content="no" />
<meta http-equiv="Refresh" content="900" />
<meta http-equiv="X-UA-Compatible" content="IE=8"/>
<link rel="stylesheet" type="text/css" href="/css/WMAX.css" />
</head>
<body>
<div id="wrap">
  <div id="top-menu">
    <ul id="top-navigation" class="inline-navigation-list">
      <li><a href="http://www.unisys.com" title="Unisys Home Page">Unisys.com</a></li>
      <li><a href="/index.php" title="Unisys Weather">Weather Home</a></li>
      <li><a href="/analyses.php" title="Analyses">Analyses</a></li>
      <li><a href="/forehome.php" title="Forecast">Forecasts</a></li>
      <li><a href="/archives.php" title="Archives">Archives</a></li>
      <li><a href="/links.php" title="NOAA Links">NOAA Links</a></li>
      <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
    </ul>
  </div>

  <div id="header"> <a href="http://unisys.com"><img src="/images/Unisys_logo.gif" alt="Unisys" /></a>
    <h1>Unisys Weather</h1>
  </div>

<div id="leftside">
  <ul class="avmenu">
    <li><a href="/index.php" class="purple">Unisys Weather</a></li>
    <li><a href="/index.php"> Weather Home</a></li>
    <li><a href="/solutions/index.php">Weather Solutions</a></li>
    <li><a href="/mobile/index.php"><img id="mobile_icon" src="/mobile/Icon.png" width="24" height="24" alt="Download Unisys Weather Mobile App"/>iPhone App</a></li>
    <li><a href="/info/index.php">Information</a></li>
    <li><a href="/content.php">Contents</a></li>
    <li><a href="/analyses.php" class="purple">Analyses</a></li>
    <li><a href="/satellite/index.php">Satellite Images</a></li>
    <li><a href="/surface/index.php">Surface Data</a></li>
    <li><a href="/upper_air/index.php">Upper Air Data</a></li>
    <li><a href="/radar/index.php">Radar Data</a></li>
    <li><a href="/forehome.php" class="purple">Forecasts</a></li>
    <li><a href="/mos/index.php">Model Statistics</a></li>
    <li><a href="/nam/index.php">NAM/Wrf Model</a></li>
    <li><a href="/gfs/index.php?r=us">GFS/Avn Model</a></li>
    <li><a href="/gfsx/index.php?r=us">GFSx/MRF Model</a></li>
    <li><a href="/rap/index.php">RAP Model</a></li>
    <li><a href="/ecmwf/index.php">ECMWF Model</a></li>
    <li><a href="/archives.php" class="purple">Archive</a></li>
    <li><a href="/hurricane/index.php">Hurricane Data</a></li>
    <li><a href="/archive/index.php">Archive of Images</a></li>
    <li><a href="/usgs/index.php">USGS Maps</a></li>
  </ul>
</div>

<div id="extras">
  <ul class="avmenu">
    <li><a href="/foresetup.php" class="purple">Get a Forecast</a></li>
  </ul>

<script type="text/javascript">
function fsubmit()
{
     document.getElementById("Forecast").submit();
}
</script>

  <form method="get" id="Forecast" action="/forecast.php">
    <p class="center"> Enter a zip code or city name to get forecast:
      <input type="text" name="Name" id="Name" size="15" />
      <br />
      <button type="submit" style="border:none; background-color:transparent;">
         <img src="/images/GO.png" id="Go" alt="Get Forecast Data" style="height:30px;" />
      </button>
      <a href="/foresetup.php"><img src="/images/setup.png" alt="Setup Location" height="30" width="70" /></a> </p>
  </form>
  <script type="text/javascript">
                <!-- HIDE
                var index = document.cookie.indexOf("ZIP")
                var zipcode = 0
                var region = ""
                if( index != -1 ){
                   //zipcode = parseInt( document.cookie.substring(index+4,index+9),10)
                   zipcode = document.cookie.substring(index+4,index+9)
                   var validateZipCode = function() {
                     var zipcodeRegexp = /^\d{5}$/;
                     var zipTest = zipcodeRegexp.test(zipcode);
   
                     if (zipTest == false) {
                       return false;
                     }
                   }
                   validateZipCode();

                    if( ! isNaN(zipcode))

                    document.getElementById('Name').value = zipcode

                   if( zipcode >= 01000 && zipcode <= 19699 )
                      region = "ne"
                   else if( zipcode >= 19700 && zipcode <= 28999 )
                      region = "at"
                   else if( zipcode >= 43000 && zipcode <= 45999 )
                      region = "at"
                   else if( zipcode >= 29000 && zipcode <= 36999 )
                      region = "se"
                   else if( zipcode >= 38600 && zipcode <= 39999 )
                      region = "se"
                   else if( zipcode >= 46000 && zipcode <= 58999 )
                      region = "mw"
                   else if( zipcode >= 60000 && zipcode <= 62999 )
                      region = "mw"
                   else if( zipcode >= 68000 && zipcode <= 69999 )
                      region = "mw"
                   else if( zipcode >= 63000 && zipcode <= 67999 )
                      region = "cp"
                   else if( zipcode >= 71600 && zipcode <= 74999 )
                      region = "cp"
                   else if( zipcode >= 70000 && zipcode <= 71499 )
                      region = "sp"
                   else if( zipcode >= 75000 && zipcode <= 79999 )
                      region = "sp"
                   else if( zipcode >= 59000 && zipcode <= 59999 )
                      region = "nw"
                   else if( zipcode >= 82000 && zipcode <= 83999 )
                      region = "nw"
                   else if( zipcode >= 97000 && zipcode <= 99499 )
                      region = "nw"
                   else if( zipcode >= 80000 && zipcode <= 81999 )
                      region = "sw"
                   else if( zipcode >= 84000 && zipcode <= 96199 )
                      region = "sw"

                   if( region != "" ){
                      document.write( "<table border=\"0\" align=\"center\" class=\"grey\" width=\"100%\">" )
                      document.write( "<tr>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/surface/sfc_map.php?image=sfc&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Sfc" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=\"radar/rad" + region + ".php\">" )
                      document.write( "<a href=/radar/rcm_rad.php?image=rad&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Rad" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=vis&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Vis" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=enh&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>IR" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "</tr></table>" )
                      document.write( "</b>" )
                      }


                   
                   }
                // UNHIDE -->
                </script>
  <ul class="avmenu">
    <li><a href="/links.php" class="purple">NOAA Links</a></li>
    <li><a href="http://lwf.ncdc.noaa.gov/">National Climatic Data Center</a></li>
    <li><a href="http://www.cpc.noaa.gov/">Climate Prediction Center</a></li>
    <li><a href="http://oceanservice.noaa.gov/">National Ocean Service</a></li>
    <li><a href="http://www.lib.noaa.gov/">NOAA Library</a></li>
    <li><a href="http://www.oar.noaa.gov/">NOAA Office of Oceanic and Atmospheric Research</a></li>
    <li><a href="http://www.esrl.noaa.gov/">Earth Systems Research Laboratory</a></li>
    <li><a href="/overview.php" class="purple">About Us</a></li>
    <li><a href="/overview.php" title="Contact Us">Overview</a></li>
    <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
  </ul>
</div>
<div id="content">

<table width="640" border="0">
  <tr>
    <td>
    <big><big><span style="font-family: helvetica,arial,sans-serif; font-weight: bold;">Western Pacific Hurricane Tracking Data by Year<small><br/><small><br/>from Joint Typhoon Warning Center Best Track Data</small></small><br/></span></big></big>
    <p style="font-family: helvetica,arial,sans-serif;"><small>This is a list of Western Pacific hurricanes since 1945. Provided are charts on the track of the storm plus a text based table of tracking information. The table includes position in latitude and longitude, maximum sustained winds in knots, and central pressure in millibars. <b>NOTE:</b> Data courtesy of Joint Typhoon Warning Center.</small></p>
    
    <table border="0" cellpadding="0" style="font-family: helvetica,arial,sans-serif;"> 
      <tr>
        <td bgcolor="#a0e0ff"><br/></td>
        <td bgcolor="#a0e0ff"><br/></td>
        <td bgcolor="#a0e0ff"><br/></td>
        <td bgcolor="#a0e0ff"><br/></td>
        <td bgcolor="#a0e0ff"><br/></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/1945/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1945</a></strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/1946/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1946</a></strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/1947/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1947</a></strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/1948/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1948</a></strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/1949/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1949</a></strong></td>
      </tr>
      <tr>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/1950/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1950</a></strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/1951/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1951</a></strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/1952/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1952</a> </strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/1953/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1953</a></strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/1954/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1954</a> </strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/1955/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1955</a></strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/1956/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1956</a></strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/1957/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1957</a></strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/1958/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1958</a></strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/1959/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1959</a></strong></td>
      </tr>
      <tr>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/1960/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1960</a></strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/1961/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1961</a></strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/1962/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1962</a></strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/1963/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1963</a></strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/1964/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1964</a></strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/1965/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1965</a></strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/1966/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1966</a></strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/1967/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1967</a></strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/1968/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1968</a></strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/1969/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1969</a></strong></td>
      </tr>
      <tr>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/1970/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1970</a></strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/1971/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1971</a></strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/1972/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1972</a></strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/1973/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1973</a></strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/1974/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1974</a></strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/1975/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1975</a></strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/1976/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1976</a></strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/1977/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1977</a></strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/1978/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1978</a></strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/1979/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1979</a></strong></td>
      </tr>
      <tr>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/1980/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1980</a></strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/1981/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1981</a></strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/1982/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1982</a></strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/1983/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1983</a></strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/1984/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1984</a></strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/1985/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1985</a></strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/1986/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1986</a></strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/1987/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1987</a></strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/1988/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1988</a></strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/1989/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1989</a></strong></td>
      </tr>
      <tr>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/1990/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1990</a></strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/1991/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1991</a> </strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/1992/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1992</a> </strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/1993/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1993</a> </strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/1994/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1994</a> </strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/1995/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1995</a> </strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/1996/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1996</a></strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/1997/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1997</a></strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/1998/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1998</a></strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/1999/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1999</a></strong></td>
      </tr>
      <tr>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/2000/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />2000</a></strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/2001/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />2001</a></strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/2002/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />2002</a></strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/2003/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />2003</a></strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/2004/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />2004</a></strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/2005/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />2005</a></strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/2006/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />2006</a></strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/2007/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />2007</a></strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/2008/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />2008</a></strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/2009/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />2009</a></strong></td>
      </tr>
      <tr>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/2010/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />2010</a></strong></td>
        <td bgcolor="#a0e0ff"><strong><a href="/hurricane/w_pacific/2011/index.php"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />2011</a></strong></td>
        <td bgcolor="#a0e0ff"><br/></td>
        <td bgcolor="#a0e0ff"><br/></td>
        <td bgcolor="#a0e0ff"><br/></td>
        <td bgcolor="#a0e0ff"><br/></td>
        <td bgcolor="#a0e0ff"><br/></td>
        <td bgcolor="#a0e0ff"><br/></td>
        <td bgcolor="#a0e0ff"><br/></td>
        <td bgcolor="#a0e0ff"><br/></td>
      </tr>
    </table>
    <br/>
    <big style="font-weight: bold;"><span style="font-family: helvetica,arial,sans-serif;"> Saffir-Simpson Scale</span></big><p style="font-family: helvetica,arial,sans-serif;">The chart color codes intensity (category based on Saffir-Simpson scale): </p>

    <table border="0" style="font-family: helvetica,arial,sans-serif;">
      <tr>
        <td valign="top" bgcolor="#000099" style="color: rgb(255, 255, 255); font-weight: bold;"><small>Type</small></td>
        <td align="center" valign="top" bgcolor="#000099" style="color: rgb(255, 255, 255); font-weight: bold;"><small>Category</small></td>
        <td align="center" valign="top" bgcolor="#000099" style="color: rgb(255, 255, 255); font-weight: bold;"><small>Pressure (mb)</small></td>
        <td align="center" valign="top" bgcolor="#000099" style="color: rgb(255, 255, 255); font-weight: bold;"><small>Winds<br/>(knots)</small></td>
        <td align="center" valign="top" bgcolor="#000099" style="color: rgb(255, 255, 255); font-weight: bold;"><small>Winds<br/>(mph)</small></td>
        <td align="center" valign="top" bgcolor="#000099" style="color: rgb(255, 255, 255); font-weight: bold;"><small>Surge<br/>(ft)</small></td>
        <td align="center" valign="top" bgcolor="#000099" style="color: rgb(255, 255, 255); font-weight: bold;"><small>Line Color</small></td>
      </tr>
      <tr>
        <td valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>Depression</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>TD</small></td>
        <td style="text-align: center; vertical-align: top; background-color: rgb(160, 224, 255); font-weight: bold;"><small>-----</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>&lt; 34</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>&lt; 39</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>&nbsp;</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>Green</small></td>
      </tr>
      <tr>
        <td valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>Tropical Storm</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>TS</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>-----</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>34-63</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>39-73</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>&nbsp;</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>Yellow</small></td>
      </tr>
      <tr>
        <td valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>Typhoon</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>1</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>&gt; 980</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>64-82</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>74-95</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>4-5</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>Red</small></td>
      </tr>
      <tr>
        <td valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>Typhoon</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>2</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>965-980</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>83-95</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>96-110</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>6-8</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>Light Red</small></td>
      </tr>
      <tr>
        <td valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>Typhoon</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>3</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>945-965</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>96-112</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>111-130</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>9-12</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>Magenta</small></td>
      </tr>
      <tr>
        <td valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>Typhoon</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>4</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>920-945</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>113-135</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>131-155</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>13-18</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>Light Magenta</small></td>
      </tr>
      <tr>
        <td valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>Super Typhoon</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>5</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>&lt; 920</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>&gt;135</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>&gt;155</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>&gt;18</small></td>
        <td align="center" valign="top" bgcolor="#a0e0ff" style="font-weight: bold;"><small>White</small></td>
      </tr>
   </table>
   <p style="font-family: helvetica,arial,sans-serif;"><small><b>NOTE:</b> Pressures are in millibars and winds are in <b>knots</b> where one knot is equal to 1.15 mph</small></p>

    <h3>Hurricane Database Raw Data </h3>
    <p>The data is reformatted from its original format to conform with the TPC Best Track format.</p>
    <p><strong><a href="/hurricane/w_pacific/tracks.wpa"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />Download Hurricane Database</a></strong></p><br/>
    <p><b>Hurricane Database reformatted by decade</b><br/>
    <strong>
    <a href="/hurricane/w_pacific/1940.data"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1940</a>
    <a href="/hurricane/w_pacific/1950.data"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1950</a>
    <a href="/hurricane/w_pacific/1960.data"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1960</a>
    <a href="/hurricane/w_pacific/1970.data"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1970</a>
    <a href="/hurricane/w_pacific/1980.data"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1980</a>
    <a href="/hurricane/w_pacific/1990.data"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />1990</a>
    <a href="/hurricane/w_pacific/2000.data"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />2000</a>
    <a href="/hurricane/w_pacific/2010.data"><img src="/images/gforw.gif" width="13" height="13" border="0" alt="Arrow" />2010</a>
    </strong></p>
    <hr/>
 
   </td>
 </tr>
</table>

<div class="clearboth">&nbsp;</div>

</div>

<div id="footer"> <span id="copyright"><small>Copyright &copy; Unisys 2012</small></span>
  <ul class="inline-navigation-list" id="bottom-navigation">
    <li><a href="http://www.unisys.com/unisys/privacy.html" target="_blank">Privacy Notice</a></li>
    <li><a href="http://www.unisys.com/unisys/terms-and-conditions.html" target="_blank">Terms of Use</a></li>
    <li><a href="/contactus.php">Contact Us</a></li>
    <li><a href="http://www.unisys.com/unisys/trademarks.html" target="_blank">Trademarks</a></li>
  </ul>
</div>
</div>
</body>
</html>
