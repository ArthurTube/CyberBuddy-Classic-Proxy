<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Unisys Weather  - 2011 Hurricane/Tropical Data for Western Pacific </title>
<meta name="description" content="The intent of this weather site is to provide a complete source of graphical weather 		information. This is intended to satisfy the needs of the weather professional, but can be a tool for the casual user as well. The graphics and data are displayed as a meteorologist would expect to see. For the novice user, there are detailed explanation pages to guide them through the various plots, charts and images. The data on this site are provided from the National Weather Service via the NOAAPORT satellite data service. All the images are generated using the Weather Processor (WXP) analysis package which is available from Unisys. "/>
<meta name="keywords" content="weather, unisys, unisys weather, weather maps, maps, nam, wrf, GFS, GFSx, hurricane, radar, satellite, surface, upper air" />
<meta name="copyright" content="Unisys Corp - 2011" />
<meta name="author" content="Unisys Corporation" />
<meta name="email" content="technical-support@weather.unisys.com" />
<meta name="Distribution" content="Global" />
<meta name="Rating" content="General" />
<meta name="Robots" content="INDEX,FOLLOW" />
<meta name="Revisit-after" content="7 Days" />
<meta http-equiv="Content-type" content="text/html;charset=UTF-8" />
<meta http-equiv="imagetoolbar" content="no" />
<meta http-equiv="Refresh" content="900" />
<meta http-equiv="X-UA-Compatible" content="IE=8"/>
<link rel="stylesheet" type="text/css" href="/css/WMAX.css" />
</head>
<body>
<div id="wrap">
  <div id="top-menu">
    <ul id="top-navigation" class="inline-navigation-list">
      <li><a href="http://www.unisys.com" title="Unisys Home Page">Unisys.com</a></li>
      <li><a href="/index.php" title="Unisys Weather">Weather Home</a></li>
      <li><a href="/analyses.php" title="Analyses">Analyses</a></li>
      <li><a href="/forehome.php" title="Forecast">Forecasts</a></li>
      <li><a href="/archives.php" title="Archives">Archives</a></li>
      <li><a href="/links.php" title="NOAA Links">NOAA Links</a></li>
      <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
    </ul>
  </div>

  <div id="header"> <a href="http://unisys.com"><img src="/images/Unisys_logo.gif" alt="Unisys" /></a>
    <h1>Unisys Weather</h1>
  </div>

<div id="leftside">
  <ul class="avmenu">
    <li><a href="/index.php" class="purple">Unisys Weather</a></li>
    <li><a href="/index.php"> Weather Home</a></li>
    <li><a href="/solutions/index.php">Weather Solutions</a></li>
    <li><a href="/mobile/index.php"><img id="mobile_icon" src="/mobile/Icon.png" width="24" height="24" alt="Download Unisys Weather Mobile App"/>iPhone App</a></li>
    <li><a href="/info/index.php">Information</a></li>
    <li><a href="/content.php">Contents</a></li>
    <li><a href="/analyses.php" class="purple">Analyses</a></li>
    <li><a href="/satellite/index.php">Satellite Images</a></li>
    <li><a href="/surface/index.php">Surface Data</a></li>
    <li><a href="/upper_air/index.php">Upper Air Data</a></li>
    <li><a href="/radar/index.php">Radar Data</a></li>
    <li><a href="/forehome.php" class="purple">Forecasts</a></li>
    <li><a href="/mos/index.php">Model Statistics</a></li>
    <li><a href="/nam/index.php">NAM/Wrf Model</a></li>
    <li><a href="/gfs/index.php?r=us">GFS/Avn Model</a></li>
    <li><a href="/gfsx/index.php?r=us">GFSx/MRF Model</a></li>
    <li><a href="/rap/index.php">RAP Model</a></li>
    <li><a href="/ecmwf/index.php">ECMWF Model</a></li>
    <li><a href="/archives.php" class="purple">Archive</a></li>
    <li><a href="/hurricane/index.php">Hurricane Data</a></li>
    <li><a href="/archive/index.php">Archive of Images</a></li>
    <li><a href="/usgs/index.php">USGS Maps</a></li>
  </ul>
</div>

<div id="extras">
  <ul class="avmenu">
    <li><a href="/foresetup.php" class="purple">Get a Forecast</a></li>
  </ul>

<script type="text/javascript">
function fsubmit()
{
     document.getElementById("Forecast").submit();
}
</script>

  <form method="get" id="Forecast" action="/forecast.php">
    <p class="center"> Enter a zip code or city name to get forecast:
      <input type="text" name="Name" id="Name" size="15" />
      <br />
      <button type="submit" style="border:none; background-color:transparent;">
         <img src="/images/GO.png" id="Go" alt="Get Forecast Data" style="height:30px;" />
      </button>
      <a href="/foresetup.php"><img src="/images/setup.png" alt="Setup Location" height="30" width="70" /></a> </p>
  </form>
  <script type="text/javascript">
                <!-- HIDE
                var index = document.cookie.indexOf("ZIP")
                var zipcode = 0
                var region = ""
                if( index != -1 ){
                   //zipcode = parseInt( document.cookie.substring(index+4,index+9),10)
                   zipcode = document.cookie.substring(index+4,index+9)
                   var validateZipCode = function() {
                     var zipcodeRegexp = /^\d{5}$/;
                     var zipTest = zipcodeRegexp.test(zipcode);
   
                     if (zipTest == false) {
                       return false;
                     }
                   }
                   validateZipCode();

                    if( ! isNaN(zipcode))

                    document.getElementById('Name').value = zipcode

                   if( zipcode >= 01000 && zipcode <= 19699 )
                      region = "ne"
                   else if( zipcode >= 19700 && zipcode <= 28999 )
                      region = "at"
                   else if( zipcode >= 43000 && zipcode <= 45999 )
                      region = "at"
                   else if( zipcode >= 29000 && zipcode <= 36999 )
                      region = "se"
                   else if( zipcode >= 38600 && zipcode <= 39999 )
                      region = "se"
                   else if( zipcode >= 46000 && zipcode <= 58999 )
                      region = "mw"
                   else if( zipcode >= 60000 && zipcode <= 62999 )
                      region = "mw"
                   else if( zipcode >= 68000 && zipcode <= 69999 )
                      region = "mw"
                   else if( zipcode >= 63000 && zipcode <= 67999 )
                      region = "cp"
                   else if( zipcode >= 71600 && zipcode <= 74999 )
                      region = "cp"
                   else if( zipcode >= 70000 && zipcode <= 71499 )
                      region = "sp"
                   else if( zipcode >= 75000 && zipcode <= 79999 )
                      region = "sp"
                   else if( zipcode >= 59000 && zipcode <= 59999 )
                      region = "nw"
                   else if( zipcode >= 82000 && zipcode <= 83999 )
                      region = "nw"
                   else if( zipcode >= 97000 && zipcode <= 99499 )
                      region = "nw"
                   else if( zipcode >= 80000 && zipcode <= 81999 )
                      region = "sw"
                   else if( zipcode >= 84000 && zipcode <= 96199 )
                      region = "sw"

                   if( region != "" ){
                      document.write( "<table border=\"0\" align=\"center\" class=\"grey\" width=\"100%\">" )
                      document.write( "<tr>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/surface/sfc_map.php?image=sfc&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Sfc" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=\"radar/rad" + region + ".php\">" )
                      document.write( "<a href=/radar/rcm_rad.php?image=rad&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Rad" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=vis&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Vis" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=enh&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>IR" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "</tr></table>" )
                      document.write( "</b>" )
                      }


                   
                   }
                // UNHIDE -->
                </script>
  <ul class="avmenu">
    <li><a href="/links.php" class="purple">NOAA Links</a></li>
    <li><a href="http://lwf.ncdc.noaa.gov/">National Climatic Data Center</a></li>
    <li><a href="http://www.cpc.noaa.gov/">Climate Prediction Center</a></li>
    <li><a href="http://oceanservice.noaa.gov/">National Ocean Service</a></li>
    <li><a href="http://www.lib.noaa.gov/">NOAA Library</a></li>
    <li><a href="http://www.oar.noaa.gov/">NOAA Office of Oceanic and Atmospheric Research</a></li>
    <li><a href="http://www.esrl.noaa.gov/">Earth Systems Research Laboratory</a></li>
    <li><a href="/overview.php" class="purple">About Us</a></li>
    <li><a href="/overview.php" title="Contact Us">Overview</a></li>
    <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
  </ul>
</div>
<div id="content">

<h2 style="font-family: helvetica,arial,sans-serif;">1999 Hurricane/Tropical Data for Western Pacific</h2>
<a href="/hurricane/w_pacific/1999H/track.gif">
  <img src="/hurricane/w_pacific/1999H/track.gif" width="640" height="512" alt="Track Map"/></a>
<h3 style="font-family: helvetica,arial,sans-serif;">Individual Storm Summary</h3>
<p style="font-family: helvetica,arial,sans-serif;">Winds in knots, pressure in millibars,
category is based on Saffir-Simpson scale.</p>
<table border="0">
<tr style="font-size: 10pt; font-family: helvetica,arial,sans-serif; color: black;"><td width="20" align="right">#</td><td width="250">Name</td><td width="125" align="center">Date</td><td width="40" align="right">Wind</td><td width="40" align="right">Pres</td><td width="40" align="right">Cat</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">1</td><td width="250" style="color:black;">Tropical Storm HILDA      </td><td width="125" align="right" style="color:black;">04-06 JAN     </td><td width="40" align="right" style="color:black;"> 35 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">2</td><td width="250" style="color:black;">Tropical Storm IRIS       </td><td width="125" align="right" style="color:black;">16-17 JAN     </td><td width="40" align="right" style="color:black;"> 35 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">3</td><td width="250" style="color:black;">Tropical Storm JACOB      </td><td width="125" align="right" style="color:black;">06-08 APR     </td><td width="40" align="right" style="color:black;"> 35 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">4</td><td width="250" style="color:black;">Typhoon KATE              </td><td width="125" align="right" style="color:black;">22-28 APR     </td><td width="40" align="right" style="color:black;"> 75 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  1</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">5</td><td width="250" style="color:black;">Typhoon LEO               </td><td width="125" align="right" style="color:black;">27 APR-02 MAY </td><td width="40" align="right" style="color:black;">110 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  3</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">6</td><td width="250" style="color:black;">Typhoon MAGGIE            </td><td width="125" align="right" style="color:black;">02-06 JUN     </td><td width="40" align="right" style="color:black;">105 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  3</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">7</td><td width="250" style="color:black;">Tropical Depression 07W   </td><td width="125" align="right" style="color:black;">15-18 JUL     </td><td width="40" align="right" style="color:black;"> 30 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">8</td><td width="250" style="color:black;">Tropical Depression 08W   </td><td width="125" align="right" style="color:black;">21-22 JUL     </td><td width="40" align="right" style="color:black;"> 30 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">9</td><td width="250" style="color:black;">Tropical Storm NEIL       </td><td width="125" align="right" style="color:black;">25-27 JUL     </td><td width="40" align="right" style="color:black;"> 40 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">10</td><td width="250" style="color:black;">Tropical Depression 10W   </td><td width="125" align="right" style="color:black;">26-27 JUL     </td><td width="40" align="right" style="color:black;"> 25 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">11</td><td width="250" style="color:black;">Typhoon OLGA              </td><td width="125" align="right" style="color:black;">29 JUL-03 AUG </td><td width="40" align="right" style="color:black;"> 75 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  1</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">12</td><td width="250" style="color:black;">Tropical Storm PAUL       </td><td width="125" align="right" style="color:black;">03-05 AUG     </td><td width="40" align="right" style="color:black;"> 50 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">13</td><td width="250" style="color:black;">Tropical Storm RACHEL     </td><td width="125" align="right" style="color:black;">06-08 AUG     </td><td width="40" align="right" style="color:black;"> 35 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">14</td><td width="250" style="color:black;">Tropical Depression 14W   </td><td width="125" align="right" style="color:black;">08-10 AUG     </td><td width="40" align="right" style="color:black;"> 30 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">15</td><td width="250" style="color:black;">Tropical Depression 15W   </td><td width="125" align="right" style="color:black;">16-18 AUG     </td><td width="40" align="right" style="color:black;"> 25 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">16</td><td width="250" style="color:black;">Typhoon SAM               </td><td width="125" align="right" style="color:black;">18-23 AUG     </td><td width="40" align="right" style="color:black;"> 75 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  1</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">17</td><td width="250" style="color:black;">Typhoon TANYA             </td><td width="125" align="right" style="color:black;">19-23 AUG     </td><td width="40" align="right" style="color:black;"> 70 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  1</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">18</td><td width="250" style="color:black;">Typhoon DORA              </td><td width="125" align="right" style="color:black;">06-21 AUG     </td><td width="40" align="right" style="color:black;">120 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  4</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">19</td><td width="250" style="color:black;">Tropical Depression 18W   </td><td width="125" align="right" style="color:black;">21-24 AUG     </td><td width="40" align="right" style="color:black;"> 30 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">20</td><td width="250" style="color:black;">Typhoon VIRGIL            </td><td width="125" align="right" style="color:black;">24-27 AUG     </td><td width="40" align="right" style="color:black;"> 75 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  1</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">21</td><td width="250" style="color:black;">Tropical Storm WENDY      </td><td width="125" align="right" style="color:black;">01-03 SEP     </td><td width="40" align="right" style="color:black;"> 40 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">22</td><td width="250" style="color:black;">Typhoon YORK              </td><td width="125" align="right" style="color:black;">11-16 SEP     </td><td width="40" align="right" style="color:black;"> 70 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  1</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">23</td><td width="250" style="color:black;">Tropical Storm ZIA        </td><td width="125" align="right" style="color:black;">13-15 SEP     </td><td width="40" align="right" style="color:black;"> 35 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">24</td><td width="250" style="color:black;">Tropical Storm ANN        </td><td width="125" align="right" style="color:black;">15-19 SEP     </td><td width="40" align="right" style="color:black;"> 45 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">25</td><td width="250" style="color:black;">Tropical Storm 23W        </td><td width="125" align="right" style="color:black;">15-16 SEP     </td><td width="40" align="right" style="color:black;"> 40 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">26</td><td width="250" style="color:black;">Super Typhoon BART        </td><td width="125" align="right" style="color:black;">17-24 SEP     </td><td width="40" align="right" style="color:black;">140 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  5</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">27</td><td width="250" style="color:black;">Tropical Storm CAM        </td><td width="125" align="right" style="color:black;">23-25 SEP     </td><td width="40" align="right" style="color:black;"> 40 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">28</td><td width="250" style="color:black;">Tropical Depression 26W   </td><td width="125" align="right" style="color:black;">02-03 OCT     </td><td width="40" align="right" style="color:black;"> 30 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">29</td><td width="250" style="color:black;">Typhoon DAN               </td><td width="125" align="right" style="color:black;">03-09 OCT     </td><td width="40" align="right" style="color:black;">110 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  3</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">30</td><td width="250" style="color:black;">Tropical Storm EVE        </td><td width="125" align="right" style="color:black;">15-19 OCT     </td><td width="40" align="right" style="color:black;"> 45 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">31</td><td width="250" style="color:black;">Tropical Depression 28W   </td><td width="125" align="right" style="color:black;">06-06 NOV     </td><td width="40" align="right" style="color:black;"> 30 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">32</td><td width="250" style="color:black;">Tropical Storm FRANKIE    </td><td width="125" align="right" style="color:black;">06-08 NOV     </td><td width="40" align="right" style="color:black;"> 35 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">33</td><td width="250" style="color:black;">Typhoon GLORIA            </td><td width="125" align="right" style="color:black;">13-16 NOV     </td><td width="40" align="right" style="color:black;"> 65 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  1</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">34</td><td width="250" style="color:black;">Tropical Depression 31W   </td><td width="125" align="right" style="color:black;">01-01 DEC     </td><td width="40" align="right" style="color:black;"> 30 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">35</td><td width="250" style="color:black;">Tropical Depression 32W   </td><td width="125" align="right" style="color:black;">09-11 DEC     </td><td width="40" align="right" style="color:black;"> 30 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">36</td><td width="250" style="color:black;">Tropical Depression 33W   </td><td width="125" align="right" style="color:black;">14-16 DEC     </td><td width="40" align="right" style="color:black;"> 30 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
</table><br/>
<big style="font-weight: bold;"><span
 style="font-family: helvetica,arial,sans-serif;"> Saffir-Simpson Scale</span></big>
      <p style="font-family: helvetica,arial,sans-serif;">The chart
color codes intensity (category based on Saffir-Simpson scale): </p>
      <table border="0" style="font-family: helvetica,arial,sans-serif;">
        <tbody>
          <tr>
            <td valign="top" bgcolor="#000099"
 style="color: rgb(255, 255, 255); font-weight: bold;"><small>Type</small></td>
            <td align="center" valign="top" bgcolor="#000099"
 style="color: rgb(255, 255, 255); font-weight: bold;"><small>Category</small></td>
            <td align="center" valign="top" bgcolor="#000099"
 style="color: rgb(255, 255, 255); font-weight: bold;"><small>Pressure
(mb)</small></td>
            <td align="center" valign="top" bgcolor="#000099"
 style="color: rgb(255, 255, 255); font-weight: bold;"><small>Winds<br/>
(knots)</small></td>
            <td align="center" valign="top" bgcolor="#000099"
 style="color: rgb(255, 255, 255); font-weight: bold;"><small>Winds<br/>
(mph)</small></td>
            <td align="center" valign="top" bgcolor="#000099"
 style="color: rgb(255, 255, 255); font-weight: bold;"><small>Line Color</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Depression</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>td</small></td>
            <td
 style="text-align: center; vertical-align: top; background-color: rgb(160, 224, 255); font-weight: bold;"><small>-----</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>&lt; 34</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>&lt; 39</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Green</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Tropical Storm</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>TS</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>-----</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>34-63</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>39-73</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Yellow</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Hurricane</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>1</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>&gt; 980</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>64-82</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>74-95</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Red</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Hurricane</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>2</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>965-980</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>83-95</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>96-110</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Light Red</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Hurricane</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>3</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>945-965</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>96-112</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>111-130</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Magenta</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Hurricane</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>4</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>920-945</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>113-135</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>131-155</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Light Magenta</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Hurricane</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>5</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>&lt; 920</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>&gt;135</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>&gt;155</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>White</small></td>
          </tr>
        </tbody>
      </table>
      <p style="font-family: helvetica,arial,sans-serif;"><small><b>NOTE:</b>
Pressures are in millibars and winds are in <b>knots</b> where one knot
is equal to 1.15 mph</small></p><hr/>
<h3 style="font-family: helvetica,arial,sans-serif;">Individual Storm Details</h3>
<table border="1" style="font-family: helvetica,arial,sans-serif;">

<TR><TD VALIGN=TOP>
<A HREF=33W/track.gif>
  <IMG SRC=33W/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Tropical Depression 33W</b> (14-16 DEC)<br>
Storm - Max Winds: 30 Category: TD<P>
<A HREF=33W/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=32W/track.gif>
  <IMG SRC=32W/track_s.gif border=0 alt="Track"></A><br>
</TD><TD>
<LI><b>Tropical Depression 32W</b> (09-11 DEC)<br>
Storm - Max Winds: 30 Category: TD<br>
<A HREF=32W/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=31W/track.gif>
  <IMG SRC=31W/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Tropical Depression 31W</b> (01-01 DEC)<br>
Storm - Max Winds: 30 Category: TD<P>
<A HREF=31W/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=GLORIA/track.gif>
  <IMG SRC=GLORIA/track_s.gif border=0 alt="Track"></A><br>
</TD><TD>
<LI><b>Typhoon GLORIA</b> (13-16 NOV)<br>
Storm - Max Winds: 65 Category: 1<br>
<A HREF=GLORIA/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=FRANKIE/track.gif>
  <IMG SRC=FRANKIE/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Tropical Storm FRANKIE</b> (06-08 NOV)<br>
Storm - Max Winds: 35 Category: TS<P>
<A HREF=FRANKIE/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=28W/track.gif>
  <IMG SRC=28W/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Tropical Depression 28W</b> (06-06 NOV)<br>
Storm - Max Winds: 30 Category: TD<P>
<A HREF=28W/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=EVE/track.gif>
  <IMG SRC=EVE/track_s.gif border=0 alt="Track"></A><br>
</TD><TD>
<LI><b>Tropical Storm EVE</b> (15-19 OCT)<br>
Storm - Max Winds: 45 Category: TS<br>
<A HREF=EVE/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=DAN/track.gif>
  <IMG SRC=DAN/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Typhoon DAN</b> (03-09 OCT)<br>
Storm - Max Winds: 110 Category: 3<P>
<A HREF=DAN/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=26W/track.gif>
  <IMG SRC=26W/track_s.gif border=0 alt="Track"></A><br>
</TD><TD>
<LI><b>Tropical Depression 26W</b> (02-03 OCT)<br>
Storm - Max Winds: 30 Category: TD<br>
<A HREF=26W/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=CAM/track.gif>
  <IMG SRC=CAM/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Tropical Storm CAM</b> (23-25 SEP)<br>
Storm - Max Winds: 40 Category: TS<P>
<A HREF=CAM/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=BART/track.gif>
  <IMG SRC=BART/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Super Typhoon BART</b> (17-24 SEP)<br>
Storm - Max Winds: 140 Category: 5<P>
<A HREF=BART/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=23W/track.gif>
  <IMG SRC=23W/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Tropical Storm 23W</b> (15-16 SEP)<br>
Storm - Max Winds: 40 Category: TS<P>
<A HREF=23W/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=ANN/track.gif>
  <IMG SRC=ANN/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Tropical Storm ANN</b> (15-19 SEP)<br>
Storm - Max Winds: 45 Category: TS<P>
<A HREF=ANN/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=ZIA/track.gif>
  <IMG SRC=ZIA/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Tropical Storm ZIA</b> (13-15 SEP)<br>
Storm - Max Winds: 35 Category: TS<P>
<A HREF=ZIA/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=YORK/track.gif>
  <IMG SRC=YORK/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Typhoon YORK</b> (11-16 SEP)<br>
Storm - Max Winds: 70 Category: 1<P>
<A HREF=YORK/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=WENDY/track.gif>
  <IMG SRC=WENDY/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Tropical Storm WENDY</b> (01-03 SEP)<br>
Storm - Max Winds: 40 Category: TS<P>
<A HREF=WENDY/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=VIRGIL/track.gif>
  <IMG SRC=VIRGIL/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Typhoon VIRGIL</b> (24-27 AUG)<br>
Storm - Max Winds: 75 Category: 1<P>
<A HREF=VIRGIL/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=18W/track.gif>
  <IMG SRC=18W/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Tropical Depression 18W</b> (21-24 AUG)<br>
Storm - Max Winds: 30 Category: TD<P>
<A HREF=18W/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=DORA/track.gif>
  <IMG SRC=DORA/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Typhoon DORA</b> (06-21 AUG)<br>
Storm - Max Winds: 120 Category: 4<P>
<A HREF=DORA/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=TANYA/track.gif>
  <IMG SRC=TANYA/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Typhoon TANYA</b> (19-23 AUG)<br>
Storm - Max Winds: 70 Category: 1<P>
<A HREF=TANYA/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=SAM/track.gif>
  <IMG SRC=SAM/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Typhoon SAM</b> (18-23 AUG)<br>
Storm - Max Winds: 75 Category: 1<P>
<A HREF=SAM/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=15W/track.gif>
  <IMG SRC=15W/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Tropical Depression 15W</b> (16-18 AUG)<br>
Storm - Max Winds: 25 Category: TD<P>
<A HREF=15W/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=14W/track.gif>
  <IMG SRC=14W/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Tropical Depression 14W</b> (08-10 AUG)<br>
Storm - Max Winds: 30 Category: TD<P>
<A HREF=14W/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=RACHEL/track.gif>
  <IMG SRC=RACHEL/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Tropical Storm RACHEL</b> (06-08 AUG)<br>
Storm - Max Winds: 35 Category: TS<P>
<A HREF=RACHEL/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=PAUL/track.gif>
  <IMG SRC=PAUL/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Tropical Storm PAUL</b> (04-05 AUG)<br>
Storm - Max Winds: 50 Category: TS<P>
<A HREF=PAUL/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=OLGA/track.gif>
  <IMG SRC=OLGA/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Typhoon OLGA</b> (29 JUL-03 AUG)<br>
Storm - Max Winds: 75 Category: 1<P>
<A HREF=OLGA/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=10W/track.gif>
  <IMG SRC=10W/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Tropical Depression 10W</b> (26-27 JUL)<br>
Storm - Max Winds: 25 Category: TD<P>
<A HREF=10W/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=NEIL/track.gif>
  <IMG SRC=NEIL/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Tropical Storm NEIL</b> (25-27 JUL)<br>
Storm - Max Winds: 40 Category: TS<P>
<A HREF=NEIL/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=08W/track.gif>
  <IMG SRC=08W/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Tropical Depression 08W</b> (21-22 JUL)<br>
Storm - Max Winds: 30 Category: TD<P>
<A HREF=08W/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=07W/track.gif>
  <IMG SRC=07W/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Tropical Depression 07W</b> (15-18 JUL)<br>
Storm - Max Winds: 30 Category: TD<P>
<A HREF=07W/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=MAGGIE/track.gif>
  <IMG SRC=MAGGIE/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Typhoon MAGGIE</b> (02-06 JUN)<br>
Storm - Max Winds: 105 Category: 3<P>
<A HREF=MAGGIE/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=LEO/track.gif>
  <IMG SRC=LEO/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Typhoon LEO</b> (27 APR-02 MAY)<br>
Storm - Max Winds: 110 Category: 3<P>
<A HREF=LEO/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=KATE/track.gif>
  <IMG SRC=KATE/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Typhoon KATE</b> (23-28 APR)<br>
Storm - Max Winds: 75 Category: 1<P>
<A HREF=KATE/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=JACOB/track.gif>
  <IMG SRC=JACOB/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Tropical Storm JACOB</b> (06-08 APR)<br>
Storm - Max Winds: 35 Category: TS<P>
<A HREF=JACOB/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=IRIS/track.gif>
  <IMG SRC=IRIS/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Tropical Storm IRIS</b> (16-17 JAN)<br>
Storm - Max Winds: 35 Category: TS<P>
<A HREF=IRIS/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=HILDA/track.gif>
  <IMG SRC=HILDA/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Tropical Storm HILDA</b> (04-06 JAN)<br>
Storm - Max Winds: 35 Category: TS<P>
<A HREF=HILDA/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

</table>
<div class="clearboth">&nbsp;</div>

</div>

<div id="footer"> <span id="copyright"><small>Copyright &copy; Unisys 2012</small></span>
  <ul class="inline-navigation-list" id="bottom-navigation">
    <li><a href="http://www.unisys.com/unisys/privacy.html" target="_blank">Privacy Notice</a></li>
    <li><a href="http://www.unisys.com/unisys/terms-and-conditions.html" target="_blank">Terms of Use</a></li>
    <li><a href="/contactus.php">Contact Us</a></li>
    <li><a href="http://www.unisys.com/unisys/trademarks.html" target="_blank">Trademarks</a></li>
  </ul>
</div>
</div>
</body>
</html>
