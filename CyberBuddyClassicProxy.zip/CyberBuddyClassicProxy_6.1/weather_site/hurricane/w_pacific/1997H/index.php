<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Unisys Weather  - 2011 Hurricane/Tropical Data for Western Pacific </title>
<meta name="description" content="The intent of this weather site is to provide a complete source of graphical weather 		information. This is intended to satisfy the needs of the weather professional, but can be a tool for the casual user as well. The graphics and data are displayed as a meteorologist would expect to see. For the novice user, there are detailed explanation pages to guide them through the various plots, charts and images. The data on this site are provided from the National Weather Service via the NOAAPORT satellite data service. All the images are generated using the Weather Processor (WXP) analysis package which is available from Unisys. "/>
<meta name="keywords" content="weather, unisys, unisys weather, weather maps, maps, nam, wrf, GFS, GFSx, hurricane, radar, satellite, surface, upper air" />
<meta name="copyright" content="Unisys Corp - 2011" />
<meta name="author" content="Unisys Corporation" />
<meta name="email" content="technical-support@weather.unisys.com" />
<meta name="Distribution" content="Global" />
<meta name="Rating" content="General" />
<meta name="Robots" content="INDEX,FOLLOW" />
<meta name="Revisit-after" content="7 Days" />
<meta http-equiv="Content-type" content="text/html;charset=UTF-8" />
<meta http-equiv="imagetoolbar" content="no" />
<meta http-equiv="Refresh" content="900" />
<meta http-equiv="X-UA-Compatible" content="IE=8"/>
<link rel="stylesheet" type="text/css" href="/css/WMAX.css" />
</head>
<body>
<div id="wrap">
  <div id="top-menu">
    <ul id="top-navigation" class="inline-navigation-list">
      <li><a href="http://www.unisys.com" title="Unisys Home Page">Unisys.com</a></li>
      <li><a href="/index.php" title="Unisys Weather">Weather Home</a></li>
      <li><a href="/analyses.php" title="Analyses">Analyses</a></li>
      <li><a href="/forehome.php" title="Forecast">Forecasts</a></li>
      <li><a href="/archives.php" title="Archives">Archives</a></li>
      <li><a href="/links.php" title="NOAA Links">NOAA Links</a></li>
      <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
    </ul>
  </div>

  <div id="header"> <a href="http://unisys.com"><img src="/images/Unisys_logo.gif" alt="Unisys" /></a>
    <h1>Unisys Weather</h1>
  </div>

<div id="leftside">
  <ul class="avmenu">
    <li><a href="/index.php" class="purple">Unisys Weather</a></li>
    <li><a href="/index.php"> Weather Home</a></li>
    <li><a href="/solutions/index.php">Weather Solutions</a></li>
    <li><a href="/mobile/index.php"><img id="mobile_icon" src="/mobile/Icon.png" width="24" height="24" alt="Download Unisys Weather Mobile App"/>iPhone App</a></li>
    <li><a href="/info/index.php">Information</a></li>
    <li><a href="/content.php">Contents</a></li>
    <li><a href="/analyses.php" class="purple">Analyses</a></li>
    <li><a href="/satellite/index.php">Satellite Images</a></li>
    <li><a href="/surface/index.php">Surface Data</a></li>
    <li><a href="/upper_air/index.php">Upper Air Data</a></li>
    <li><a href="/radar/index.php">Radar Data</a></li>
    <li><a href="/forehome.php" class="purple">Forecasts</a></li>
    <li><a href="/mos/index.php">Model Statistics</a></li>
    <li><a href="/nam/index.php">NAM/Wrf Model</a></li>
    <li><a href="/gfs/index.php?r=us">GFS/Avn Model</a></li>
    <li><a href="/gfsx/index.php?r=us">GFSx/MRF Model</a></li>
    <li><a href="/rap/index.php">RAP Model</a></li>
    <li><a href="/ecmwf/index.php">ECMWF Model</a></li>
    <li><a href="/archives.php" class="purple">Archive</a></li>
    <li><a href="/hurricane/index.php">Hurricane Data</a></li>
    <li><a href="/archive/index.php">Archive of Images</a></li>
    <li><a href="/usgs/index.php">USGS Maps</a></li>
  </ul>
</div>

<div id="extras">
  <ul class="avmenu">
    <li><a href="/foresetup.php" class="purple">Get a Forecast</a></li>
  </ul>

<script type="text/javascript">
function fsubmit()
{
     document.getElementById("Forecast").submit();
}
</script>

  <form method="get" id="Forecast" action="/forecast.php">
    <p class="center"> Enter a zip code or city name to get forecast:
      <input type="text" name="Name" id="Name" size="15" />
      <br />
      <button type="submit" style="border:none; background-color:transparent;">
         <img src="/images/GO.png" id="Go" alt="Get Forecast Data" style="height:30px;" />
      </button>
      <a href="/foresetup.php"><img src="/images/setup.png" alt="Setup Location" height="30" width="70" /></a> </p>
  </form>
  <script type="text/javascript">
                <!-- HIDE
                var index = document.cookie.indexOf("ZIP")
                var zipcode = 0
                var region = ""
                if( index != -1 ){
                   //zipcode = parseInt( document.cookie.substring(index+4,index+9),10)
                   zipcode = document.cookie.substring(index+4,index+9)
                   var validateZipCode = function() {
                     var zipcodeRegexp = /^\d{5}$/;
                     var zipTest = zipcodeRegexp.test(zipcode);
   
                     if (zipTest == false) {
                       return false;
                     }
                   }
                   validateZipCode();

                    if( ! isNaN(zipcode))

                    document.getElementById('Name').value = zipcode

                   if( zipcode >= 01000 && zipcode <= 19699 )
                      region = "ne"
                   else if( zipcode >= 19700 && zipcode <= 28999 )
                      region = "at"
                   else if( zipcode >= 43000 && zipcode <= 45999 )
                      region = "at"
                   else if( zipcode >= 29000 && zipcode <= 36999 )
                      region = "se"
                   else if( zipcode >= 38600 && zipcode <= 39999 )
                      region = "se"
                   else if( zipcode >= 46000 && zipcode <= 58999 )
                      region = "mw"
                   else if( zipcode >= 60000 && zipcode <= 62999 )
                      region = "mw"
                   else if( zipcode >= 68000 && zipcode <= 69999 )
                      region = "mw"
                   else if( zipcode >= 63000 && zipcode <= 67999 )
                      region = "cp"
                   else if( zipcode >= 71600 && zipcode <= 74999 )
                      region = "cp"
                   else if( zipcode >= 70000 && zipcode <= 71499 )
                      region = "sp"
                   else if( zipcode >= 75000 && zipcode <= 79999 )
                      region = "sp"
                   else if( zipcode >= 59000 && zipcode <= 59999 )
                      region = "nw"
                   else if( zipcode >= 82000 && zipcode <= 83999 )
                      region = "nw"
                   else if( zipcode >= 97000 && zipcode <= 99499 )
                      region = "nw"
                   else if( zipcode >= 80000 && zipcode <= 81999 )
                      region = "sw"
                   else if( zipcode >= 84000 && zipcode <= 96199 )
                      region = "sw"

                   if( region != "" ){
                      document.write( "<table border=\"0\" align=\"center\" class=\"grey\" width=\"100%\">" )
                      document.write( "<tr>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/surface/sfc_map.php?image=sfc&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Sfc" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=\"radar/rad" + region + ".php\">" )
                      document.write( "<a href=/radar/rcm_rad.php?image=rad&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Rad" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=vis&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Vis" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=enh&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>IR" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "</tr></table>" )
                      document.write( "</b>" )
                      }


                   
                   }
                // UNHIDE -->
                </script>
  <ul class="avmenu">
    <li><a href="/links.php" class="purple">NOAA Links</a></li>
    <li><a href="http://lwf.ncdc.noaa.gov/">National Climatic Data Center</a></li>
    <li><a href="http://www.cpc.noaa.gov/">Climate Prediction Center</a></li>
    <li><a href="http://oceanservice.noaa.gov/">National Ocean Service</a></li>
    <li><a href="http://www.lib.noaa.gov/">NOAA Library</a></li>
    <li><a href="http://www.oar.noaa.gov/">NOAA Office of Oceanic and Atmospheric Research</a></li>
    <li><a href="http://www.esrl.noaa.gov/">Earth Systems Research Laboratory</a></li>
    <li><a href="/overview.php" class="purple">About Us</a></li>
    <li><a href="/overview.php" title="Contact Us">Overview</a></li>
    <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
  </ul>
</div>
<div id="content">

<h2 style="font-family: helvetica,arial,sans-serif;">1997 Hurricane/Tropical Data for Western Pacific</h2>
<a href="/hurricane/w_pacific/1997H/track.gif">
  <img src="/hurricane/w_pacific/1997H/track.gif" width="640" height="512" alt="Track Map"/></a>
<h3 style="font-family: helvetica,arial,sans-serif;">Individual Storm Summary</h3>
<p style="font-family: helvetica,arial,sans-serif;">Winds in knots, pressure in millibars,
category is based on Saffir-Simpson scale.</p>
<table border="0">
<tr style="font-size: 10pt; font-family: helvetica,arial,sans-serif; color: black;"><td width="20" align="right">#</td><td width="250">Name</td><td width="125" align="center">Date</td><td width="40" align="right">Wind</td><td width="40" align="right">Pres</td><td width="40" align="right">Cat</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">1</td><td width="250" style="color:black;">Tropical Storm HANNAH     </td><td width="125" align="right" style="color:black;">19-24 JAN     </td><td width="40" align="right" style="color:black;"> 50 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">2</td><td width="250" style="color:black;">Super Typhoon ISA         </td><td width="125" align="right" style="color:black;">11-23 APR     </td><td width="40" align="right" style="color:black;">145 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  5</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">3</td><td width="250" style="color:black;">Tropical Storm JIMMY      </td><td width="125" align="right" style="color:black;">22-25 APR     </td><td width="40" align="right" style="color:black;"> 50 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">4</td><td width="250" style="color:black;">Tropical Storm KELLY      </td><td width="125" align="right" style="color:black;">07-10 MAY     </td><td width="40" align="right" style="color:black;"> 45 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">5</td><td width="250" style="color:black;">Tropical Storm LEVI       </td><td width="125" align="right" style="color:black;">25-30 MAY     </td><td width="40" align="right" style="color:black;"> 45 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">6</td><td width="250" style="color:black;">Typhoon MARIE             </td><td width="125" align="right" style="color:black;">26 MAY-02 JUN </td><td width="40" align="right" style="color:black;"> 90 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  2</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">7</td><td width="250" style="color:black;">Super Typhoon NESTOR      </td><td width="125" align="right" style="color:black;">07-14 JUN     </td><td width="40" align="right" style="color:black;">140 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  5</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">8</td><td width="250" style="color:black;">Typhoon OPAL              </td><td width="125" align="right" style="color:black;">16-21 JUN     </td><td width="40" align="right" style="color:black;"> 90 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  2</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">9</td><td width="250" style="color:black;">Typhoon PETER             </td><td width="125" align="right" style="color:black;">23-29 JUN     </td><td width="40" align="right" style="color:black;"> 65 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  1</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">10</td><td width="250" style="color:black;">Super Typhoon ROSIE       </td><td width="125" align="right" style="color:black;">19 SEP-27 JUL </td><td width="40" align="right" style="color:black;">140 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  5</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">11</td><td width="250" style="color:black;">Tropical Storm SCOTT      </td><td width="125" align="right" style="color:black;">27 JUL-02 AUG </td><td width="40" align="right" style="color:black;"> 55 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">12</td><td width="250" style="color:black;">Typhoon TINA              </td><td width="125" align="right" style="color:black;">30 JUL-09 AUG </td><td width="40" align="right" style="color:black;"> 95 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  2</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">13</td><td width="250" style="color:black;">Tropical Storm VICTOR     </td><td width="125" align="right" style="color:black;">31 JUL-03 AUG </td><td width="40" align="right" style="color:black;"> 55 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">14</td><td width="250" style="color:black;">Super Typhoon WINNIE      </td><td width="125" align="right" style="color:black;">08-19 AUG     </td><td width="40" align="right" style="color:black;">140 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  5</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">15</td><td width="250" style="color:black;">Tropical Storm YULE       </td><td width="125" align="right" style="color:black;">16-23 AUG     </td><td width="40" align="right" style="color:black;"> 55 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">16</td><td width="250" style="color:black;">Typhoon ZITA              </td><td width="125" align="right" style="color:black;">21-23 AUG     </td><td width="40" align="right" style="color:black;"> 75 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  1</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">17</td><td width="250" style="color:black;">Typhoon AMBER             </td><td width="125" align="right" style="color:black;">21-29 AUG     </td><td width="40" align="right" style="color:black;">110 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  3</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">18</td><td width="250" style="color:black;">Super Typhoon BING        </td><td width="125" align="right" style="color:black;">27 AUG-05 SEP </td><td width="40" align="right" style="color:black;">125 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  4</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">19</td><td width="250" style="color:black;">Tropical Storm CASS       </td><td width="125" align="right" style="color:black;">28-30 AUG     </td><td width="40" align="right" style="color:black;"> 45 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">20</td><td width="250" style="color:black;">Super Typhoon OLIWA       </td><td width="125" align="right" style="color:black;">02-16 SEP     </td><td width="40" align="right" style="color:black;">140 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  5</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">21</td><td width="250" style="color:black;">Tropical Depression 21W   </td><td width="125" align="right" style="color:black;">11-12 SEP     </td><td width="40" align="right" style="color:black;"> 30 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">22</td><td width="250" style="color:black;">Typhoon DAVID             </td><td width="125" align="right" style="color:black;">11-20 SEP     </td><td width="40" align="right" style="color:black;"> 95 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  2</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">23</td><td width="250" style="color:black;">Tropical Storm ELLA       </td><td width="125" align="right" style="color:black;">21-23 SEP     </td><td width="40" align="right" style="color:black;"> 40 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">24</td><td width="250" style="color:black;">Typhoon FRITZ             </td><td width="125" align="right" style="color:black;">20-25 SEP     </td><td width="40" align="right" style="color:black;"> 75 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  1</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">25</td><td width="250" style="color:black;">Super Typhoon GINGER      </td><td width="125" align="right" style="color:black;">22-30 SEP     </td><td width="40" align="right" style="color:black;">145 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  5</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">26</td><td width="250" style="color:black;">Tropical Storm HANK       </td><td width="125" align="right" style="color:black;">03-03 OCT     </td><td width="40" align="right" style="color:black;"> 40 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">27</td><td width="250" style="color:black;">Tropical Depression 26W   </td><td width="125" align="right" style="color:black;">04-07 OCT     </td><td width="40" align="right" style="color:black;"> 30 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">28</td><td width="250" style="color:black;">Super Typhoon IVAN        </td><td width="125" align="right" style="color:black;">13-24 OCT     </td><td width="40" align="right" style="color:black;">160 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  5</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">29</td><td width="250" style="color:black;">Super Typhoon JOAN        </td><td width="125" align="right" style="color:black;">13-24 OCT     </td><td width="40" align="right" style="color:black;">160 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  5</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">30</td><td width="250" style="color:black;">Super Typhoon KEITH       </td><td width="125" align="right" style="color:black;">27 OCT-08 NOV </td><td width="40" align="right" style="color:black;">160 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  5</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">31</td><td width="250" style="color:black;">Typhoon LINDA             </td><td width="125" align="right" style="color:black;">31-03 NOV     </td><td width="40" align="right" style="color:black;"> 65 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  1</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">32</td><td width="250" style="color:black;">Typhoon MORT              </td><td width="125" align="right" style="color:black;">10-16 NOV     </td><td width="40" align="right" style="color:black;"> 65 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  1</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">33</td><td width="250" style="color:black;">Super Typhoon PAKA        </td><td width="125" align="right" style="color:black;">02-21 DEC     </td><td width="40" align="right" style="color:black;">160 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  5</td><td>&nbsp;</td>
</tr>
</table><br/>
<big style="font-weight: bold;"><span
 style="font-family: helvetica,arial,sans-serif;"> Saffir-Simpson Scale</span></big>
      <p style="font-family: helvetica,arial,sans-serif;">The chart
color codes intensity (category based on Saffir-Simpson scale): </p>
      <table border="0" style="font-family: helvetica,arial,sans-serif;">
        <tbody>
          <tr>
            <td valign="top" bgcolor="#000099"
 style="color: rgb(255, 255, 255); font-weight: bold;"><small>Type</small></td>
            <td align="center" valign="top" bgcolor="#000099"
 style="color: rgb(255, 255, 255); font-weight: bold;"><small>Category</small></td>
            <td align="center" valign="top" bgcolor="#000099"
 style="color: rgb(255, 255, 255); font-weight: bold;"><small>Pressure
(mb)</small></td>
            <td align="center" valign="top" bgcolor="#000099"
 style="color: rgb(255, 255, 255); font-weight: bold;"><small>Winds<br/>
(knots)</small></td>
            <td align="center" valign="top" bgcolor="#000099"
 style="color: rgb(255, 255, 255); font-weight: bold;"><small>Winds<br/>
(mph)</small></td>
            <td align="center" valign="top" bgcolor="#000099"
 style="color: rgb(255, 255, 255); font-weight: bold;"><small>Line Color</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Depression</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>td</small></td>
            <td
 style="text-align: center; vertical-align: top; background-color: rgb(160, 224, 255); font-weight: bold;"><small>-----</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>&lt; 34</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>&lt; 39</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Green</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Tropical Storm</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>TS</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>-----</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>34-63</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>39-73</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Yellow</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Hurricane</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>1</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>&gt; 980</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>64-82</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>74-95</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Red</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Hurricane</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>2</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>965-980</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>83-95</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>96-110</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Light Red</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Hurricane</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>3</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>945-965</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>96-112</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>111-130</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Magenta</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Hurricane</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>4</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>920-945</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>113-135</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>131-155</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Light Magenta</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Hurricane</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>5</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>&lt; 920</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>&gt;135</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>&gt;155</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>White</small></td>
          </tr>
        </tbody>
      </table>
      <p style="font-family: helvetica,arial,sans-serif;"><small><b>NOTE:</b>
Pressures are in millibars and winds are in <b>knots</b> where one knot
is equal to 1.15 mph</small></p><hr/>
<h3 style="font-family: helvetica,arial,sans-serif;">Individual Storm Details</h3>
<table border="1" style="font-family: helvetica,arial,sans-serif;">

<TR><TD VALIGN=TOP>
<A HREF=PAKA/track.gif>
  <IMG SRC=PAKA/track_s.gif></A><br>
</TD><TD>
<LI><b>Super Typhoon PAKA</b> (02-21 DEC)<br>
Storm - Max Winds: 160 Category: 5<br>
<A HREF=PAKA/track.dat>
<IMG SRC=../../images/DETAILS.gif>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=MORT/track.gif>
  <IMG SRC=MORT/track_s.gif></A><br>
</TD><TD>
<LI><b>Typhoon MORT</b> (10-16 NOV)<br>
Storm - Max Winds: 65 Category: 1<br>
<A HREF=MORT/track.dat>
<IMG SRC=../../images/DETAILS.gif>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=LINDA/track.gif>
  <IMG SRC=LINDA/track_s.gif></A><br>
</TD><TD>
<LI><b>Typhoon LINDA</b> (31-03 NOV)<br>
Storm - Max Winds: 65 Category: 1<br>
<A HREF=LINDA/track.dat>
<IMG SRC=../../images/DETAILS.gif>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=KEITH/track.gif>
  <IMG SRC=KEITH/track_s.gif></A><br>
</TD><TD>
<LI><b>Super Typhoon KEITH</b> (27 OCT-08 NOV)<br>
Storm - Max Winds: 160 Category: 5<br>
<A HREF=KEITH/track.dat>
<IMG SRC=../../images/DETAILS.gif>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=JOAN/track.gif>
  <IMG SRC=JOAN/track_s.gif></A><br>
</TD><TD>
<LI><b>Super Typhoon JOAN</b> (13-24 OCT)<br>
Storm - Max Winds: 160 Category: 5<br>
<A HREF=JOAN/track.dat>
<IMG SRC=../../images/DETAILS.gif>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=IVAN/track.gif>
  <IMG SRC=IVAN/track_s.gif></A><br>
</TD><TD>
<LI><b>Super Typhoon IVAN</b> (13-24 OCT)<br>
Storm - Max Winds: 160 Category: 5<br>
<A HREF=IVAN/track.dat>
<IMG SRC=../../images/DETAILS.gif>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=26W/track.gif>
  <IMG SRC=26W/track_s.gif></A><br>
</TD><TD>
<LI><b>Tropical Depression 26W</b> (04-07 OCT)<br>
Storm - Max Winds: 30 Category: TD<br>
<A HREF=26W/track.dat>
<IMG SRC=../../images/DETAILS.gif>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=HANK/track.gif>
  <IMG SRC=HANK/track_s.gif></A><br>
</TD><TD>
<LI><b>Tropical Storm HANK</b> (03-03 OCT)<br>
Storm - Max Winds: 40 Category: TS<br>
<A HREF=HANK/track.dat>
<IMG SRC=../../images/DETAILS.gif>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=GINGER/track.gif>
  <IMG SRC=GINGER/track_s.gif></A><br>
</TD><TD>
<LI><b>Super Typhoon GINGER</b> (22-30 SEP)<br>
Storm - Max Winds: 145 Category: 5<br>
<A HREF=GINGER/track.dat>
<IMG SRC=../../images/DETAILS.gif>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=FRITZ/track.gif>
  <IMG SRC=FRITZ/track_s.gif></A><br>
</TD><TD>
<LI><b>Typhoon FRITZ</b> (20-25 SEP)<br>
Storm - Max Winds: 75 Category: 1<br>
<A HREF=FRITZ/track.dat>
<IMG SRC=../../images/DETAILS.gif>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=ELLA/track.gif>
  <IMG SRC=ELLA/track_s.gif></A><br>
</TD><TD>
<LI><b>Tropical Storm ELLA</b> (21-23 SEP)<br>
Storm - Max Winds: 40 Category: TS<br>
<A HREF=ELLA/track.dat>
<IMG SRC=../../images/DETAILS.gif>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=DAVID/track.gif>
  <IMG SRC=DAVID/track_s.gif></A><br>
</TD><TD>
<LI><b>Typhoon DAVID</b> (11-20 SEP)<br>
Storm - Max Winds: 95 Category: 2<br>
<A HREF=DAVID/track.dat>
<IMG SRC=../../images/DETAILS.gif>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=21W/track.gif>
  <IMG SRC=21W/track_s.gif></A><br>
</TD><TD>
<LI><b>Tropical Depression 21W</b> (11-12 SEP)<br>
Storm - Max Winds: 30 Category: TD<br>
<A HREF=21W/track.dat>
<IMG SRC=../../images/DETAILS.gif>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=OLIWA/track.gif>
  <IMG SRC=OLIWA/track_s.gif></A><br>
</TD><TD>
<LI><b>Super Typhoon OLIWA</b> (02-16 SEP)<br>
Storm - Max Winds: 140 Category: 5<br>
<A HREF=OLIWA/track.dat>
<IMG SRC=../../images/DETAILS.gif>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=CASS/track.gif>
  <IMG SRC=CASS/track_s.gif></A><br>
</TD><TD>
<LI><b>Tropical Storm CASS</b> (28-30 AUG)<br>
Storm - Max Winds: 45 Category: TS<br>
<A HREF=CASS/track.dat>
<IMG SRC=../../images/DETAILS.gif>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=BING/track.gif>
  <IMG SRC=BING/track_s.gif></A><br>
</TD><TD>
<LI><b>Super Typhoon BING</b> (27 AUG-05 SEP)<br>
Storm - Max Winds: 125 Category: 4<br>
<A HREF=BING/track.dat>
<IMG SRC=../../images/DETAILS.gif>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=AMBER/track.gif>
  <IMG SRC=AMBER/track_s.gif></A><br>
</TD><TD>
<LI><b>Typhoon AMBER</b> (21-29 AUG)<br>
Storm - Max Winds: 110 Category: 3<br>
<A HREF=AMBER/track.dat>
<IMG SRC=../../images/DETAILS.gif>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=ZITA/track.gif>
  <IMG SRC=ZITA/track_s.gif></A><br>
</TD><TD>
<LI><b>Typhoon ZITA</b> (21-23 AUG)<br>
Storm - Max Winds: 75 Category: 1<br>
<A HREF=ZITA/track.dat>
<IMG SRC=../../images/DETAILS.gif>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=YULE/track.gif>
  <IMG SRC=YULE/track_s.gif></A><br>
</TD><TD>
<LI><b>Tropical Storm YULE</b> (16-23 AUG)<br>
Storm - Max Winds: 55 Category: TS<br>
<A HREF=YULE/track.dat>
<IMG SRC=../../images/DETAILS.gif>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=WINNIE/track.gif>
  <IMG SRC=WINNIE/track_s.gif></A><br>
</TD><TD>
<LI><b>Super Typhoon WINNIE</b> (08-19 AUG)<br>
Storm - Max Winds: 140 Category: 5<br>
<A HREF=WINNIE/track.dat>
<IMG SRC=../../images/DETAILS.gif>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=VICTOR/track.gif>
  <IMG SRC=VICTOR/track_s.gif></A><br>
</TD><TD>
<LI><b>Tropical Storm VICTOR</b> (31 JUL-03 AUG)<br>
Storm - Max Winds: 55 Category: TS<br>
<A HREF=VICTOR/track.dat>
<IMG SRC=../../images/DETAILS.gif>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=TINA/track.gif>
  <IMG SRC=TINA/track_s.gif></A><br>
</TD><TD>
<LI><b>Typhoon TINA</b> (30 JUL-09 AUG)<br>
Storm - Max Winds: 95 Category: 2<br>
<A HREF=TINA/track.dat>
<IMG SRC=../../images/DETAILS.gif>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=SCOTT/track.gif>
  <IMG SRC=SCOTT/track_s.gif></A><br>
</TD><TD>
<LI><b>Tropical Storm SCOTT</b> (27 JUL-02 AUG)<br>
Storm - Max Winds: 55 Category: TS<br>
<A HREF=SCOTT/track.dat>
<IMG SRC=../../images/DETAILS.gif>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=ROSIE/track.gif>
  <IMG SRC=ROSIE/track_s.gif></A><br>
</TD><TD>
<LI><b>Super Typhoon ROSIE</b> (19 SEP-27 JUL)<br>
Storm - Max Winds: 140 Category: 5<br>
<A HREF=ROSIE/track.dat>
<IMG SRC=../../images/DETAILS.gif>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=PETER/track.gif>
  <IMG SRC=PETER/track_s.gif></A><br>
</TD><TD>
<LI><b>Typhoon PETER</b> (23-29 JUN)<br>
Storm - Max Winds: 65 Category: 1<br>
<A HREF=PETER/track.dat>
<IMG SRC=../../images/DETAILS.gif>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=OPAL/track.gif>
  <IMG SRC=OPAL/track_s.gif></A><br>
</TD><TD>
<LI><b>Typhoon OPAL</b> (16-21 JUN)<br>
Storm - Max Winds: 90 Category: 2<br>
<A HREF=OPAL/track.dat>
<IMG SRC=../../images/DETAILS.gif>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=NESTOR/track.gif>
  <IMG SRC=NESTOR/track_s.gif></A><br>
</TD><TD>
<LI><b>Super Typhoon NESTOR</b> (07-14 JUN)<br>
Storm - Max Winds: 140 Category: 5<br>
<A HREF=NESTOR/track.dat>
<IMG SRC=../../images/DETAILS.gif>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=MARIE/track.gif>
  <IMG SRC=MARIE/track_s.gif></A><br>
</TD><TD>
<LI><b>Typhoon MARIE</b> (26 MAY-02 JUN)<br>
Storm - Max Winds: 90 Category: 2<br>
<A HREF=MARIE/track.dat>
<IMG SRC=../../images/DETAILS.gif>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=LEVI/track.gif>
  <IMG SRC=LEVI/track_s.gif></A><br>
</TD><TD>
<LI><b>Tropical Storm LEVI</b> (25-30 MAY)<br>
Storm - Max Winds: 45 Category: TS<br>
<A HREF=LEVI/track.dat>
<IMG SRC=../../images/DETAILS.gif>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=KELLY/track.gif>
  <IMG SRC=KELLY/track_s.gif></A><br>
</TD><TD>
<LI><b>Tropical Storm KELLY</b> (07-10 MAY)<br>
Storm - Max Winds: 45 Category: TS<br>
<A HREF=KELLY/track.dat>
<IMG SRC=../../images/DETAILS.gif>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=JIMMY/track.gif>
  <IMG SRC=JIMMY/track_s.gif></A><br>
</TD><TD>
<LI><b>Tropical Storm JIMMY</b> (22-25 APR)<br>
Storm - Max Winds: 50 Category: TS<br>
<A HREF=JIMMY/track.dat>
<IMG SRC=../../images/DETAILS.gif>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=ISA/track.gif>
  <IMG SRC=ISA/track_s.gif></A><br>
</TD><TD>
<LI><b>Super Typhoon ISA</b> (11-23 APR)<br>
Storm - Max Winds: 145 Category: 5<br>
<A HREF=ISA/track.dat>
<IMG SRC=../../images/DETAILS.gif>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=HANNAH/track.gif>
  <IMG SRC=HANNAH/track_s.gif></A><br>
</TD><TD>
<LI><b>Tropical Storm HANNAH</b> (19-24 JAN)<br>
Storm - Max Winds: 50 Category: TS<br>
<A HREF=HANNAH/track.dat>
<IMG SRC=../../images/DETAILS.gif>Tracking information</A><P>
</TD></TR>

</table>
<div class="clearboth">&nbsp;</div>

</div>

<div id="footer"> <span id="copyright"><small>Copyright &copy; Unisys 2012</small></span>
  <ul class="inline-navigation-list" id="bottom-navigation">
    <li><a href="http://www.unisys.com/unisys/privacy.html" target="_blank">Privacy Notice</a></li>
    <li><a href="http://www.unisys.com/unisys/terms-and-conditions.html" target="_blank">Terms of Use</a></li>
    <li><a href="/contactus.php">Contact Us</a></li>
    <li><a href="http://www.unisys.com/unisys/trademarks.html" target="_blank">Trademarks</a></li>
  </ul>
</div>
</div>
</body>
</html>
