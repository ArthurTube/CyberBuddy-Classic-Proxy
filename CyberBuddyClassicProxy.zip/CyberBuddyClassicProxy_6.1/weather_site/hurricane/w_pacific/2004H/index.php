<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Unisys Weather  - 2011 Hurricane/Tropical Data for Western Pacific </title>
<meta name="description" content="The intent of this weather site is to provide a complete source of graphical weather 		information. This is intended to satisfy the needs of the weather professional, but can be a tool for the casual user as well. The graphics and data are displayed as a meteorologist would expect to see. For the novice user, there are detailed explanation pages to guide them through the various plots, charts and images. The data on this site are provided from the National Weather Service via the NOAAPORT satellite data service. All the images are generated using the Weather Processor (WXP) analysis package which is available from Unisys. "/>
<meta name="keywords" content="weather, unisys, unisys weather, weather maps, maps, nam, wrf, GFS, GFSx, hurricane, radar, satellite, surface, upper air" />
<meta name="copyright" content="Unisys Corp - 2011" />
<meta name="author" content="Unisys Corporation" />
<meta name="email" content="technical-support@weather.unisys.com" />
<meta name="Distribution" content="Global" />
<meta name="Rating" content="General" />
<meta name="Robots" content="INDEX,FOLLOW" />
<meta name="Revisit-after" content="7 Days" />
<meta http-equiv="Content-type" content="text/html;charset=UTF-8" />
<meta http-equiv="imagetoolbar" content="no" />
<meta http-equiv="Refresh" content="900" />
<meta http-equiv="X-UA-Compatible" content="IE=8"/>
<link rel="stylesheet" type="text/css" href="/css/WMAX.css" />
</head>
<body>
<div id="wrap">
  <div id="top-menu">
    <ul id="top-navigation" class="inline-navigation-list">
      <li><a href="http://www.unisys.com" title="Unisys Home Page">Unisys.com</a></li>
      <li><a href="/index.php" title="Unisys Weather">Weather Home</a></li>
      <li><a href="/analyses.php" title="Analyses">Analyses</a></li>
      <li><a href="/forehome.php" title="Forecast">Forecasts</a></li>
      <li><a href="/archives.php" title="Archives">Archives</a></li>
      <li><a href="/links.php" title="NOAA Links">NOAA Links</a></li>
      <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
    </ul>
  </div>

  <div id="header"> <a href="http://unisys.com"><img src="/images/Unisys_logo.gif" alt="Unisys" /></a>
    <h1>Unisys Weather</h1>
  </div>

<div id="leftside">
  <ul class="avmenu">
    <li><a href="/index.php" class="purple">Unisys Weather</a></li>
    <li><a href="/index.php"> Weather Home</a></li>
    <li><a href="/solutions/index.php">Weather Solutions</a></li>
    <li><a href="/mobile/index.php"><img id="mobile_icon" src="/mobile/Icon.png" width="24" height="24" alt="Download Unisys Weather Mobile App"/>iPhone App</a></li>
    <li><a href="/info/index.php">Information</a></li>
    <li><a href="/content.php">Contents</a></li>
    <li><a href="/analyses.php" class="purple">Analyses</a></li>
    <li><a href="/satellite/index.php">Satellite Images</a></li>
    <li><a href="/surface/index.php">Surface Data</a></li>
    <li><a href="/upper_air/index.php">Upper Air Data</a></li>
    <li><a href="/radar/index.php">Radar Data</a></li>
    <li><a href="/forehome.php" class="purple">Forecasts</a></li>
    <li><a href="/mos/index.php">Model Statistics</a></li>
    <li><a href="/nam/index.php">NAM/Wrf Model</a></li>
    <li><a href="/gfs/index.php?r=us">GFS/Avn Model</a></li>
    <li><a href="/gfsx/index.php?r=us">GFSx/MRF Model</a></li>
    <li><a href="/rap/index.php">RAP Model</a></li>
    <li><a href="/ecmwf/index.php">ECMWF Model</a></li>
    <li><a href="/archives.php" class="purple">Archive</a></li>
    <li><a href="/hurricane/index.php">Hurricane Data</a></li>
    <li><a href="/archive/index.php">Archive of Images</a></li>
    <li><a href="/usgs/index.php">USGS Maps</a></li>
  </ul>
</div>

<div id="extras">
  <ul class="avmenu">
    <li><a href="/foresetup.php" class="purple">Get a Forecast</a></li>
  </ul>

<script type="text/javascript">
function fsubmit()
{
     document.getElementById("Forecast").submit();
}
</script>

  <form method="get" id="Forecast" action="/forecast.php">
    <p class="center"> Enter a zip code or city name to get forecast:
      <input type="text" name="Name" id="Name" size="15" />
      <br />
      <button type="submit" style="border:none; background-color:transparent;">
         <img src="/images/GO.png" id="Go" alt="Get Forecast Data" style="height:30px;" />
      </button>
      <a href="/foresetup.php"><img src="/images/setup.png" alt="Setup Location" height="30" width="70" /></a> </p>
  </form>
  <script type="text/javascript">
                <!-- HIDE
                var index = document.cookie.indexOf("ZIP")
                var zipcode = 0
                var region = ""
                if( index != -1 ){
                   //zipcode = parseInt( document.cookie.substring(index+4,index+9),10)
                   zipcode = document.cookie.substring(index+4,index+9)
                   var validateZipCode = function() {
                     var zipcodeRegexp = /^\d{5}$/;
                     var zipTest = zipcodeRegexp.test(zipcode);
   
                     if (zipTest == false) {
                       return false;
                     }
                   }
                   validateZipCode();

                    if( ! isNaN(zipcode))

                    document.getElementById('Name').value = zipcode

                   if( zipcode >= 01000 && zipcode <= 19699 )
                      region = "ne"
                   else if( zipcode >= 19700 && zipcode <= 28999 )
                      region = "at"
                   else if( zipcode >= 43000 && zipcode <= 45999 )
                      region = "at"
                   else if( zipcode >= 29000 && zipcode <= 36999 )
                      region = "se"
                   else if( zipcode >= 38600 && zipcode <= 39999 )
                      region = "se"
                   else if( zipcode >= 46000 && zipcode <= 58999 )
                      region = "mw"
                   else if( zipcode >= 60000 && zipcode <= 62999 )
                      region = "mw"
                   else if( zipcode >= 68000 && zipcode <= 69999 )
                      region = "mw"
                   else if( zipcode >= 63000 && zipcode <= 67999 )
                      region = "cp"
                   else if( zipcode >= 71600 && zipcode <= 74999 )
                      region = "cp"
                   else if( zipcode >= 70000 && zipcode <= 71499 )
                      region = "sp"
                   else if( zipcode >= 75000 && zipcode <= 79999 )
                      region = "sp"
                   else if( zipcode >= 59000 && zipcode <= 59999 )
                      region = "nw"
                   else if( zipcode >= 82000 && zipcode <= 83999 )
                      region = "nw"
                   else if( zipcode >= 97000 && zipcode <= 99499 )
                      region = "nw"
                   else if( zipcode >= 80000 && zipcode <= 81999 )
                      region = "sw"
                   else if( zipcode >= 84000 && zipcode <= 96199 )
                      region = "sw"

                   if( region != "" ){
                      document.write( "<table border=\"0\" align=\"center\" class=\"grey\" width=\"100%\">" )
                      document.write( "<tr>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/surface/sfc_map.php?image=sfc&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Sfc" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=\"radar/rad" + region + ".php\">" )
                      document.write( "<a href=/radar/rcm_rad.php?image=rad&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Rad" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=vis&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Vis" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=enh&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>IR" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "</tr></table>" )
                      document.write( "</b>" )
                      }


                   
                   }
                // UNHIDE -->
                </script>
  <ul class="avmenu">
    <li><a href="/links.php" class="purple">NOAA Links</a></li>
    <li><a href="http://lwf.ncdc.noaa.gov/">National Climatic Data Center</a></li>
    <li><a href="http://www.cpc.noaa.gov/">Climate Prediction Center</a></li>
    <li><a href="http://oceanservice.noaa.gov/">National Ocean Service</a></li>
    <li><a href="http://www.lib.noaa.gov/">NOAA Library</a></li>
    <li><a href="http://www.oar.noaa.gov/">NOAA Office of Oceanic and Atmospheric Research</a></li>
    <li><a href="http://www.esrl.noaa.gov/">Earth Systems Research Laboratory</a></li>
    <li><a href="/overview.php" class="purple">About Us</a></li>
    <li><a href="/overview.php" title="Contact Us">Overview</a></li>
    <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
  </ul>
</div>
<div id="content">

<h2 style="font-family: helvetica,arial,sans-serif;">2004 Hurricane/Tropical Data for Western Pacific</h2>
<a href="/hurricane/w_pacific/2004H/track.gif">
  <img src="/hurricane/w_pacific/2004H/track.gif" width="640" height="512" alt="Track Map"/></a>
<h3 style="font-family: helvetica,arial,sans-serif;">Individual Storm Summary</h3>
<p style="font-family: helvetica,arial,sans-serif;">Winds in knots, pressure in millibars,
category is based on Saffir-Simpson scale.</p>
<table border="0">
<tr style="font-size: 10pt; font-family: helvetica,arial,sans-serif; color: black;"><td width="20" align="right">#</td><td width="250">Name</td><td width="125" align="center">Date</td><td width="40" align="right">Wind</td><td width="40" align="right">Pres</td><td width="40" align="right">Cat</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">1</td><td width="250" style="color:black;">Tropical Storm 01W        </td><td width="125" align="right" style="color:black;">11-16 FEB     </td><td width="40" align="right" style="color:black;"> 35 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">2</td><td width="250" style="color:black;">Tropical Storm 02W        </td><td width="125" align="right" style="color:black;">16-22 MAR     </td><td width="40" align="right" style="color:black;"> 45 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">3</td><td width="250" style="color:black;">Super Typhoon SUDAL       </td><td width="125" align="right" style="color:black;">04-15 APR     </td><td width="40" align="right" style="color:black;">130 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  4</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">4</td><td width="250" style="color:black;">Super Typhoon NIDA        </td><td width="125" align="right" style="color:black;">13-21 MAY     </td><td width="40" align="right" style="color:black;">140 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  5</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">5</td><td width="250" style="color:black;">Tropical Storm 05W        </td><td width="125" align="right" style="color:black;">15-17 MAY     </td><td width="40" align="right" style="color:black;"> 35 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">6</td><td width="250" style="color:black;">Typhoon OMAIS             </td><td width="125" align="right" style="color:black;">17-22 MAY     </td><td width="40" align="right" style="color:black;"> 65 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  1</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">7</td><td width="250" style="color:black;">Typhoon CONSON            </td><td width="125" align="right" style="color:black;">04-11 JUN     </td><td width="40" align="right" style="color:black;"> 95 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  2</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">8</td><td width="250" style="color:black;">Typhoon CHANTHU           </td><td width="125" align="right" style="color:black;">09-13 JUN     </td><td width="40" align="right" style="color:black;"> 75 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  1</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">9</td><td width="250" style="color:black;">Super Typhoon DIANMU      </td><td width="125" align="right" style="color:black;">13-21 JUN     </td><td width="40" align="right" style="color:black;">155 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  5</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">10</td><td width="250" style="color:black;">Super Typhoon MINDULLE    </td><td width="125" align="right" style="color:black;">23 JUN-04 JUL </td><td width="40" align="right" style="color:black;">125 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  4</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">11</td><td width="250" style="color:black;">Typhoon TINGTING          </td><td width="125" align="right" style="color:black;">25 JUN-03 JUL </td><td width="40" align="right" style="color:black;"> 80 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  1</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">12</td><td width="250" style="color:black;">Tropical Storm KOMPASU    </td><td width="125" align="right" style="color:black;">13-16 JUL     </td><td width="40" align="right" style="color:black;"> 45 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">13</td><td width="250" style="color:black;">Typhoon NAMTHEUN          </td><td width="125" align="right" style="color:black;">25 JUL-01 AUG </td><td width="40" align="right" style="color:black;">115 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  4</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">14</td><td width="250" style="color:black;">Tropical Depression MALOU </td><td width="125" align="right" style="color:black;">04-05 AUG     </td><td width="40" align="right" style="color:black;"> 30 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">15</td><td width="250" style="color:black;">Typhoon MERANTI           </td><td width="125" align="right" style="color:black;">03-08 AUG     </td><td width="40" align="right" style="color:black;"> 90 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  2</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">16</td><td width="250" style="color:black;">Typhoon RANANIM           </td><td width="125" align="right" style="color:black;">07-13 AUG     </td><td width="40" align="right" style="color:black;"> 90 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  2</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">17</td><td width="250" style="color:black;">Tropical Storm MALAKAS    </td><td width="125" align="right" style="color:black;">10-12 AUG     </td><td width="40" align="right" style="color:black;"> 35 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">18</td><td width="250" style="color:black;">Typhoon MEGI              </td><td width="125" align="right" style="color:black;">14-19 AUG     </td><td width="40" align="right" style="color:black;"> 65 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  1</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">19</td><td width="250" style="color:black;">Super Typhoon CHABA       </td><td width="125" align="right" style="color:black;">18-31 AUG     </td><td width="40" align="right" style="color:black;">155 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  5</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">20</td><td width="250" style="color:black;">Typhoon AERE              </td><td width="125" align="right" style="color:black;">19-26 AUG     </td><td width="40" align="right" style="color:black;"> 85 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  2</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">21</td><td width="250" style="color:black;">Tropical Storm 21W        </td><td width="125" align="right" style="color:black;">26-28 AUG     </td><td width="40" align="right" style="color:black;"> 35 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">22</td><td width="250" style="color:black;">Super Typhoon SONGDA      </td><td width="125" align="right" style="color:black;">27 AUG-07 SEP </td><td width="40" align="right" style="color:black;">130 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  4</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">23</td><td width="250" style="color:black;">Tropical Storm SARIKA     </td><td width="125" align="right" style="color:black;">04-07 SEP     </td><td width="40" align="right" style="color:black;"> 60 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">24</td><td width="250" style="color:black;">Tropical Depression HAIMA </td><td width="125" align="right" style="color:black;">12-13 SEP     </td><td width="40" align="right" style="color:black;"> 30 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">25</td><td width="250" style="color:black;">Typhoon MEARI             </td><td width="125" align="right" style="color:black;">20-29 SEP     </td><td width="40" align="right" style="color:black;">120 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  4</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">26</td><td width="250" style="color:black;">Super Typhoon MA_ON       </td><td width="125" align="right" style="color:black;">04-09 OCT     </td><td width="40" align="right" style="color:black;">140 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  5</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">27</td><td width="250" style="color:black;">Super Typhoon TOKAGE      </td><td width="125" align="right" style="color:black;">12-20 OCT     </td><td width="40" align="right" style="color:black;">125 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  4</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">28</td><td width="250" style="color:black;">Tropical Storm 27W        </td><td width="125" align="right" style="color:black;">12-13 OCT     </td><td width="40" align="right" style="color:black;"> 45 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">29</td><td width="250" style="color:black;">Typhoon NOCK_TEN          </td><td width="125" align="right" style="color:black;">14-26 OCT     </td><td width="40" align="right" style="color:black;">110 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  3</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">30</td><td width="250" style="color:black;">Typhoon MUIFA             </td><td width="125" align="right" style="color:black;">14-26 NOV     </td><td width="40" align="right" style="color:black;">115 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  4</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">31</td><td width="250" style="color:black;">Super Typhoon NANMADOL    </td><td width="125" align="right" style="color:black;">28 NOV-03 DEC </td><td width="40" align="right" style="color:black;">130 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  4</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">32</td><td width="250" style="color:black;">Tropical Storm TALAS      </td><td width="125" align="right" style="color:black;">10-19 DEC     </td><td width="40" align="right" style="color:black;"> 45 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">33</td><td width="250" style="color:black;">Tropical Storm NORU       </td><td width="125" align="right" style="color:black;">17-21 DEC     </td><td width="40" align="right" style="color:black;"> 55 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">34</td><td width="250" style="color:black;">Tropical Storm 32W        </td><td width="125" align="right" style="color:black;">17-18 DEC     </td><td width="40" align="right" style="color:black;"> 35 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
</table><br/>
<big style="font-weight: bold;"><span
 style="font-family: helvetica,arial,sans-serif;"> Saffir-Simpson Scale</span></big>
      <p style="font-family: helvetica,arial,sans-serif;">The chart
color codes intensity (category based on Saffir-Simpson scale): </p>
      <table border="0" style="font-family: helvetica,arial,sans-serif;">
        <tbody>
          <tr>
            <td valign="top" bgcolor="#000099"
 style="color: rgb(255, 255, 255); font-weight: bold;"><small>Type</small></td>
            <td align="center" valign="top" bgcolor="#000099"
 style="color: rgb(255, 255, 255); font-weight: bold;"><small>Category</small></td>
            <td align="center" valign="top" bgcolor="#000099"
 style="color: rgb(255, 255, 255); font-weight: bold;"><small>Pressure
(mb)</small></td>
            <td align="center" valign="top" bgcolor="#000099"
 style="color: rgb(255, 255, 255); font-weight: bold;"><small>Winds<br/>
(knots)</small></td>
            <td align="center" valign="top" bgcolor="#000099"
 style="color: rgb(255, 255, 255); font-weight: bold;"><small>Winds<br/>
(mph)</small></td>
            <td align="center" valign="top" bgcolor="#000099"
 style="color: rgb(255, 255, 255); font-weight: bold;"><small>Line Color</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Depression</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>td</small></td>
            <td
 style="text-align: center; vertical-align: top; background-color: rgb(160, 224, 255); font-weight: bold;"><small>-----</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>&lt; 34</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>&lt; 39</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Green</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Tropical Storm</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>TS</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>-----</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>34-63</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>39-73</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Yellow</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Hurricane</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>1</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>&gt; 980</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>64-82</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>74-95</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Red</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Hurricane</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>2</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>965-980</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>83-95</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>96-110</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Light Red</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Hurricane</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>3</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>945-965</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>96-112</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>111-130</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Magenta</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Hurricane</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>4</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>920-945</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>113-135</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>131-155</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Light Magenta</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Hurricane</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>5</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>&lt; 920</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>&gt;135</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>&gt;155</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>White</small></td>
          </tr>
        </tbody>
      </table>
      <p style="font-family: helvetica,arial,sans-serif;"><small><b>NOTE:</b>
Pressures are in millibars and winds are in <b>knots</b> where one knot
is equal to 1.15 mph</small></p><hr/>
<h3 style="font-family: helvetica,arial,sans-serif;">Individual Storm Details</h3>
<table border="1" style="font-family: helvetica,arial,sans-serif;">

<TR><TD VALIGN=TOP>
<A HREF=32W/track.gif>
  <IMG SRC=32W/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Tropical Storm 32W</b> (17-18 DEC)<br>
Storm - Max Winds: 35 Category: TS<P>
<A HREF=32W/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=NORU/track.gif>
  <IMG SRC=NORU/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Tropical Storm NORU</b> (17-21 DEC)<br>
Storm - Max Winds: 55 Category: TS<P>
<A HREF=NORU/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=TALAS/track.gif>
  <IMG SRC=TALAS/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Tropical Storm TALAS</b> (10-19 DEC)<br>
Storm - Max Winds: 45 Category: TS<P>
<A HREF=TALAS/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=NANMADOL/track.gif>
  <IMG SRC=NANMADOL/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Super Typhoon NANMADOL</b> (28 NOV-03 DEC)<br>
Storm - Max Winds: 130 Category: 4<P>
<A HREF=NANMADOL/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=MUIFA/track.gif>
  <IMG SRC=MUIFA/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Typhoon MUIFA</b> (14-26 NOV)<br>
Storm - Max Winds: 115 Category: 4<P>
<A HREF=MUIFA/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=NOCK_TEN/track.gif>
  <IMG SRC=NOCK_TEN/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Typhoon NOCK_TEN</b> (14-26 OCT)<br>
Storm - Max Winds: 110 Category: 3<P>
<A HREF=NOCK_TEN/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=27W/track.gif>
  <IMG SRC=27W/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Tropical Storm 27W</b> (12-13 OCT)<br>
Storm - Max Winds: 45 Category: TS<P>
<A HREF=27W/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=TOKAGE/track.gif>
  <IMG SRC=TOKAGE/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Super Typhoon TOKAGE</b> (12-20 OCT)<br>
Storm - Max Winds: 125 Category: 4<P>
<A HREF=TOKAGE/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=MA_ON/track.gif>
  <IMG SRC=MA_ON/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Super Typhoon MA_ON</b> (04-09 OCT)<br>
Storm - Max Winds: 140 Category: 5<P>
<A HREF=MA_ON/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=MEARI/track.gif>
  <IMG SRC=MEARI/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Typhoon MEARI</b> (20-29 SEP)<br>
Storm - Max Winds: 120 Category: 4<P>
<A HREF=MEARI/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=HAIMA/track.gif>
  <IMG SRC=HAIMA/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Tropical Depression HAIMA</b> (12-13 SEP)<br>
Storm - Max Winds: 30 Category: TD<P>
<A HREF=HAIMA/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=SARIKA/track.gif>
  <IMG SRC=SARIKA/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Tropical Storm SARIKA</b> (04-07 SEP)<br>
Storm - Max Winds: 60 Category: TS<P>
<A HREF=SARIKA/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=SONGDA/track.gif>
  <IMG SRC=SONGDA/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Super Typhoon SONGDA</b> (27 AUG-07 SEP)<br>
Storm - Max Winds: 130 Category: 4<P>
<A HREF=SONGDA/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=21W/track.gif>
  <IMG SRC=21W/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Tropical Storm 21W</b> (26-28 AUG)<br>
Storm - Max Winds: 35 Category: TS<P>
<A HREF=21W/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=AERE/track.gif>
  <IMG SRC=AERE/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Typhoon AERE</b> (19-26 AUG)<br>
Storm - Max Winds: 85 Category: 2<P>
<A HREF=AERE/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=CHABA/track.gif>
  <IMG SRC=CHABA/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Super Typhoon CHABA</b> (18-31 AUG)<br>
Storm - Max Winds: 155 Category: 5<P>
<A HREF=CHABA/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=MEGI/track.gif>
  <IMG SRC=MEGI/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Typhoon MEGI</b> (14-19 AUG)<br>
Storm - Max Winds: 65 Category: 1<P>
<A HREF=MEGI/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=MALAKAS/track.gif>
  <IMG SRC=MALAKAS/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Tropical Storm MALAKAS</b> (10-12 AUG)<br>
Storm - Max Winds: 35 Category: TS<P>
<A HREF=MALAKAS/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=RANANIM/track.gif>
  <IMG SRC=RANANIM/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Typhoon RANANIM</b> (07-13 AUG)<br>
Storm - Max Winds: 90 Category: 2<P>
<A HREF=RANANIM/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=MERANTI/track.gif>
  <IMG SRC=MERANTI/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Typhoon MERANTI</b> (03-08 AUG)<br>
Storm - Max Winds: 90 Category: 2<P>
<A HREF=MERANTI/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=MALOU/track.gif>
  <IMG SRC=MALOU/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Tropical Depression MALOU</b> (04-05 AUG)<br>
Storm - Max Winds: 30 Category: TD<P>
<A HREF=MALOU/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=NAMTHEUN/track.gif>
  <IMG SRC=NAMTHEUN/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Typhoon NAMTHEUN</b> (25 JUL-01 AUG)<br>
Storm - Max Winds: 115 Category: 4<P>
<A HREF=NAMTHEUN/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=KOMPASU/track.gif>
  <IMG SRC=KOMPASU/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Tropical Storm KOMPASU</b> (13-16 JUL)<br>
Storm - Max Winds: 45 Category: TS<P>
<A HREF=KOMPASU/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=TINGTING/track.gif>
  <IMG SRC=TINGTING/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Typhoon TINGTING</b> (25 JUN-03 JUL)<br>
Storm - Max Winds: 80 Category: 1<P>
<A HREF=TINGTING/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=MINDULLE/track.gif>
  <IMG SRC=MINDULLE/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Super Typhoon MINDULLE</b> (23 JUN-04 JUL)<br>
Storm - Max Winds: 125 Category: 4<P>
<A HREF=MINDULLE/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=DIANMU/track.gif>
  <IMG SRC=DIANMU/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Super Typhoon DIANMU</b> (13-21 JUN)<br>
Storm - Max Winds: 155 Category: 5<P>
<A HREF=DIANMU/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=CHANTHU/track.gif>
  <IMG SRC=CHANTHU/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Typhoon CHANTHU</b> (09-13 JUN)<br>
Storm - Max Winds: 75 Category: 1<P>
<A HREF=CHANTHU/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=CONSON/track.gif>
  <IMG SRC=CONSON/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Typhoon CONSON</b> (17-11 MAY)<br>
Storm - Max Winds: 95 Category: 2<P>
<A HREF=CONSON/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=OMAIS/track.gif>
  <IMG SRC=OMAIS/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Typhoon OMAIS</b> (17-22 MAY)<br>
Storm - Max Winds: 65 Category: 1<P>
<A HREF=OMAIS/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=05W/track.gif>
  <IMG SRC=05W/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Tropical Storm 05W</b> (15 JUN-17 MAY)<br>
Storm - Max Winds: 60 Category: TS<P>
<A HREF=05W/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=NIDA/track.gif>
  <IMG SRC=NIDA/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Super Typhoon NIDA</b> (17-21 MAY)<br>
Storm - Max Winds: 140 Category: 5<P>
<A HREF=NIDA/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=SUDAL/track.gif>
  <IMG SRC=SUDAL/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Super Typhoon SUDAL</b> (04-15 APR)<br>
Storm - Max Winds: 130 Category: 4<P>
<A HREF=SUDAL/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=02W/track.gif>
  <IMG SRC=02W/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Tropical Storm 02W</b> (16-22 MAR)<br>
Storm - Max Winds: 35 Category: TS<P>
<A HREF=02W/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=01W/track.gif>
  <IMG SRC=01W/track_s.gif border=0 alt="Track"></A>
</TD><TD>
<LI><b>Tropical Depression 01W</b> (11-16 FEB)<br>
Storm - Max Winds: 30 Category: TD<P>
<A HREF=01W/track.dat>
<IMG SRC=../../images/DETAILS.gif border=0>Tracking information</A><P>
</TD></TR>

</table>
<div class="clearboth">&nbsp;</div>

</div>

<div id="footer"> <span id="copyright"><small>Copyright &copy; Unisys 2012</small></span>
  <ul class="inline-navigation-list" id="bottom-navigation">
    <li><a href="http://www.unisys.com/unisys/privacy.html" target="_blank">Privacy Notice</a></li>
    <li><a href="http://www.unisys.com/unisys/terms-and-conditions.html" target="_blank">Terms of Use</a></li>
    <li><a href="/contactus.php">Contact Us</a></li>
    <li><a href="http://www.unisys.com/unisys/trademarks.html" target="_blank">Trademarks</a></li>
  </ul>
</div>
</div>
</body>
</html>
