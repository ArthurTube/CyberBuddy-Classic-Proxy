<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Unisys Weather  - 2011 Hurricane/Tropical Data for Western Pacific </title>
<meta name="description" content="The intent of this weather site is to provide a complete source of graphical weather 		information. This is intended to satisfy the needs of the weather professional, but can be a tool for the casual user as well. The graphics and data are displayed as a meteorologist would expect to see. For the novice user, there are detailed explanation pages to guide them through the various plots, charts and images. The data on this site are provided from the National Weather Service via the NOAAPORT satellite data service. All the images are generated using the Weather Processor (WXP) analysis package which is available from Unisys. "/>
<meta name="keywords" content="weather, unisys, unisys weather, weather maps, maps, nam, wrf, GFS, GFSx, hurricane, radar, satellite, surface, upper air" />
<meta name="copyright" content="Unisys Corp - 2011" />
<meta name="author" content="Unisys Corporation" />
<meta name="email" content="technical-support@weather.unisys.com" />
<meta name="Distribution" content="Global" />
<meta name="Rating" content="General" />
<meta name="Robots" content="INDEX,FOLLOW" />
<meta name="Revisit-after" content="7 Days" />
<meta http-equiv="Content-type" content="text/html;charset=UTF-8" />
<meta http-equiv="imagetoolbar" content="no" />
<meta http-equiv="Refresh" content="900" />
<meta http-equiv="X-UA-Compatible" content="IE=8"/>
<link rel="stylesheet" type="text/css" href="/css/WMAX.css" />
</head>
<body>
<div id="wrap">
  <div id="top-menu">
    <ul id="top-navigation" class="inline-navigation-list">
      <li><a href="http://www.unisys.com" title="Unisys Home Page">Unisys.com</a></li>
      <li><a href="/index.php" title="Unisys Weather">Weather Home</a></li>
      <li><a href="/analyses.php" title="Analyses">Analyses</a></li>
      <li><a href="/forehome.php" title="Forecast">Forecasts</a></li>
      <li><a href="/archives.php" title="Archives">Archives</a></li>
      <li><a href="/links.php" title="NOAA Links">NOAA Links</a></li>
      <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
    </ul>
  </div>

  <div id="header"> <a href="http://unisys.com"><img src="/images/Unisys_logo.gif" alt="Unisys" /></a>
    <h1>Unisys Weather</h1>
  </div>

<div id="leftside">
  <ul class="avmenu">
    <li><a href="/index.php" class="purple">Unisys Weather</a></li>
    <li><a href="/index.php"> Weather Home</a></li>
    <li><a href="/solutions/index.php">Weather Solutions</a></li>
    <li><a href="/mobile/index.php"><img id="mobile_icon" src="/mobile/Icon.png" width="24" height="24" alt="Download Unisys Weather Mobile App"/>iPhone App</a></li>
    <li><a href="/info/index.php">Information</a></li>
    <li><a href="/content.php">Contents</a></li>
    <li><a href="/analyses.php" class="purple">Analyses</a></li>
    <li><a href="/satellite/index.php">Satellite Images</a></li>
    <li><a href="/surface/index.php">Surface Data</a></li>
    <li><a href="/upper_air/index.php">Upper Air Data</a></li>
    <li><a href="/radar/index.php">Radar Data</a></li>
    <li><a href="/forehome.php" class="purple">Forecasts</a></li>
    <li><a href="/mos/index.php">Model Statistics</a></li>
    <li><a href="/nam/index.php">NAM/Wrf Model</a></li>
    <li><a href="/gfs/index.php?r=us">GFS/Avn Model</a></li>
    <li><a href="/gfsx/index.php?r=us">GFSx/MRF Model</a></li>
    <li><a href="/rap/index.php">RAP Model</a></li>
    <li><a href="/ecmwf/index.php">ECMWF Model</a></li>
    <li><a href="/archives.php" class="purple">Archive</a></li>
    <li><a href="/hurricane/index.php">Hurricane Data</a></li>
    <li><a href="/archive/index.php">Archive of Images</a></li>
    <li><a href="/usgs/index.php">USGS Maps</a></li>
  </ul>
</div>

<div id="extras">
  <ul class="avmenu">
    <li><a href="/foresetup.php" class="purple">Get a Forecast</a></li>
  </ul>

<script type="text/javascript">
function fsubmit()
{
     document.getElementById("Forecast").submit();
}
</script>

  <form method="get" id="Forecast" action="/forecast.php">
    <p class="center"> Enter a zip code or city name to get forecast:
      <input type="text" name="Name" id="Name" size="15" />
      <br />
      <button type="submit" style="border:none; background-color:transparent;">
         <img src="/images/GO.png" id="Go" alt="Get Forecast Data" style="height:30px;" />
      </button>
      <a href="/foresetup.php"><img src="/images/setup.png" alt="Setup Location" height="30" width="70" /></a> </p>
  </form>
  <script type="text/javascript">
                <!-- HIDE
                var index = document.cookie.indexOf("ZIP")
                var zipcode = 0
                var region = ""
                if( index != -1 ){
                   //zipcode = parseInt( document.cookie.substring(index+4,index+9),10)
                   zipcode = document.cookie.substring(index+4,index+9)
                   var validateZipCode = function() {
                     var zipcodeRegexp = /^\d{5}$/;
                     var zipTest = zipcodeRegexp.test(zipcode);
   
                     if (zipTest == false) {
                       return false;
                     }
                   }
                   validateZipCode();

                    if( ! isNaN(zipcode))

                    document.getElementById('Name').value = zipcode

                   if( zipcode >= 01000 && zipcode <= 19699 )
                      region = "ne"
                   else if( zipcode >= 19700 && zipcode <= 28999 )
                      region = "at"
                   else if( zipcode >= 43000 && zipcode <= 45999 )
                      region = "at"
                   else if( zipcode >= 29000 && zipcode <= 36999 )
                      region = "se"
                   else if( zipcode >= 38600 && zipcode <= 39999 )
                      region = "se"
                   else if( zipcode >= 46000 && zipcode <= 58999 )
                      region = "mw"
                   else if( zipcode >= 60000 && zipcode <= 62999 )
                      region = "mw"
                   else if( zipcode >= 68000 && zipcode <= 69999 )
                      region = "mw"
                   else if( zipcode >= 63000 && zipcode <= 67999 )
                      region = "cp"
                   else if( zipcode >= 71600 && zipcode <= 74999 )
                      region = "cp"
                   else if( zipcode >= 70000 && zipcode <= 71499 )
                      region = "sp"
                   else if( zipcode >= 75000 && zipcode <= 79999 )
                      region = "sp"
                   else if( zipcode >= 59000 && zipcode <= 59999 )
                      region = "nw"
                   else if( zipcode >= 82000 && zipcode <= 83999 )
                      region = "nw"
                   else if( zipcode >= 97000 && zipcode <= 99499 )
                      region = "nw"
                   else if( zipcode >= 80000 && zipcode <= 81999 )
                      region = "sw"
                   else if( zipcode >= 84000 && zipcode <= 96199 )
                      region = "sw"

                   if( region != "" ){
                      document.write( "<table border=\"0\" align=\"center\" class=\"grey\" width=\"100%\">" )
                      document.write( "<tr>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/surface/sfc_map.php?image=sfc&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Sfc" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=\"radar/rad" + region + ".php\">" )
                      document.write( "<a href=/radar/rcm_rad.php?image=rad&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Rad" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=vis&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Vis" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=enh&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>IR" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "</tr></table>" )
                      document.write( "</b>" )
                      }


                   
                   }
                // UNHIDE -->
                </script>
  <ul class="avmenu">
    <li><a href="/links.php" class="purple">NOAA Links</a></li>
    <li><a href="http://lwf.ncdc.noaa.gov/">National Climatic Data Center</a></li>
    <li><a href="http://www.cpc.noaa.gov/">Climate Prediction Center</a></li>
    <li><a href="http://oceanservice.noaa.gov/">National Ocean Service</a></li>
    <li><a href="http://www.lib.noaa.gov/">NOAA Library</a></li>
    <li><a href="http://www.oar.noaa.gov/">NOAA Office of Oceanic and Atmospheric Research</a></li>
    <li><a href="http://www.esrl.noaa.gov/">Earth Systems Research Laboratory</a></li>
    <li><a href="/overview.php" class="purple">About Us</a></li>
    <li><a href="/overview.php" title="Contact Us">Overview</a></li>
    <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
  </ul>
</div>
<div id="content">

<h2 style="font-family: helvetica,arial,sans-serif;">2008 Hurricane/Tropical Data for Western Pacific</h2>
<a href="/hurricane/w_pacific/2008H/track.gif">
  <img src="/hurricane/w_pacific/2008H/track.gif" width="640" height="512" alt="Track Map"/></a>
<h3 style="font-family: helvetica,arial,sans-serif;">Individual Storm Summary</h3>
<p style="font-family: helvetica,arial,sans-serif;">Winds in knots, pressure in millibars,
category is based on Saffir-Simpson scale.</p>
<table border="0">
<tr style="font-size: 10pt; font-family: helvetica,arial,sans-serif; color: black;"><td width="20" align="right">#</td><td width="250">Name</td><td width="125" align="center">Date</td><td width="40" align="right">Wind</td><td width="40" align="right">Pres</td><td width="40" align="right">Cat</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">1</td><td width="250" style="color:black;">Tropical Storm #1         </td><td width="125" align="right" style="color:black;">12-17 JAN     </td><td width="40" align="right" style="color:black;"> 40 </td><td width="40" align="right" style="color:black;"> 993 </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">2</td><td width="250" style="color:black;">Typhoon #2                </td><td width="125" align="right" style="color:black;">13-19 APR     </td><td width="40" align="right" style="color:black;">100 </td><td width="40" align="right" style="color:black;"> 948 </td><td width="40" align="right" style="color:black;">  3</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">3</td><td width="250" style="color:black;">Super Typhoon #3          </td><td width="125" align="right" style="color:black;"> 6-13 MAY     </td><td width="40" align="right" style="color:black;">135 </td><td width="40" align="right" style="color:black;"> 922 </td><td width="40" align="right" style="color:black;">  4</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">4</td><td width="250" style="color:black;">Tropical Storm #4         </td><td width="125" align="right" style="color:black;">13-16 MAY     </td><td width="40" align="right" style="color:black;"> 40 </td><td width="40" align="right" style="color:black;"> 993 </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">5</td><td width="250" style="color:black;">Typhoon #5                </td><td width="125" align="right" style="color:black;">14-20 MAY     </td><td width="40" align="right" style="color:black;"> 75 </td><td width="40" align="right" style="color:black;"> 967 </td><td width="40" align="right" style="color:black;">  1</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">6</td><td width="250" style="color:black;">Typhoon #6                </td><td width="125" align="right" style="color:black;">26 MAY- 3 JUN </td><td width="40" align="right" style="color:black;">125 </td><td width="40" align="right" style="color:black;"> 929 </td><td width="40" align="right" style="color:black;">  4</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">7</td><td width="250" style="color:black;">Typhoon #7                </td><td width="125" align="right" style="color:black;">17-25 JUN     </td><td width="40" align="right" style="color:black;">110 </td><td width="40" align="right" style="color:black;"> 941 </td><td width="40" align="right" style="color:black;">  3</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">8</td><td width="250" style="color:black;">Typhoon #8                </td><td width="125" align="right" style="color:black;">11-20 JUL     </td><td width="40" align="right" style="color:black;"> 90 </td><td width="40" align="right" style="color:black;"> 956 </td><td width="40" align="right" style="color:black;">  2</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">9</td><td width="250" style="color:black;">Typhoon #9                </td><td width="125" align="right" style="color:black;">23-29 JUL     </td><td width="40" align="right" style="color:black;"> 95 </td><td width="40" align="right" style="color:black;"> 952 </td><td width="40" align="right" style="color:black;">  2</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">10</td><td width="250" style="color:black;">Tropical Storm #10        </td><td width="125" align="right" style="color:black;"> 3- 7 AUG     </td><td width="40" align="right" style="color:black;"> 50 </td><td width="40" align="right" style="color:black;"> 985 </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">11</td><td width="250" style="color:black;">Tropical Storm #11        </td><td width="125" align="right" style="color:black;">11-15 AUG     </td><td width="40" align="right" style="color:black;"> 35 </td><td width="40" align="right" style="color:black;"> 996 </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">12</td><td width="250" style="color:black;">Tropical Storm #12        </td><td width="125" align="right" style="color:black;">12-17 AUG     </td><td width="40" align="right" style="color:black;"> 55 </td><td width="40" align="right" style="color:black;"> 982 </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">13</td><td width="250" style="color:black;">Typhoon #13               </td><td width="125" align="right" style="color:black;">16-23 AUG     </td><td width="40" align="right" style="color:black;">100 </td><td width="40" align="right" style="color:black;"> 948 </td><td width="40" align="right" style="color:black;">  3</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">14</td><td width="250" style="color:black;">Tropical Storm #14        </td><td width="125" align="right" style="color:black;">25-29 AUG     </td><td width="40" align="right" style="color:black;"> 35 </td><td width="40" align="right" style="color:black;">1000 </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">15</td><td width="250" style="color:black;">Typhoon #15               </td><td width="125" align="right" style="color:black;"> 7-21 SEP     </td><td width="40" align="right" style="color:black;">125 </td><td width="40" align="right" style="color:black;"> 929 </td><td width="40" align="right" style="color:black;">  4</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">16</td><td width="250" style="color:black;">Tropical Storm #16        </td><td width="125" align="right" style="color:black;"> 9-12 SEP     </td><td width="40" align="right" style="color:black;"> 35 </td><td width="40" align="right" style="color:black;"> 996 </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">17</td><td width="250" style="color:black;">Tropical Storm #17        </td><td width="125" align="right" style="color:black;">12-15 SEP     </td><td width="40" align="right" style="color:black;"> 35 </td><td width="40" align="right" style="color:black;"> 996 </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">18</td><td width="250" style="color:black;">Typhoon #18               </td><td width="125" align="right" style="color:black;">17-25 SEP     </td><td width="40" align="right" style="color:black;">125 </td><td width="40" align="right" style="color:black;"> 929 </td><td width="40" align="right" style="color:black;">  4</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">19</td><td width="250" style="color:black;">Super Typhoon #19         </td><td width="125" align="right" style="color:black;">23 SEP- 1 OCT </td><td width="40" align="right" style="color:black;">140 </td><td width="40" align="right" style="color:black;"> 918 </td><td width="40" align="right" style="color:black;">  5</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">20</td><td width="250" style="color:black;">Tropical Storm #20        </td><td width="125" align="right" style="color:black;">27-30 SEP     </td><td width="40" align="right" style="color:black;"> 55 </td><td width="40" align="right" style="color:black;"> 982 </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">21</td><td width="250" style="color:black;">Tropical Storm #21        </td><td width="125" align="right" style="color:black;">27 SEP- 6 OCT </td><td width="40" align="right" style="color:black;"> 40 </td><td width="40" align="right" style="color:black;"> 993 </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">22</td><td width="250" style="color:black;">Tropical Storm #22        </td><td width="125" align="right" style="color:black;">12-15 OCT     </td><td width="40" align="right" style="color:black;"> 35 </td><td width="40" align="right" style="color:black;"> 996 </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">23</td><td width="250" style="color:black;">Tropical Storm #23        </td><td width="125" align="right" style="color:black;">17-20 OCT     </td><td width="40" align="right" style="color:black;"> 45 </td><td width="40" align="right" style="color:black;"> 989 </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">24</td><td width="250" style="color:black;">Tropical Storm #24        </td><td width="125" align="right" style="color:black;"> 5-13 NOV     </td><td width="40" align="right" style="color:black;"> 55 </td><td width="40" align="right" style="color:black;"> 982 </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">25</td><td width="250" style="color:black;">Tropical Storm #25        </td><td width="125" align="right" style="color:black;">14-17 NOV     </td><td width="40" align="right" style="color:black;"> 40 </td><td width="40" align="right" style="color:black;"> 993 </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">26</td><td width="250" style="color:black;">Tropical Storm #26        </td><td width="125" align="right" style="color:black;">14-17 NOV     </td><td width="40" align="right" style="color:black;"> 40 </td><td width="40" align="right" style="color:black;"> 993 </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">27</td><td width="250" style="color:black;">Typhoon #27               </td><td width="125" align="right" style="color:black;"> 8-18 DEC     </td><td width="40" align="right" style="color:black;"> 85 </td><td width="40" align="right" style="color:black;"> 959 </td><td width="40" align="right" style="color:black;">  2</td><td>&nbsp;</td>
</tr>
</table><br/>
<big style="font-weight: bold;"><span
 style="font-family: helvetica,arial,sans-serif;"> Saffir-Simpson Scale</span></big>
      <p style="font-family: helvetica,arial,sans-serif;">The chart
color codes intensity (category based on Saffir-Simpson scale): </p>
      <table border="0" style="font-family: helvetica,arial,sans-serif;">
        <tbody>
          <tr>
            <td valign="top" bgcolor="#000099"
 style="color: rgb(255, 255, 255); font-weight: bold;"><small>Type</small></td>
            <td align="center" valign="top" bgcolor="#000099"
 style="color: rgb(255, 255, 255); font-weight: bold;"><small>Category</small></td>
            <td align="center" valign="top" bgcolor="#000099"
 style="color: rgb(255, 255, 255); font-weight: bold;"><small>Pressure
(mb)</small></td>
            <td align="center" valign="top" bgcolor="#000099"
 style="color: rgb(255, 255, 255); font-weight: bold;"><small>Winds<br/>
(knots)</small></td>
            <td align="center" valign="top" bgcolor="#000099"
 style="color: rgb(255, 255, 255); font-weight: bold;"><small>Winds<br/>
(mph)</small></td>
            <td align="center" valign="top" bgcolor="#000099"
 style="color: rgb(255, 255, 255); font-weight: bold;"><small>Line Color</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Depression</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>td</small></td>
            <td
 style="text-align: center; vertical-align: top; background-color: rgb(160, 224, 255); font-weight: bold;"><small>-----</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>&lt; 34</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>&lt; 39</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Green</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Tropical Storm</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>TS</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>-----</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>34-63</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>39-73</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Yellow</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Hurricane</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>1</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>&gt; 980</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>64-82</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>74-95</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Red</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Hurricane</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>2</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>965-980</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>83-95</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>96-110</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Light Red</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Hurricane</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>3</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>945-965</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>96-112</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>111-130</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Magenta</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Hurricane</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>4</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>920-945</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>113-135</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>131-155</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Light Magenta</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Hurricane</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>5</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>&lt; 920</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>&gt;135</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>&gt;155</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>White</small></td>
          </tr>
        </tbody>
      </table>
      <p style="font-family: helvetica,arial,sans-serif;"><small><b>NOTE:</b>
Pressures are in millibars and winds are in <b>knots</b> where one knot
is equal to 1.15 mph</small></p><hr/>
<h3 style="font-family: helvetica,arial,sans-serif;">Individual Storm Details</h3>
<table border="1" style="font-family: helvetica,arial,sans-serif;">

<TR><TD VALIGN=TOP>
<A HREF=27/track.gif><IMG SRC=27/track_s.gif width=240 height=160></A></TD><TD VALIGN=TOP><b>
Typhoon #27</b> (08-18 DEC)<br>Storm -  Max Winds: 85 Min Pres: 959 Category: 2<P>
<A HREF=27/track.dat>
<IMG SRC=/images/DETAILS.gif width=49 height=13 border=0>Tracking information</A><br>
</TD>

<TR><TD VALIGN=TOP>
<A HREF=26/track.gif><IMG SRC=26/track_s.gif width=240 height=160></A></TD><TD VALIGN=TOP><b>
Tropical Storm #26</b> (14-17 NOV)<br>Storm -  Max Winds: 40 Min Pres: 993<P>
<A HREF=26/track.dat>
<IMG SRC=/images/DETAILS.gif width=49 height=13 border=0>Tracking information</A><br>
</TD>

<TR><TD VALIGN=TOP>
<A HREF=25/track.gif><IMG SRC=25/track_s.gif width=240 height=160></A></TD><TD VALIGN=TOP><b>
Tropical Storm #25</b> (14-17 NOV)<br>Storm -  Max Winds: 40 Min Pres: 993<P>
<A HREF=25/track.dat>
<IMG SRC=/images/DETAILS.gif width=49 height=13 border=0>Tracking information</A><br>
</TD>

<TR><TD VALIGN=TOP>
<A HREF=24/track.gif><IMG SRC=24/track_s.gif width=240 height=160></A></TD><TD VALIGN=TOP><b>
Tropical Storm #24</b> (05-13 NOV)<br>Storm -  Max Winds: 55 Min Pres: 982<P>
<A HREF=24/track.dat>
<IMG SRC=/images/DETAILS.gif width=49 height=13 border=0>Tracking information</A><br>
</TD>

<TR><TD VALIGN=TOP>
<A HREF=23/track.gif><IMG SRC=23/track_s.gif width=240 height=160></A></TD><TD VALIGN=TOP><b>
Tropical Storm #23</b> (17-20 OCT)<br>Storm -  Max Winds: 45 Min Pres: 989<P>
<A HREF=23/track.dat>
<IMG SRC=/images/DETAILS.gif width=49 height=13 border=0>Tracking information</A><br>
</TD>

<TR><TD VALIGN=TOP>
<A HREF=22/track.gif><IMG SRC=22/track_s.gif width=240 height=160></A></TD><TD VALIGN=TOP><b>
Tropical Storm #22</b> (12-15 OCT)<br>Storm -  Max Winds: 35 Min Pres: 996<P>
<A HREF=22/track.dat>
<IMG SRC=/images/DETAILS.gif width=49 height=13 border=0>Tracking information</A><br>
</TD>

<TR><TD VALIGN=TOP>
<A HREF=21/track.gif><IMG SRC=21/track_s.gif width=240 height=160></A></TD><TD VALIGN=TOP><b>
Tropical Storm #21</b> (27 SEP-06 OCT)<br>Storm -  Max Winds: 40 Min Pres: 993<P>
<A HREF=21/track.dat>
<IMG SRC=/images/DETAILS.gif width=49 height=13 border=0>Tracking information</A><br>
</TD>

<TR><TD VALIGN=TOP>
<A HREF=20/track.gif><IMG SRC=20/track_s.gif width=240 height=160></A></TD><TD VALIGN=TOP><b>
Tropical Storm #20</b> (27-30 SEP)<br>Storm -  Max Winds: 55 Min Pres: 982<P>
<A HREF=20/track.dat>
<IMG SRC=/images/DETAILS.gif width=49 height=13 border=0>Tracking information</A><br>
</TD>

<TR><TD VALIGN=TOP>
<A HREF=19/track.gif><IMG SRC=19/track_s.gif width=240 height=160></A></TD><TD VALIGN=TOP><b>
Super Typhoon #19</b> (23 SEP-01 OCT)<br>Storm -  Max Winds: 140 Min Pres: 918 Category: 5<P>
<A HREF=19/track.dat>
<IMG SRC=/images/DETAILS.gif width=49 height=13 border=0>Tracking information</A><br>
</TD>

<TR><TD VALIGN=TOP>
<A HREF=18/track.gif><IMG SRC=18/track_s.gif width=240 height=160></A></TD><TD VALIGN=TOP><b>
Typhoon #18</b> (17-25 SEP)<br>Storm -  Max Winds: 125 Min Pres: 929 Category: 4<P>
<A HREF=18/track.dat>
<IMG SRC=/images/DETAILS.gif width=49 height=13 border=0>Tracking information</A><br>
</TD>

<TR><TD VALIGN=TOP>
<A HREF=17/track.gif><IMG SRC=17/track_s.gif width=240 height=160></A></TD><TD VALIGN=TOP><b>
Tropical Storm #17</b> (12-15 SEP)<br>Storm -  Max Winds: 35 Min Pres: 996<P>
<A HREF=17/track.dat>
<IMG SRC=/images/DETAILS.gif width=49 height=13 border=0>Tracking information</A><br>
</TD>

<TR><TD VALIGN=TOP>
<A HREF=16/track.gif><IMG SRC=16/track_s.gif width=240 height=160></A></TD><TD VALIGN=TOP><b>
Tropical Storm #16</b> (09-12 SEP)<br>Storm -  Max Winds: 35 Min Pres: 996<P>
<A HREF=16/track.dat>
<IMG SRC=/images/DETAILS.gif width=49 height=13 border=0>Tracking information</A><br>
</TD>

<TR><TD VALIGN=TOP>
<A HREF=15/track.gif><IMG SRC=15/track_s.gif width=240 height=160></A></TD><TD VALIGN=TOP><b>
Typhoon #15</b> (07-21 SEP)<br>Storm -  Max Winds: 125 Min Pres: 929 Category: 4<P>
<A HREF=15/track.dat>
<IMG SRC=/images/DETAILS.gif width=49 height=13 border=0>Tracking information</A><br>
</TD>

<TR><TD VALIGN=TOP>
<A HREF=14/track.gif><IMG SRC=14/track_s.gif width=240 height=160></A></TD><TD VALIGN=TOP><b>
Tropical Storm #14</b> (25-29 AUG)<br>Storm -  Max Winds: 35 Min Pres: 1000<P>
<A HREF=14/track.dat>
<IMG SRC=/images/DETAILS.gif width=49 height=13 border=0>Tracking information</A><br>
</TD>

<TR><TD VALIGN=TOP>
<A HREF=13/track.gif><IMG SRC=13/track_s.gif width=240 height=160></A></TD><TD VALIGN=TOP><b>
Typhoon #13</b> (16-23 AUG)<br>Storm -  Max Winds: 100 Min Pres: 948 Category: 3<P>
<A HREF=13/track.dat>
<IMG SRC=/images/DETAILS.gif width=49 height=13 border=0>Tracking information</A><br>
</TD>

<TR><TD VALIGN=TOP>
<A HREF=12/track.gif><IMG SRC=12/track_s.gif width=240 height=160></A></TD><TD VALIGN=TOP><b>
Tropical Storm #12</b> (12-17 AUG)<br>Storm -  Max Winds: 55 Min Pres: 982<P>
<A HREF=12/track.dat>
<IMG SRC=/images/DETAILS.gif width=49 height=13 border=0>Tracking information</A><br>
</TD>

<TR><TD VALIGN=TOP>
<A HREF=11/track.gif><IMG SRC=11/track_s.gif width=240 height=160></A></TD><TD VALIGN=TOP><b>
Tropical Storm #11</b> (11-15 AUG)<br>Storm -  Max Winds: 35 Min Pres: 996<P>
<A HREF=11/track.dat>
<IMG SRC=/images/DETAILS.gif width=49 height=13 border=0>Tracking information</A><br>
</TD>

<TR><TD VALIGN=TOP>
<A HREF=10/track.gif><IMG SRC=10/track_s.gif width=240 height=160></A></TD><TD VALIGN=TOP><b>
Tropical Storm #10</b> (03-07 AUG)<br>Storm -  Max Winds: 50 Min Pres: 985<P>
<A HREF=10/track.dat>
<IMG SRC=/images/DETAILS.gif width=49 height=13 border=0>Tracking information</A><br>
</TD>

<TR><TD VALIGN=TOP>
<A HREF=9/track.gif><IMG SRC=9/track_s.gif width=240 height=160></A></TD><TD VALIGN=TOP><b>
Typhoon #9</b> (23-29 JUL)<br>Storm -  Max Winds: 95 Min Pres: 952 Category: 2<P>
<A HREF=9/track.dat>
<IMG SRC=/images/DETAILS.gif width=49 height=13 border=0>Tracking information</A><br>
</TD>

<TR><TD VALIGN=TOP>
<A HREF=8/track.gif><IMG SRC=8/track_s.gif width=240 height=160></A></TD><TD VALIGN=TOP><b>
Typhoon #8</b> (11-20 JUL)<br>Storm -  Max Winds: 90 Min Pres: 956 Category: 2<P>
<A HREF=8/track.dat>
<IMG SRC=/images/DETAILS.gif width=49 height=13 border=0>Tracking information</A><br>
</TD>

<TR><TD VALIGN=TOP>
<A HREF=7/track.gif><IMG SRC=7/track_s.gif width=240 height=160></A></TD><TD VALIGN=TOP><b>
Typhoon #7</b> (17-25 JUN)<br>Storm -  Max Winds: 110 Min Pres: 941 Category: 3<P>
<A HREF=7/track.dat>
<IMG SRC=/images/DETAILS.gif width=49 height=13 border=0>Tracking information</A><br>
</TD>

<TR><TD VALIGN=TOP>
<A HREF=6/track.gif><IMG SRC=6/track_s.gif width=240 height=160></A></TD><TD VALIGN=TOP><b>
Typhoon #6</b> (26 MAY-03 JUN)<br>Storm -  Max Winds: 125 Min Pres: 929 Category: 4<P>
<A HREF=6/track.dat>
<IMG SRC=/images/DETAILS.gif width=49 height=13 border=0>Tracking information</A><br>
</TD>

<TR><TD VALIGN=TOP>
<A HREF=5/track.gif><IMG SRC=5/track_s.gif width=240 height=160></A></TD><TD VALIGN=TOP><b>
Typhoon #5</b> (14-20 MAY)<br>Storm -  Max Winds: 75 Min Pres: 967 Category: 1<P>
<A HREF=5/track.dat>
<IMG SRC=/images/DETAILS.gif width=49 height=13 border=0>Tracking information</A><br>
</TD>

<TR><TD VALIGN=TOP>
<A HREF=4/track.gif><IMG SRC=4/track_s.gif width=240 height=160></A></TD><TD VALIGN=TOP><b>
Tropical Storm #4</b> (13-16 MAY)<br>Storm -  Max Winds: 40 Min Pres: 993<P>
<A HREF=4/track.dat>
<IMG SRC=/images/DETAILS.gif width=49 height=13 border=0>Tracking information</A><br>
</TD>

<TR><TD VALIGN=TOP>
<A HREF=3/track.gif><IMG SRC=3/track_s.gif width=240 height=160></A></TD><TD VALIGN=TOP><b>
Super Typhoon #3</b> (06-13 MAY)<br>Storm -  Max Winds: 135 Min Pres: 922 Category: 4<P>
<A HREF=3/track.dat>
<IMG SRC=/images/DETAILS.gif width=49 height=13 border=0>Tracking information</A><br>
</TD>

<TR><TD VALIGN=TOP>
<A HREF=2/track.gif><IMG SRC=2/track_s.gif width=240 height=160></A></TD><TD VALIGN=TOP><b>
Typhoon #2</b> (13-19 APR)<br>Storm -  Max Winds: 100 Min Pres: 948 Category: 3<P>
<A HREF=2/track.dat>
<IMG SRC=/images/DETAILS.gif width=49 height=13 border=0>Tracking information</A><br>
</TD>

<TR><TD VALIGN=TOP>
<A HREF=1/track.gif><IMG SRC=1/track_s.gif width=240 height=160></A></TD><TD VALIGN=TOP><b>
Tropical Storm #1</b> (12-17 JAN)<br>Storm -  Max Winds: 40 Min Pres: 993<P>
<A HREF=1/track.dat>
<IMG SRC=/images/DETAILS.gif width=49 height=13 border=0>Tracking information</A><br>
</TD>

</table>
<div class="clearboth">&nbsp;</div>

</div>

<div id="footer"> <span id="copyright"><small>Copyright &copy; Unisys 2012</small></span>
  <ul class="inline-navigation-list" id="bottom-navigation">
    <li><a href="http://www.unisys.com/unisys/privacy.html" target="_blank">Privacy Notice</a></li>
    <li><a href="http://www.unisys.com/unisys/terms-and-conditions.html" target="_blank">Terms of Use</a></li>
    <li><a href="/contactus.php">Contact Us</a></li>
    <li><a href="http://www.unisys.com/unisys/trademarks.html" target="_blank">Trademarks</a></li>
  </ul>
</div>
</div>
</body>
</html>
