<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Unisys Weather  - 2011 Hurricane/Tropical Data for Eastern Pacific </title>
<meta name="description" content="The intent of this weather site is to provide a complete source of graphical weather 		information. This is intended to satisfy the needs of the weather professional, but can be a tool for the casual user as well. The graphics and data are displayed as a meteorologist would expect to see. For the novice user, there are detailed explanation pages to guide them through the various plots, charts and images. The data on this site are provided from the National Weather Service via the NOAAPORT satellite data service. All the images are generated using the Weather Processor (WXP) analysis package which is available from Unisys. "/>
<meta name="keywords" content="weather, unisys, unisys weather, weather maps, maps, nam, wrf, GFS, GFSx, hurricane, radar, satellite, surface, upper air" />
<meta name="copyright" content="Unisys Corp - 2011" />
<meta name="author" content="Unisys Corporation" />
<meta name="email" content="technical-support@weather.unisys.com" />
<meta name="Distribution" content="Global" />
<meta name="Rating" content="General" />
<meta name="Robots" content="INDEX,FOLLOW" />
<meta name="Revisit-after" content="7 Days" />
<meta http-equiv="Content-type" content="text/html;charset=UTF-8" />
<meta http-equiv="imagetoolbar" content="no" />
<meta http-equiv="Refresh" content="900" />
<meta http-equiv="X-UA-Compatible" content="IE=8"/>
<link rel="stylesheet" type="text/css" href="/css/WMAX.css" />
</head>
<body>
<div id="wrap">
  <div id="top-menu">
    <ul id="top-navigation" class="inline-navigation-list">
      <li><a href="http://www.unisys.com" title="Unisys Home Page">Unisys.com</a></li>
      <li><a href="/index.php" title="Unisys Weather">Weather Home</a></li>
      <li><a href="/analyses.php" title="Analyses">Analyses</a></li>
      <li><a href="/forehome.php" title="Forecast">Forecasts</a></li>
      <li><a href="/archives.php" title="Archives">Archives</a></li>
      <li><a href="/links.php" title="NOAA Links">NOAA Links</a></li>
      <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
    </ul>
  </div>

  <div id="header"> <a href="http://unisys.com"><img src="/images/Unisys_logo.gif" alt="Unisys" /></a>
    <h1>Unisys Weather</h1>
  </div>

<div id="leftside">
  <ul class="avmenu">
    <li><a href="/index.php" class="purple">Unisys Weather</a></li>
    <li><a href="/index.php"> Weather Home</a></li>
    <li><a href="/solutions/index.php">Weather Solutions</a></li>
    <li><a href="/mobile/index.php"><img id="mobile_icon" src="/mobile/Icon.png" width="24" height="24" alt="Download Unisys Weather Mobile App"/>iPhone App</a></li>
    <li><a href="/info/index.php">Information</a></li>
    <li><a href="/content.php">Contents</a></li>
    <li><a href="/analyses.php" class="purple">Analyses</a></li>
    <li><a href="/satellite/index.php">Satellite Images</a></li>
    <li><a href="/surface/index.php">Surface Data</a></li>
    <li><a href="/upper_air/index.php">Upper Air Data</a></li>
    <li><a href="/radar/index.php">Radar Data</a></li>
    <li><a href="/forehome.php" class="purple">Forecasts</a></li>
    <li><a href="/mos/index.php">Model Statistics</a></li>
    <li><a href="/nam/index.php">NAM/Wrf Model</a></li>
    <li><a href="/gfs/index.php?r=us">GFS/Avn Model</a></li>
    <li><a href="/gfsx/index.php?r=us">GFSx/MRF Model</a></li>
    <li><a href="/rap/index.php">RAP Model</a></li>
    <li><a href="/ecmwf/index.php">ECMWF Model</a></li>
    <li><a href="/archives.php" class="purple">Archive</a></li>
    <li><a href="/hurricane/index.php">Hurricane Data</a></li>
    <li><a href="/archive/index.php">Archive of Images</a></li>
    <li><a href="/usgs/index.php">USGS Maps</a></li>
  </ul>
</div>

<div id="extras">
  <ul class="avmenu">
    <li><a href="/foresetup.php" class="purple">Get a Forecast</a></li>
  </ul>

<script type="text/javascript">
function fsubmit()
{
     document.getElementById("Forecast").submit();
}
</script>

  <form method="get" id="Forecast" action="/forecast.php">
    <p class="center"> Enter a zip code or city name to get forecast:
      <input type="text" name="Name" id="Name" size="15" />
      <br />
      <button type="submit" style="border:none; background-color:transparent;">
         <img src="/images/GO.png" id="Go" alt="Get Forecast Data" style="height:30px;" />
      </button>
      <a href="/foresetup.php"><img src="/images/setup.png" alt="Setup Location" height="30" width="70" /></a> </p>
  </form>
  <script type="text/javascript">
                <!-- HIDE
                var index = document.cookie.indexOf("ZIP")
                var zipcode = 0
                var region = ""
                if( index != -1 ){
                   //zipcode = parseInt( document.cookie.substring(index+4,index+9),10)
                   zipcode = document.cookie.substring(index+4,index+9)
                   var validateZipCode = function() {
                     var zipcodeRegexp = /^\d{5}$/;
                     var zipTest = zipcodeRegexp.test(zipcode);
   
                     if (zipTest == false) {
                       return false;
                     }
                   }
                   validateZipCode();

                    if( ! isNaN(zipcode))

                    document.getElementById('Name').value = zipcode

                   if( zipcode >= 01000 && zipcode <= 19699 )
                      region = "ne"
                   else if( zipcode >= 19700 && zipcode <= 28999 )
                      region = "at"
                   else if( zipcode >= 43000 && zipcode <= 45999 )
                      region = "at"
                   else if( zipcode >= 29000 && zipcode <= 36999 )
                      region = "se"
                   else if( zipcode >= 38600 && zipcode <= 39999 )
                      region = "se"
                   else if( zipcode >= 46000 && zipcode <= 58999 )
                      region = "mw"
                   else if( zipcode >= 60000 && zipcode <= 62999 )
                      region = "mw"
                   else if( zipcode >= 68000 && zipcode <= 69999 )
                      region = "mw"
                   else if( zipcode >= 63000 && zipcode <= 67999 )
                      region = "cp"
                   else if( zipcode >= 71600 && zipcode <= 74999 )
                      region = "cp"
                   else if( zipcode >= 70000 && zipcode <= 71499 )
                      region = "sp"
                   else if( zipcode >= 75000 && zipcode <= 79999 )
                      region = "sp"
                   else if( zipcode >= 59000 && zipcode <= 59999 )
                      region = "nw"
                   else if( zipcode >= 82000 && zipcode <= 83999 )
                      region = "nw"
                   else if( zipcode >= 97000 && zipcode <= 99499 )
                      region = "nw"
                   else if( zipcode >= 80000 && zipcode <= 81999 )
                      region = "sw"
                   else if( zipcode >= 84000 && zipcode <= 96199 )
                      region = "sw"

                   if( region != "" ){
                      document.write( "<table border=\"0\" align=\"center\" class=\"grey\" width=\"100%\">" )
                      document.write( "<tr>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/surface/sfc_map.php?image=sfc&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Sfc" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=\"radar/rad" + region + ".php\">" )
                      document.write( "<a href=/radar/rcm_rad.php?image=rad&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Rad" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=vis&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Vis" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=enh&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>IR" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "</tr></table>" )
                      document.write( "</b>" )
                      }


                   
                   }
                // UNHIDE -->
                </script>
  <ul class="avmenu">
    <li><a href="/links.php" class="purple">NOAA Links</a></li>
    <li><a href="http://lwf.ncdc.noaa.gov/">National Climatic Data Center</a></li>
    <li><a href="http://www.cpc.noaa.gov/">Climate Prediction Center</a></li>
    <li><a href="http://oceanservice.noaa.gov/">National Ocean Service</a></li>
    <li><a href="http://www.lib.noaa.gov/">NOAA Library</a></li>
    <li><a href="http://www.oar.noaa.gov/">NOAA Office of Oceanic and Atmospheric Research</a></li>
    <li><a href="http://www.esrl.noaa.gov/">Earth Systems Research Laboratory</a></li>
    <li><a href="/overview.php" class="purple">About Us</a></li>
    <li><a href="/overview.php" title="Contact Us">Overview</a></li>
    <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
  </ul>
</div>
<div id="content">

<h2 style="font-family: helvetica,arial,sans-serif;">2012 Hurricane/Tropical Data for Eastern Pacific</h2>
<a href="/hurricane/e_pacific/2012/track.gif">
  <img src="/hurricane/e_pacific/2012/track.gif" width="640" height="512" alt="Track Map"/></a>
<h3 style="font-family: helvetica,arial,sans-serif;">Individual Storm Summary</h3>
<p style="font-family: helvetica,arial,sans-serif;">Winds in knots, pressure in millibars,
category is based on Saffir-Simpson scale.</p>
<table border="0">
<tr style="font-size: 10pt; font-family: helvetica,arial,sans-serif; color: black;"><td width="20" align="right">#</td><td width="250">Name</td><td width="125" align="center">Date</td><td width="40" align="right">Wind</td><td width="40" align="right">Pres</td><td width="40" align="right">Cat</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">1</td><td width="250" style="color:black;">Tropical Storm ALETTA     </td><td width="125" align="right" style="color:black;">14-19 MAY     </td><td width="40" align="right" style="color:black;"> 40 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">2</td><td width="250" style="color:black;">Hurricane-3 BUD           </td><td width="125" align="right" style="color:black;">21-26 MAY     </td><td width="40" align="right" style="color:black;">100 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  3</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">3</td><td width="250" style="color:black;">Hurricane-2 CARLOTTA      </td><td width="125" align="right" style="color:black;">14-17 JUN     </td><td width="40" align="right" style="color:black;"> 90 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  2</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">4</td><td width="250" style="color:black;">Hurricane-3 DANIEL        </td><td width="125" align="right" style="color:black;">04-12 JUL     </td><td width="40" align="right" style="color:black;">100 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  3</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">5</td><td width="250" style="color:black;">Hurricane-4 EMILIA        </td><td width="125" align="right" style="color:black;">07-15 JUL     </td><td width="40" align="right" style="color:black;">120 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  4</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">6</td><td width="250" style="color:black;">Hurricane-2 FABIO         </td><td width="125" align="right" style="color:black;">12-18 JUL     </td><td width="40" align="right" style="color:black;"> 90 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  2</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">7</td><td width="250" style="color:black;">Hurricane-1 GILMA         </td><td width="125" align="right" style="color:black;">07-11 AUG     </td><td width="40" align="right" style="color:black;"> 70 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  1</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">8</td><td width="250" style="color:black;">Tropical Storm HECTOR     </td><td width="125" align="right" style="color:black;">11-17 AUG     </td><td width="40" align="right" style="color:black;"> 40 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">9</td><td width="250" style="color:black;">Hurricane-1 ILEANA        </td><td width="125" align="right" style="color:black;">27 AUG-02 SEP </td><td width="40" align="right" style="color:black;"> 75 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  1</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">10</td><td width="250" style="color:black;">Tropical Storm JOHN       </td><td width="125" align="right" style="color:black;">02-04 SEP     </td><td width="40" align="right" style="color:black;"> 35 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">11</td><td width="250" style="color:black;">Tropical Storm KRISTY     </td><td width="125" align="right" style="color:black;">12-17 SEP     </td><td width="40" align="right" style="color:black;"> 50 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">12</td><td width="250" style="color:black;">Hurricane-1 LANE          </td><td width="125" align="right" style="color:black;">15-19 SEP     </td><td width="40" align="right" style="color:black;"> 70 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  1</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">13</td><td width="250" style="color:black;">Hurricane-3 MIRIAM        </td><td width="125" align="right" style="color:black;">22-28 SEP     </td><td width="40" align="right" style="color:black;">105 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  3</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">14</td><td width="250" style="color:black;">Tropical Storm NORMAN     </td><td width="125" align="right" style="color:black;">28-29 SEP     </td><td width="40" align="right" style="color:black;"> 40 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">15</td><td width="250" style="color:black;">Tropical Storm OLIVIA     </td><td width="125" align="right" style="color:black;">06-09 OCT     </td><td width="40" align="right" style="color:black;"> 50 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">16</td><td width="250" style="color:black;">Hurricane-3 PAUL          </td><td width="125" align="right" style="color:black;">13-17 OCT     </td><td width="40" align="right" style="color:black;">105 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  3</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">17</td><td width="250" style="color:black;">Tropical Storm ROSA       </td><td width="125" align="right" style="color:black;">30 OCT-04 NOV </td><td width="40" align="right" style="color:black;"> 50 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
</table><br/>
<big style="font-weight: bold;"><span
 style="font-family: helvetica,arial,sans-serif;"> Saffir-Simpson Scale</span></big>
      <p style="font-family: helvetica,arial,sans-serif;">The chart
color codes intensity (category based on Saffir-Simpson scale): </p>
      <table border="0" style="font-family: helvetica,arial,sans-serif;">
        <tbody>
          <tr>
            <td valign="top" bgcolor="#000099"
 style="color: rgb(255, 255, 255); font-weight: bold;"><small>Type</small></td>
            <td align="center" valign="top" bgcolor="#000099"
 style="color: rgb(255, 255, 255); font-weight: bold;"><small>Category</small></td>
            <td align="center" valign="top" bgcolor="#000099"
 style="color: rgb(255, 255, 255); font-weight: bold;"><small>Pressure
(mb)</small></td>
            <td align="center" valign="top" bgcolor="#000099"
 style="color: rgb(255, 255, 255); font-weight: bold;"><small>Winds<br/>
(knots)</small></td>
            <td align="center" valign="top" bgcolor="#000099"
 style="color: rgb(255, 255, 255); font-weight: bold;"><small>Winds<br/>
(mph)</small></td>
            <td align="center" valign="top" bgcolor="#000099"
 style="color: rgb(255, 255, 255); font-weight: bold;"><small>Line Color</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Depression</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>td</small></td>
            <td
 style="text-align: center; vertical-align: top; background-color: rgb(160, 224, 255); font-weight: bold;"><small>-----</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>&lt; 34</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>&lt; 39</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Green</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Tropical Storm</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>TS</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>-----</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>34-63</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>39-73</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Yellow</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Hurricane</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>1</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>&gt; 980</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>64-82</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>74-95</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Red</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Hurricane</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>2</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>965-980</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>83-95</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>96-110</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Light Red</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Hurricane</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>3</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>945-965</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>96-112</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>111-130</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Magenta</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Hurricane</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>4</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>920-945</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>113-135</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>131-155</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Light Magenta</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Hurricane</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>5</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>&lt; 920</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>&gt;135</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>&gt;155</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>White</small></td>
          </tr>
        </tbody>
      </table>
      <p style="font-family: helvetica,arial,sans-serif;"><small><b>NOTE:</b>
Pressures are in millibars and winds are in <b>knots</b> where one knot
is equal to 1.15 mph</small></p><hr/>
<h3 style="font-family: helvetica,arial,sans-serif;">Individual Storm Details</h3>
<table border="1" style="font-family: helvetica,arial,sans-serif;">

<tr><td valign="top">
<a href="/hurricane/e_pacific/2012/ROSA/track.gif">
  <img src="/hurricane/e_pacific/2012/ROSA/track_s.gif" border="0" alt="Track"/></a><br/>
<a href="/hurricane/e_pacific/2012/ROSA/sat_ir.gif">
  <img src="/hurricane/e_pacific/2012/ROSA/sat_ir_s.gif" border="0" alt="Sat IR"/></a><br/>
  <b>Current: <a href="/hurricane/e_pacific/2012/ROSA/track.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Track"/>Track</a> 
  <a href="/hurricane/e_pacific/2012/ROSA/sat_ir.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Sat IR"/>IR</a>
  <a href="/hurricane/e_pacific/2012/ROSA/sat_vis.gif">
     <img src="/hurricane/images/GIF.gif" border="0" alt="Sat Vis"/>Vis</a>
</b><br/>
</td><td>
<ul><li><b>Tropical Storm ROSA</b> (30 OCT-04 NOV)<br/>
Storm - Max Winds: 50 Category: TS<br/>
Current - Max Winds: 25 Category: TD<br/>
</li></ul>
<pre><span style="font-size:x-small;">

   WARNING POSITION:
   041800Z --- NEAR 12.5N 121.4W
     MOVEMENT PAST SIX HOURS - 295 DEGREES AT 02 KTS
     POSITION ACCURATE TO WITHIN 025 NM
     POSITION BASED ON CENTER LOCATED BY SATELLITE
   PRESENT WIND DISTRIBUTION:
   MAX SUSTAINED WINDS - 025 KT, GUSTS 035 KT
   WIND RADII VALID OVER OPEN WATER ONLY
   REPEAT POSIT: 12.5N 121.4W
    ---
   FORECASTS:
</span></pre>
<ul><li class="nobullet">
<a href="/hurricane/e_pacific/2012/ROSA/track.dat">
<img src="/hurricane/images/DETAILS.gif" border="0" alt="Details"/>Tracking information</a><br/></li></ul>
</td></tr>

<tr><td valign="top">
<a href="/hurricane/e_pacific/2012/PAUL/track.gif">
  <img src="/hurricane/e_pacific/2012/PAUL/track_s.gif" border="0" alt="Track"/></a><br/>
<a href="/hurricane/e_pacific/2012/PAUL/sat_ir.gif">
  <img src="/hurricane/e_pacific/2012/PAUL/sat_ir_s.gif" border="0" alt="Sat IR"/></a><br/>
  <b>Current: <a href="/hurricane/e_pacific/2012/PAUL/track.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Track"/>Track</a> 
  <a href="/hurricane/e_pacific/2012/PAUL/sat_ir.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Sat IR"/>IR</a>
  <a href="/hurricane/e_pacific/2012/PAUL/sat_vis.gif">
     <img src="/hurricane/images/GIF.gif" border="0" alt="Sat Vis"/>Vis</a>
</b><br/>
</td><td>
<ul><li><b>Hurricane-3 PAUL</b> (13-17 OCT)<br/>
Storm - Max Winds: 105 Category: 3<br/>
Current - Max Winds: 30 Category: TD<br/>
</li></ul>
<pre><span style="font-size:x-small;">

   WARNING POSITION:
   171800Z --- NEAR 27.4N 114.7W
     MOVEMENT PAST SIX HOURS - 310 DEGREES AT 10 KTS
     POSITION ACCURATE TO WITHIN 020 NM
     POSITION BASED ON CENTER LOCATED BY SATELLITE
   PRESENT WIND DISTRIBUTION:
   MAX SUSTAINED WINDS - 030 KT, GUSTS 040 KT
   WIND RADII VALID OVER OPEN WATER ONLY
   REPEAT POSIT: 27.4N 114.7W
    ---
   FORECASTS:
</span></pre>
<ul><li class="nobullet">
<a href="/hurricane/e_pacific/2012/PAUL/track.dat">
<img src="/hurricane/images/DETAILS.gif" border="0" alt="Details"/>Tracking information</a><br/></li></ul>
</td></tr>

<tr><td valign="top">
<a href="/hurricane/e_pacific/2012/OLIVIA/track.gif">
  <img src="/hurricane/e_pacific/2012/OLIVIA/track_s.gif" border="0" alt="Track"/></a><br/>
<a href="/hurricane/e_pacific/2012/OLIVIA/sat_ir.gif">
  <img src="/hurricane/e_pacific/2012/OLIVIA/sat_ir_s.gif" border="0" alt="Sat IR"/></a><br/>
  <b>Current: <a href="/hurricane/e_pacific/2012/OLIVIA/track.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Track"/>Track</a> 
  <a href="/hurricane/e_pacific/2012/OLIVIA/sat_ir.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Sat IR"/>IR</a>
  <a href="/hurricane/e_pacific/2012/OLIVIA/sat_vis.gif">
     <img src="/hurricane/images/GIF.gif" border="0" alt="Sat Vis"/>Vis</a>
</b><br/>
</td><td>
<ul><li><b>Tropical Storm OLIVIA</b> (06-09 OCT)<br/>
Storm - Max Winds: 50 Category: TS<br/>
Current - Max Winds: 30 Category: TD<br/>
</li></ul>
<pre><span style="font-size:x-small;">

   WARNING POSITION:
   090600Z --- NEAR 15.3N 121.7W
     MOVEMENT PAST SIX HOURS - 215 DEGREES AT 07 KTS
     POSITION ACCURATE TO WITHIN 060 NM
     POSITION BASED ON CENTER LOCATED BY SATELLITE
   PRESENT WIND DISTRIBUTION:
   MAX SUSTAINED WINDS - 030 KT, GUSTS 040 KT
   WIND RADII VALID OVER OPEN WATER ONLY
   REPEAT POSIT: 15.3N 121.7W
    ---
   FORECASTS:
</span></pre>
<ul><li class="nobullet">
<a href="/hurricane/e_pacific/2012/OLIVIA/track.dat">
<img src="/hurricane/images/DETAILS.gif" border="0" alt="Details"/>Tracking information</a><br/></li></ul>
</td></tr>

<tr><td valign="top">
<a href="/hurricane/e_pacific/2012/NORMAN/track.gif">
  <img src="/hurricane/e_pacific/2012/NORMAN/track_s.gif" border="0" alt="Track"/></a><br/>
<a href="/hurricane/e_pacific/2012/NORMAN/sat_ir.gif">
  <img src="/hurricane/e_pacific/2012/NORMAN/sat_ir_s.gif" border="0" alt="Sat IR"/></a><br/>
  <b>Current: <a href="/hurricane/e_pacific/2012/NORMAN/track.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Track"/>Track</a> 
  <a href="/hurricane/e_pacific/2012/NORMAN/sat_ir.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Sat IR"/>IR</a>
  <a href="/hurricane/e_pacific/2012/NORMAN/sat_vis.gif">
     <img src="/hurricane/images/GIF.gif" border="0" alt="Sat Vis"/>Vis</a>
</b><br/>
</td><td>
<ul><li><b>Tropical Storm NORMAN</b> (28-29 SEP)<br/>
Storm - Max Winds: 40 Category: TS<br/>
Current - Max Winds: 25 Category: TD<br/>
</li></ul>
<pre><span style="font-size:x-small;">

   WARNING POSITION:
   291800Z --- NEAR 25.9N 110.8W
     MOVEMENT PAST SIX HOURS - 240 DEGREES AT 06 KTS
     POSITION ACCURATE TO WITHIN 030 NM
     POSITION BASED ON CENTER LOCATED BY SATELLITE
   PRESENT WIND DISTRIBUTION:
   MAX SUSTAINED WINDS - 025 KT, GUSTS 035 KT
   WIND RADII VALID OVER OPEN WATER ONLY
   POST-TROP/REMNT LOW
   REPEAT POSIT: 25.9N 110.8W
    ---
   FORECASTS:
</span></pre>
<ul><li class="nobullet">
<a href="/hurricane/e_pacific/2012/NORMAN/track.dat">
<img src="/hurricane/images/DETAILS.gif" border="0" alt="Details"/>Tracking information</a><br/></li></ul>
</td></tr>

<tr><td valign="top">
<a href="/hurricane/e_pacific/2012/MIRIAM/track.gif">
  <img src="/hurricane/e_pacific/2012/MIRIAM/track_s.gif" border="0" alt="Track"/></a><br/>
<a href="/hurricane/e_pacific/2012/MIRIAM/sat_ir.gif">
  <img src="/hurricane/e_pacific/2012/MIRIAM/sat_ir_s.gif" border="0" alt="Sat IR"/></a><br/>
  <b>Current: <a href="/hurricane/e_pacific/2012/MIRIAM/track.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Track"/>Track</a> 
  <a href="/hurricane/e_pacific/2012/MIRIAM/sat_ir.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Sat IR"/>IR</a>
  <a href="/hurricane/e_pacific/2012/MIRIAM/sat_vis.gif">
     <img src="/hurricane/images/GIF.gif" border="0" alt="Sat Vis"/>Vis</a>
</b><br/>
</td><td>
<ul><li><b>Hurricane-3 MIRIAM</b> (22-28 SEP)<br/>
Storm - Max Winds: 105 Category: 3<br/>
Current - Max Winds: 30 Category: TD<br/>
</li></ul>
<pre><span style="font-size:x-small;">

   WARNING POSITION:
   280000Z --- NEAR 22.0N 116.6W
     MOVEMENT PAST SIX HOURS - 135 DEGREES AT 01 KTS
     POSITION ACCURATE TO WITHIN 015 NM
     POSITION BASED ON CENTER LOCATED BY SATELLITE
   PRESENT WIND DISTRIBUTION:
   MAX SUSTAINED WINDS - 030 KT, GUSTS 040 KT
   WIND RADII VALID OVER OPEN WATER ONLY
   POST-TROP/REMNT LOW
   REPEAT POSIT: 22.0N 116.6W
    ---
   FORECASTS:
</span></pre>
<ul><li class="nobullet">
<a href="/hurricane/e_pacific/2012/MIRIAM/track.dat">
<img src="/hurricane/images/DETAILS.gif" border="0" alt="Details"/>Tracking information</a><br/></li></ul>
</td></tr>

<tr><td valign="top">
<a href="/hurricane/e_pacific/2012/LANE/track.gif">
  <img src="/hurricane/e_pacific/2012/LANE/track_s.gif" border="0" alt="Track"/></a><br/>
<a href="/hurricane/e_pacific/2012/LANE/sat_ir.gif">
  <img src="/hurricane/e_pacific/2012/LANE/sat_ir_s.gif" border="0" alt="Sat IR"/></a><br/>
  <b>Current: <a href="/hurricane/e_pacific/2012/LANE/track.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Track"/>Track</a> 
  <a href="/hurricane/e_pacific/2012/LANE/sat_ir.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Sat IR"/>IR</a>
  <a href="/hurricane/e_pacific/2012/LANE/sat_vis.gif">
     <img src="/hurricane/images/GIF.gif" border="0" alt="Sat Vis"/>Vis</a>
</b><br/>
</td><td>
<ul><li><b>Hurricane-1 LANE</b> (15-19 SEP)<br/>
Storm - Max Winds: 70 Category: 1<br/>
Current - Max Winds: 30 Category: TD<br/>
</li></ul>
<pre><span style="font-size:x-small;">

   WARNING POSITION:
   191200Z --- NEAR 20.9N 131.0W
     MOVEMENT PAST SIX HOURS - 280 DEGREES AT 05 KTS
     POSITION ACCURATE TO WITHIN 020 NM
     POSITION BASED ON CENTER LOCATED BY SATELLITE
   PRESENT WIND DISTRIBUTION:
   MAX SUSTAINED WINDS - 030 KT, GUSTS 040 KT
   WIND RADII VALID OVER OPEN WATER ONLY
   REPEAT POSIT: 20.9N 131.0W
    ---
   FORECASTS:
</span></pre>
<ul><li class="nobullet">
<a href="/hurricane/e_pacific/2012/LANE/track.dat">
<img src="/hurricane/images/DETAILS.gif" border="0" alt="Details"/>Tracking information</a><br/></li></ul>
</td></tr>

<tr><td valign="top">
<a href="/hurricane/e_pacific/2012/KRISTY/track.gif">
  <img src="/hurricane/e_pacific/2012/KRISTY/track_s.gif" border="0" alt="Track"/></a><br/>
<a href="/hurricane/e_pacific/2012/KRISTY/sat_ir.gif">
  <img src="/hurricane/e_pacific/2012/KRISTY/sat_ir_s.gif" border="0" alt="Sat IR"/></a><br/>
  <b>Current: <a href="/hurricane/e_pacific/2012/KRISTY/track.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Track"/>Track</a> 
  <a href="/hurricane/e_pacific/2012/KRISTY/sat_ir.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Sat IR"/>IR</a>
  <a href="/hurricane/e_pacific/2012/KRISTY/sat_vis.gif">
     <img src="/hurricane/images/GIF.gif" border="0" alt="Sat Vis"/>Vis</a>
</b><br/>
</td><td>
<ul><li><b>Tropical Storm KRISTY</b> (12-17 SEP)<br/>
Storm - Max Winds: 50 Category: TS<br/>
Current - Max Winds: 30 Category: TD<br/>
</li></ul>
<pre><span style="font-size:x-small;">

   WARNING POSITION:
   171200Z --- NEAR 26.1N 119.5W
     MOVEMENT PAST SIX HOURS - 340 DEGREES AT 05 KTS
     POSITION ACCURATE TO WITHIN 060 NM
     POSITION BASED ON CENTER LOCATED BY SATELLITE
   PRESENT WIND DISTRIBUTION:
   MAX SUSTAINED WINDS - 030 KT, GUSTS 040 KT
   WIND RADII VALID OVER OPEN WATER ONLY
   REPEAT POSIT: 26.1N 119.5W
    ---
   FORECASTS:
</span></pre>
<ul><li class="nobullet">
<a href="/hurricane/e_pacific/2012/KRISTY/track.dat">
<img src="/hurricane/images/DETAILS.gif" border="0" alt="Details"/>Tracking information</a><br/></li></ul>
</td></tr>

<tr><td valign="top">
<a href="/hurricane/e_pacific/2012/JOHN/track.gif">
  <img src="/hurricane/e_pacific/2012/JOHN/track_s.gif" border="0" alt="Track"/></a><br/>
<a href="/hurricane/e_pacific/2012/JOHN/sat_ir.gif">
  <img src="/hurricane/e_pacific/2012/JOHN/sat_ir_s.gif" border="0" alt="Sat IR"/></a><br/>
  <b>Current: <a href="/hurricane/e_pacific/2012/JOHN/track.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Track"/>Track</a> 
  <a href="/hurricane/e_pacific/2012/JOHN/sat_ir.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Sat IR"/>IR</a>
  <a href="/hurricane/e_pacific/2012/JOHN/sat_vis.gif">
     <img src="/hurricane/images/GIF.gif" border="0" alt="Sat Vis"/>Vis</a>
</b><br/>
</td><td>
<ul><li><b>Tropical Storm JOHN</b> (02-04 SEP)<br/>
Storm - Max Winds: 35 Category: TS<br/>
Current - Max Winds: 30 Category: TD<br/>
</li></ul>
<pre><span style="font-size:x-small;">

   WARNING POSITION:
   041800Z --- NEAR 24.0N 117.3W
     MOVEMENT PAST SIX HOURS - 310 DEGREES AT 14 KTS
     POSITION ACCURATE TO WITHIN 020 NM
     POSITION BASED ON CENTER LOCATED BY SATELLITE
   PRESENT WIND DISTRIBUTION:
   MAX SUSTAINED WINDS - 030 KT, GUSTS 040 KT
   WIND RADII VALID OVER OPEN WATER ONLY
   POST-TROP/REMNT LOW
   REPEAT POSIT: 24.0N 117.3W
    ---
   FORECASTS:
</span></pre>
<ul><li class="nobullet">
<a href="/hurricane/e_pacific/2012/JOHN/track.dat">
<img src="/hurricane/images/DETAILS.gif" border="0" alt="Details"/>Tracking information</a><br/></li></ul>
</td></tr>

<tr><td valign="top">
<a href="/hurricane/e_pacific/2012/ILEANA/track.gif">
  <img src="/hurricane/e_pacific/2012/ILEANA/track_s.gif" border="0" alt="Track"/></a><br/>
<a href="/hurricane/e_pacific/2012/ILEANA/sat_ir.gif">
  <img src="/hurricane/e_pacific/2012/ILEANA/sat_ir_s.gif" border="0" alt="Sat IR"/></a><br/>
  <b>Current: <a href="/hurricane/e_pacific/2012/ILEANA/track.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Track"/>Track</a> 
  <a href="/hurricane/e_pacific/2012/ILEANA/sat_ir.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Sat IR"/>IR</a>
  <a href="/hurricane/e_pacific/2012/ILEANA/sat_vis.gif">
     <img src="/hurricane/images/GIF.gif" border="0" alt="Sat Vis"/>Vis</a>
</b><br/>
</td><td>
<ul><li><b>Hurricane-1 ILEANA</b> (27 AUG-02 SEP)<br/>
Storm - Max Winds: 75 Category: 1<br/>
Current - Max Winds: 25 Category: TD<br/>
</li></ul>
<pre><span style="font-size:x-small;">

   WARNING POSITION:
   021200Z --- NEAR 22.7N 122.0W
     MOVEMENT PAST SIX HOURS - 270 DEGREES AT 11 KTS
     POSITION ACCURATE TO WITHIN 060 NM
     POSITION BASED ON CENTER LOCATED BY SATELLITE
   PRESENT WIND DISTRIBUTION:
   MAX SUSTAINED WINDS - 025 KT, GUSTS 035 KT
   WIND RADII VALID OVER OPEN WATER ONLY
   POST-TROP/REMNT LOW
   REPEAT POSIT: 22.7N 122.0W
    ---
   FORECASTS:
</span></pre>
<ul><li class="nobullet">
<a href="/hurricane/e_pacific/2012/ILEANA/track.dat">
<img src="/hurricane/images/DETAILS.gif" border="0" alt="Details"/>Tracking information</a><br/></li></ul>
</td></tr>

<tr><td valign="top">
<a href="/hurricane/e_pacific/2012/HECTOR/track.gif">
  <img src="/hurricane/e_pacific/2012/HECTOR/track_s.gif" border="0" alt="Track"/></a><br/>
<a href="/hurricane/e_pacific/2012/HECTOR/sat_ir.gif">
  <img src="/hurricane/e_pacific/2012/HECTOR/sat_ir_s.gif" border="0" alt="Sat IR"/></a><br/>
  <b>Current: <a href="/hurricane/e_pacific/2012/HECTOR/track.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Track"/>Track</a> 
  <a href="/hurricane/e_pacific/2012/HECTOR/sat_ir.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Sat IR"/>IR</a>
  <a href="/hurricane/e_pacific/2012/HECTOR/sat_vis.gif">
     <img src="/hurricane/images/GIF.gif" border="0" alt="Sat Vis"/>Vis</a>
</b><br/>
</td><td>
<ul><li><b>Tropical Storm HECTOR</b> (11-17 AUG)<br/>
Storm - Max Winds: 40 Category: TS<br/>
Current - Max Winds: 25 Category: TD<br/>
</li></ul>
<pre><span style="font-size:x-small;">

   WARNING POSITION:
   170600Z --- NEAR 20.5N 116.3W
     MOVEMENT PAST SIX HOURS - 325 DEGREES AT 06 KTS
     POSITION ACCURATE TO WITHIN 020 NM
     POSITION BASED ON CENTER LOCATED BY SATELLITE
   PRESENT WIND DISTRIBUTION:
   MAX SUSTAINED WINDS - 025 KT, GUSTS 035 KT
   WIND RADII VALID OVER OPEN WATER ONLY
   POST-TROP/REMNT LOW
   REPEAT POSIT: 20.5N 116.3W
    ---
   FORECASTS:
</span></pre>
<ul><li class="nobullet">
<a href="/hurricane/e_pacific/2012/HECTOR/track.dat">
<img src="/hurricane/images/DETAILS.gif" border="0" alt="Details"/>Tracking information</a><br/></li></ul>
</td></tr>

<tr><td valign="top">
<a href="/hurricane/e_pacific/2012/GILMA/track.gif">
  <img src="/hurricane/e_pacific/2012/GILMA/track_s.gif" border="0" alt="Track"/></a><br/>
<a href="/hurricane/e_pacific/2012/GILMA/sat_ir.gif">
  <img src="/hurricane/e_pacific/2012/GILMA/sat_ir_s.gif" border="0" alt="Sat IR"/></a><br/>
  <b>Current: <a href="/hurricane/e_pacific/2012/GILMA/track.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Track"/>Track</a> 
  <a href="/hurricane/e_pacific/2012/GILMA/sat_ir.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Sat IR"/>IR</a>
  <a href="/hurricane/e_pacific/2012/GILMA/sat_vis.gif">
     <img src="/hurricane/images/GIF.gif" border="0" alt="Sat Vis"/>Vis</a>
</b><br/>
</td><td>
<ul><li><b>Hurricane-1 GILMA</b> (07-11 AUG)<br/>
Storm - Max Winds: 70 Category: 1<br/>
Current - Max Winds: 30 Category: TD<br/>
</li></ul>
<pre><span style="font-size:x-small;">

   WARNING POSITION:
   111800Z --- NEAR 20.4N 120.3W
     MOVEMENT PAST SIX HOURS - 320 DEGREES AT 05 KTS
     POSITION ACCURATE TO WITHIN 020 NM
     POSITION BASED ON CENTER LOCATED BY SATELLITE
   PRESENT WIND DISTRIBUTION:
   MAX SUSTAINED WINDS - 030 KT, GUSTS 040 KT
   WIND RADII VALID OVER OPEN WATER ONLY
   DISSIPATING AS A SIGNIFICANT TROPICAL CYCLONE OVER WATER
   REPEAT POSIT: 20.4N 120.3W
    ---
   FORECASTS:
</span></pre>
<ul><li class="nobullet">
<a href="/hurricane/e_pacific/2012/GILMA/track.dat">
<img src="/hurricane/images/DETAILS.gif" border="0" alt="Details"/>Tracking information</a><br/></li></ul>
</td></tr>

<tr><td valign="top">
<a href="/hurricane/e_pacific/2012/FABIO/track.gif">
  <img src="/hurricane/e_pacific/2012/FABIO/track_s.gif" border="0" alt="Track"/></a><br/>
<a href="/hurricane/e_pacific/2012/FABIO/sat_ir.gif">
  <img src="/hurricane/e_pacific/2012/FABIO/sat_ir_s.gif" border="0" alt="Sat IR"/></a><br/>
  <b>Current: <a href="/hurricane/e_pacific/2012/FABIO/track.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Track"/>Track</a> 
  <a href="/hurricane/e_pacific/2012/FABIO/sat_ir.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Sat IR"/>IR</a>
  <a href="/hurricane/e_pacific/2012/FABIO/sat_vis.gif">
     <img src="/hurricane/images/GIF.gif" border="0" alt="Sat Vis"/>Vis</a>
</b><br/>
</td><td>
<ul><li><b>Hurricane-2 FABIO</b> (12-18 JUL)<br/>
Storm - Max Winds: 90 Category: 2<br/>
Current - Max Winds: 25 Category: TD<br/>
</li></ul>
<pre><span style="font-size:x-small;">

   WARNING POSITION:
   181200Z --- NEAR 25.3N 120.8W
     MOVEMENT PAST SIX HOURS - 355 DEGREES AT 08 KTS
     POSITION ACCURATE TO WITHIN 020 NM
     POSITION BASED ON CENTER LOCATED BY SATELLITE
   PRESENT WIND DISTRIBUTION:
   MAX SUSTAINED WINDS - 025 KT, GUSTS 035 KT
   WIND RADII VALID OVER OPEN WATER ONLY
   POST-TROP/REMNT LOW
   REPEAT POSIT: 25.3N 120.8W
    ---
   FORECASTS:
</span></pre>
<ul><li class="nobullet">
<a href="/hurricane/e_pacific/2012/FABIO/track.dat">
<img src="/hurricane/images/DETAILS.gif" border="0" alt="Details"/>Tracking information</a><br/></li></ul>
</td></tr>

<tr><td valign="top">
<a href="/hurricane/e_pacific/2012/EMILIA/track.gif">
  <img src="/hurricane/e_pacific/2012/EMILIA/track_s.gif" border="0" alt="Track"/></a><br/>
<a href="/hurricane/e_pacific/2012/EMILIA/sat_ir.gif">
  <img src="/hurricane/e_pacific/2012/EMILIA/sat_ir_s.gif" border="0" alt="Sat IR"/></a><br/>
  <b>Current: <a href="/hurricane/e_pacific/2012/EMILIA/track.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Track"/>Track</a> 
  <a href="/hurricane/e_pacific/2012/EMILIA/sat_ir.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Sat IR"/>IR</a>
  <a href="/hurricane/e_pacific/2012/EMILIA/sat_vis.gif">
     <img src="/hurricane/images/GIF.gif" border="0" alt="Sat Vis"/>Vis</a>
</b><br/>
</td><td>
<ul><li><b>Hurricane-4 EMILIA</b> (07-15 JUL)<br/>
Storm - Max Winds: 120 Category: 4<br/>
Current - Max Winds: 30 Category: TD<br/>
</li></ul>
<pre><span style="font-size:x-small;">

   WARNING POSITION:
   151200Z --- NEAR 15.7N 137.4W
     MOVEMENT PAST SIX HOURS - 270 DEGREES AT 16 KTS
     POSITION ACCURATE TO WITHIN 020 NM
     POSITION BASED ON CENTER LOCATED BY SATELLITE
   PRESENT WIND DISTRIBUTION:
   MAX SUSTAINED WINDS - 030 KT, GUSTS 040 KT
   WIND RADII VALID OVER OPEN WATER ONLY
   REPEAT POSIT: 15.7N 137.4W
    ---
   FORECASTS:
</span></pre>
<ul><li class="nobullet">
<a href="/hurricane/e_pacific/2012/EMILIA/track.dat">
<img src="/hurricane/images/DETAILS.gif" border="0" alt="Details"/>Tracking information</a><br/></li></ul>
</td></tr>

<tr><td valign="top">
<a href="/hurricane/e_pacific/2012/DANIEL/track.gif">
  <img src="/hurricane/e_pacific/2012/DANIEL/track_s.gif" border="0" alt="Track"/></a><br/>
<a href="/hurricane/e_pacific/2012/DANIEL/sat_ir.gif">
  <img src="/hurricane/e_pacific/2012/DANIEL/sat_ir_s.gif" border="0" alt="Sat IR"/></a><br/>
  <b>Current: <a href="/hurricane/e_pacific/2012/DANIEL/track.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Track"/>Track</a> 
  <a href="/hurricane/e_pacific/2012/DANIEL/sat_ir.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Sat IR"/>IR</a>
  <a href="/hurricane/e_pacific/2012/DANIEL/sat_vis.gif">
     <img src="/hurricane/images/GIF.gif" border="0" alt="Sat Vis"/>Vis</a>
</b><br/>
</td><td>
<ul><li><b>Hurricane-3 DANIEL</b> (04-12 JUL)<br/>
Storm - Max Winds: 100 Category: 3<br/>
Current - Max Winds: 30 Category: TD<br/>
</li></ul>
<pre><span style="font-size:x-small;">

   WARNING POSITION:
   120000Z --- NEAR 15.5N 143.0W
     MOVEMENT PAST SIX HOURS - 270 DEGREES AT 13 KTS
     POSITION ACCURATE TO WITHIN 020 NM
     POSITION BASED ON CENTER LOCATED BY SATELLITE
   PRESENT WIND DISTRIBUTION:
   MAX SUSTAINED WINDS - 030 KT, GUSTS 040 KT
   WIND RADII VALID OVER OPEN WATER ONLY
   REPEAT POSIT: 15.5N 143.0W
    ---
   FORECASTS:
</span></pre>
<ul><li class="nobullet">
<a href="/hurricane/e_pacific/2012/DANIEL/track.dat">
<img src="/hurricane/images/DETAILS.gif" border="0" alt="Details"/>Tracking information</a><br/></li></ul>
</td></tr>

<tr><td valign="top">
<a href="/hurricane/e_pacific/2012/CARLOTTA/track.gif">
  <img src="/hurricane/e_pacific/2012/CARLOTTA/track_s.gif" border="0" alt="Track"/></a><br/>
<a href="/hurricane/e_pacific/2012/CARLOTTA/sat_ir.gif">
  <img src="/hurricane/e_pacific/2012/CARLOTTA/sat_ir_s.gif" border="0" alt="Sat IR"/></a><br/>
  <b>Current: <a href="/hurricane/e_pacific/2012/CARLOTTA/track.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Track"/>Track</a> 
  <a href="/hurricane/e_pacific/2012/CARLOTTA/sat_ir.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Sat IR"/>IR</a>
  <a href="/hurricane/e_pacific/2012/CARLOTTA/sat_vis.gif">
     <img src="/hurricane/images/GIF.gif" border="0" alt="Sat Vis"/>Vis</a>
</b><br/>
</td><td>
<ul><li><b>Hurricane-2 CARLOTTA</b> (14-17 JUN)<br/>
Storm - Max Winds: 90 Category: 2<br/>
Current - Max Winds: 20 Category: TD<br/>
</li></ul>
<pre><span style="font-size:x-small;">

   WARNING POSITION:
   170000Z --- NEAR 18.0N 100.1W
     MOVEMENT PAST SIX HOURS - 295 DEGREES AT 05 KTS
     POSITION ACCURATE TO WITHIN 025 NM
     POSITION BASED ON CENTER LOCATED BY SATELLITE
   PRESENT WIND DISTRIBUTION:
   MAX SUSTAINED WINDS - 020 KT, GUSTS 030 KT
   WIND RADII VALID OVER OPEN WATER ONLY
   DISSIPATED AS A SIGNIFICANT TROPICAL CYCLONE OVER LAND
   REPEAT POSIT: 18.0N 100.1W
    ---
   FORECASTS:
</span></pre>
<ul><li class="nobullet">
<a href="/hurricane/e_pacific/2012/CARLOTTA/track.dat">
<img src="/hurricane/images/DETAILS.gif" border="0" alt="Details"/>Tracking information</a><br/></li></ul>
</td></tr>

<tr><td valign="top">
<a href="/hurricane/e_pacific/2012/BUD/track.gif">
  <img src="/hurricane/e_pacific/2012/BUD/track_s.gif" border="0" alt="Track"/></a><br/>
<a href="/hurricane/e_pacific/2012/BUD/sat_ir.gif">
  <img src="/hurricane/e_pacific/2012/BUD/sat_ir_s.gif" border="0" alt="Sat IR"/></a><br/>
  <b>Current: <a href="/hurricane/e_pacific/2012/BUD/track.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Track"/>Track</a> 
  <a href="/hurricane/e_pacific/2012/BUD/sat_ir.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Sat IR"/>IR</a>
  <a href="/hurricane/e_pacific/2012/BUD/sat_vis.gif">
     <img src="/hurricane/images/GIF.gif" border="0" alt="Sat Vis"/>Vis</a>
</b><br/>
</td><td>
<ul><li><b>Hurricane-3 BUD</b> (21-26 MAY)<br/>
Storm - Max Winds: 100 Category: 3<br/>
Current - Max Winds: 25 Category: TD<br/>
</li></ul>
<pre><span style="font-size:x-small;">

   WARNING POSITION:
   261200Z --- NEAR 20.5N 105.8W
     MOVEMENT PAST SIX HOURS - 350 DEGREES AT 03 KTS
     POSITION ACCURATE TO WITHIN 075 NM
     POSITION BASED ON CENTER LOCATED BY SATELLITE
   PRESENT WIND DISTRIBUTION:
   MAX SUSTAINED WINDS - 025 KT, GUSTS 035 KT
   WIND RADII VALID OVER OPEN WATER ONLY
   DISSIPATED AS A SIGNIFICANT TROPICAL CYCLONE OVER WATER
   REPEAT POSIT: 20.5N 105.8W
    ---
   FORECASTS:
</span></pre>
<ul><li class="nobullet">
<a href="/hurricane/e_pacific/2012/BUD/track.dat">
<img src="/hurricane/images/DETAILS.gif" border="0" alt="Details"/>Tracking information</a><br/></li></ul>
</td></tr>

<tr><td valign="top">
<a href="/hurricane/e_pacific/2012/ALETTA/track.gif">
  <img src="/hurricane/e_pacific/2012/ALETTA/track_s.gif" border="0" alt="Track"/></a><br/>
<a href="/hurricane/e_pacific/2012/ALETTA/sat_ir.gif">
  <img src="/hurricane/e_pacific/2012/ALETTA/sat_ir_s.gif" border="0" alt="Sat IR"/></a><br/>
  <b>Current: <a href="/hurricane/e_pacific/2012/ALETTA/track.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Track"/>Track</a> 
  <a href="/hurricane/e_pacific/2012/ALETTA/sat_ir.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Sat IR"/>IR</a>
  <a href="/hurricane/e_pacific/2012/ALETTA/sat_vis.gif">
     <img src="/hurricane/images/GIF.gif" border="0" alt="Sat Vis"/>Vis</a>
</b><br/>
</td><td>
<ul><li><b>Tropical Storm ALETTA</b> (14-19 MAY)<br/>
Storm - Max Winds: 40 Category: TS<br/>
Current - Max Winds: 25 Category: TD<br/>
</li></ul>
<pre><span style="font-size:x-small;">

   WARNING POSITION:
   191200Z --- NEAR 14.8N 112.6W
     MOVEMENT PAST SIX HOURS - 065 DEGREES AT 04 KTS
     POSITION ACCURATE TO WITHIN 030 NM
     POSITION BASED ON CENTER LOCATED BY SATELLITE
   PRESENT WIND DISTRIBUTION:
   MAX SUSTAINED WINDS - 025 KT, GUSTS 035 KT
   WIND RADII VALID OVER OPEN WATER ONLY
   DISSIPATING AS A SIGNIFICANT TROPICAL CYCLONE OVER WATER
   REPEAT POSIT: 14.8N 112.6W
    ---
   FORECASTS:
</span></pre>
<ul><li class="nobullet">
<a href="/hurricane/e_pacific/2012/ALETTA/track.dat">
<img src="/hurricane/images/DETAILS.gif" border="0" alt="Details"/>Tracking information</a><br/></li></ul>
</td></tr>

</table>
<div class="clearboth">&nbsp;</div>

</div>

<div id="footer"> <span id="copyright"><small>Copyright &copy; Unisys 2012</small></span>
  <ul class="inline-navigation-list" id="bottom-navigation">
    <li><a href="http://www.unisys.com/unisys/privacy.html" target="_blank">Privacy Notice</a></li>
    <li><a href="http://www.unisys.com/unisys/terms-and-conditions.html" target="_blank">Terms of Use</a></li>
    <li><a href="/contactus.php">Contact Us</a></li>
    <li><a href="http://www.unisys.com/unisys/trademarks.html" target="_blank">Trademarks</a></li>
  </ul>
</div>
</div>
</body>
</html>
