<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Unisys Weather  - 2011 Hurricane/Tropical Data for Eastern Pacific </title>
<meta name="description" content="The intent of this weather site is to provide a complete source of graphical weather 		information. This is intended to satisfy the needs of the weather professional, but can be a tool for the casual user as well. The graphics and data are displayed as a meteorologist would expect to see. For the novice user, there are detailed explanation pages to guide them through the various plots, charts and images. The data on this site are provided from the National Weather Service via the NOAAPORT satellite data service. All the images are generated using the Weather Processor (WXP) analysis package which is available from Unisys. "/>
<meta name="keywords" content="weather, unisys, unisys weather, weather maps, maps, nam, wrf, GFS, GFSx, hurricane, radar, satellite, surface, upper air" />
<meta name="copyright" content="Unisys Corp - 2011" />
<meta name="author" content="Unisys Corporation" />
<meta name="email" content="technical-support@weather.unisys.com" />
<meta name="Distribution" content="Global" />
<meta name="Rating" content="General" />
<meta name="Robots" content="INDEX,FOLLOW" />
<meta name="Revisit-after" content="7 Days" />
<meta http-equiv="Content-type" content="text/html;charset=UTF-8" />
<meta http-equiv="imagetoolbar" content="no" />
<meta http-equiv="Refresh" content="900" />
<meta http-equiv="X-UA-Compatible" content="IE=8"/>
<link rel="stylesheet" type="text/css" href="/css/WMAX.css" />
</head>
<body>
<div id="wrap">
  <div id="top-menu">
    <ul id="top-navigation" class="inline-navigation-list">
      <li><a href="http://www.unisys.com" title="Unisys Home Page">Unisys.com</a></li>
      <li><a href="/index.php" title="Unisys Weather">Weather Home</a></li>
      <li><a href="/analyses.php" title="Analyses">Analyses</a></li>
      <li><a href="/forehome.php" title="Forecast">Forecasts</a></li>
      <li><a href="/archives.php" title="Archives">Archives</a></li>
      <li><a href="/links.php" title="NOAA Links">NOAA Links</a></li>
      <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
    </ul>
  </div>

  <div id="header"> <a href="http://unisys.com"><img src="/images/Unisys_logo.gif" alt="Unisys" /></a>
    <h1>Unisys Weather</h1>
  </div>

<div id="leftside">
  <ul class="avmenu">
    <li><a href="/index.php" class="purple">Unisys Weather</a></li>
    <li><a href="/index.php"> Weather Home</a></li>
    <li><a href="/solutions/index.php">Weather Solutions</a></li>
    <li><a href="/mobile/index.php"><img id="mobile_icon" src="/mobile/Icon.png" width="24" height="24" alt="Download Unisys Weather Mobile App"/>iPhone App</a></li>
    <li><a href="/info/index.php">Information</a></li>
    <li><a href="/content.php">Contents</a></li>
    <li><a href="/analyses.php" class="purple">Analyses</a></li>
    <li><a href="/satellite/index.php">Satellite Images</a></li>
    <li><a href="/surface/index.php">Surface Data</a></li>
    <li><a href="/upper_air/index.php">Upper Air Data</a></li>
    <li><a href="/radar/index.php">Radar Data</a></li>
    <li><a href="/forehome.php" class="purple">Forecasts</a></li>
    <li><a href="/mos/index.php">Model Statistics</a></li>
    <li><a href="/nam/index.php">NAM/Wrf Model</a></li>
    <li><a href="/gfs/index.php?r=us">GFS/Avn Model</a></li>
    <li><a href="/gfsx/index.php?r=us">GFSx/MRF Model</a></li>
    <li><a href="/rap/index.php">RAP Model</a></li>
    <li><a href="/ecmwf/index.php">ECMWF Model</a></li>
    <li><a href="/archives.php" class="purple">Archive</a></li>
    <li><a href="/hurricane/index.php">Hurricane Data</a></li>
    <li><a href="/archive/index.php">Archive of Images</a></li>
    <li><a href="/usgs/index.php">USGS Maps</a></li>
  </ul>
</div>

<div id="extras">
  <ul class="avmenu">
    <li><a href="/foresetup.php" class="purple">Get a Forecast</a></li>
  </ul>

<script type="text/javascript">
function fsubmit()
{
     document.getElementById("Forecast").submit();
}
</script>

  <form method="get" id="Forecast" action="/forecast.php">
    <p class="center"> Enter a zip code or city name to get forecast:
      <input type="text" name="Name" id="Name" size="15" />
      <br />
      <button type="submit" style="border:none; background-color:transparent;">
         <img src="/images/GO.png" id="Go" alt="Get Forecast Data" style="height:30px;" />
      </button>
      <a href="/foresetup.php"><img src="/images/setup.png" alt="Setup Location" height="30" width="70" /></a> </p>
  </form>
  <script type="text/javascript">
                <!-- HIDE
                var index = document.cookie.indexOf("ZIP")
                var zipcode = 0
                var region = ""
                if( index != -1 ){
                   //zipcode = parseInt( document.cookie.substring(index+4,index+9),10)
                   zipcode = document.cookie.substring(index+4,index+9)
                   var validateZipCode = function() {
                     var zipcodeRegexp = /^\d{5}$/;
                     var zipTest = zipcodeRegexp.test(zipcode);
   
                     if (zipTest == false) {
                       return false;
                     }
                   }
                   validateZipCode();

                    if( ! isNaN(zipcode))

                    document.getElementById('Name').value = zipcode

                   if( zipcode >= 01000 && zipcode <= 19699 )
                      region = "ne"
                   else if( zipcode >= 19700 && zipcode <= 28999 )
                      region = "at"
                   else if( zipcode >= 43000 && zipcode <= 45999 )
                      region = "at"
                   else if( zipcode >= 29000 && zipcode <= 36999 )
                      region = "se"
                   else if( zipcode >= 38600 && zipcode <= 39999 )
                      region = "se"
                   else if( zipcode >= 46000 && zipcode <= 58999 )
                      region = "mw"
                   else if( zipcode >= 60000 && zipcode <= 62999 )
                      region = "mw"
                   else if( zipcode >= 68000 && zipcode <= 69999 )
                      region = "mw"
                   else if( zipcode >= 63000 && zipcode <= 67999 )
                      region = "cp"
                   else if( zipcode >= 71600 && zipcode <= 74999 )
                      region = "cp"
                   else if( zipcode >= 70000 && zipcode <= 71499 )
                      region = "sp"
                   else if( zipcode >= 75000 && zipcode <= 79999 )
                      region = "sp"
                   else if( zipcode >= 59000 && zipcode <= 59999 )
                      region = "nw"
                   else if( zipcode >= 82000 && zipcode <= 83999 )
                      region = "nw"
                   else if( zipcode >= 97000 && zipcode <= 99499 )
                      region = "nw"
                   else if( zipcode >= 80000 && zipcode <= 81999 )
                      region = "sw"
                   else if( zipcode >= 84000 && zipcode <= 96199 )
                      region = "sw"

                   if( region != "" ){
                      document.write( "<table border=\"0\" align=\"center\" class=\"grey\" width=\"100%\">" )
                      document.write( "<tr>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/surface/sfc_map.php?image=sfc&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Sfc" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=\"radar/rad" + region + ".php\">" )
                      document.write( "<a href=/radar/rcm_rad.php?image=rad&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Rad" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=vis&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Vis" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=enh&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>IR" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "</tr></table>" )
                      document.write( "</b>" )
                      }


                   
                   }
                // UNHIDE -->
                </script>
  <ul class="avmenu">
    <li><a href="/links.php" class="purple">NOAA Links</a></li>
    <li><a href="http://lwf.ncdc.noaa.gov/">National Climatic Data Center</a></li>
    <li><a href="http://www.cpc.noaa.gov/">Climate Prediction Center</a></li>
    <li><a href="http://oceanservice.noaa.gov/">National Ocean Service</a></li>
    <li><a href="http://www.lib.noaa.gov/">NOAA Library</a></li>
    <li><a href="http://www.oar.noaa.gov/">NOAA Office of Oceanic and Atmospheric Research</a></li>
    <li><a href="http://www.esrl.noaa.gov/">Earth Systems Research Laboratory</a></li>
    <li><a href="/overview.php" class="purple">About Us</a></li>
    <li><a href="/overview.php" title="Contact Us">Overview</a></li>
    <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
  </ul>
</div>
<div id="content">

<h2 style="font-family: helvetica,arial,sans-serif;">1997 Hurricane/Tropical Data for Eastern Pacific</h2>
<a href="/hurricane/e_pacific/1997H/track.gif">
  <img src="/hurricane/e_pacific/1997H/track.gif" width="640" height="512" alt="Track Map"/></a>
<h3 style="font-family: helvetica,arial,sans-serif;">Individual Storm Summary</h3>
<p style="font-family: helvetica,arial,sans-serif;">Winds in knots, pressure in millibars,
category is based on Saffir-Simpson scale.</p>
<table border="0">
<tr style="font-size: 10pt; font-family: helvetica,arial,sans-serif; color: black;"><td width="20" align="right">#</td><td width="250">Name</td><td width="125" align="center">Date</td><td width="40" align="right">Wind</td><td width="40" align="right">Pres</td><td width="40" align="right">Cat</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">1</td><td width="250" style="color:black;">Tropical Storm ANDRES     </td><td width="125" align="right" style="color:black;">01-06 JUN     </td><td width="40" align="right" style="color:black;"> 45 </td><td width="40" align="right" style="color:black;">1000 </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">2</td><td width="250" style="color:black;">Tropical Storm BLANCA     </td><td width="125" align="right" style="color:black;">09-12 JUN     </td><td width="40" align="right" style="color:black;"> 40 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">3</td><td width="250" style="color:black;">Tropical Depression THREE-</td><td width="125" align="right" style="color:black;">21-24 JUN     </td><td width="40" align="right" style="color:black;"> 30 </td><td width="40" align="right" style="color:black;">1006 </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">4</td><td width="250" style="color:black;">Tropical Storm CARLOS     </td><td width="125" align="right" style="color:black;">25-27 JUN     </td><td width="40" align="right" style="color:black;"> 45 </td><td width="40" align="right" style="color:black;"> 996 </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">5</td><td width="250" style="color:black;">Tropical Depression FIVE_E</td><td width="125" align="right" style="color:black;">29 JUN-04 JUL </td><td width="40" align="right" style="color:black;"> 30 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">6</td><td width="250" style="color:black;">Hurricane DOLORES         </td><td width="125" align="right" style="color:black;">06-12 JUL     </td><td width="40" align="right" style="color:black;"> 80 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  1</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">7</td><td width="250" style="color:black;">Hurricane ENRIQUE         </td><td width="125" align="right" style="color:black;">12 JAN-16 JUL </td><td width="40" align="right" style="color:black;"> 90 </td><td width="40" align="right" style="color:black;"> 970 </td><td width="40" align="right" style="color:black;">  2</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">8</td><td width="250" style="color:black;">Hurricane FELICIA         </td><td width="125" align="right" style="color:black;">14-22 JUL     </td><td width="40" align="right" style="color:black;">115 </td><td width="40" align="right" style="color:black;"> 948 </td><td width="40" align="right" style="color:black;">  4</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">9</td><td width="250" style="color:black;">Tropical Depression ONE_C </td><td width="125" align="right" style="color:black;">26-27 JUL     </td><td width="40" align="right" style="color:black;"> 25 </td><td width="40" align="right" style="color:black;">1007 </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">10</td><td width="250" style="color:black;">Hurricane GUILLERMO       </td><td width="125" align="right" style="color:black;">30 JUL-15 AUG </td><td width="40" align="right" style="color:black;">140 </td><td width="40" align="right" style="color:black;"> 921 </td><td width="40" align="right" style="color:black;">  5</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">11</td><td width="250" style="color:black;">Tropical Storm HILDA      </td><td width="125" align="right" style="color:black;">10-15 AUG     </td><td width="40" align="right" style="color:black;"> 45 </td><td width="40" align="right" style="color:black;">1000 </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">12</td><td width="250" style="color:black;">Tropical Storm IGNACIO    </td><td width="125" align="right" style="color:black;">17-18 AUG     </td><td width="40" align="right" style="color:black;"> 35 </td><td width="40" align="right" style="color:black;">1004 </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">13</td><td width="250" style="color:black;">Hurricane JIMENA          </td><td width="125" align="right" style="color:black;">25-29 AUG     </td><td width="40" align="right" style="color:black;">115 </td><td width="40" align="right" style="color:black;"> 948 </td><td width="40" align="right" style="color:black;">  4</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">14</td><td width="250" style="color:black;">Tropical Storm KEVIN      </td><td width="125" align="right" style="color:black;">03-06 SEP     </td><td width="40" align="right" style="color:black;"> 50 </td><td width="40" align="right" style="color:black;"> 994 </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">15</td><td width="250" style="color:black;">Hurricane LINDA           </td><td width="125" align="right" style="color:black;">09-17 SEP     </td><td width="40" align="right" style="color:black;">160 </td><td width="40" align="right" style="color:black;"> 900 </td><td width="40" align="right" style="color:black;">  5</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">16</td><td width="250" style="color:black;">Tropical Storm MARTY      </td><td width="125" align="right" style="color:black;">13-16 SEP     </td><td width="40" align="right" style="color:black;"> 40 </td><td width="40" align="right" style="color:black;">1002 </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">17</td><td width="250" style="color:black;">Hurricane NORA            </td><td width="125" align="right" style="color:black;">16-26 SEP     </td><td width="40" align="right" style="color:black;">110 </td><td width="40" align="right" style="color:black;"> 950 </td><td width="40" align="right" style="color:black;">  3</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">18</td><td width="250" style="color:black;">Tropical Storm OLAF       </td><td width="125" align="right" style="color:black;">26 SEP-12 OCT </td><td width="40" align="right" style="color:black;"> 60 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">19</td><td width="250" style="color:black;">Hurricane PAULINE         </td><td width="125" align="right" style="color:black;">06-10 OCT     </td><td width="40" align="right" style="color:black;">115 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  4</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">20</td><td width="250" style="color:black;">Tropical Depression FOUR_C</td><td width="125" align="right" style="color:black;">31-31 OCT     </td><td width="40" align="right" style="color:black;"> 30 </td><td width="40" align="right" style="color:black;">1012 </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">21</td><td width="250" style="color:black;">Hurricane RICK            </td><td width="125" align="right" style="color:black;">07-10 NOV     </td><td width="40" align="right" style="color:black;"> 75 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  1</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">22</td><td width="250" style="color:black;">Tropical Storm PAKA       </td><td width="125" align="right" style="color:black;">02-06 DEC     </td><td width="40" align="right" style="color:black;"> 55 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
</table><br/>
<big style="font-weight: bold;"><span
 style="font-family: helvetica,arial,sans-serif;"> Saffir-Simpson Scale</span></big>
      <p style="font-family: helvetica,arial,sans-serif;">The chart
color codes intensity (category based on Saffir-Simpson scale): </p>
      <table border="0" style="font-family: helvetica,arial,sans-serif;">
        <tbody>
          <tr>
            <td valign="top" bgcolor="#000099"
 style="color: rgb(255, 255, 255); font-weight: bold;"><small>Type</small></td>
            <td align="center" valign="top" bgcolor="#000099"
 style="color: rgb(255, 255, 255); font-weight: bold;"><small>Category</small></td>
            <td align="center" valign="top" bgcolor="#000099"
 style="color: rgb(255, 255, 255); font-weight: bold;"><small>Pressure
(mb)</small></td>
            <td align="center" valign="top" bgcolor="#000099"
 style="color: rgb(255, 255, 255); font-weight: bold;"><small>Winds<br/>
(knots)</small></td>
            <td align="center" valign="top" bgcolor="#000099"
 style="color: rgb(255, 255, 255); font-weight: bold;"><small>Winds<br/>
(mph)</small></td>
            <td align="center" valign="top" bgcolor="#000099"
 style="color: rgb(255, 255, 255); font-weight: bold;"><small>Line Color</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Depression</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>td</small></td>
            <td
 style="text-align: center; vertical-align: top; background-color: rgb(160, 224, 255); font-weight: bold;"><small>-----</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>&lt; 34</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>&lt; 39</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Green</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Tropical Storm</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>TS</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>-----</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>34-63</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>39-73</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Yellow</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Hurricane</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>1</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>&gt; 980</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>64-82</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>74-95</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Red</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Hurricane</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>2</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>965-980</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>83-95</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>96-110</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Light Red</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Hurricane</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>3</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>945-965</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>96-112</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>111-130</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Magenta</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Hurricane</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>4</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>920-945</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>113-135</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>131-155</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Light Magenta</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Hurricane</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>5</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>&lt; 920</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>&gt;135</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>&gt;155</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>White</small></td>
          </tr>
        </tbody>
      </table>
      <p style="font-family: helvetica,arial,sans-serif;"><small><b>NOTE:</b>
Pressures are in millibars and winds are in <b>knots</b> where one knot
is equal to 1.15 mph</small></p><hr/>
<h3 style="font-family: helvetica,arial,sans-serif;">Individual Storm Details</h3>
<table border="1" style="font-family: helvetica,arial,sans-serif;">

<TR><TD VALIGN=TOP>
<A HREF=PAKA/track.gif>
  <IMG SRC=PAKA/track_s.gif></A><br>
</TD><TD>
<LI><b>Tropical Storm PAKA</b> (02-06 DEC)<br>
Storm - Max Winds: 55 Category: TS<br>
<A HREF=PAKA/track.dat>
<IMG SRC=../../images/DETAILS.gif>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=RICK/track.gif>
  <IMG SRC=RICK/track_s.gif></A><br>
</TD><TD>
<LI><b>Hurricane RICK</b> (07-10 NOV)<br>
Storm - Max Winds: 75 Category: 1<br>
<p>
<A HREF=RICK/track.dat>
<IMG SRC=../../images/DETAILS.gif>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=FOUR_C/track.gif>
  <IMG SRC=FOUR_C/track_s.gif></A><br>
</TD><TD>
<LI><b>Tropical Depression FOUR_C</b> (31-31 OCT)<br>
Storm - Max Winds: 30 Min Pres: 1012 Category: TD<br>
<p>
<A HREF=FOUR_C/track.dat>
<IMG SRC=../../images/DETAILS.gif>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=PAULINE/track.gif>
  <IMG SRC=PAULINE/track_s.gif></A><br>
</TD><TD>
<LI><b>Hurricane PAULINE</b> (06-10 OCT)<br>
Storm - Max Winds: 115 Category: 4<br>
<p>
<A HREF=PAULINE/track.dat>
<IMG SRC=../../images/DETAILS.gif>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=OLAF/track.gif>
  <IMG SRC=OLAF/track_s.gif></A><br>
</TD><TD>
<LI><b>Tropical Storm OLAF</b> (26 SEP-12 OCT)<br>
Storm - Max Winds: 60 Category: TS<br>
<p>
<A HREF=OLAF/track.dat>
<IMG SRC=../../images/DETAILS.gif>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=NORA/track.gif>
  <IMG SRC=NORA/track_s.gif></A><br>
</TD><TD>
<LI><b>Hurricane NORA</b> (16-26 SEP)<br>
Storm - Max Winds: 110 Min Pres: 950 Category: 3<br>
<p>
<A HREF=NORA/track.dat>
<IMG SRC=../../images/DETAILS.gif>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=MARTY/track.gif>
  <IMG SRC=MARTY/track_s.gif></A><br>
</TD><TD>
<LI><b>Tropical Storm MARTY</b> (13-16 SEP)<br>
Storm - Max Winds: 40 Min Pres: 1002 Category: TS<br>
<p>
<A HREF=MARTY/track.dat>
<IMG SRC=../../images/DETAILS.gif>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=LINDA/track.gif>
  <IMG SRC=LINDA/track_s.gif></A><br>
<A HREF=LINDA/sat_ir_091123.gif>
  <IMG SRC=LINDA/sat_ir_091123_s.gif></A><br>
</TD><TD>
<LI><b>Hurricane LINDA</b> (09-17 SEP)<br>
Storm - Max Winds: 160 Min Pres: 900 Category: 5<br>
<p>
  <A HREF=LINDA/sat_ir_091123.gif>
     <IMG SRC=../../images/GIF.gif>IR image of Linda (23Z 11 SEP)</A><br>
  <A HREF=LINDA/sat_vis_091122.gif>
     <IMG SRC=../../images/GIF.gif>Vis image of Linda (22Z 11 SEP)</A><br>
  <A HREF=LINDA/sat_vis_091200.gif>
     <IMG SRC=../../images/GIF.gif>Large Vis of Linda at sunset</A><br>
  <A HREF=LINDA/sat_vis_091218.gif>
     <IMG SRC=../../images/GIF.gif>Vis image of Linda (18Z 12 SEP)</A><br>
  <A HREF=LINDA/sat_vis_091520.gif>
     <IMG SRC=../../images/GIF.gif>Vis image of Linda dissapating (20Z 15 SEP)</A><br>
<A HREF=LINDA/track.dat>
<IMG SRC=../../images/DETAILS.gif>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=KEVIN/track.gif>
  <IMG SRC=KEVIN/track_s.gif></A><br>
</TD><TD>
<LI><b>Tropical Storm KEVIN</b> (03-06 SEP)<br>
Storm - Max Winds: 50 Min Pres: 994 Category: TS<br>
<p>
<A HREF=KEVIN/track.dat>
<IMG SRC=../../images/DETAILS.gif>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=JIMENA/track.gif>
  <IMG SRC=JIMENA/track_s.gif></A><br>
</TD><TD>
<LI><b>Hurricane JIMENA</b> (25-29 AUG)<br>
Storm - Max Winds: 115 Min Pres: 948 Category: 4<br>
<p>
<A HREF=JIMENA/track.dat>
<IMG SRC=../../images/DETAILS.gif>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=IGNACIO/track.gif>
  <IMG SRC=IGNACIO/track_s.gif></A><br>
</TD><TD>
<LI><b>Tropical Storm IGNACIO</b> (17-18 AUG)<br>
Storm - Max Winds: 35 Min Pres: 1004 Category: TS<br>
<p>
<A HREF=IGNACIO/track.dat>
<IMG SRC=../../images/DETAILS.gif>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=HILDA/track.gif>
  <IMG SRC=HILDA/track_s.gif></A><br>
</TD><TD>
<LI><b>Tropical Storm HILDA</b> (10-15 AUG)<br>
Storm - Max Winds: 45 Min Pres: 1000 Category: TS<br>
<p>
<A HREF=HILDA/track.dat>
<IMG SRC=../../images/DETAILS.gif>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=GUILLERMO/track.gif>
  <IMG SRC=GUILLERMO/track_s.gif></A><br>
</TD><TD>
<LI><b>Hurricane GUILLERMO</b> (30 JUL-15 AUG)<br>
Storm - Max Winds: 140 Min Pres: 921 Category: 5<br>
<p>
<A HREF=GUILLERMO/track.dat>
<IMG SRC=../../images/DETAILS.gif>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=ONE_C/track.gif>
  <IMG SRC=ONE_C/track_s.gif></A><br>
</TD><TD>
<LI><b>Tropical Depression ONE_C</b> (26-27 JUL)<br>
Storm - Max Winds: 25 Min Pres: 1007 Category: TD<br>
<p>
<A HREF=ONE_C/track.dat>
<IMG SRC=../../images/DETAILS.gif>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=FELICIA/track.gif>
  <IMG SRC=FELICIA/track_s.gif></A><br>
</TD><TD>
<LI><b>Hurricane FELICIA</b> (14-22 JUL)<br>
Storm - Max Winds: 115 Min Pres: 948 Category: 4<br>
<p>
<A HREF=FELICIA/track.dat>
<IMG SRC=../../images/DETAILS.gif>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=ENRIQUE/track.gif>
  <IMG SRC=ENRIQUE/track_s.gif></A><br>
</TD><TD>
<LI><b>Hurricane ENRIQUE</b> (12 JAN-16 JUL)<br>
Storm - Max Winds: 90 Min Pres: 970 Category: 2<br>
<p>
<A HREF=ENRIQUE/track.dat>
<IMG SRC=../../images/DETAILS.gif>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=DOLORES/track.gif>
  <IMG SRC=DOLORES/track_s.gif></A><br>
</TD><TD>
<LI><b>Hurricane DOLORES</b> (06-12 JUL)<br>
Storm - Max Winds: 80 Category: 1<br>
<p>
<A HREF=DOLORES/track.dat>
<IMG SRC=../../images/DETAILS.gif>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=FIVE_E/track.gif>
  <IMG SRC=FIVE_E/track_s.gif></A><br>
</TD><TD>
<LI><b>Tropical Depression FIVE_E</b> (29 JUN-04 JUL)<br>
Storm - Max Winds: 30 Category: TD<br>
<p>
<A HREF=FIVE_E/track.dat>
<IMG SRC=../../images/DETAILS.gif>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=CARLOS/track.gif>
  <IMG SRC=CARLOS/track_s.gif></A><br>
</b><br>
</TD><TD>
<LI><b>Tropical Storm CARLOS</b> (25-27 JUN)<br>
Storm - Max Winds: 45 Min Pres: 996 Category: TS<br>
<p>
<A HREF=CARLOS/track.dat>
<IMG SRC=../../images/DETAILS.gif>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=THREE_E/track.gif>
  <IMG SRC=THREE_E/track_s.gif></A><br>
</TD><TD>
<LI><b>Tropical Depression THREE_E</b> (21-24 JUN)<br>
Storm - Max Winds: 30 Min Pres: 1006 Category: TD<br>
<p>
<A HREF=THREE_E/track.dat>
<IMG SRC=../../images/DETAILS.gif>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=BLANCA/track.gif>
  <IMG SRC=BLANCA/track_s.gif></A><br>
</TD><TD>
<LI><b>Tropical Storm BLANCA</b> (09-12 JUN)<br>
Storm - Max Winds: 40 Category: TS<br>
<p>
<A HREF=BLANCA/track.dat>
<IMG SRC=../../images/DETAILS.gif>Tracking information</A><P>
</TD></TR>

<TR><TD VALIGN=TOP>
<A HREF=ANDRES/track.gif>
  <IMG SRC=ANDRES/track_s.gif></A><br>
</TD><TD>
<LI><b>Tropical Storm ANDRES</b> (01-06 JUN)<br>
Storm - Max Winds: 45 Min Pres: 1000 Category: TS<P>
<A HREF=ANDRES/track.dat>
<IMG SRC=../../images/DETAILS.gif>Tracking information</A><P>
</TD></TR>

</table>
<div class="clearboth">&nbsp;</div>

</div>

<div id="footer"> <span id="copyright"><small>Copyright &copy; Unisys 2012</small></span>
  <ul class="inline-navigation-list" id="bottom-navigation">
    <li><a href="http://www.unisys.com/unisys/privacy.html" target="_blank">Privacy Notice</a></li>
    <li><a href="http://www.unisys.com/unisys/terms-and-conditions.html" target="_blank">Terms of Use</a></li>
    <li><a href="/contactus.php">Contact Us</a></li>
    <li><a href="http://www.unisys.com/unisys/trademarks.html" target="_blank">Trademarks</a></li>
  </ul>
</div>
</div>
</body>
</html>
