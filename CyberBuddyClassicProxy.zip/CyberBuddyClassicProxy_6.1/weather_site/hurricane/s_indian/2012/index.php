<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Unisys Weather  - 2011 Hurricane/Tropical Data for Southern Indian Ocean </title>
<meta name="description" content="The intent of this weather site is to provide a complete source of graphical weather 		information. This is intended to satisfy the needs of the weather professional, but can be a tool for the casual user as well. The graphics and data are displayed as a meteorologist would expect to see. For the novice user, there are detailed explanation pages to guide them through the various plots, charts and images. The data on this site are provided from the National Weather Service via the NOAAPORT satellite data service. All the images are generated using the Weather Processor (WXP) analysis package which is available from Unisys. "/>
<meta name="keywords" content="weather, unisys, unisys weather, weather maps, maps, nam, wrf, GFS, GFSx, hurricane, radar, satellite, surface, upper air" />
<meta name="copyright" content="Unisys Corp - 2011" />
<meta name="author" content="Unisys Corporation" />
<meta name="email" content="technical-support@weather.unisys.com" />
<meta name="Distribution" content="Global" />
<meta name="Rating" content="General" />
<meta name="Robots" content="INDEX,FOLLOW" />
<meta name="Revisit-after" content="7 Days" />
<meta http-equiv="Content-type" content="text/html;charset=UTF-8" />
<meta http-equiv="imagetoolbar" content="no" />
<meta http-equiv="Refresh" content="900" />
<meta http-equiv="X-UA-Compatible" content="IE=8"/>
<link rel="stylesheet" type="text/css" href="/css/WMAX.css" />
</head>
<body>
<div id="wrap">
  <div id="top-menu">
    <ul id="top-navigation" class="inline-navigation-list">
      <li><a href="http://www.unisys.com" title="Unisys Home Page">Unisys.com</a></li>
      <li><a href="/index.php" title="Unisys Weather">Weather Home</a></li>
      <li><a href="/analyses.php" title="Analyses">Analyses</a></li>
      <li><a href="/forehome.php" title="Forecast">Forecasts</a></li>
      <li><a href="/archives.php" title="Archives">Archives</a></li>
      <li><a href="/links.php" title="NOAA Links">NOAA Links</a></li>
      <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
    </ul>
  </div>

  <div id="header"> <a href="http://unisys.com"><img src="/images/Unisys_logo.gif" alt="Unisys" /></a>
    <h1>Unisys Weather</h1>
  </div>

<div id="leftside">
  <ul class="avmenu">
    <li><a href="/index.php" class="purple">Unisys Weather</a></li>
    <li><a href="/index.php"> Weather Home</a></li>
    <li><a href="/solutions/index.php">Weather Solutions</a></li>
    <li><a href="/mobile/index.php"><img id="mobile_icon" src="/mobile/Icon.png" width="24" height="24" alt="Download Unisys Weather Mobile App"/>iPhone App</a></li>
    <li><a href="/info/index.php">Information</a></li>
    <li><a href="/content.php">Contents</a></li>
    <li><a href="/analyses.php" class="purple">Analyses</a></li>
    <li><a href="/satellite/index.php">Satellite Images</a></li>
    <li><a href="/surface/index.php">Surface Data</a></li>
    <li><a href="/upper_air/index.php">Upper Air Data</a></li>
    <li><a href="/radar/index.php">Radar Data</a></li>
    <li><a href="/forehome.php" class="purple">Forecasts</a></li>
    <li><a href="/mos/index.php">Model Statistics</a></li>
    <li><a href="/nam/index.php">NAM/Wrf Model</a></li>
    <li><a href="/gfs/index.php?r=us">GFS/Avn Model</a></li>
    <li><a href="/gfsx/index.php?r=us">GFSx/MRF Model</a></li>
    <li><a href="/rap/index.php">RAP Model</a></li>
    <li><a href="/ecmwf/index.php">ECMWF Model</a></li>
    <li><a href="/archives.php" class="purple">Archive</a></li>
    <li><a href="/hurricane/index.php">Hurricane Data</a></li>
    <li><a href="/archive/index.php">Archive of Images</a></li>
    <li><a href="/usgs/index.php">USGS Maps</a></li>
  </ul>
</div>

<div id="extras">
  <ul class="avmenu">
    <li><a href="/foresetup.php" class="purple">Get a Forecast</a></li>
  </ul>

<script type="text/javascript">
function fsubmit()
{
     document.getElementById("Forecast").submit();
}
</script>

  <form method="get" id="Forecast" action="/forecast.php">
    <p class="center"> Enter a zip code or city name to get forecast:
      <input type="text" name="Name" id="Name" size="15" />
      <br />
      <button type="submit" style="border:none; background-color:transparent;">
         <img src="/images/GO.png" id="Go" alt="Get Forecast Data" style="height:30px;" />
      </button>
      <a href="/foresetup.php"><img src="/images/setup.png" alt="Setup Location" height="30" width="70" /></a> </p>
  </form>
  <script type="text/javascript">
                <!-- HIDE
                var index = document.cookie.indexOf("ZIP")
                var zipcode = 0
                var region = ""
                if( index != -1 ){
                   //zipcode = parseInt( document.cookie.substring(index+4,index+9),10)
                   zipcode = document.cookie.substring(index+4,index+9)
                   var validateZipCode = function() {
                     var zipcodeRegexp = /^\d{5}$/;
                     var zipTest = zipcodeRegexp.test(zipcode);
   
                     if (zipTest == false) {
                       return false;
                     }
                   }
                   validateZipCode();

                    if( ! isNaN(zipcode))

                    document.getElementById('Name').value = zipcode

                   if( zipcode >= 01000 && zipcode <= 19699 )
                      region = "ne"
                   else if( zipcode >= 19700 && zipcode <= 28999 )
                      region = "at"
                   else if( zipcode >= 43000 && zipcode <= 45999 )
                      region = "at"
                   else if( zipcode >= 29000 && zipcode <= 36999 )
                      region = "se"
                   else if( zipcode >= 38600 && zipcode <= 39999 )
                      region = "se"
                   else if( zipcode >= 46000 && zipcode <= 58999 )
                      region = "mw"
                   else if( zipcode >= 60000 && zipcode <= 62999 )
                      region = "mw"
                   else if( zipcode >= 68000 && zipcode <= 69999 )
                      region = "mw"
                   else if( zipcode >= 63000 && zipcode <= 67999 )
                      region = "cp"
                   else if( zipcode >= 71600 && zipcode <= 74999 )
                      region = "cp"
                   else if( zipcode >= 70000 && zipcode <= 71499 )
                      region = "sp"
                   else if( zipcode >= 75000 && zipcode <= 79999 )
                      region = "sp"
                   else if( zipcode >= 59000 && zipcode <= 59999 )
                      region = "nw"
                   else if( zipcode >= 82000 && zipcode <= 83999 )
                      region = "nw"
                   else if( zipcode >= 97000 && zipcode <= 99499 )
                      region = "nw"
                   else if( zipcode >= 80000 && zipcode <= 81999 )
                      region = "sw"
                   else if( zipcode >= 84000 && zipcode <= 96199 )
                      region = "sw"

                   if( region != "" ){
                      document.write( "<table border=\"0\" align=\"center\" class=\"grey\" width=\"100%\">" )
                      document.write( "<tr>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/surface/sfc_map.php?image=sfc&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Sfc" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=\"radar/rad" + region + ".php\">" )
                      document.write( "<a href=/radar/rcm_rad.php?image=rad&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Rad" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=vis&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Vis" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=enh&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>IR" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "</tr></table>" )
                      document.write( "</b>" )
                      }


                   
                   }
                // UNHIDE -->
                </script>
  <ul class="avmenu">
    <li><a href="/links.php" class="purple">NOAA Links</a></li>
    <li><a href="http://lwf.ncdc.noaa.gov/">National Climatic Data Center</a></li>
    <li><a href="http://www.cpc.noaa.gov/">Climate Prediction Center</a></li>
    <li><a href="http://oceanservice.noaa.gov/">National Ocean Service</a></li>
    <li><a href="http://www.lib.noaa.gov/">NOAA Library</a></li>
    <li><a href="http://www.oar.noaa.gov/">NOAA Office of Oceanic and Atmospheric Research</a></li>
    <li><a href="http://www.esrl.noaa.gov/">Earth Systems Research Laboratory</a></li>
    <li><a href="/overview.php" class="purple">About Us</a></li>
    <li><a href="/overview.php" title="Contact Us">Overview</a></li>
    <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
  </ul>
</div>
<div id="content">

<h2 style="font-family: helvetica,arial,sans-serif;">2012 Hurricane/Tropical Data for Southern Indian Ocean</h2>
<a href="/hurricane/s_indian/2012/track.gif">
  <img src="/hurricane/s_indian/2012/track.gif" width="640" height="512" alt="Track Map"/></a>
<h3 style="font-family: helvetica,arial,sans-serif;">Individual Storm Summary</h3>
<p style="font-family: helvetica,arial,sans-serif;">Winds in knots, pressure in millibars,
category is based on Saffir-Simpson scale.</p>
<table border="0">
<tr style="font-size: 10pt; font-family: helvetica,arial,sans-serif; color: black;"><td width="20" align="right">#</td><td width="250">Name</td><td width="125" align="center">Date</td><td width="40" align="right">Wind</td><td width="40" align="right">Pres</td><td width="40" align="right">Cat</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">1</td><td width="250" style="color:black;">Cyclone-2 BENILDE         </td><td width="125" align="right" style="color:black;">28 DEC-04 JAN </td><td width="40" align="right" style="color:black;">    </td><td width="40" align="right" style="color:black;"> 85  </td><td width="40" align="right" style="color:black;">   </td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">2</td><td width="250" style="color:black;">Tropical Storm CHANDA     </td><td width="125" align="right" style="color:black;">07-08 JAN     </td><td width="40" align="right" style="color:black;"> 35 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">3</td><td width="250" style="color:black;">Tropical Storm HEIDI      </td><td width="125" align="right" style="color:black;">10-11 JAN     </td><td width="40" align="right" style="color:black;"> 55 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">4</td><td width="250" style="color:black;">Cyclone-1 ETHEL           </td><td width="125" align="right" style="color:black;">19-22 JAN     </td><td width="40" align="right" style="color:black;"> 75 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  1</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">5</td><td width="250" style="color:black;">Cyclone-4 FUNSO           </td><td width="125" align="right" style="color:black;">19-28 JAN     </td><td width="40" align="right" style="color:black;">120 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  4</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">6</td><td width="250" style="color:black;">Cyclone-1 IGGY            </td><td width="125" align="right" style="color:black;">25 JAN-02 FEB </td><td width="40" align="right" style="color:black;"> 65 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  1</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">7</td><td width="250" style="color:black;">Cyclone-4 GIOVANNA        </td><td width="125" align="right" style="color:black;">09-21 FEB     </td><td width="40" align="right" style="color:black;">125 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  4</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">8</td><td width="250" style="color:black;">Tropical Storm HILWA      </td><td width="125" align="right" style="color:black;">14-22 FEB     </td><td width="40" align="right" style="color:black;"> 50 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">9</td><td width="250" style="color:black;">Tropical Storm IRINA      </td><td width="125" align="right" style="color:black;">29 FEB-10 MAR </td><td width="40" align="right" style="color:black;"> 60 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">10</td><td width="250" style="color:black;">Tropical Storm FIFTEEN    </td><td width="125" align="right" style="color:black;">29 FEB-01 MAR </td><td width="40" align="right" style="color:black;"> 35 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">11</td><td width="250" style="color:black;">Cyclone-1 KOJI            </td><td width="125" align="right" style="color:black;">07-12 MAR     </td><td width="40" align="right" style="color:black;"> 70 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  1</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">12</td><td width="250" style="color:black;">Cyclone-2 LUA             </td><td width="125" align="right" style="color:black;">13-17 MAR     </td><td width="40" align="right" style="color:black;"> 95 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  2</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">13</td><td width="250" style="color:black;">Tropical Storm NINETEEN   </td><td width="125" align="right" style="color:black;">07-07 MAY     </td><td width="40" align="right" style="color:black;"> 35 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">14</td><td width="250" style="color:black;">Tropical Storm KUENA      </td><td width="125" align="right" style="color:black;">06-07 JUN     </td><td width="40" align="right" style="color:black;"> 50 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">15</td><td width="250" style="color:black;">Cyclone-3 ANAIS           </td><td width="125" align="right" style="color:black;">12-17 OCT     </td><td width="40" align="right" style="color:black;">105 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  3</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">16</td><td width="250" style="color:black;">Tropical Storm BOLDWIN    </td><td width="125" align="right" style="color:black;">24-25 NOV     </td><td width="40" align="right" style="color:black;"> 55 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">17</td><td width="250" style="color:black;">Cyclone-3 CLAUDIA         </td><td width="125" align="right" style="color:black;">06-13 DEC     </td><td width="40" align="right" style="color:black;">105 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  3</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:black;">18</td><td width="250" style="color:black;">Tropical Storm MITCHELL   </td><td width="125" align="right" style="color:black;">28-30 DEC     </td><td width="40" align="right" style="color:black;"> 45 </td><td width="40" align="right" style="color:black;">     </td><td width="40" align="right" style="color:black;">  -</td><td>&nbsp;</td>
</tr>
<tr><td width="20" align="right" style="color:red;">19</td><td width="250" style="color:red;">Tropical Storm SEVEN      </td><td width="125" align="right" style="color:red;">31-31 DEC     </td><td width="40" align="right" style="color:red;"> 35 </td><td width="40" align="right" style="color:red;">     </td><td width="40" align="right" style="color:red;">  -</td><td width="60" align="right" style="color:red;">Active</td>
</tr>
</table><br/>
<big style="font-weight: bold;"><span
 style="font-family: helvetica,arial,sans-serif;"> Saffir-Simpson Scale</span></big>
      <p style="font-family: helvetica,arial,sans-serif;">The chart
color codes intensity (category based on Saffir-Simpson scale): </p>
      <table border="0" style="font-family: helvetica,arial,sans-serif;">
        <tbody>
          <tr>
            <td valign="top" bgcolor="#000099"
 style="color: rgb(255, 255, 255); font-weight: bold;"><small>Type</small></td>
            <td align="center" valign="top" bgcolor="#000099"
 style="color: rgb(255, 255, 255); font-weight: bold;"><small>Category</small></td>
            <td align="center" valign="top" bgcolor="#000099"
 style="color: rgb(255, 255, 255); font-weight: bold;"><small>Pressure
(mb)</small></td>
            <td align="center" valign="top" bgcolor="#000099"
 style="color: rgb(255, 255, 255); font-weight: bold;"><small>Winds<br/>
(knots)</small></td>
            <td align="center" valign="top" bgcolor="#000099"
 style="color: rgb(255, 255, 255); font-weight: bold;"><small>Winds<br/>
(mph)</small></td>
            <td align="center" valign="top" bgcolor="#000099"
 style="color: rgb(255, 255, 255); font-weight: bold;"><small>Line Color</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Depression</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>td</small></td>
            <td
 style="text-align: center; vertical-align: top; background-color: rgb(160, 224, 255); font-weight: bold;"><small>-----</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>&lt; 34</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>&lt; 39</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Green</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Tropical Storm</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>TS</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>-----</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>34-63</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>39-73</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Yellow</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Hurricane</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>1</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>&gt; 980</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>64-82</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>74-95</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Red</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Hurricane</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>2</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>965-980</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>83-95</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>96-110</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Light Red</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Hurricane</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>3</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>945-965</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>96-112</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>111-130</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Magenta</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Hurricane</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>4</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>920-945</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>113-135</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>131-155</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Light Magenta</small></td>
          </tr>
          <tr>
            <td valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>Hurricane</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>5</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>&lt; 920</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>&gt;135</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>&gt;155</small></td>
            <td align="center" valign="top" bgcolor="#a0e0ff"
 style="font-weight: bold;"><small>White</small></td>
          </tr>
        </tbody>
      </table>
      <p style="font-family: helvetica,arial,sans-serif;"><small><b>NOTE:</b>
Pressures are in millibars and winds are in <b>knots</b> where one knot
is equal to 1.15 mph</small></p><hr/>
<h3 style="font-family: helvetica,arial,sans-serif;">Individual Storm Details</h3>
<table border="1" style="font-family: helvetica,arial,sans-serif;">

<tr><td valign="top">
<a href="/hurricane/s_indian/2012/SEVEN/track.gif">
  <img src="/hurricane/s_indian/2012/SEVEN/track_s.gif" border="0" alt="Track"/></a><br/>

  <b>Current: <a href="/hurricane/s_indian/2012/SEVEN/track.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Track"/>Track</a> 
</b><br/>
</td><td>
<ul><li><b>Tropical Storm SEVEN</b> (31-31 DEC)<br/>
Storm - Max Winds: 35 Category: TS<br/>
Current - Max Winds: 35 Category: TS<br/>
</li></ul>
<pre><span style="font-size:x-small;">

   WARNING POSITION:
   311800Z --- NEAR 11.9S 56.4E
     MOVEMENT PAST SIX HOURS - 255 DEGREES AT 13 KTS
     POSITION ACCURATE TO WITHIN 060 NM
     POSITION BASED ON CENTER LOCATED BY SATELLITE
   PRESENT WIND DISTRIBUTION:
   MAX SUSTAINED WINDS - 035 KT, GUSTS 045 KT
   WIND RADII VALID OVER OPEN WATER ONLY
   REPEAT POSIT: 11.9S 56.4E
    ---
   FORECASTS:
</span></pre>
<ul><li class="nobullet">
<a href="/hurricane/s_indian/2012/SEVEN/track.dat">
<img src="/hurricane/images/DETAILS.gif" border="0" alt="Details"/>Tracking information</a><br/></li></ul>
</td></tr>

<tr><td valign="top">
<a href="/hurricane/s_indian/2012/MITCHELL/track.gif">
  <img src="/hurricane/s_indian/2012/MITCHELL/track_s.gif" border="0" alt="Track"/></a><br/>

  <b>Current: <a href="/hurricane/s_indian/2012/MITCHELL/track.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Track"/>Track</a> 
</b><br/>
</td><td>
<ul><li><b>Tropical Storm MITCHELL</b> (28-30 DEC)<br/>
Storm - Max Winds: 45 Category: TS<br/>
Current - Max Winds: 35 Category: TS<br/>
</li></ul>
<pre><span style="font-size:x-small;">

   WARNING POSITION:
   300600Z --- NEAR 22.6S 110.0E
     MOVEMENT PAST SIX HOURS - 185 DEGREES AT 13 KTS
     POSITION ACCURATE TO WITHIN 060 NM
     POSITION BASED ON CENTER LOCATED BY SATELLITE
   PRESENT WIND DISTRIBUTION:
   MAX SUSTAINED WINDS - 035 KT, GUSTS 045 KT
   WIND RADII VALID OVER OPEN WATER ONLY
   DISSIPATING AS A SIGNIFICANT TROPICAL CYCLONE OVER WATER
   REPEAT POSIT: 22.6S 110.0E
    ---
   FORECASTS:
</span></pre>
<ul><li class="nobullet">
<a href="/hurricane/s_indian/2012/MITCHELL/track.dat">
<img src="/hurricane/images/DETAILS.gif" border="0" alt="Details"/>Tracking information</a><br/></li></ul>
</td></tr>

<tr><td valign="top">
<a href="/hurricane/s_indian/2012/CLAUDIA/track.gif">
  <img src="/hurricane/s_indian/2012/CLAUDIA/track_s.gif" border="0" alt="Track"/></a><br/>

  <b>Current: <a href="/hurricane/s_indian/2012/CLAUDIA/track.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Track"/>Track</a> 
</b><br/>
</td><td>
<ul><li><b>Cyclone-3 CLAUDIA</b> (06-13 DEC)<br/>
Storm - Max Winds: 105 Category: 3<br/>
Current - Max Winds: 35 Category: TS<br/>
</li></ul>
<pre><span style="font-size:x-small;">

   WARNING POSITION:
   130000Z --- NEAR 27.6S 75.3E
     MOVEMENT PAST SIX HOURS - 150 DEGREES AT 14 KTS
     POSITION ACCURATE TO WITHIN 030 NM
     POSITION BASED ON CENTER LOCATED BY SATELLITE
   PRESENT WIND DISTRIBUTION:
   MAX SUSTAINED WINDS - 035 KT, GUSTS 045 KT
   WIND RADII VALID OVER OPEN WATER ONLY
   BECOMING EXTRATROPICAL
   REPEAT POSIT: 27.6S 75.3E
    ---
   FORECASTS:
</span></pre>
<ul><li class="nobullet">
<a href="/hurricane/s_indian/2012/CLAUDIA/track.dat">
<img src="/hurricane/images/DETAILS.gif" border="0" alt="Details"/>Tracking information</a><br/></li></ul>
</td></tr>

<tr><td valign="top">
<a href="/hurricane/s_indian/2012/BOLDWIN/track.gif">
  <img src="/hurricane/s_indian/2012/BOLDWIN/track_s.gif" border="0" alt="Track"/></a><br/>

  <b>Current: <a href="/hurricane/s_indian/2012/BOLDWIN/track.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Track"/>Track</a> 
</b><br/>
</td><td>
<ul><li><b>Tropical Storm BOLDWIN</b> (24-25 NOV)<br/>
Storm - Max Winds: 55 Category: TS<br/>
Current - Max Winds: 35 Category: TS<br/>
</li></ul>
<pre><span style="font-size:x-small;">

   WARNING POSITION:
   251800Z --- NEAR 15.2S 71.6E
     MOVEMENT PAST SIX HOURS - 250 DEGREES AT 09 KTS
     POSITION ACCURATE TO WITHIN 060 NM
     POSITION BASED ON CENTER LOCATED BY SATELLITE
   PRESENT WIND DISTRIBUTION:
   MAX SUSTAINED WINDS - 035 KT, GUSTS 045 KT
   WIND RADII VALID OVER OPEN WATER ONLY
   DISSIPATING AS A SIGNIFICANT TROPICAL CYCLONE OVER WATER
   REPEAT POSIT: 15.2S 71.6E
    ---
   FORECASTS:
</span></pre>
<ul><li class="nobullet">
<a href="/hurricane/s_indian/2012/BOLDWIN/track.dat">
<img src="/hurricane/images/DETAILS.gif" border="0" alt="Details"/>Tracking information</a><br/></li></ul>
</td></tr>

<tr><td valign="top">
<a href="/hurricane/s_indian/2012/ANAIS/track.gif">
  <img src="/hurricane/s_indian/2012/ANAIS/track_s.gif" border="0" alt="Track"/></a><br/>

  <b>Current: <a href="/hurricane/s_indian/2012/ANAIS/track.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Track"/>Track</a> 
</b><br/>
</td><td>
<ul><li><b>Cyclone-3 ANAIS</b> (12-17 OCT)<br/>
Storm - Max Winds: 105 Category: 3<br/>
Current - Max Winds: 35 Category: TS<br/>
</li></ul>
<pre><span style="font-size:x-small;">

   WARNING POSITION:
   171200Z --- NEAR 16.0S 56.6E
     MOVEMENT PAST SIX HOURS - 235 DEGREES AT 11 KTS
     POSITION ACCURATE TO WITHIN 015 NM
     POSITION BASED ON CENTER LOCATED BY SATELLITE
   PRESENT WIND DISTRIBUTION:
   MAX SUSTAINED WINDS - 035 KT, GUSTS 045 KT
   WIND RADII VALID OVER OPEN WATER ONLY
   DISSIPATING AS A SIGNIFICANT TROPICAL CYCLONE OVER WATER
   REPEAT POSIT: 16.0S 56.6E
    ---
   FORECASTS:
</span></pre>
<ul><li class="nobullet">
<a href="/hurricane/s_indian/2012/ANAIS/track.dat">
<img src="/hurricane/images/DETAILS.gif" border="0" alt="Details"/>Tracking information</a><br/></li></ul>
</td></tr>

<tr><td valign="top">
<a href="/hurricane/s_indian/2012/KUENA/track.gif">
  <img src="/hurricane/s_indian/2012/KUENA/track_s.gif" border="0" alt="Track"/></a><br/>

  <b>Current: <a href="/hurricane/s_indian/2012/KUENA/track.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Track"/>Track</a> 
</b><br/>
</td><td>
<ul><li><b>Tropical Storm KUENA</b> (06-07 JUN)<br/>
Storm - Max Winds: 50 Category: TS<br/>
Current - Max Winds: 30 Category: TD<br/>
</li></ul>
<pre><span style="font-size:x-small;">

   WARNING POSITION:
   071200Z --- NEAR 8.7S 55.5E
     MOVEMENT PAST SIX HOURS - 310 DEGREES AT 06 KTS
     POSITION ACCURATE TO WITHIN 020 NM
     POSITION BASED ON CENTER LOCATED BY SATELLITE
   PRESENT WIND DISTRIBUTION:
   MAX SUSTAINED WINDS - 030 KT, GUSTS 040 KT
   WIND RADII VALID OVER OPEN WATER ONLY
   DISSIPATED AS A SIGNIFICANT TROPICAL CYCLONE OVER WATER
   REPEAT POSIT: 8.7S 55.5E
    ---
   FORECASTS:
</span></pre>
<ul><li class="nobullet">
<a href="/hurricane/s_indian/2012/KUENA/track.dat">
<img src="/hurricane/images/DETAILS.gif" border="0" alt="Details"/>Tracking information</a><br/></li></ul>
</td></tr>

<tr><td valign="top">
<a href="/hurricane/s_indian/2012/NINETEEN/track.gif">
  <img src="/hurricane/s_indian/2012/NINETEEN/track_s.gif" border="0" alt="Track"/></a><br/>

  <b>Current: <a href="/hurricane/s_indian/2012/NINETEEN/track.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Track"/>Track</a> 
</b><br/>
</td><td>
<ul><li><b>Tropical Storm NINETEEN</b> (07-07 MAY)<br/>
Storm - Max Winds: 35 Category: TS<br/>
Current - Max Winds: 30 Category: TD<br/>
</li></ul>
<pre><span style="font-size:x-small;">

   WARNING POSITION:
   071200Z --- NEAR 8.1S 129.8E
     MOVEMENT PAST SIX HOURS - 160 DEGREES AT 13 KTS
     POSITION ACCURATE TO WITHIN 060 NM
     POSITION BASED ON CENTER LOCATED BY SATELLITE
   PRESENT WIND DISTRIBUTION:
   MAX SUSTAINED WINDS - 030 KT, GUSTS 040 KT
   WIND RADII VALID OVER OPEN WATER ONLY
   REPEAT POSIT: 8.1S 129.8E
    ---
   FORECASTS:
</span></pre>
<ul><li class="nobullet">
<a href="/hurricane/s_indian/2012/NINETEEN/track.dat">
<img src="/hurricane/images/DETAILS.gif" border="0" alt="Details"/>Tracking information</a><br/></li></ul>
</td></tr>

<tr><td valign="top">
<a href="/hurricane/s_indian/2012/LUA/track.gif">
  <img src="/hurricane/s_indian/2012/LUA/track_s.gif" border="0" alt="Track"/></a><br/>

  <b>Current: <a href="/hurricane/s_indian/2012/LUA/track.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Track"/>Track</a> 
</b><br/>
</td><td>
<ul><li><b>Cyclone-2 LUA</b> (13-17 MAR)<br/>
Storm - Max Winds: 95 Category: 2<br/>
Current - Max Winds: 60 Category: TS<br/>
</li></ul>
<pre><span style="font-size:x-small;">

   WARNING POSITION:
   171200Z --- NEAR 21.5S 120.3E
     MOVEMENT PAST SIX HOURS - 170 DEGREES AT 18 KTS
     POSITION ACCURATE TO WITHIN 025 NM
     POSITION BASED ON CENTER LOCATED BY A COMBINATION OF
     SATELLITE, RADAR AND SYNOPTIC DATA
   PRESENT WIND DISTRIBUTION:
   MAX SUSTAINED WINDS - 060 KT, GUSTS 075 KT
   WIND RADII VALID OVER OPEN WATER ONLY
   DISSIPATING AS A SIGNIFICANT TROPICAL CYCLONE OVER LAND
   REPEAT POSIT: 21.5S 120.3E
    ---
   FORECASTS:
</span></pre>
<ul><li class="nobullet">
<a href="/hurricane/s_indian/2012/LUA/track.dat">
<img src="/hurricane/images/DETAILS.gif" border="0" alt="Details"/>Tracking information</a><br/></li></ul>
</td></tr>

<tr><td valign="top">
<a href="/hurricane/s_indian/2012/KOJI/track.gif">
  <img src="/hurricane/s_indian/2012/KOJI/track_s.gif" border="0" alt="Track"/></a><br/>

  <b>Current: <a href="/hurricane/s_indian/2012/KOJI/track.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Track"/>Track</a> 
</b><br/>
</td><td>
<ul><li><b>Cyclone-1 KOJI</b> (07-12 MAR)<br/>
Storm - Max Winds: 70 Category: 1<br/>
Current - Max Winds: 35 Category: TS<br/>
</li></ul>
<pre><span style="font-size:x-small;">

   WARNING POSITION:
   120600Z --- NEAR 27.4S 81.7E
     MOVEMENT PAST SIX HOURS - 135 DEGREES AT 13 KTS
     POSITION ACCURATE TO WITHIN 040 NM
     POSITION BASED ON CENTER LOCATED BY SATELLITE
   PRESENT WIND DISTRIBUTION:
   MAX SUSTAINED WINDS - 035 KT, GUSTS 045 KT
   WIND RADII VALID OVER OPEN WATER ONLY
   DISSIPATING AS A SIGNIFICANT TROPICAL CYCLONE OVER WATER
   REPEAT POSIT: 27.4S 81.7E
    ---
   FORECASTS:
</span></pre>
<ul><li class="nobullet">
<a href="/hurricane/s_indian/2012/KOJI/track.dat">
<img src="/hurricane/images/DETAILS.gif" border="0" alt="Details"/>Tracking information</a><br/></li></ul>
</td></tr>

<tr><td valign="top">
<a href="/hurricane/s_indian/2012/FIFTEEN/track.gif">
  <img src="/hurricane/s_indian/2012/FIFTEEN/track_s.gif" border="0" alt="Track"/></a><br/>

  <b>Current: <a href="/hurricane/s_indian/2012/FIFTEEN/track.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Track"/>Track</a> 
</b><br/>
</td><td>
<ul><li><b>Tropical Storm FIFTEEN</b> (29 FEB-01 MAR)<br/>
Storm - Max Winds: 35 Category: TS<br/>
Current - Max Winds: 30 Category: TD<br/>
</li></ul>
<pre><span style="font-size:x-small;">

   WARNING POSITION:
   011800Z --- NEAR 15.3S 63.7E
     MOVEMENT PAST SIX HOURS - 245 DEGREES AT 07 KTS
     POSITION ACCURATE TO WITHIN 040 NM
     POSITION BASED ON CENTER LOCATED BY SATELLITE
   PRESENT WIND DISTRIBUTION:
   MAX SUSTAINED WINDS - 030 KT, GUSTS 040 KT
   WIND RADII VALID OVER OPEN WATER ONLY
   DISSIPATED AS A SIGNIFICANT TROPICAL CYCLONE OVER WATER
   REPEAT POSIT: 15.3S 63.7E
    ---
   FORECASTS:
</span></pre>
<ul><li class="nobullet">
<a href="/hurricane/s_indian/2012/FIFTEEN/track.dat">
<img src="/hurricane/images/DETAILS.gif" border="0" alt="Details"/>Tracking information</a><br/></li></ul>
</td></tr>

<tr><td valign="top">
<a href="/hurricane/s_indian/2012/IRINA/track.gif">
  <img src="/hurricane/s_indian/2012/IRINA/track_s.gif" border="0" alt="Track"/></a><br/>

  <b>Current: <a href="/hurricane/s_indian/2012/IRINA/track.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Track"/>Track</a> 
</b><br/>
</td><td>
<ul><li><b>Tropical Storm IRINA</b> (29 FEB-10 MAR)<br/>
Storm - Max Winds: 60 Category: TS<br/>
Current - Max Winds: 30 Category: TD<br/>
</li></ul>
<pre><span style="font-size:x-small;">

   WARNING POSITION:
   100000Z --- NEAR 29.6S 36.3E
     MOVEMENT PAST SIX HOURS - 270 DEGREES AT 05 KTS
     POSITION ACCURATE TO WITHIN 060 NM
     POSITION BASED ON CENTER LOCATED BY SATELLITE
   PRESENT WIND DISTRIBUTION:
   MAX SUSTAINED WINDS - 030 KT, GUSTS 040 KT
   WIND RADII VALID OVER OPEN WATER ONLY
   DISSIPATED AS A SIGNIFICANT TROPICAL CYCLONE OVER WATER
   REPEAT POSIT: 29.6S 36.3E
    ---
   FORECASTS:
</span></pre>
<ul><li class="nobullet">
<a href="/hurricane/s_indian/2012/IRINA/track.dat">
<img src="/hurricane/images/DETAILS.gif" border="0" alt="Details"/>Tracking information</a><br/></li></ul>
</td></tr>

<tr><td valign="top">
<a href="/hurricane/s_indian/2012/HILWA/track.gif">
  <img src="/hurricane/s_indian/2012/HILWA/track_s.gif" border="0" alt="Track"/></a><br/>

  <b>Current: <a href="/hurricane/s_indian/2012/HILWA/track.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Track"/>Track</a> 
</b><br/>
</td><td>
<ul><li><b>Tropical Storm HILWA</b> (14-22 FEB)<br/>
Storm - Max Winds: 50 Category: TS<br/>
Current - Max Winds: 35 Category: TS<br/>
</li></ul>
<pre><span style="font-size:x-small;">

   WARNING POSITION:
   220600Z --- NEAR 22.5S 63.6E
     MOVEMENT PAST SIX HOURS - 175 DEGREES AT 11 KTS
     POSITION ACCURATE TO WITHIN 030 NM
     POSITION BASED ON CENTER LOCATED BY SATELLITE
   PRESENT WIND DISTRIBUTION:
   MAX SUSTAINED WINDS - 035 KT, GUSTS 045 KT
   WIND RADII VALID OVER OPEN WATER ONLY
   DISSIPATING AS A SIGNIFICANT TROPICAL CYCLONE OVER WATER
   REPEAT POSIT: 22.5S 63.6E
    ---
   FORECASTS:
</span></pre>
<ul><li class="nobullet">
<a href="/hurricane/s_indian/2012/HILWA/track.dat">
<img src="/hurricane/images/DETAILS.gif" border="0" alt="Details"/>Tracking information</a><br/></li></ul>
</td></tr>

<tr><td valign="top">
<a href="/hurricane/s_indian/2012/GIOVANNA/track.gif">
  <img src="/hurricane/s_indian/2012/GIOVANNA/track_s.gif" border="0" alt="Track"/></a><br/>

  <b>Current: <a href="/hurricane/s_indian/2012/GIOVANNA/track.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Track"/>Track</a> 
</b><br/>
</td><td>
<ul><li><b>Cyclone-4 GIOVANNA</b> (09-21 FEB)<br/>
Storm - Max Winds: 125 Category: 4<br/>
Current - Max Winds: 30 Category: TD<br/>
</li></ul>
<pre><span style="font-size:x-small;">

   WARNING POSITION:
   210000Z --- NEAR 23.4S 52.6E
     MOVEMENT PAST SIX HOURS - 345 DEGREES AT 07 KTS
     POSITION ACCURATE TO WITHIN 045 NM
     POSITION BASED ON CENTER LOCATED BY SATELLITE
   PRESENT WIND DISTRIBUTION:
   MAX SUSTAINED WINDS - 030 KT, GUSTS 040 KT
   WIND RADII VALID OVER OPEN WATER ONLY
   DISSIPATED AS A SIGNIFICANT TROPICAL CYCLONE OVER WATER
   REPEAT POSIT: 23.4S 52.6E
    ---
   FORECASTS:
</span></pre>
<ul><li class="nobullet">
<a href="/hurricane/s_indian/2012/GIOVANNA/track.dat">
<img src="/hurricane/images/DETAILS.gif" border="0" alt="Details"/>Tracking information</a><br/></li></ul>
</td></tr>

<tr><td valign="top">
<a href="/hurricane/s_indian/2012/IGGY/track.gif">
  <img src="/hurricane/s_indian/2012/IGGY/track_s.gif" border="0" alt="Track"/></a><br/>

  <b>Current: <a href="/hurricane/s_indian/2012/IGGY/track.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Track"/>Track</a> 
</b><br/>
</td><td>
<ul><li><b>Cyclone-1 IGGY</b> (25 JAN-02 FEB)<br/>
Storm - Max Winds: 65 Category: 1<br/>
Current - Max Winds: 30 Category: TD<br/>
</li></ul>
<pre><span style="font-size:x-small;">

   WARNING POSITION:
   021200Z --- NEAR 29.9S 113.5E
     MOVEMENT PAST SIX HOURS - 095 DEGREES AT 14 KTS
     POSITION ACCURATE TO WITHIN 030 NM
     POSITION BASED ON CENTER LOCATED BY SATELLITE
   PRESENT WIND DISTRIBUTION:
   MAX SUSTAINED WINDS - 030 KT, GUSTS 040 KT
   WIND RADII VALID OVER OPEN WATER ONLY
   DISSIPATED AS A SIGNIFICANT TROPICAL CYCLONE OVER WATER
   REPEAT POSIT: 29.9S 113.5E
    ---
   FORECASTS:
</span></pre>
<ul><li class="nobullet">
<a href="/hurricane/s_indian/2012/IGGY/track.dat">
<img src="/hurricane/images/DETAILS.gif" border="0" alt="Details"/>Tracking information</a><br/></li></ul>
</td></tr>

<tr><td valign="top">
<a href="/hurricane/s_indian/2012/FUNSO/track.gif">
  <img src="/hurricane/s_indian/2012/FUNSO/track_s.gif" border="0" alt="Track"/></a><br/>

  <b>Current: <a href="/hurricane/s_indian/2012/FUNSO/track.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Track"/>Track</a> 
</b><br/>
</td><td>
<ul><li><b>Cyclone-4 FUNSO</b> (19-28 JAN)<br/>
Storm - Max Winds: 120 Category: 4<br/>
Current - Max Winds: 35 Category: TS<br/>
</li></ul>
<pre><span style="font-size:x-small;">

   WARNING POSITION:
   281800Z --- NEAR 31.0S 43.3E
     MOVEMENT PAST SIX HOURS - 140 DEGREES AT 17 KTS
     POSITION ACCURATE TO WITHIN 040 NM
     POSITION BASED ON CENTER LOCATED BY SATELLITE
   PRESENT WIND DISTRIBUTION:
   MAX SUSTAINED WINDS - 035 KT, GUSTS 045 KT
   WIND RADII VALID OVER OPEN WATER ONLY
   BECOMING EXTRATROPICAL
   REPEAT POSIT: 31.0S 43.3E
    ---
   FORECASTS:
</span></pre>
<ul><li class="nobullet">
<a href="/hurricane/s_indian/2012/FUNSO/track.dat">
<img src="/hurricane/images/DETAILS.gif" border="0" alt="Details"/>Tracking information</a><br/></li></ul>
</td></tr>

<tr><td valign="top">
<a href="/hurricane/s_indian/2012/ETHEL/track.gif">
  <img src="/hurricane/s_indian/2012/ETHEL/track_s.gif" border="0" alt="Track"/></a><br/>

  <b>Current: <a href="/hurricane/s_indian/2012/ETHEL/track.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Track"/>Track</a> 
</b><br/>
</td><td>
<ul><li><b>Cyclone-1 ETHEL</b> (19-22 JAN)<br/>
Storm - Max Winds: 75 Category: 1<br/>
Current - Max Winds: 45 Category: TS<br/>
</li></ul>
<pre><span style="font-size:x-small;">

   WARNING POSITION:
   221200Z --- NEAR 28.1S 65.4E
     MOVEMENT PAST SIX HOURS - 160 DEGREES AT 20 KTS
     POSITION ACCURATE TO WITHIN 060 NM
     POSITION BASED ON CENTER LOCATED BY SATELLITE
   PRESENT WIND DISTRIBUTION:
   MAX SUSTAINED WINDS - 045 KT, GUSTS 055 KT
   WIND RADII VALID OVER OPEN WATER ONLY
   EXTRATROPICAL
   REPEAT POSIT: 28.1S 65.4E
    ---
   FORECASTS:
</span></pre>
<ul><li class="nobullet">
<a href="/hurricane/s_indian/2012/ETHEL/track.dat">
<img src="/hurricane/images/DETAILS.gif" border="0" alt="Details"/>Tracking information</a><br/></li></ul>
</td></tr>

<tr><td valign="top">
<a href="/hurricane/s_indian/2012/HEIDI/track.gif">
  <img src="/hurricane/s_indian/2012/HEIDI/track_s.gif" border="0" alt="Track"/></a><br/>

  <b>Current: <a href="/hurricane/s_indian/2012/HEIDI/track.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Track"/>Track</a> 
</b><br/>
</td><td>
<ul><li><b>Tropical Storm HEIDI</b> (10-11 JAN)<br/>
Storm - Max Winds: 55 Category: TS<br/>
Current - Max Winds: 45 Category: TS<br/>
</li></ul>
<pre><span style="font-size:x-small;">

   WARNING POSITION:
   111800Z --- NEAR 20.1S 118.7E
     MOVEMENT PAST SIX HOURS - 200 DEGREES AT 05 KTS
     POSITION ACCURATE TO WITHIN 020 NM
     POSITION BASED ON CENTER LOCATED BY A COMBINATION OF
     SATELLITE AND RADAR
   PRESENT WIND DISTRIBUTION:
   MAX SUSTAINED WINDS - 045 KT, GUSTS 055 KT
   WIND RADII VALID OVER OPEN WATER ONLY
   RADIUS OF 034 KT WINDS - 050 NM NORTHEAST QUADRANT
                            050 NM SOUTHEAST QUADRANT
                            050 NM SOUTHWEST QUADRANT
                            050 NM NORTHWEST QUADRANT
   REPEAT POSIT: 20.1S 118.7E
    ---
   FORECASTS:
</span></pre>
<ul><li class="nobullet">
<a href="/hurricane/s_indian/2012/HEIDI/track.dat">
<img src="/hurricane/images/DETAILS.gif" border="0" alt="Details"/>Tracking information</a><br/></li></ul>
</td></tr>

<tr><td valign="top">
<a href="/hurricane/s_indian/2012/CHANDA/track.gif">
  <img src="/hurricane/s_indian/2012/CHANDA/track_s.gif" border="0" alt="Track"/></a><br/>

  <b>Current: <a href="/hurricane/s_indian/2012/CHANDA/track.gif">
      <img src="/hurricane/images/GIF.gif" border="0" alt="Track"/>Track</a> 
</b><br/>
</td><td>
<ul><li><b>Tropical Storm CHANDA</b> (07-08 JAN)<br/>
Storm - Max Winds: 35 Category: TS<br/>
Current - Max Winds: 35 Category: TS<br/>
</li></ul>
<pre><span style="font-size:x-small;">

   WARNING POSITION:
   081800Z --- NEAR 20.3S 43.8E
     MOVEMENT PAST SIX HOURS - 130 DEGREES AT 06 KTS
     POSITION ACCURATE TO WITHIN 060 NM
     POSITION BASED ON CENTER LOCATED BY SATELLITE
   PRESENT WIND DISTRIBUTION:
   MAX SUSTAINED WINDS - 035 KT, GUSTS 045 KT
   WIND RADII VALID OVER OPEN WATER ONLY
   DISSIPATING AS A SIGNIFICANT TROPICAL CYCLONE OVER WATER
   REPEAT POSIT: 20.3S 43.8E
    ---
   FORECASTS:
</span></pre>
<ul><li class="nobullet">
<a href="/hurricane/s_indian/2012/CHANDA/track.dat">
<img src="/hurricane/images/DETAILS.gif" border="0" alt="Details"/>Tracking information</a><br/></li></ul>
</td></tr>

<tr><td valign="top">
<a href="/hurricane/s_indian/2012/BENILDE/track.gif">
  <img src="/hurricane/s_indian/2012/BENILDE/track_s.gif" border="0" alt="Track"/></a>
</td><td>
<ul><li><b>Cyclone-2 BENILDE</b> (28 DEC-04 JAN)<br/>
Storm - Max Winds: 85 Category: 2<br/>
</li></ul>
<ul><li class="nobullet">
<a href="/hurricane/s_indian/2012/BENILDE/track.dat">
<img src="/hurricane/images/DETAILS.gif" border="0" alt="Details"/>Tracking information</a><br/></li></ul>
</td></tr>

</table>
<div class="clearboth">&nbsp;</div>

</div>

<div id="footer"> <span id="copyright"><small>Copyright &copy; Unisys 2012</small></span>
  <ul class="inline-navigation-list" id="bottom-navigation">
    <li><a href="http://www.unisys.com/unisys/privacy.html" target="_blank">Privacy Notice</a></li>
    <li><a href="http://www.unisys.com/unisys/terms-and-conditions.html" target="_blank">Terms of Use</a></li>
    <li><a href="/contactus.php">Contact Us</a></li>
    <li><a href="http://www.unisys.com/unisys/trademarks.html" target="_blank">Trademarks</a></li>
  </ul>
</div>
</div>
</body>
</html>
