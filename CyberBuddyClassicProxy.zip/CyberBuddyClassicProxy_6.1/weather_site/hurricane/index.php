<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Unisys Weather  - Hurricane / Tropical Data</title>
<meta name="description" content="The intent of this weather site is to provide a complete source of graphical weather 		information. This is intended to satisfy the needs of the weather professional, but can be a tool for the casual user as well. The graphics and data are displayed as a meteorologist would expect to see. For the novice user, there are detailed explanation pages to guide them through the various plots, charts and images. The data on this site are provided from the National Weather Service via the NOAAPORT satellite data service. All the images are generated using the Weather Processor (WXP) analysis package which is available from Unisys. "/>
<meta name="keywords" content="weather, unisys, unisys weather, weather maps, maps, nam, wrf, GFS, GFSx, hurricane, radar, satellite, surface, upper air" />
<meta name="copyright" content="Unisys Corp - 2011" />
<meta name="author" content="Unisys Corporation" />
<meta name="email" content="technical-support@weather.unisys.com" />
<meta name="Distribution" content="Global" />
<meta name="Rating" content="General" />
<meta name="Robots" content="INDEX,FOLLOW" />
<meta name="Revisit-after" content="7 Days" />
<meta http-equiv="Content-type" content="text/html;charset=UTF-8" />
<meta http-equiv="imagetoolbar" content="no" />
<meta http-equiv="Refresh" content="900" />
<meta http-equiv="X-UA-Compatible" content="IE=8"/>
<link rel="stylesheet" type="text/css" href="/css/WMAX.css" />
</head>
<body>
<div id="wrap">
  <div id="top-menu">
    <ul id="top-navigation" class="inline-navigation-list">
      <li><a href="http://www.unisys.com" title="Unisys Home Page">Unisys.com</a></li>
      <li><a href="/index.php" title="Unisys Weather">Weather Home</a></li>
      <li><a href="/analyses.php" title="Analyses">Analyses</a></li>
      <li><a href="/forehome.php" title="Forecast">Forecasts</a></li>
      <li><a href="/archives.php" title="Archives">Archives</a></li>
      <li><a href="/links.php" title="NOAA Links">NOAA Links</a></li>
      <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
    </ul>
  </div>

  <div id="header"> <a href="http://unisys.com"><img src="/images/Unisys_logo.gif" alt="Unisys" /></a>
    <h1>Unisys Weather</h1>
  </div>

<div id="leftside">
  <ul class="avmenu">
    <li><a href="/index.php" class="purple">Unisys Weather</a></li>
    <li><a href="/index.php"> Weather Home</a></li>
    <li><a href="/solutions/index.php">Weather Solutions</a></li>
    <li><a href="/mobile/index.php"><img id="mobile_icon" src="/mobile/Icon.png" width="24" height="24" alt="Download Unisys Weather Mobile App"/>iPhone App</a></li>
    <li><a href="/info/index.php">Information</a></li>
    <li><a href="/content.php">Contents</a></li>
    <li><a href="/analyses.php" class="purple">Analyses</a></li>
    <li><a href="/satellite/index.php">Satellite Images</a></li>
    <li><a href="/surface/index.php">Surface Data</a></li>
    <li><a href="/upper_air/index.php">Upper Air Data</a></li>
    <li><a href="/radar/index.php">Radar Data</a></li>
    <li><a href="/forehome.php" class="purple">Forecasts</a></li>
    <li><a href="/mos/index.php">Model Statistics</a></li>
    <li><a href="/nam/index.php">NAM/Wrf Model</a></li>
    <li><a href="/gfs/index.php?r=us">GFS/Avn Model</a></li>
    <li><a href="/gfsx/index.php?r=us">GFSx/MRF Model</a></li>
    <li><a href="/rap/index.php">RAP Model</a></li>
    <li><a href="/ecmwf/index.php">ECMWF Model</a></li>
    <li><a href="/archives.php" class="purple">Archive</a></li>
    <li><a href="/hurricane/index.php">Hurricane Data</a></li>
    <li><a href="/archive/index.php">Archive of Images</a></li>
    <li><a href="/usgs/index.php">USGS Maps</a></li>
  </ul>
</div>

<div id="extras">
  <ul class="avmenu">
    <li><a href="/foresetup.php" class="purple">Get a Forecast</a></li>
  </ul>

<script type="text/javascript">
function fsubmit()
{
     document.getElementById("Forecast").submit();
}
</script>

  <form method="get" id="Forecast" action="/forecast.php">
    <p class="center"> Enter a zip code or city name to get forecast:
      <input type="text" name="Name" id="Name" size="15" />
      <br />
      <button type="submit" style="border:none; background-color:transparent;">
         <img src="/images/GO.png" id="Go" alt="Get Forecast Data" style="height:30px;" />
      </button>
      <a href="/foresetup.php"><img src="/images/setup.png" alt="Setup Location" height="30" width="70" /></a> </p>
  </form>
  <script type="text/javascript">
                <!-- HIDE
                var index = document.cookie.indexOf("ZIP")
                var zipcode = 0
                var region = ""
                if( index != -1 ){
                   //zipcode = parseInt( document.cookie.substring(index+4,index+9),10)
                   zipcode = document.cookie.substring(index+4,index+9)
                   var validateZipCode = function() {
                     var zipcodeRegexp = /^\d{5}$/;
                     var zipTest = zipcodeRegexp.test(zipcode);
   
                     if (zipTest == false) {
                       return false;
                     }
                   }
                   validateZipCode();

                    if( ! isNaN(zipcode))

                    document.getElementById('Name').value = zipcode

                   if( zipcode >= 01000 && zipcode <= 19699 )
                      region = "ne"
                   else if( zipcode >= 19700 && zipcode <= 28999 )
                      region = "at"
                   else if( zipcode >= 43000 && zipcode <= 45999 )
                      region = "at"
                   else if( zipcode >= 29000 && zipcode <= 36999 )
                      region = "se"
                   else if( zipcode >= 38600 && zipcode <= 39999 )
                      region = "se"
                   else if( zipcode >= 46000 && zipcode <= 58999 )
                      region = "mw"
                   else if( zipcode >= 60000 && zipcode <= 62999 )
                      region = "mw"
                   else if( zipcode >= 68000 && zipcode <= 69999 )
                      region = "mw"
                   else if( zipcode >= 63000 && zipcode <= 67999 )
                      region = "cp"
                   else if( zipcode >= 71600 && zipcode <= 74999 )
                      region = "cp"
                   else if( zipcode >= 70000 && zipcode <= 71499 )
                      region = "sp"
                   else if( zipcode >= 75000 && zipcode <= 79999 )
                      region = "sp"
                   else if( zipcode >= 59000 && zipcode <= 59999 )
                      region = "nw"
                   else if( zipcode >= 82000 && zipcode <= 83999 )
                      region = "nw"
                   else if( zipcode >= 97000 && zipcode <= 99499 )
                      region = "nw"
                   else if( zipcode >= 80000 && zipcode <= 81999 )
                      region = "sw"
                   else if( zipcode >= 84000 && zipcode <= 96199 )
                      region = "sw"

                   if( region != "" ){
                      document.write( "<table border=\"0\" align=\"center\" class=\"grey\" width=\"100%\">" )
                      document.write( "<tr>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/surface/sfc_map.php?image=sfc&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Sfc" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=\"radar/rad" + region + ".php\">" )
                      document.write( "<a href=/radar/rcm_rad.php?image=rad&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Rad" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=vis&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>Vis" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "<td valign=\"top\">" )
                      document.write( "<a href=/satellite/sat_vis.php?image=enh&inv=0&t=cur&region=" + region +">" )
                      document.write( "<b>IR" )
                      document.write( "</b></a>" )
                      document.write( "</td>" )
                      document.write( "</tr></table>" )
                      document.write( "</b>" )
                      }


                   
                   }
                // UNHIDE -->
                </script>
  <ul class="avmenu">
    <li><a href="/links.php" class="purple">NOAA Links</a></li>
    <li><a href="http://lwf.ncdc.noaa.gov/">National Climatic Data Center</a></li>
    <li><a href="http://www.cpc.noaa.gov/">Climate Prediction Center</a></li>
    <li><a href="http://oceanservice.noaa.gov/">National Ocean Service</a></li>
    <li><a href="http://www.lib.noaa.gov/">NOAA Library</a></li>
    <li><a href="http://www.oar.noaa.gov/">NOAA Office of Oceanic and Atmospheric Research</a></li>
    <li><a href="http://www.esrl.noaa.gov/">Earth Systems Research Laboratory</a></li>
    <li><a href="/overview.php" class="purple">About Us</a></li>
    <li><a href="/overview.php" title="Contact Us">Overview</a></li>
    <li><a href="/contactus.php" title="Contact Us">Contact Us</a></li>
  </ul>
</div>
<div id="content">

<h2>Hurricane/Tropical Data</h2>
<p>
This page provides access to a wealth of hurricane information including charts on the track of the storm plus a text based table of tracking information. The table includes position in latitude and longitude, maximum sustained winds in knots, and central pressure in millibars.</p>

<table>
  <tr>
    <th width="33%"><a href="/hurricane/atlantic/index.php">Atlantic</a></th>
    <th width="33%"><a href="/hurricane/e_pacific/index.php">East Pacific</a></th>
    <th width="33%"><a href="/hurricane/w_pacific/index.php">West Pacific</a></th>
  </tr>  
  <tr>
    <td width="33%" valign="top">
      <b>From TPC Advisories:<br/>
      <a href="/hurricane/atlantic/2013/index.php">2013</a><br/>
      <a href="/hurricane/atlantic/2012/index.php">2012</a><br/>
      <a href="/hurricane/atlantic/2011H/index.php">2011</a><br/>
      <a href="/hurricane/atlantic/2010H/index.php">2010</a><br/>
      <a href="/hurricane/atlantic/2009H/index.php">2009</a><br/>
      <a href="/hurricane/atlantic/2008H/index.php">2008</a><br/>
      <a href="/hurricane/atlantic/2007H/index.php">2007</a><br/>
      <a href="/hurricane/atlantic/2006H/index.php">2006</a><br/>
      <a href="/hurricane/atlantic/2005H/index.php">2005</a><br/>
      <a href="/hurricane/atlantic/2004H/index.php">2004</a><br/>
      <a href="/hurricane/atlantic/2003H/index.php">2003</a><br/>
      <a href="/hurricane/atlantic/2002H/index.php">2002</a><br/>
      <a href="/hurricane/atlantic/2001H/index.php">2001</a><br/>
      <a href="/hurricane/atlantic/2000H/index.php">2000</a><br/>
      <a href="/hurricane/atlantic/1999H/index.php">1999</a><br/>
      <a href="/hurricane/atlantic/1998H/index.php">1998</a><br/>
      <a href="/hurricane/atlantic/1997H/index.php">1997</a><br/>
      <a href="/hurricane/atlantic/1996H/index.php">1996</a><br/>
      <a href="/hurricane/atlantic/1995H/index.php">1995</a></b>
    </td>
    <td width="33%" valign="top">
      <b>From TPC Advisories:<br/>
      <a href="/hurricane/e_pacific/2013/index.php">2013</a><br/>
      <a href="/hurricane/e_pacific/2012/index.php">2012</a><br/>
      <a href="/hurricane/e_pacific/2011H/index.php">2011</a><br/>
      <a href="/hurricane/e_pacific/2010H/index.php">2010</a><br/>
      <a href="/hurricane/e_pacific/2009H/index.php">2009</a><br/>
      <a href="/hurricane/e_pacific/2008H/index.php">2008</a><br/>
      <a href="/hurricane/e_pacific/2007H/index.php">2007</a><br/>
      <a href="/hurricane/e_pacific/2006H/index.php">2006</a><br/>
      <a href="/hurricane/e_pacific/2005H/index.php">2005</a><br/>
      <a href="/hurricane/e_pacific/2004H/index.php">2004</a><br/>
      <a href="/hurricane/e_pacific/2003H/index.php">2003</a><br/>
      <a href="/hurricane/e_pacific/2002H/index.php">2002</a><br/>
      <a href="/hurricane/e_pacific/2001H/index.php">2001</a><br/>
      <a href="/hurricane/e_pacific/2000H/index.php">2000</a><br/>
      <a href="/hurricane/e_pacific/1999H/index.php">1999</a><br/>
      <a href="/hurricane/e_pacific/1998H/index.php">1998</a><br/>
      <a href="/hurricane/e_pacific/1997H/index.php">1997</a></b>
    </td>
    <td width="33%" valign="top">
      <b>From JTWC Advisories:<br/>
      <a href="/hurricane/w_pacific/2013/index.php">2013</a><br/>
      <a href="/hurricane/w_pacific/2012/index.php">2012</a><br/>
      <a href="/hurricane/w_pacific/2011H/index.php">2011</a><br/>
      <a href="/hurricane/w_pacific/2010H/index.php">2010</a><br/>
      <a href="/hurricane/w_pacific/2009H/index.php">2009</a><br/>
      <a href="/hurricane/w_pacific/2008H/index.php">2008</a><br/>
      <a href="/hurricane/w_pacific/2007H/index.php">2007</a><br/>
      <a href="/hurricane/w_pacific/2006H/index.php">2006</a><br/>
      <a href="/hurricane/w_pacific/2005H/index.php">2005</a><br/>
      <a href="/hurricane/w_pacific/2004H/index.php">2004</a><br/>
      <a href="/hurricane/w_pacific/2003H/index.php">2003</a><br/>
      <a href="/hurricane/w_pacific/2002H/index.php">2002</a><br/>
      <a href="/hurricane/w_pacific/2001H/index.php">2001</a><br/>
      <a href="/hurricane/w_pacific/2000H/index.php">2000</a><br/>
      <a href="/hurricane/w_pacific/1999H/index.php">1999</a><br/>
      <a href="/hurricane/w_pacific/1998H/index.php">1998</a><br/>
      <a href="/hurricane/w_pacific/1997H/index.php">1997</a><br/>
      <a href="/hurricane/w_pacific/1996H/index.php">1996</a></b>
    </td>
  </tr>
  <tr>
    <td width="33%"  >
      <a href="/hurricane/atlantic/index.php">Best Track: 1851-2011</a><br/>
      <a href="/hurricane/atlantic/atl_names.php">Storm names</a><br/>
      <a href="/hurricane/atlantic/classic.php">Classic Hurricanes</a>
    </td>
    <td width="33%"  >
      <a href="/hurricane/e_pacific/index.php">Best Track: 1949-2011</a><br/>
      <a href="/hurricane/e_pacific/pac-e_names.php">Storm names</a><br/>
      &nbsp;
    </td>
    <td width="33%"  >
      <a href="/hurricane/w_pacific/index.php">Best Track: 1945-2011</a><br/>
      &nbsp;<br/>
      &nbsp;
    </td>
  </tr>
  <tr>
    <th width="33%"><a href="/hurricane/s_pacific/index.php">South Pacific</a></th>
    <th width="33%"><a href="/hurricane/s_indian/index.php">South Indian</a></th>
    <th width="33%"><a href="/hurricane/n_indian/index.php">North Indian</a></th>
  </tr>
  <tr>
    <td width="33%"  >
      <b>From JTWC Advisories:<br/>
      <a href="/hurricane/s_pacific/2013/index.php">2013</a><br/>
      <a href="/hurricane/s_pacific/2012/index.php">2012</a><br/>
      <a href="/hurricane/s_pacific/2011/index.php">2011</a><br/>
      <a href="/hurricane/s_pacific/2010/index.php">2010</a><br/>
      <a href="/hurricane/s_pacific/2009/index.php">2009</a><br/>
      <a href="/hurricane/s_pacific/2008/index.php">2008</a><br/>
      <a href="/hurricane/s_pacific/2007/index.php">2007</a><br/>
      <a href="/hurricane/s_pacific/2006/index.php">2006</a><br/>
      <a href="/hurricane/s_pacific/2005/index.php">2005</a><br/>
      <a href="/hurricane/s_pacific/2004/index.php">2004</a><br/>
      <a href="/hurricane/s_pacific/2003/index.php">2003</a><br/>
      <a href="/hurricane/s_pacific/2002/index.php">2002</a><br/>
      <a href="/hurricane/s_pacific/2001/index.php">2001</a><br/>
      <a href="/hurricane/s_pacific/2000/index.php">2000</a></b>
    </td>
    <td width="33%"  >
      <b>From JTWC Advisories:<br/>
      <a href="/hurricane/s_indian/2013/index.php">2013</a><br/>
      <a href="/hurricane/s_indian/2012/index.php">2012</a><br/>
      <a href="/hurricane/s_indian/2011H/index.php">2011</a><br/>
      <a href="/hurricane/s_indian/2010H/index.php">2010</a><br/>
      <a href="/hurricane/s_indian/2009H/index.php">2009</a><br/>
      <a href="/hurricane/s_indian/2008H/index.php">2008</a><br/>
      <a href="/hurricane/s_indian/2007H/index.php">2007</a><br/>
      <a href="/hurricane/s_indian/2006H/index.php">2006</a><br/>
      <a href="/hurricane/s_indian/2005H/index.php">2005</a><br/>
      <a href="/hurricane/s_indian/2004H/index.php">2004</a><br/>
      <a href="/hurricane/s_indian/2003H/index.php">2003</a><br/>
      <a href="/hurricane/s_indian/2002H/index.php">2002</a><br/>
      <a href="/hurricane/s_indian/2001H/index.php">2001</a><br/>
      <a href="/hurricane/s_indian/2000H/index.php">2000</a></b>
    </td>
    <td width="33%">
      <b>From JTWC Advisories:<br/>
      <a href="/hurricane/n_indian/2013/index.php">2013</a><br/>
      <a href="/hurricane/n_indian/2012/index.php">2012</a><br/>
      <a href="/hurricane/n_indian/2011H/index.php">2011</a><br/>
      <a href="/hurricane/n_indian/2010H/index.php">2010</a><br/>
      <a href="/hurricane/n_indian/2009H/index.php">2009</a><br/>
      <a href="/hurricane/n_indian/2008H/index.php">2008</a><br/>
      <a href="/hurricane/n_indian/2007H/index.php">2007</a><br/>
      <a href="/hurricane/n_indian/2006H/index.php">2006</a><br/>
      <a href="/hurricane/n_indian/2005H/index.php">2005</a><br/>
      <a href="/hurricane/n_indian/2004H/index.php">2004</a><br/>
      <a href="/hurricane/n_indian/2003H/index.php">2003</a><br/>
      <a href="/hurricane/n_indian/2002H/index.php">2002</a><br/>
      <a href="/hurricane/n_indian/2001H/index.php">2001</a><br/>
      <a href="/hurricane/n_indian/2000H/index.php">2000</a></b>
    </td>
  </tr>
  <tr>
    <td width="33%">
    </td>
    <td width="33%">
      <a href="/hurricane/s_indian/index.php">Best Track: 1949-2011</a>
    </td>
    <td width="33%">
      <a href="/hurricane/n_indian/index.php">Best Track: 1945-2011</a>
    </td>
  </tr>
</table>

<h3>Current Tropical Satellite Images</h3>

<table >
  <tr>
    <td width="25%" >
      <b>Atlantic</b>
    </td>
    <td width="25%" >
      <b><a href="/hurricane/sat_vis_a.gif">Visible</a></b>
    </td>
    <td width="25%" >
      <b><a href="/hurricane/sat_ir_a.gif">Infrared</a></b>
    </td>
    <td width="25%" >
      <b><a href="/hurricane/sat_wv_a.gif">Water Vapor</a></b>
    </td>
  </tr>
  <tr>
    <td width="25%" >
      <b>East Pacific</b>
    </td>
    <td width="25%" >
      <b><a href="/hurricane/sat_vis_p.gif">Visible</a></b>
    </td>
    <td width="25%" >
      <b><a href="/hurricane/sat_ir_p.gif">Infrared</a></b>
    </td>
    <td width="25%" >
      <b><a href="/hurricane/sat_wv_p.gif">Water Vapor</a></b>
    </td>
  </tr>
</table>

<h3>Aviation Model Forecasts for the Atlantic</h3>

<table>
  <tr>
    <td >
      <b>Sea Level Pressure</b>
    </td>
    <td >
      <b><a href="/hurricane/slp_00.gif">Analysis</a></b>
    </td>
    <td >
      <b><a href="/hurricane/slp_12.gif">12 hour</a></b>
    </td>
    <td >
      <b><a href="/hurricane/slp_24.gif">24 hour</a></b>
    </td>
    <td >
      <b><a href="/hurricane/slp_36.gif">36 hour</a></b>
    </td>
    <td >
      <b><a href="/hurricane/slp_48.gif">48 hour</a></b>
    </td>
  </tr>
  <tr>
    <td >
      <b>500 mb Vorticity</b>
    </td>
    <td >
      <b><a href="/hurricane/5av_00.gif">Analysis</a></b>
    </td>
    <td >
      <b><a href="/hurricane/5av_12.gif">12 hour</a></b>
    </td>
    <td >
      <b><a href="/hurricane/5av_24.gif">24 hour</a></b>
    </td>
    <td >
      <b><a href="/hurricane/5av_36.gif">36 hour</a></b>
    </td>
    <td >
      <b><a href="/hurricane/5av_48.gif">48 hour</a></b>
    </td>
  </tr>
  <tr>
    <td >
      <b>300 mb Height</b>
    </td>
    <td >
      <b><a href="/hurricane/3hh_00.gif">Analysis</a></b>
    </td>
    <td >
      <b><a href="/hurricane/3hh_12.gif">12 hour</a></b>
    </td>
    <td >
      <b><a href="/hurricane/3hh_24.gif">24 hour</a></b>
    </td>
    <td >
      <b><a href="/hurricane/3hh_36.gif">36 hour</a></b>
    </td>
    <td >
      <b><a href="/hurricane/3hh_48.gif">48 hour</a></b>
    </td>
  </tr>
  <tr>
    <td >
      <b>300-850mb Shear Magnitude</b>
    </td>
    <td >
      <b><a href="/hurricane/shr_00.gif">Analysis</a></b>
    </td>
    <td >
      <b><a href="/hurricane/shr_12.gif">12 hour</a></b>
    </td>
    <td >
      <b><a href="/hurricane/shr_24.gif">24 hour</a></b>
    </td>
    <td >
      <b><a href="/hurricane/shr_36.gif">36 hour</a></b>
    </td>
    <td >
      <b><a href="/hurricane/shr_48.gif">48 hour</a></b>
    </td>
  </tr>
</table>

<h3>Tropical Advisory Archive</h3>

<p>
This is an archive of the TPC products, advisories and bulletins:
</p>
<p><b><a href="/hurricane/archive">Archive</a>
</b></p>

<hr width="99%"/>

<h3>Saffir-Simpson Scale</h3>
<p>
The chart color codes intensity (category based on Saffir-Simpson scale): 
</p>

<table  width="99%">
  <tr>
    <td ><b>Type</b></td>
    <td  align="center"><b>Category</b></td>
    <td  align="center"><b>Pressure (mb)</b></td>
    <td  align="center"><b>Winds<br/>(knots)</b></td>
    <td  align="center"><b>Winds<br/>(mph)</b></td>
    <td  align="center"><b>Line Color</b></td>
  </tr>
  <tr>
    <td ><b>Depression</b></td>
    <td  align="center">TD</td>
    <td  align="center">-----</td>
    <td  align="center">&lt; 34</td>
    <td  align="center">&lt; 39</td>
    <td  align="center">Green</td>
  </tr>
  <tr>
    <td ><b>Tropical Storm</b></td>
    <td  align="center">TS</td>
    <td  align="center">-----</td>
    <td  align="center">34-63</td>
    <td  align="center">39-73</td>
    <td  align="center">Yellow</td>
  </tr>
  <tr>
    <td ><b>Hurricane</b></td>
    <td  align="center">1</td>
    <td  align="center">&gt; 980</td>
    <td  align="center">64-82</td>
    <td  align="center">74-95</td>
    <td  align="center">Red</td>
  </tr>
  <tr>
    <td ><b>Hurricane</b></td>
    <td  align="center">2</td>
    <td  align="center">965-980</td>
    <td  align="center">83-95</td>
    <td  align="center">96-110</td>
    <td  align="center">Light Red</td>
  </tr>
  <tr>
    <td ><b>Hurricane</b></td>
    <td  align="center">3</td>
    <td  align="center">945-965</td>
    <td  align="center">96-113</td>
    <td  align="center">111-130</td>
    <td  align="center">Magenta</td>
  </tr>
  <tr>
    <td ><b>Hurricane</b></td>
    <td  align="center">4</td>
    <td  align="center">920-945</td>
    <td  align="center">114-135</td>
    <td  align="center">131-155</td>
    <td  align="center">Light Magenta</td>
  </tr>
  <tr>
    <td ><b>Hurricane</b></td>
    <td  align="center">5</td>
    <td  align="center">&lt; 920</td>
    <td  align="center">&gt; 135</td>
    <td  align="center">&gt; 155</td>
    <td  align="center">White</td>
  </tr>
</table>
<p><b>NOTE:</b>Pressures are in millibars and winds are in knots where one knot is equal to 1.15 mph.</p>
<div class="clearboth">&nbsp;</div>

</div>

<div id="footer"> <span id="copyright"><small>Copyright &copy; Unisys 2012</small></span>
  <ul class="inline-navigation-list" id="bottom-navigation">
    <li><a href="http://www.unisys.com/unisys/privacy.html" target="_blank">Privacy Notice</a></li>
    <li><a href="http://www.unisys.com/unisys/terms-and-conditions.html" target="_blank">Terms of Use</a></li>
    <li><a href="/contactus.php">Contact Us</a></li>
    <li><a href="http://www.unisys.com/unisys/trademarks.html" target="_blank">Trademarks</a></li>
  </ul>
</div>
</div>
</body>
</html>
