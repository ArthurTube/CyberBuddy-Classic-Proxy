@echo off
cd /d "%~dp0"
echo Keep the proxy running in another window.
echo.
powershell -NoProfile -Command "$r=Invoke-WebRequest -UseBasicParsing -Proxy http://127.0.0.1:8081 http://proxy.local/; $r.Content"
echo.
powershell -NoProfile -Command "$r=Invoke-WebRequest -UseBasicParsing -Proxy http://127.0.0.1:8081 http://g1.globo.com/rss/g1/; Write-Host ('RSS G1: HTTP '+[int]$r.StatusCode+' - '+$r.RawContentLength+' bytes')"
echo.
pause
