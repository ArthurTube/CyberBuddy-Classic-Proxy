CyberBuddy UIN Directory restoration

The directory now has 200 visible slots. Live users who use Publish My UIN are placed first. The supplied historical snapshot is used as the archive seed. The pasted snapshot contained 173 concrete rows; remaining slots are explicitly labeled archive placeholders rather than invented identities.
